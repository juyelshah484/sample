import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'users': {
        const users = await db.systemUser.findMany({ orderBy: { createdAt: 'desc' } })
        return NextResponse.json({ users })
      }
      case 'audit-logs': {
        const logs = await db.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 50 })
        return NextResponse.json({ logs })
      }
      default: {
        const users = await db.systemUser.findMany({ orderBy: { createdAt: 'desc' } })
        const logs = await db.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 30 })
        return NextResponse.json({ users, logs })
      }
    }
  } catch (error) {
    console.error('Security API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'user': return NextResponse.json({ item: await db.systemUser.create({ data }) })
      case 'audit-log': return NextResponse.json({ item: await db.auditLog.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Security POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'user': return NextResponse.json({ item: await db.systemUser.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Security PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'user': await db.systemUser.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Security DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
