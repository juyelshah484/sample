import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const type = searchParams.get('type')
    const isActive = searchParams.get('isActive')
    const code = searchParams.get('code')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (type) where.type = type
    if (isActive !== null) where.isActive = isActive === 'true'
    if (code) where.code = code

    const promotions = await db.promotion.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    // Add computed fields
    const now = new Date()
    const promotionsWithStatus = promotions.map(p => ({
      ...p,
      isExpired: new Date(p.endDate) < now,
      isCurrentlyActive: new Date(p.startDate) <= now && new Date(p.endDate) >= now && p.isActive,
      usageRemaining: p.usageLimit ? p.usageLimit - p.usedCount : null,
    }))

    return NextResponse.json({ promotions: promotionsWithStatus })
  } catch (error) {
    console.error('Promotions API error:', error)
    return NextResponse.json({ error: 'Failed to load promotions' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code || !body.hotelId || body.value === undefined || !body.startDate || !body.endDate) {
      return NextResponse.json(
        { error: 'Name, code, hotelId, value, startDate, and endDate are required' },
        { status: 400 }
      )
    }

    const validTypes = ['discount', 'coupon', 'package', 'corporate']
    if (body.type && !validTypes.includes(body.type)) {
      return NextResponse.json(
        { error: `Invalid type. Must be one of: ${validTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const validValueTypes = ['percentage', 'fixed']
    if (body.valueType && !validValueTypes.includes(body.valueType)) {
      return NextResponse.json(
        { error: `Invalid valueType. Must be one of: ${validValueTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const promotion = await db.promotion.create({
      data: {
        hotelId: body.hotelId,
        name: body.name,
        code: body.code,
        type: body.type ?? 'discount',
        value: body.value,
        valueType: body.valueType ?? 'percentage',
        startDate: new Date(body.startDate),
        endDate: new Date(body.endDate),
        minBooking: body.minBooking ?? 0,
        maxDiscount: body.maxDiscount,
        usageLimit: body.usageLimit,
        usedCount: 0,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ promotion }, { status: 201 })
  } catch (error) {
    console.error('Promotions POST error:', error)
    return NextResponse.json({ error: 'Failed to create promotion' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Promotion ID is required' }, { status: 400 })
    }

    const existing = await db.promotion.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Promotion not found' }, { status: 404 })
    }

    const promotion = await db.promotion.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        type: body.type,
        value: body.value,
        valueType: body.valueType,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : undefined,
        minBooking: body.minBooking,
        maxDiscount: body.maxDiscount,
        usageLimit: body.usageLimit,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ promotion })
  } catch (error) {
    console.error('Promotions PUT error:', error)
    return NextResponse.json({ error: 'Failed to update promotion' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Promotion ID is required' }, { status: 400 })
    }

    const existing = await db.promotion.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Promotion not found' }, { status: 404 })
    }

    await db.promotion.delete({ where: { id } })

    return NextResponse.json({ message: 'Promotion deleted successfully' })
  } catch (error) {
    console.error('Promotions DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete promotion' }, { status: 500 })
  }
}
