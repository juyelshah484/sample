import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'folios': {
        const folios = await db.folio.findMany({
          include: { reservation: { include: { guest: true } }, folioItems: true, payments: true },
          orderBy: { createdAt: 'desc' },
        })
        return NextResponse.json({ folios })
      }
      case 'payments': {
        const payments = await db.payment.findMany({
          include: { reservation: { include: { guest: true } } },
          orderBy: { createdAt: 'desc' },
        })
        return NextResponse.json({ payments })
      }
      default: {
        const folios = await db.folio.findMany({
          include: { reservation: { include: { guest: true } }, folioItems: true, payments: true },
          orderBy: { createdAt: 'desc' }, take: 30,
        })
        const payments = await db.payment.findMany({
          include: { reservation: { include: { guest: true } } },
          orderBy: { createdAt: 'desc' }, take: 30,
        })
        return NextResponse.json({ folios, payments })
      }
    }
  } catch (error) {
    console.error('Billing API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'folio': return NextResponse.json({ item: await db.folio.create({ data }) })
      case 'folio-item': return NextResponse.json({ item: await db.folioItem.create({ data }) })
      case 'payment': return NextResponse.json({ item: await db.payment.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Billing POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'folio': return NextResponse.json({ item: await db.folio.update({ where: { id }, data }) })
      case 'payment': return NextResponse.json({ item: await db.payment.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Billing PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}
