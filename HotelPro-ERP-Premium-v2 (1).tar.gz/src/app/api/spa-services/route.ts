import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const category = searchParams.get('category')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (category) where.category = category
    if (isActive !== null) where.isActive = isActive === 'true'

    const spaServices = await db.spaService.findMany({
      where,
      include: {
        bookings: {
          include: { guest: true },
          orderBy: { dateTime: 'desc' },
        },
        _count: { select: { bookings: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ spaServices })
  } catch (error) {
    console.error('Spa Services API error:', error)
    return NextResponse.json({ error: 'Failed to load spa services' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.hotelId || body.duration === undefined || body.price === undefined) {
      return NextResponse.json(
        { error: 'Name, hotelId, duration, and price are required' },
        { status: 400 }
      )
    }

    const spaService = await db.spaService.create({
      data: {
        hotelId: body.hotelId,
        name: body.name,
        category: body.category ?? 'massage',
        duration: body.duration,
        price: body.price,
        description: body.description,
        isActive: body.isActive ?? true,
      },
    })

    // Create booking if provided
    if (body.booking) {
      await db.spaBooking.create({
        data: {
          serviceId: spaService.id,
          guestId: body.booking.guestId,
          therapistId: body.booking.therapistId,
          dateTime: new Date(body.booking.dateTime),
          status: body.booking.status ?? 'booked',
          notes: body.booking.notes,
        },
      })
    }

    const result = await db.spaService.findUnique({
      where: { id: spaService.id },
      include: { bookings: { include: { guest: true } } },
    })

    return NextResponse.json({ spaService: result }, { status: 201 })
  } catch (error) {
    console.error('Spa Services POST error:', error)
    return NextResponse.json({ error: 'Failed to create spa service' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Spa service ID is required' }, { status: 400 })
    }

    const existing = await db.spaService.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Spa service not found' }, { status: 404 })
    }

    const spaService = await db.spaService.update({
      where: { id: body.id },
      data: {
        name: body.name,
        category: body.category,
        duration: body.duration,
        price: body.price,
        description: body.description,
        isActive: body.isActive,
      },
      include: { bookings: true },
    })

    return NextResponse.json({ spaService })
  } catch (error) {
    console.error('Spa Services PUT error:', error)
    return NextResponse.json({ error: 'Failed to update spa service' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Spa service ID is required' }, { status: 400 })
    }

    const existing = await db.spaService.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Spa service not found' }, { status: 404 })
    }

    await db.spaBooking.deleteMany({ where: { serviceId: id } })
    await db.spaService.delete({ where: { id } })

    return NextResponse.json({ message: 'Spa service deleted successfully' })
  } catch (error) {
    console.error('Spa Services DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete spa service' }, { status: 500 })
  }
}
