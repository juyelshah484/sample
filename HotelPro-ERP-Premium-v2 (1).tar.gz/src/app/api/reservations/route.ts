import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const source = searchParams.get('source')
    const hotelId = searchParams.get('hotelId')
    const guestId = searchParams.get('guestId')
    const checkIn = searchParams.get('checkIn')
    const checkOut = searchParams.get('checkOut')

    const where: any = {}
    if (status) where.status = status
    if (source) where.bookingSource = source
    if (hotelId) where.hotelId = hotelId
    if (guestId) where.guestId = guestId
    if (checkIn || checkOut) {
      where.checkInDate = {}
      if (checkIn) where.checkInDate.gte = new Date(checkIn)
      if (checkOut) where.checkInDate.lte = new Date(checkOut)
    }

    const reservations = await db.reservation.findMany({
      where,
      include: {
        guest: true,
        rooms: { include: { room: { include: { roomType: true } } } },
        payments: true,
        folios: { include: { folioItems: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    const stats = {
      total: reservations.length,
      confirmed: reservations.filter(r => r.status === 'confirmed').length,
      checkedIn: reservations.filter(r => r.status === 'checked_in').length,
      checkedOut: reservations.filter(r => r.status === 'checked_out').length,
      cancelled: reservations.filter(r => r.status === 'cancelled').length,
      noShow: reservations.filter(r => r.status === 'no_show').length,
    }

    return NextResponse.json({ reservations, stats })
  } catch (error) {
    console.error('Reservations API error:', error)
    return NextResponse.json({ error: 'Failed to load reservations' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.guestId || !body.checkInDate || !body.checkOutDate) {
      return NextResponse.json(
        { error: 'HotelId, guestId, checkInDate, and checkOutDate are required' },
        { status: 400 }
      )
    }

    if (!body.rooms || !Array.isArray(body.rooms) || body.rooms.length === 0) {
      return NextResponse.json(
        { error: 'At least one room with roomId and rate is required' },
        { status: 400 }
      )
    }

    const validStatuses = ['confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show', 'waitlisted']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    // Generate confirmation code
    const reservationCount = await db.reservation.count()
    const confirmationCode = `RES-${String(reservationCount + 1).padStart(6, '0')}`

    // Calculate total amount from rooms
    let totalAmount = 0
    for (const room of body.rooms) {
      const checkIn = new Date(body.checkInDate)
      const checkOut = new Date(body.checkOutDate)
      const nights = Math.max(1, Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)))
      totalAmount += room.rate * nights
    }

    const reservation = await db.reservation.create({
      data: {
        hotelId: body.hotelId,
        guestId: body.guestId,
        confirmationCode,
        bookingSource: body.bookingSource ?? 'direct',
        otaReference: body.otaReference,
        status: body.status ?? 'confirmed',
        checkInDate: new Date(body.checkInDate),
        checkOutDate: new Date(body.checkOutDate),
        numberOfGuests: body.numberOfGuests ?? 1,
        numberOfRooms: body.rooms.length,
        specialRequests: body.specialRequests,
        notes: body.notes,
        totalAmount,
        paidAmount: 0,
        discount: body.discount ?? 0,
        taxAmount: body.taxAmount ?? totalAmount * 0.15,
        rooms: {
          create: body.rooms.map((room: any) => ({
            roomId: room.roomId,
            checkInDate: new Date(body.checkInDate),
            checkOutDate: new Date(body.checkOutDate),
            rate: room.rate,
            status: 'reserved',
          })),
        },
      },
      include: {
        guest: true,
        rooms: { include: { room: { include: { roomType: true } } } },
      },
    })

    // Create a folio for the reservation
    const folioCount = await db.folio.count()
    const folioNumber = `FOL-${String(folioCount + 1).padStart(6, '0')}`
    await db.folio.create({
      data: {
        reservationId: reservation.id,
        guestId: body.guestId,
        hotelId: body.hotelId,
        folioNumber,
        status: 'open',
        totalAmount,
        paidAmount: 0,
        balance: totalAmount,
      },
    })

    return NextResponse.json({ reservation }, { status: 201 })
  } catch (error) {
    console.error('Reservations POST error:', error)
    return NextResponse.json({ error: 'Failed to create reservation' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Reservation ID is required' }, { status: 400 })
    }

    const existing = await db.reservation.findUnique({
      where: { id: body.id },
      include: { rooms: true },
    })
    if (!existing) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 })
    }

    // Validate status transitions
    const validStatuses = ['confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show', 'waitlisted']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    // Check-in logic
    if (body.status === 'checked_in' && existing.status === 'confirmed') {
      // Update room statuses to occupied
      for (const resRoom of existing.rooms) {
        await db.room.update({
          where: { id: resRoom.roomId },
          data: { status: 'occupied' },
        })
        await db.reservationRoom.update({
          where: { id: resRoom.id },
          data: { status: 'checked_in' },
        })
      }
    }

    // Check-out logic
    if (body.status === 'checked_out' && existing.status === 'checked_in') {
      // Update room statuses to available
      for (const resRoom of existing.rooms) {
        await db.room.update({
          where: { id: resRoom.roomId },
          data: { status: 'available' },
        })
        await db.reservationRoom.update({
          where: { id: resRoom.id },
          data: { status: 'checked_out' },
        })
      }

      // Close folios
      await db.folio.updateMany({
        where: { reservationId: body.id },
        data: { status: 'closed' },
      })
    }

    // Cancel logic
    if (body.status === 'cancelled') {
      // Release rooms back to available
      for (const resRoom of existing.rooms) {
        if (resRoom.status === 'checked_in') {
          await db.room.update({
            where: { id: resRoom.roomId },
            data: { status: 'available' },
          })
        }
        await db.reservationRoom.update({
          where: { id: resRoom.id },
          data: { status: 'cancelled' },
        })
      }
    }

    const reservation = await db.reservation.update({
      where: { id: body.id },
      data: {
        status: body.status,
        bookingSource: body.bookingSource,
        otaReference: body.otaReference,
        checkInDate: body.checkInDate ? new Date(body.checkInDate) : undefined,
        checkOutDate: body.checkOutDate ? new Date(body.checkOutDate) : undefined,
        numberOfGuests: body.numberOfGuests,
        specialRequests: body.specialRequests,
        notes: body.notes,
        totalAmount: body.totalAmount,
        paidAmount: body.paidAmount,
        discount: body.discount,
        taxAmount: body.taxAmount,
      },
      include: {
        guest: true,
        rooms: { include: { room: { include: { roomType: true } } } },
        payments: true,
        folios: true,
      },
    })

    return NextResponse.json({ reservation })
  } catch (error) {
    console.error('Reservations PUT error:', error)
    return NextResponse.json({ error: 'Failed to update reservation' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Reservation ID is required' }, { status: 400 })
    }

    const existing = await db.reservation.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Reservation not found' }, { status: 404 })
    }

    // Release rooms
    const resRooms = await db.reservationRoom.findMany({ where: { reservationId: id } })
    for (const resRoom of resRooms) {
      if (resRoom.status === 'checked_in') {
        await db.room.update({
          where: { id: resRoom.roomId },
          data: { status: 'available' },
        })
      }
    }

    await db.folioItem.deleteMany({
      where: { folio: { reservationId: id } },
    })
    await db.payment.deleteMany({ where: { reservationId: id } })
    await db.folio.deleteMany({ where: { reservationId: id } })
    await db.reservationRoom.deleteMany({ where: { reservationId: id } })
    await db.reservation.delete({ where: { id } })

    return NextResponse.json({ message: 'Reservation deleted successfully' })
  } catch (error) {
    console.error('Reservations DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete reservation' }, { status: 500 })
  }
}
