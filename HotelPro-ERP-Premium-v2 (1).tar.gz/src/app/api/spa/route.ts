import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'services': {
        const services = await db.spaService.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ services })
      }
      case 'bookings': {
        const bookings = await db.spaBooking.findMany({
          include: { service: true, guest: true },
          orderBy: { dateTime: 'desc' },
        })
        return NextResponse.json({ bookings })
      }
      default: {
        const services = await db.spaService.findMany({ orderBy: { name: 'asc' } })
        const bookings = await db.spaBooking.findMany({ include: { service: true, guest: true }, orderBy: { dateTime: 'desc' } })
        return NextResponse.json({ services, bookings })
      }
    }
  } catch (error) {
    console.error('Spa API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'service': return NextResponse.json({ item: await db.spaService.create({ data }) })
      case 'booking': return NextResponse.json({ item: await db.spaBooking.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Spa POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'service': return NextResponse.json({ item: await db.spaService.update({ where: { id }, data }) })
      case 'booking': return NextResponse.json({ item: await db.spaBooking.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Spa PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'service': await db.spaService.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'booking': await db.spaBooking.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Spa DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
