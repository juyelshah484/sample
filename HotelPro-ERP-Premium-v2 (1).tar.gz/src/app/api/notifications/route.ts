import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const userId = searchParams.get('userId')
    const type = searchParams.get('type')
    const isRead = searchParams.get('isRead')
    const channel = searchParams.get('channel')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (userId) where.userId = userId
    if (type) where.type = type
    if (isRead !== null) where.isRead = isRead === 'true'
    if (channel) where.channel = channel

    const notifications = await db.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    const stats = {
      total: notifications.length,
      unread: notifications.filter(n => !n.isRead).length,
      byType: notifications.reduce((acc: any, n) => {
        acc[n.type] = (acc[n.type] || 0) + 1
        return acc
      }, {}),
    }

    return NextResponse.json({ notifications, stats })
  } catch (error) {
    console.error('Notifications API error:', error)
    return NextResponse.json({ error: 'Failed to load notifications' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.title || !body.message) {
      return NextResponse.json(
        { error: 'Title and message are required' },
        { status: 400 }
      )
    }

    const validTypes = ['system', 'booking', 'payment', 'checkin', 'checkout', 'maintenance', 'housekeeping']
    if (body.type && !validTypes.includes(body.type)) {
      return NextResponse.json(
        { error: `Invalid type. Must be one of: ${validTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const validChannels = ['in_app', 'email', 'sms', 'whatsapp', 'push']
    if (body.channel && !validChannels.includes(body.channel)) {
      return NextResponse.json(
        { error: `Invalid channel. Must be one of: ${validChannels.join(', ')}` },
        { status: 400 }
      )
    }

    const notification = await db.notification.create({
      data: {
        hotelId: body.hotelId,
        userId: body.userId,
        type: body.type ?? 'system',
        title: body.title,
        message: body.message,
        channel: body.channel ?? 'in_app',
        isRead: false,
      },
    })

    return NextResponse.json({ notification }, { status: 201 })
  } catch (error) {
    console.error('Notifications POST error:', error)
    return NextResponse.json({ error: 'Failed to create notification' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    // Mark single notification as read
    if (body.id) {
      const existing = await db.notification.findUnique({ where: { id: body.id } })
      if (!existing) {
        return NextResponse.json({ error: 'Notification not found' }, { status: 404 })
      }

      const notification = await db.notification.update({
        where: { id: body.id },
        data: { isRead: body.isRead ?? true },
      })

      return NextResponse.json({ notification })
    }

    // Mark all as read for a user or hotel
    if (body.markAllRead) {
      const where: any = { isRead: false }
      if (body.userId) where.userId = body.userId
      if (body.hotelId) where.hotelId = body.hotelId

      const result = await db.notification.updateMany({
        where,
        data: { isRead: true },
      })

      return NextResponse.json({ message: `${result.count} notifications marked as read` })
    }

    return NextResponse.json({ error: 'Either id or markAllRead flag is required' }, { status: 400 })
  } catch (error) {
    console.error('Notifications PUT error:', error)
    return NextResponse.json({ error: 'Failed to update notification' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Notification ID is required' }, { status: 400 })
    }

    const existing = await db.notification.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Notification not found' }, { status: 404 })
    }

    await db.notification.delete({ where: { id } })

    return NextResponse.json({ message: 'Notification deleted successfully' })
  } catch (error) {
    console.error('Notifications DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete notification' }, { status: 500 })
  }
}
