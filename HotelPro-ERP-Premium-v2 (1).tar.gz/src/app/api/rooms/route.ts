import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const floorId = searchParams.get('floorId')
    const roomTypeId = searchParams.get('roomTypeId')
    const hotelId = searchParams.get('hotelId')
    const buildingId = searchParams.get('buildingId')
    const search = searchParams.get('search')

    const where: any = {}
    if (status) where.status = status
    if (floorId) where.floorId = floorId
    if (roomTypeId) where.roomTypeId = roomTypeId
    if (hotelId) where.hotelId = hotelId
    if (buildingId) where.buildingId = buildingId
    if (search) {
      where.OR = [
        { number: { contains: search } },
        { name: { contains: search } },
      ]
    }

    const rooms = await db.room.findMany({
      where,
      include: {
        roomType: true,
        roomCategory: true,
        bedType: true,
        roomView: true,
        floorRecord: { include: { building: true } },
        amenities: { include: { amenity: true } },
      },
      orderBy: { number: 'asc' },
    })

    const stats = {
      total: rooms.length,
      available: rooms.filter(r => r.status === 'available').length,
      occupied: rooms.filter(r => r.status === 'occupied').length,
      maintenance: rooms.filter(r => r.status === 'maintenance').length,
      outOfService: rooms.filter(r => r.status === 'out_of_service').length,
      blocked: rooms.filter(r => r.status === 'blocked').length,
    }

    return NextResponse.json({ rooms, stats })
  } catch (error) {
    console.error('Rooms API error:', error)
    return NextResponse.json({ error: 'Failed to load rooms' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.number || !body.hotelId || !body.roomTypeId || body.price === undefined) {
      return NextResponse.json(
        { error: 'Room number, hotelId, roomTypeId, and price are required' },
        { status: 400 }
      )
    }

    const validStatuses = ['available', 'occupied', 'maintenance', 'out_of_service', 'blocked']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const room = await db.room.create({
      data: {
        number: body.number,
        name: body.name,
        hotelId: body.hotelId,
        buildingId: body.buildingId,
        floorId: body.floorId,
        roomTypeId: body.roomTypeId,
        roomCategoryId: body.roomCategoryId,
        bedTypeId: body.bedTypeId,
        roomViewId: body.roomViewId,
        status: body.status ?? 'available',
        smoking: body.smoking ?? false,
        floor: body.floor ?? 1,
        price: body.price,
        maxGuests: body.maxGuests ?? 2,
        description: body.description,
        images: body.images,
        isActive: body.isActive ?? true,
      },
      include: {
        roomType: true,
        roomCategory: true,
        bedType: true,
        roomView: true,
        floorRecord: true,
        amenities: { include: { amenity: true } },
      },
    })

    // Create room amenities if provided
    if (body.amenityIds && Array.isArray(body.amenityIds)) {
      for (const amenityId of body.amenityIds) {
        await db.roomAmenity.create({
          data: { roomId: room.id, amenityId },
        })
      }
    }

    // Re-fetch with amenities
    const result = await db.room.findUnique({
      where: { id: room.id },
      include: {
        roomType: true,
        roomCategory: true,
        bedType: true,
        roomView: true,
        floorRecord: true,
        amenities: { include: { amenity: true } },
      },
    })

    return NextResponse.json({ room: result }, { status: 201 })
  } catch (error) {
    console.error('Rooms POST error:', error)
    return NextResponse.json({ error: 'Failed to create room' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Room ID is required' }, { status: 400 })
    }

    const existing = await db.room.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room not found' }, { status: 404 })
    }

    const validStatuses = ['available', 'occupied', 'maintenance', 'out_of_service', 'blocked']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const room = await db.room.update({
      where: { id: body.id },
      data: {
        number: body.number,
        name: body.name,
        buildingId: body.buildingId,
        floorId: body.floorId,
        roomTypeId: body.roomTypeId,
        roomCategoryId: body.roomCategoryId,
        bedTypeId: body.bedTypeId,
        roomViewId: body.roomViewId,
        status: body.status,
        smoking: body.smoking,
        floor: body.floor,
        price: body.price,
        maxGuests: body.maxGuests,
        description: body.description,
        images: body.images,
        isActive: body.isActive,
      },
      include: {
        roomType: true,
        roomCategory: true,
        bedType: true,
        roomView: true,
        floorRecord: true,
        amenities: { include: { amenity: true } },
      },
    })

    return NextResponse.json({ room })
  } catch (error) {
    console.error('Rooms PUT error:', error)
    return NextResponse.json({ error: 'Failed to update room' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Room ID is required' }, { status: 400 })
    }

    const existing = await db.room.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room not found' }, { status: 404 })
    }

    await db.roomAmenity.deleteMany({ where: { roomId: id } })
    await db.room.delete({ where: { id } })

    return NextResponse.json({ message: 'Room deleted successfully' })
  } catch (error) {
    console.error('Rooms DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete room' }, { status: 500 })
  }
}
