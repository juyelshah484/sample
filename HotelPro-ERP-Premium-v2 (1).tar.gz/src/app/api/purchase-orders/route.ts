import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const supplierId = searchParams.get('supplierId')
    const status = searchParams.get('status')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (supplierId) where.supplierId = supplierId
    if (status) where.status = status

    const purchaseOrders = await db.purchaseOrder.findMany({
      where,
      include: {
        supplier: true,
        items: { include: { item: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ purchaseOrders })
  } catch (error) {
    console.error('Purchase Orders API error:', error)
    return NextResponse.json({ error: 'Failed to load purchase orders' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.supplierId || !body.items || !Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json(
        { error: 'HotelId, supplierId, and items array are required' },
        { status: 400 }
      )
    }

    // Calculate total
    let totalAmount = 0
    for (const item of body.items) {
      totalAmount += item.unitPrice * item.quantity
    }

    // Generate PO number
    const poCount = await db.purchaseOrder.count()
    const poNumber = `PO-${String(poCount + 1).padStart(6, '0')}`

    const purchaseOrder = await db.purchaseOrder.create({
      data: {
        hotelId: body.hotelId,
        supplierId: body.supplierId,
        poNumber,
        status: body.status ?? 'draft',
        totalAmount,
        notes: body.notes,
        orderDate: body.orderDate ? new Date(body.orderDate) : new Date(),
        expectedDate: body.expectedDate ? new Date(body.expectedDate) : null,
        items: {
          create: body.items.map((item: any) => ({
            itemId: item.itemId,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.unitPrice * item.quantity,
            receivedQty: 0,
          })),
        },
      },
      include: {
        supplier: true,
        items: { include: { item: true } },
      },
    })

    return NextResponse.json({ purchaseOrder }, { status: 201 })
  } catch (error) {
    console.error('Purchase Orders POST error:', error)
    return NextResponse.json({ error: 'Failed to create purchase order' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Purchase order ID is required' }, { status: 400 })
    }

    const existing = await db.purchaseOrder.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Purchase order not found' }, { status: 404 })
    }

    const validStatuses = ['draft', 'submitted', 'approved', 'received', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const purchaseOrder = await db.purchaseOrder.update({
      where: { id: body.id },
      data: {
        status: body.status,
        totalAmount: body.totalAmount,
        notes: body.notes,
        expectedDate: body.expectedDate ? new Date(body.expectedDate) : undefined,
      },
      include: {
        supplier: true,
        items: { include: { item: true } },
      },
    })

    return NextResponse.json({ purchaseOrder })
  } catch (error) {
    console.error('Purchase Orders PUT error:', error)
    return NextResponse.json({ error: 'Failed to update purchase order' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Purchase order ID is required' }, { status: 400 })
    }

    const existing = await db.purchaseOrder.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Purchase order not found' }, { status: 404 })
    }

    await db.purchaseOrderItem.deleteMany({ where: { purchaseOrderId: id } })
    await db.purchaseOrder.delete({ where: { id } })

    return NextResponse.json({ message: 'Purchase order deleted successfully' })
  } catch (error) {
    console.error('Purchase Orders DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete purchase order' }, { status: 500 })
  }
}
