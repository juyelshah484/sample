import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const reservationId = searchParams.get('reservationId')
    const guestId = searchParams.get('guestId')
    const status = searchParams.get('status')

    const where: any = {}
    if (reservationId) where.reservationId = reservationId
    if (guestId) where.guestId = guestId
    if (status) where.status = status

    const folios = await db.folio.findMany({
      where,
      include: {
        reservation: { include: { guest: true } },
        folioItems: { orderBy: { createdAt: 'desc' } },
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ folios })
  } catch (error) {
    console.error('Folios API error:', error)
    return NextResponse.json({ error: 'Failed to load folios' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Create a folio item
    if (body.folioId) {
      if (!body.description || !body.category || body.amount === undefined) {
        return NextResponse.json(
          { error: 'FolioId, description, category, and amount are required for folio item' },
          { status: 400 }
        )
      }

      const validCategories = ['room', 'restaurant', 'spa', 'laundry', 'minibar', 'banquet', 'other']
      if (!validCategories.includes(body.category)) {
        return NextResponse.json(
          { error: `Invalid category. Must be one of: ${validCategories.join(', ')}` },
          { status: 400 }
        )
      }

      const folioItem = await db.folioItem.create({
        data: {
          folioId: body.folioId,
          description: body.description,
          category: body.category,
          amount: body.amount,
          quantity: body.quantity ?? 1,
          referenceId: body.referenceId,
        },
      })

      // Update folio totals
      const folioItems = await db.folioItem.findMany({
        where: { folioId: body.folioId },
      })
      const totalAmount = folioItems.reduce((sum, item) => sum + item.amount * item.quantity, 0)
      const folio = await db.folio.findUnique({ where: { id: body.folioId } })
      const paidAmount = folio?.paidAmount ?? 0

      await db.folio.update({
        where: { id: body.folioId },
        data: {
          totalAmount,
          balance: totalAmount - paidAmount,
        },
      })

      return NextResponse.json({ folioItem }, { status: 201 })
    }

    // Create a new folio
    if (!body.reservationId || !body.guestId) {
      return NextResponse.json(
        { error: 'ReservationId and guestId are required' },
        { status: 400 }
      )
    }

    // Generate folio number
    const folioCount = await db.folio.count()
    const folioNumber = `FOL-${String(folioCount + 1).padStart(6, '0')}`

    const folio = await db.folio.create({
      data: {
        reservationId: body.reservationId,
        guestId: body.guestId,
        hotelId: body.hotelId,
        folioNumber,
        status: body.status ?? 'open',
        totalAmount: 0,
        paidAmount: 0,
        balance: 0,
      },
      include: {
        reservation: true,
        folioItems: true,
      },
    })

    return NextResponse.json({ folio }, { status: 201 })
  } catch (error) {
    console.error('Folios POST error:', error)
    return NextResponse.json({ error: 'Failed to create folio/folio item' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Folio ID is required' }, { status: 400 })
    }

    const existing = await db.folio.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Folio not found' }, { status: 404 })
    }

    const validStatuses = ['open', 'closed']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const folio = await db.folio.update({
      where: { id: body.id },
      data: {
        status: body.status,
        paidAmount: body.paidAmount,
        balance: body.balance !== undefined ? body.balance : existing.totalAmount - (body.paidAmount ?? existing.paidAmount),
      },
      include: {
        reservation: true,
        folioItems: true,
        payments: true,
      },
    })

    return NextResponse.json({ folio })
  } catch (error) {
    console.error('Folios PUT error:', error)
    return NextResponse.json({ error: 'Failed to update folio' }, { status: 500 })
  }
}
