import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (isActive !== null) where.isActive = isActive === 'true'

    const roomViews = await db.roomView.findMany({
      where,
      include: {
        _count: { select: { rooms: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ roomViews })
  } catch (error) {
    console.error('Room Views API error:', error)
    return NextResponse.json({ error: 'Failed to load room views' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code) {
      return NextResponse.json(
        { error: 'Name and code are required' },
        { status: 400 }
      )
    }

    const roomView = await db.roomView.create({
      data: {
        name: body.name,
        code: body.code,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ roomView }, { status: 201 })
  } catch (error) {
    console.error('Room Views POST error:', error)
    return NextResponse.json({ error: 'Failed to create room view' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Room view ID is required' }, { status: 400 })
    }

    const existing = await db.roomView.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room view not found' }, { status: 404 })
    }

    const roomView = await db.roomView.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ roomView })
  } catch (error) {
    console.error('Room Views PUT error:', error)
    return NextResponse.json({ error: 'Failed to update room view' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Room view ID is required' }, { status: 400 })
    }

    const existing = await db.roomView.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room view not found' }, { status: 404 })
    }

    await db.roomView.delete({ where: { id } })

    return NextResponse.json({ message: 'Room view deleted successfully' })
  } catch (error) {
    console.error('Room Views DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete room view' }, { status: 500 })
  }
}
