import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const category = searchParams.get('category')
    const isActive = searchParams.get('isActive')
    const search = searchParams.get('search')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (category) where.category = category
    if (isActive !== null) where.isActive = isActive === 'true'
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { code: { contains: search } },
      ]
    }

    const items = await db.item.findMany({
      where,
      include: {
        stockLevels: { include: { store: true } },
        _count: { select: { stockMovements: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ items })
  } catch (error) {
    console.error('Items API error:', error)
    return NextResponse.json({ error: 'Failed to load items' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code || !body.hotelId) {
      return NextResponse.json(
        { error: 'Name, code, and hotelId are required' },
        { status: 400 }
      )
    }

    const item = await db.item.create({
      data: {
        hotelId: body.hotelId,
        name: body.name,
        code: body.code,
        category: body.category,
        unit: body.unit ?? 'pcs',
        reorderLevel: body.reorderLevel ?? 10,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ item }, { status: 201 })
  } catch (error) {
    console.error('Items POST error:', error)
    return NextResponse.json({ error: 'Failed to create item' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Item ID is required' }, { status: 400 })
    }

    const existing = await db.item.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Item not found' }, { status: 404 })
    }

    const item = await db.item.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        category: body.category,
        unit: body.unit,
        reorderLevel: body.reorderLevel,
        isActive: body.isActive,
      },
      include: { stockLevels: { include: { store: true } } },
    })

    return NextResponse.json({ item })
  } catch (error) {
    console.error('Items PUT error:', error)
    return NextResponse.json({ error: 'Failed to update item' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Item ID is required' }, { status: 400 })
    }

    const existing = await db.item.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Item not found' }, { status: 404 })
    }

    await db.stockMovement.deleteMany({ where: { itemId: id } })
    await db.stockLevel.deleteMany({ where: { itemId: id } })
    await db.item.delete({ where: { id } })

    return NextResponse.json({ message: 'Item deleted successfully' })
  } catch (error) {
    console.error('Items DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete item' }, { status: 500 })
  }
}
