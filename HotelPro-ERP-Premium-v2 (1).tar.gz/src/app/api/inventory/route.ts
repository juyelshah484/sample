import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'items': {
        const items = await db.item.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ items })
      }
      case 'stock-levels': {
        const levels = await db.stockLevel.findMany({ include: { item: true, store: true } })
        return NextResponse.json({ levels })
      }
      case 'movements': {
        const movements = await db.stockMovement.findMany({ include: { item: true }, orderBy: { createdAt: 'desc' }, take: 50 })
        return NextResponse.json({ movements })
      }
      case 'stores': {
        const stores = await db.store.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ stores })
      }
      default: {
        const items = await db.item.findMany({ orderBy: { name: 'asc' } })
        const stores = await db.store.findMany({ orderBy: { name: 'asc' } })
        const levels = await db.stockLevel.findMany({ include: { item: true, store: true } })
        return NextResponse.json({ items, stores, levels })
      }
    }
  } catch (error) {
    console.error('Inventory API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'item': return NextResponse.json({ item: await db.item.create({ data }) })
      case 'store': return NextResponse.json({ item: await db.store.create({ data }) })
      case 'stock-level': return NextResponse.json({ item: await db.stockLevel.create({ data }) })
      case 'movement': return NextResponse.json({ item: await db.stockMovement.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Inventory POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'item': return NextResponse.json({ item: await db.item.update({ where: { id }, data }) })
      case 'store': return NextResponse.json({ item: await db.store.update({ where: { id }, data }) })
      case 'stock-level': return NextResponse.json({ item: await db.stockLevel.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Inventory PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'item': await db.stockLevel.deleteMany({ where: { itemId: id } }); await db.stockMovement.deleteMany({ where: { itemId: id } }); await db.item.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'store': await db.stockLevel.deleteMany({ where: { storeId: id } }); await db.store.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Inventory DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
