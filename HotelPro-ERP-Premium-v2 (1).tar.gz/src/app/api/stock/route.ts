import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const itemId = searchParams.get('itemId')
    const storeId = searchParams.get('storeId')
    const hotelId = searchParams.get('hotelId')
    const type = searchParams.get('type') // movement type filter
    const lowStock = searchParams.get('lowStock')

    // Get stock levels
    const stockWhere: any = {}
    if (itemId) stockWhere.itemId = itemId
    if (storeId) stockWhere.storeId = storeId

    const stockLevels = await db.stockLevel.findMany({
      where: stockWhere,
      include: {
        item: true,
        store: true,
      },
      orderBy: { updatedAt: 'desc' },
    })

    // Filter low stock items if requested
    let filteredLevels = stockLevels
    if (lowStock === 'true') {
      filteredLevels = stockLevels.filter(s => s.quantity <= s.minStock)
    }

    // Get stock movements
    const movementWhere: any = {}
    if (itemId) movementWhere.itemId = itemId
    if (storeId) movementWhere.storeId = storeId
    if (type) movementWhere.type = type

    // Filter movements by hotel through item relation
    if (hotelId) {
      movementWhere.item = { hotelId }
    }

    const movements = await db.stockMovement.findMany({
      where: movementWhere,
      include: {
        item: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    const stats = {
      totalItems: filteredLevels.length,
      lowStockItems: filteredLevels.filter(s => s.quantity <= s.minStock).length,
      outOfStockItems: filteredLevels.filter(s => s.quantity === 0).length,
      totalMovements: movements.length,
    }

    return NextResponse.json({ stockLevels: filteredLevels, movements, stats })
  } catch (error) {
    console.error('Stock API error:', error)
    return NextResponse.json({ error: 'Failed to load stock data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Handle stock movement
    if (body.type === 'in' || body.type === 'out' || body.type === 'transfer' || body.type === 'adjustment' || body.type === 'audit') {
      if (!body.itemId || body.quantity === undefined || !body.type) {
        return NextResponse.json(
          { error: 'ItemId, quantity, and type are required for stock movement' },
          { status: 400 }
        )
      }

      const movement = await db.stockMovement.create({
        data: {
          itemId: body.itemId,
          storeId: body.storeId,
          type: body.type,
          quantity: body.quantity,
          reference: body.reference,
          notes: body.notes,
        },
      })

      // Update stock level if storeId is provided
      if (body.storeId) {
        const existingLevel = await db.stockLevel.findUnique({
          where: {
            itemId_storeId: {
              itemId: body.itemId,
              storeId: body.storeId,
            },
          },
        })

        if (existingLevel) {
          const quantityChange = body.type === 'in' ? body.quantity :
                                 body.type === 'out' ? -body.quantity :
                                 body.type === 'adjustment' ? body.quantity : 0

          await db.stockLevel.update({
            where: { id: existingLevel.id },
            data: { quantity: { increment: quantityChange } },
          })
        } else if (body.type === 'in') {
          await db.stockLevel.create({
            data: {
              itemId: body.itemId,
              storeId: body.storeId,
              quantity: body.quantity,
              minStock: body.minStock ?? 0,
              maxStock: body.maxStock ?? 100,
            },
          })
        }
      }

      const result = await db.stockMovement.findUnique({
        where: { id: movement.id },
        include: { item: true },
      })

      return NextResponse.json({ movement: result }, { status: 201 })
    }

    // Handle stock level creation/update
    if (!body.itemId || !body.storeId) {
      return NextResponse.json(
        { error: 'ItemId and storeId are required' },
        { status: 400 }
      )
    }

    const stockLevel = await db.stockLevel.upsert({
      where: {
        itemId_storeId: {
          itemId: body.itemId,
          storeId: body.storeId,
        },
      },
      create: {
        itemId: body.itemId,
        storeId: body.storeId,
        quantity: body.quantity ?? 0,
        minStock: body.minStock ?? 0,
        maxStock: body.maxStock ?? 100,
      },
      update: {
        quantity: body.quantity,
        minStock: body.minStock,
        maxStock: body.maxStock,
      },
      include: {
        item: true,
        store: true,
      },
    })

    return NextResponse.json({ stockLevel }, { status: 201 })
  } catch (error) {
    console.error('Stock POST error:', error)
    return NextResponse.json({ error: 'Failed to process stock operation' }, { status: 500 })
  }
}
