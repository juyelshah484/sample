import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'hotel': {
        const hotel = await db.hotel.findFirst()
        return NextResponse.json({ hotel })
      }
      case 'buildings': {
        const buildings = await db.building.findMany({ include: { floorRecords: true }, orderBy: { name: 'asc' } })
        return NextResponse.json({ buildings })
      }
      case 'floors': {
        const floors = await db.floor.findMany({ include: { building: true }, orderBy: { number: 'asc' } })
        return NextResponse.json({ floors })
      }
      case 'room-types': {
        const roomTypes = await db.roomType.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ roomTypes })
      }
      case 'room-categories': {
        const categories = await db.roomCategory.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ categories })
      }
      case 'bed-types': {
        const bedTypes = await db.bedType.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ bedTypes })
      }
      case 'room-views': {
        const roomViews = await db.roomView.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ roomViews })
      }
      case 'amenities': {
        const amenities = await db.amenity.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ amenities })
      }
      case 'seasonal-pricing': {
        const pricings = await db.seasonalPricing.findMany({ include: { roomType: true }, orderBy: { startDate: 'desc' } })
        return NextResponse.json({ pricings })
      }
      default: {
        const hotel = await db.hotel.findFirst()
        const buildings = await db.building.findMany({ include: { floorRecords: true } })
        const roomTypes = await db.roomType.findMany()
        const categories = await db.roomCategory.findMany()
        const bedTypes = await db.bedType.findMany()
        const roomViews = await db.roomView.findMany()
        const amenities = await db.amenity.findMany()
        const pricings = await db.seasonalPricing.findMany({ include: { roomType: true } })
        return NextResponse.json({ hotel, buildings, roomTypes, categories, bedTypes, roomViews, amenities, pricings })
      }
    }
  } catch (error) {
    console.error('Hotel setup API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body

    switch (resource) {
      case 'hotel': {
        const existing = await db.hotel.findFirst()
        if (existing) {
          const hotel = await db.hotel.update({ where: { id: existing.id }, data })
          return NextResponse.json({ hotel })
        }
        const hotel = await db.hotel.create({ data })
        return NextResponse.json({ hotel })
      }
      case 'building': {
        const building = await db.building.create({ data })
        return NextResponse.json({ building })
      }
      case 'floor': {
        const floor = await db.floor.create({ data })
        return NextResponse.json({ floor })
      }
      case 'room-type': {
        const roomType = await db.roomType.create({ data })
        return NextResponse.json({ roomType })
      }
      case 'room-category': {
        const category = await db.roomCategory.create({ data })
        return NextResponse.json({ category })
      }
      case 'bed-type': {
        const bedType = await db.bedType.create({ data })
        return NextResponse.json({ bedType })
      }
      case 'room-view': {
        const roomView = await db.roomView.create({ data })
        return NextResponse.json({ roomView })
      }
      case 'amenity': {
        const amenity = await db.amenity.create({ data })
        return NextResponse.json({ amenity })
      }
      case 'seasonal-pricing': {
        const pricing = await db.seasonalPricing.create({ data })
        return NextResponse.json({ pricing })
      }
      default:
        return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Hotel setup POST error:', error)
    return NextResponse.json({ error: 'Failed to create resource' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body

    switch (resource) {
      case 'building': {
        const building = await db.building.update({ where: { id }, data })
        return NextResponse.json({ building })
      }
      case 'floor': {
        const floor = await db.floor.update({ where: { id }, data })
        return NextResponse.json({ floor })
      }
      case 'room-type': {
        const roomType = await db.roomType.update({ where: { id }, data })
        return NextResponse.json({ roomType })
      }
      case 'room-category': {
        const category = await db.roomCategory.update({ where: { id }, data })
        return NextResponse.json({ category })
      }
      case 'bed-type': {
        const bedType = await db.bedType.update({ where: { id }, data })
        return NextResponse.json({ bedType })
      }
      case 'room-view': {
        const roomView = await db.roomView.update({ where: { id }, data })
        return NextResponse.json({ roomView })
      }
      case 'amenity': {
        const amenity = await db.amenity.update({ where: { id }, data })
        return NextResponse.json({ amenity })
      }
      case 'seasonal-pricing': {
        const pricing = await db.seasonalPricing.update({ where: { id }, data })
        return NextResponse.json({ pricing })
      }
      default:
        return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Hotel setup PUT error:', error)
    return NextResponse.json({ error: 'Failed to update resource' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')

    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })

    switch (resource) {
      case 'building': {
        await db.building.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'floor': {
        await db.floor.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'room-type': {
        await db.roomType.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'room-category': {
        await db.roomCategory.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'bed-type': {
        await db.bedType.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'room-view': {
        await db.roomView.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'amenity': {
        await db.amenity.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      case 'seasonal-pricing': {
        await db.seasonalPricing.delete({ where: { id } })
        return NextResponse.json({ success: true })
      }
      default:
        return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Hotel setup DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete resource' }, { status: 500 })
  }
}
