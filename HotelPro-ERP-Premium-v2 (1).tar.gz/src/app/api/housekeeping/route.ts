import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const type = searchParams.get('type')
    const priority = searchParams.get('priority')
    const assignedTo = searchParams.get('assignedTo')
    const roomId = searchParams.get('roomId')

    const where: any = {}
    if (status) where.status = status
    if (type) where.type = type
    if (priority) where.priority = priority
    if (assignedTo) where.assignedTo = assignedTo
    if (roomId) where.roomId = roomId

    const tasks = await db.housekeepingTask.findMany({
      where,
      include: { room: { include: { roomType: true } } },
      orderBy: { createdAt: 'desc' },
    })

    const stats = {
      pending: tasks.filter(t => t.status === 'pending').length,
      inProgress: tasks.filter(t => t.status === 'in_progress').length,
      completed: tasks.filter(t => t.status === 'completed').length,
      cancelled: tasks.filter(t => t.status === 'cancelled').length,
      total: tasks.length,
      urgent: tasks.filter(t => t.priority === 'urgent').length,
      high: tasks.filter(t => t.priority === 'high').length,
    }

    return NextResponse.json({ tasks, stats })
  } catch (error) {
    console.error('Housekeeping API error:', error)
    return NextResponse.json({ error: 'Failed to load housekeeping data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.roomId) {
      return NextResponse.json(
        { error: 'RoomId is required' },
        { status: 400 }
      )
    }

    const validTypes = ['cleaning', 'inspection', 'deep_clean', 'laundry_pickup']
    if (body.type && !validTypes.includes(body.type)) {
      return NextResponse.json(
        { error: `Invalid type. Must be one of: ${validTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const validStatuses = ['pending', 'in_progress', 'completed', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const validPriorities = ['low', 'normal', 'high', 'urgent']
    if (body.priority && !validPriorities.includes(body.priority)) {
      return NextResponse.json(
        { error: `Invalid priority. Must be one of: ${validPriorities.join(', ')}` },
        { status: 400 }
      )
    }

    const task = await db.housekeepingTask.create({
      data: {
        roomId: body.roomId,
        type: body.type ?? 'cleaning',
        status: body.status ?? 'pending',
        priority: body.priority ?? 'normal',
        assignedTo: body.assignedTo,
        notes: body.notes,
        startedAt: body.startedAt ? new Date(body.startedAt) : null,
        completedAt: body.completedAt ? new Date(body.completedAt) : null,
      },
      include: { room: { include: { roomType: true } } },
    })

    return NextResponse.json({ task }, { status: 201 })
  } catch (error) {
    console.error('Housekeeping POST error:', error)
    return NextResponse.json({ error: 'Failed to create housekeeping task' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Task ID is required' }, { status: 400 })
    }

    const existing = await db.housekeepingTask.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Housekeeping task not found' }, { status: 404 })
    }

    const validStatuses = ['pending', 'in_progress', 'completed', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    // Auto-set timestamps based on status
    const updateData: any = {
      type: body.type,
      status: body.status,
      priority: body.priority,
      assignedTo: body.assignedTo,
      notes: body.notes,
    }

    if (body.status === 'in_progress' && !existing.startedAt) {
      updateData.startedAt = new Date()
    }

    if (body.status === 'completed' && !existing.completedAt) {
      updateData.completedAt = new Date()
    }

    const task = await db.housekeepingTask.update({
      where: { id: body.id },
      data: updateData,
      include: { room: { include: { roomType: true } } },
    })

    return NextResponse.json({ task })
  } catch (error) {
    console.error('Housekeeping PUT error:', error)
    return NextResponse.json({ error: 'Failed to update housekeeping task' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Task ID is required' }, { status: 400 })
    }

    const existing = await db.housekeepingTask.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Housekeeping task not found' }, { status: 404 })
    }

    await db.housekeepingTask.delete({ where: { id } })

    return NextResponse.json({ message: 'Housekeeping task deleted successfully' })
  } catch (error) {
    console.error('Housekeeping DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete housekeeping task' }, { status: 500 })
  }
}
