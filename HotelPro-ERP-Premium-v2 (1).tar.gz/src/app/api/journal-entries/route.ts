import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const status = searchParams.get('status')
    const voucherType = searchParams.get('voucherType')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (status) where.status = status
    if (voucherType) where.voucherType = voucherType
    if (startDate || endDate) {
      where.date = {}
      if (startDate) where.date.gte = new Date(startDate)
      if (endDate) where.date.lte = new Date(endDate)
    }

    const journalEntries = await db.journalEntry.findMany({
      where,
      include: {
        debitAccount: true,
        creditAccount: true,
      },
      orderBy: { date: 'desc' },
      take: 100,
    })

    return NextResponse.json({ journalEntries })
  } catch (error) {
    console.error('Journal Entries API error:', error)
    return NextResponse.json({ error: 'Failed to load journal entries' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.voucherType || !body.debitAccountId || !body.creditAccountId || body.amount === undefined) {
      return NextResponse.json(
        { error: 'HotelId, voucherType, debitAccountId, creditAccountId, and amount are required' },
        { status: 400 }
      )
    }

    if (body.debitAccountId === body.creditAccountId) {
      return NextResponse.json(
        { error: 'Debit and credit accounts must be different' },
        { status: 400 }
      )
    }

    const validVoucherTypes = ['journal', 'payment', 'receipt', 'contra']
    if (!validVoucherTypes.includes(body.voucherType)) {
      return NextResponse.json(
        { error: `Invalid voucher type. Must be one of: ${validVoucherTypes.join(', ')}` },
        { status: 400 }
      )
    }

    // Generate voucher number
    const entryCount = await db.journalEntry.count()
    const voucherNumber = `JV-${String(entryCount + 1).padStart(6, '0')}`

    const journalEntry = await db.journalEntry.create({
      data: {
        hotelId: body.hotelId,
        voucherNumber,
        voucherType: body.voucherType,
        date: body.date ? new Date(body.date) : new Date(),
        debitAccountId: body.debitAccountId,
        creditAccountId: body.creditAccountId,
        amount: body.amount,
        description: body.description,
        reference: body.reference,
        status: body.status ?? 'draft',
      },
      include: {
        debitAccount: true,
        creditAccount: true,
      },
    })

    return NextResponse.json({ journalEntry }, { status: 201 })
  } catch (error) {
    console.error('Journal Entries POST error:', error)
    return NextResponse.json({ error: 'Failed to create journal entry' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Journal entry ID is required' }, { status: 400 })
    }

    const existing = await db.journalEntry.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Journal entry not found' }, { status: 404 })
    }

    const validStatuses = ['draft', 'posted', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const journalEntry = await db.journalEntry.update({
      where: { id: body.id },
      data: {
        voucherType: body.voucherType,
        date: body.date ? new Date(body.date) : undefined,
        debitAccountId: body.debitAccountId,
        creditAccountId: body.creditAccountId,
        amount: body.amount,
        description: body.description,
        reference: body.reference,
        status: body.status,
      },
      include: {
        debitAccount: true,
        creditAccount: true,
      },
    })

    return NextResponse.json({ journalEntry })
  } catch (error) {
    console.error('Journal Entries PUT error:', error)
    return NextResponse.json({ error: 'Failed to update journal entry' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Journal entry ID is required' }, { status: 400 })
    }

    const existing = await db.journalEntry.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Journal entry not found' }, { status: 404 })
    }

    if (existing.status === 'posted') {
      return NextResponse.json(
        { error: 'Cannot delete a posted journal entry' },
        { status: 400 }
      )
    }

    await db.journalEntry.delete({ where: { id } })

    return NextResponse.json({ message: 'Journal entry deleted successfully' })
  } catch (error) {
    console.error('Journal Entries DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete journal entry' }, { status: 500 })
  }
}
