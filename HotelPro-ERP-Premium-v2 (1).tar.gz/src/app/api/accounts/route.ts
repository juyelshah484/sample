import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const type = searchParams.get('type')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (type) where.type = type
    if (isActive !== null) where.isActive = isActive === 'true'

    const accounts = await db.account.findMany({
      where,
      include: {
        _count: {
          select: {
            debitEntries: true,
            creditEntries: true,
          },
        },
      },
      orderBy: [{ code: 'asc' }],
    })

    return NextResponse.json({ accounts })
  } catch (error) {
    console.error('Accounts API error:', error)
    return NextResponse.json({ error: 'Failed to load accounts' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.code || !body.name || !body.type || !body.hotelId) {
      return NextResponse.json(
        { error: 'Code, name, type, and hotelId are required' },
        { status: 400 }
      )
    }

    const validTypes = ['asset', 'liability', 'income', 'expense', 'equity']
    if (!validTypes.includes(body.type)) {
      return NextResponse.json(
        { error: `Invalid type. Must be one of: ${validTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const account = await db.account.create({
      data: {
        hotelId: body.hotelId,
        code: body.code,
        name: body.name,
        type: body.type,
        parentAccountId: body.parentAccountId,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ account }, { status: 201 })
  } catch (error) {
    console.error('Accounts POST error:', error)
    return NextResponse.json({ error: 'Failed to create account' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Account ID is required' }, { status: 400 })
    }

    const existing = await db.account.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    const account = await db.account.update({
      where: { id: body.id },
      data: {
        code: body.code,
        name: body.name,
        type: body.type,
        parentAccountId: body.parentAccountId,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ account })
  } catch (error) {
    console.error('Accounts PUT error:', error)
    return NextResponse.json({ error: 'Failed to update account' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Account ID is required' }, { status: 400 })
    }

    const existing = await db.account.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    await db.account.delete({ where: { id } })

    return NextResponse.json({ message: 'Account deleted successfully' })
  } catch (error) {
    console.error('Accounts DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete account' }, { status: 500 })
  }
}
