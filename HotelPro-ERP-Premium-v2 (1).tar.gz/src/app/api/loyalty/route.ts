import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'members': {
        const members = await db.loyaltyMember.findMany({ orderBy: { createdAt: 'desc' } })
        return NextResponse.json({ members })
      }
      case 'transactions': {
        const transactions = await db.loyaltyTransaction.findMany({ orderBy: { createdAt: 'desc' } })
        return NextResponse.json({ transactions })
      }
      default: {
        const members = await db.loyaltyMember.findMany({ orderBy: { createdAt: 'desc' } })
        const transactions = await db.loyaltyTransaction.findMany({ orderBy: { createdAt: 'desc' }, take: 30 })
        return NextResponse.json({ members, transactions })
      }
    }
  } catch (error) {
    console.error('Loyalty API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'member': return NextResponse.json({ item: await db.loyaltyMember.create({ data }) })
      case 'transaction': return NextResponse.json({ item: await db.loyaltyTransaction.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Loyalty POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'member': return NextResponse.json({ item: await db.loyaltyMember.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Loyalty PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}
