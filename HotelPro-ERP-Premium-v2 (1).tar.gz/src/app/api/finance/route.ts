import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'accounts': {
        const accounts = await db.account.findMany({ orderBy: { code: 'asc' } })
        return NextResponse.json({ accounts })
      }
      case 'journal-entries': {
        const entries = await db.journalEntry.findMany({
          include: { debitAccount: true, creditAccount: true },
          orderBy: { date: 'desc' },
        })
        return NextResponse.json({ entries })
      }
      default: {
        const accounts = await db.account.findMany({ orderBy: { code: 'asc' } })
        const entries = await db.journalEntry.findMany({
          include: { debitAccount: true, creditAccount: true },
          orderBy: { date: 'desc' }, take: 30,
        })
        return NextResponse.json({ accounts, entries })
      }
    }
  } catch (error) {
    console.error('Finance API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'account': return NextResponse.json({ item: await db.account.create({ data }) })
      case 'journal-entry': return NextResponse.json({ item: await db.journalEntry.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Finance POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'account': return NextResponse.json({ item: await db.account.update({ where: { id }, data }) })
      case 'journal-entry': return NextResponse.json({ item: await db.journalEntry.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Finance PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'account': await db.account.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'journal-entry': await db.journalEntry.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Finance DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
