import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (category) where.category = category
    if (isActive !== null) where.isActive = isActive === 'true'

    const amenities = await db.amenity.findMany({
      where,
      include: {
        _count: { select: { roomAmenities: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ amenities })
  } catch (error) {
    console.error('Amenities API error:', error)
    return NextResponse.json({ error: 'Failed to load amenities' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code) {
      return NextResponse.json(
        { error: 'Name and code are required' },
        { status: 400 }
      )
    }

    const amenity = await db.amenity.create({
      data: {
        name: body.name,
        code: body.code,
        icon: body.icon,
        category: body.category,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ amenity }, { status: 201 })
  } catch (error) {
    console.error('Amenities POST error:', error)
    return NextResponse.json({ error: 'Failed to create amenity' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Amenity ID is required' }, { status: 400 })
    }

    const existing = await db.amenity.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Amenity not found' }, { status: 404 })
    }

    const amenity = await db.amenity.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        icon: body.icon,
        category: body.category,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ amenity })
  } catch (error) {
    console.error('Amenities PUT error:', error)
    return NextResponse.json({ error: 'Failed to update amenity' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Amenity ID is required' }, { status: 400 })
    }

    const existing = await db.amenity.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Amenity not found' }, { status: 404 })
    }

    await db.amenity.delete({ where: { id } })

    return NextResponse.json({ message: 'Amenity deleted successfully' })
  } catch (error) {
    console.error('Amenities DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete amenity' }, { status: 500 })
  }
}
