import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const totalRevenue = await db.reservation.aggregate({ _sum: { totalAmount: true }, where: { status: { not: 'cancelled' } } })
    const totalPaid = await db.reservation.aggregate({ _sum: { paidAmount: true }, where: { status: { not: 'cancelled' } } })
    
    const roomRevenue = await db.folioItem.aggregate({
      _sum: { amount: true },
      where: { category: 'room' }
    })
    const restaurantRevenue = await db.folioItem.aggregate({
      _sum: { amount: true },
      where: { category: 'restaurant' }
    })
    const spaRevenue = await db.folioItem.aggregate({
      _sum: { amount: true },
      where: { category: 'spa' }
    })

    const reservations = await db.reservation.findMany({
      where: { status: { not: 'cancelled' } },
      include: { guest: true, rooms: { include: { room: true } } },
    })

    const cancelledCount = await db.reservation.count({ where: { status: 'cancelled' } })
    const noShowCount = await db.reservation.count({ where: { status: 'no_show' } })

    const totalRooms = await db.room.count()
    const occupiedRooms = await db.room.count({ where: { status: 'occupied' } })

    return NextResponse.json({
      totalRevenue: totalRevenue._sum.totalAmount || 0,
      totalPaid: totalPaid._sum.paidAmount || 0,
      roomRevenue: roomRevenue._sum.amount || 0,
      restaurantRevenue: restaurantRevenue._sum.amount || 0,
      spaRevenue: spaRevenue._sum.amount || 0,
      totalReservations: reservations.length,
      cancelledCount,
      noShowCount,
      occupancyRate: totalRooms > 0 ? ((occupiedRooms / totalRooms) * 100).toFixed(1) : 0,
      adr: occupiedRooms > 0 ? ((roomRevenue._sum.amount || 0) / occupiedRooms).toFixed(0) : 0,
      revpar: totalRooms > 0 ? (((roomRevenue._sum.amount || 0)) / totalRooms).toFixed(0) : 0,
    })
  } catch (error) {
    console.error('Reports API error:', error)
    return NextResponse.json({ error: 'Failed to load reports' }, { status: 500 })
  }
}
