import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const status = searchParams.get('status')
    const priority = searchParams.get('priority')
    const type = searchParams.get('type')
    const roomId = searchParams.get('roomId')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (status) where.status = status
    if (priority) where.priority = priority
    if (type) where.type = type
    if (roomId) where.roomId = roomId

    const maintenanceRequests = await db.maintenanceRequest.findMany({
      where,
      include: {
        room: { include: { roomType: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const stats = {
      total: maintenanceRequests.length,
      open: maintenanceRequests.filter(m => m.status === 'open').length,
      assigned: maintenanceRequests.filter(m => m.status === 'assigned').length,
      inProgress: maintenanceRequests.filter(m => m.status === 'in_progress').length,
      completed: maintenanceRequests.filter(m => m.status === 'completed').length,
      urgent: maintenanceRequests.filter(m => m.priority === 'urgent').length,
      high: maintenanceRequests.filter(m => m.priority === 'high').length,
    }

    return NextResponse.json({ maintenanceRequests, stats })
  } catch (error) {
    console.error('Maintenance API error:', error)
    return NextResponse.json({ error: 'Failed to load maintenance requests' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.description) {
      return NextResponse.json(
        { error: 'HotelId and description are required' },
        { status: 400 }
      )
    }

    const validTypes = ['complaint', 'preventive', 'electrical', 'plumbing', 'hvac', 'equipment']
    if (body.type && !validTypes.includes(body.type)) {
      return NextResponse.json(
        { error: `Invalid type. Must be one of: ${validTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const validPriorities = ['low', 'medium', 'high', 'urgent']
    if (body.priority && !validPriorities.includes(body.priority)) {
      return NextResponse.json(
        { error: `Invalid priority. Must be one of: ${validPriorities.join(', ')}` },
        { status: 400 }
      )
    }

    const maintenanceRequest = await db.maintenanceRequest.create({
      data: {
        hotelId: body.hotelId,
        roomId: body.roomId,
        assetId: body.assetId,
        type: body.type ?? 'complaint',
        description: body.description,
        priority: body.priority ?? 'medium',
        status: body.status ?? 'open',
        assignedTo: body.assignedTo,
        cost: body.cost ?? 0,
      },
      include: {
        room: { include: { roomType: true } },
      },
    })

    // Update room status to maintenance if roomId is provided
    if (body.roomId && body.priority === 'urgent') {
      await db.room.update({
        where: { id: body.roomId },
        data: { status: 'maintenance' },
      })
    }

    return NextResponse.json({ maintenanceRequest }, { status: 201 })
  } catch (error) {
    console.error('Maintenance POST error:', error)
    return NextResponse.json({ error: 'Failed to create maintenance request' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Maintenance request ID is required' }, { status: 400 })
    }

    const existing = await db.maintenanceRequest.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Maintenance request not found' }, { status: 404 })
    }

    const validStatuses = ['open', 'assigned', 'in_progress', 'completed', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const maintenanceRequest = await db.maintenanceRequest.update({
      where: { id: body.id },
      data: {
        type: body.type,
        description: body.description,
        priority: body.priority,
        status: body.status,
        assignedTo: body.assignedTo,
        cost: body.cost,
        completedAt: body.status === 'completed' ? new Date() : undefined,
      },
      include: {
        room: { include: { roomType: true } },
      },
    })

    // If completed and room was under maintenance, set it back to available
    if (body.status === 'completed' && existing.roomId) {
      const room = await db.room.findUnique({ where: { id: existing.roomId } })
      if (room && room.status === 'maintenance') {
        await db.room.update({
          where: { id: existing.roomId },
          data: { status: 'available' },
        })
      }
    }

    return NextResponse.json({ maintenanceRequest })
  } catch (error) {
    console.error('Maintenance PUT error:', error)
    return NextResponse.json({ error: 'Failed to update maintenance request' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Maintenance request ID is required' }, { status: 400 })
    }

    const existing = await db.maintenanceRequest.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Maintenance request not found' }, { status: 404 })
    }

    await db.maintenanceRequest.delete({ where: { id } })

    return NextResponse.json({ message: 'Maintenance request deleted successfully' })
  } catch (error) {
    console.error('Maintenance DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete maintenance request' }, { status: 500 })
  }
}
