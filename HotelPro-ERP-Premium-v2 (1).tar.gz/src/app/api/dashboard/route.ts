import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const hotel = await db.hotel.findFirst()
    const totalRooms = await db.room.count()
    const occupiedRooms = await db.room.count({ where: { status: 'occupied' } })
    const availableRooms = await db.room.count({ where: { status: 'available' } })
    const maintenanceRooms = await db.room.count({ where: { status: 'maintenance' } })
    const outOfServiceRooms = await db.room.count({ where: { status: 'out_of_service' } })
    
    const todayStart = new Date()
    todayStart.setHours(0, 0, 0, 0)
    const todayEnd = new Date()
    todayEnd.setHours(23, 59, 59, 999)

    const todayCheckins = await db.reservation.count({
      where: { checkInDate: { gte: todayStart, lte: todayEnd }, status: { in: ['confirmed', 'checked_in'] } }
    })
    const todayCheckouts = await db.reservation.count({
      where: { checkOutDate: { gte: todayStart, lte: todayEnd }, status: { in: ['checked_in', 'checked_out'] } }
    })

    const totalGuests = await db.guest.count()
    const totalReservations = await db.reservation.count()
    const activeReservations = await db.reservation.count({ where: { status: { in: ['confirmed', 'checked_in'] } } })

    const revenueResult = await db.reservation.aggregate({ _sum: { totalAmount: true, paidAmount: true } })

    const monthlyRevenue = []
    for (let i = 5; i >= 0; i--) {
      const monthStart = new Date()
      monthStart.setMonth(monthStart.getMonth() - i)
      monthStart.setDate(1)
      monthStart.setHours(0, 0, 0, 0)
      const monthEnd = new Date(monthStart)
      monthEnd.setMonth(monthEnd.getMonth() + 1)
      monthEnd.setDate(0)
      monthEnd.setHours(23, 59, 59, 999)

      const monthRev = await db.reservation.aggregate({
        _sum: { totalAmount: true },
        where: { createdAt: { gte: monthStart, lte: monthEnd }, status: { not: 'cancelled' } }
      })
      monthlyRevenue.push({ month: monthStart.toLocaleString('default', { month: 'short' }), revenue: monthRev._sum.totalAmount || 0 })
    }

    const bookingSourceStats = await db.reservation.groupBy({
      by: ['bookingSource'],
      _count: { id: true },
      where: { status: { not: 'cancelled' } }
    })

    const recentReservations = await db.reservation.findMany({
      take: 8,
      orderBy: { createdAt: 'desc' },
      include: { guest: true, rooms: { include: { room: true } } }
    })

    const housekeepingTasks = await db.housekeepingTask.count({ where: { status: { in: ['pending', 'in_progress'] } } })
    const pendingPayments = await db.reservation.aggregate({ _sum: { totalAmount: true, paidAmount: true }, where: { status: { in: ['confirmed', 'checked_in'] } } })
    const unreadNotifications = await db.notification.count({ where: { isRead: false } })

    return NextResponse.json({
      hotel,
      stats: {
        totalRooms, occupiedRooms, availableRooms, maintenanceRooms, outOfServiceRooms,
        occupancyRate: totalRooms > 0 ? ((occupiedRooms / totalRooms) * 100).toFixed(1) : 0,
        todayCheckins, todayCheckouts, totalGuests, totalReservations, activeReservations,
        totalRevenue: revenueResult._sum.totalAmount || 0,
        totalPaid: revenueResult._sum.paidAmount || 0,
        monthlyRevenue, bookingSourceStats, housekeepingTasks,
        pendingBalance: (pendingPayments._sum.totalAmount || 0) - (pendingPayments._sum.paidAmount || 0),
        unreadNotifications,
        adr: occupiedRooms > 0 ? ((revenueResult._sum.totalAmount || 0) / occupiedRooms).toFixed(0) : 0,
      },
      recentReservations,
    })
  } catch (error) {
    console.error('Dashboard API error:', error)
    return NextResponse.json({ error: 'Failed to load dashboard data' }, { status: 500 })
  }
}
