import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (isActive !== null) where.isActive = isActive === 'true'

    const roomTypes = await db.roomType.findMany({
      where,
      include: {
        _count: { select: { rooms: true, seasonalPricings: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ roomTypes })
  } catch (error) {
    console.error('Room Types API error:', error)
    return NextResponse.json({ error: 'Failed to load room types' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code || !body.hotelId || body.basePrice === undefined) {
      return NextResponse.json(
        { error: 'Name, code, hotelId, and basePrice are required' },
        { status: 400 }
      )
    }

    const roomType = await db.roomType.create({
      data: {
        name: body.name,
        code: body.code,
        hotelId: body.hotelId,
        basePrice: body.basePrice,
        maxOccupancy: body.maxOccupancy ?? 2,
        description: body.description,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ roomType }, { status: 201 })
  } catch (error) {
    console.error('Room Types POST error:', error)
    return NextResponse.json({ error: 'Failed to create room type' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Room type ID is required' }, { status: 400 })
    }

    const existing = await db.roomType.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room type not found' }, { status: 404 })
    }

    const roomType = await db.roomType.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        basePrice: body.basePrice,
        maxOccupancy: body.maxOccupancy,
        description: body.description,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ roomType })
  } catch (error) {
    console.error('Room Types PUT error:', error)
    return NextResponse.json({ error: 'Failed to update room type' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Room type ID is required' }, { status: 400 })
    }

    const existing = await db.roomType.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Room type not found' }, { status: 404 })
    }

    await db.roomType.delete({ where: { id } })

    return NextResponse.json({ message: 'Room type deleted successfully' })
  } catch (error) {
    console.error('Room Types DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete room type' }, { status: 500 })
  }
}
