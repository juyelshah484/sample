import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const promotions = await db.promotion.findMany({ orderBy: { createdAt: 'desc' } })
    return NextResponse.json({ promotions })
  } catch (error) {
    console.error('Marketing API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const item = await db.promotion.create({ data: body })
    return NextResponse.json({ item })
  } catch (error) {
    console.error('Marketing POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, ...data } = body
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    const item = await db.promotion.update({ where: { id }, data })
    return NextResponse.json({ item })
  } catch (error) {
    console.error('Marketing PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    await db.promotion.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Marketing DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
