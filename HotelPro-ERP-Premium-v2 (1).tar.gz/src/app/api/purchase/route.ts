import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'suppliers': {
        const suppliers = await db.supplier.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ suppliers })
      }
      case 'purchase-orders': {
        const pos = await db.purchaseOrder.findMany({
          include: { supplier: true, items: { include: { item: true } } },
          orderBy: { createdAt: 'desc' },
        })
        return NextResponse.json({ purchaseOrders: pos })
      }
      default: {
        const suppliers = await db.supplier.findMany({ orderBy: { name: 'asc' } })
        const pos = await db.purchaseOrder.findMany({ include: { supplier: true, items: true }, orderBy: { createdAt: 'desc' } })
        return NextResponse.json({ suppliers, purchaseOrders: pos })
      }
    }
  } catch (error) {
    console.error('Purchase API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'supplier': return NextResponse.json({ item: await db.supplier.create({ data }) })
      case 'purchase-order': {
        const { items, ...poData } = data
        const po = await db.purchaseOrder.create({ data: poData })
        if (items && items.length > 0) {
          await db.purchaseOrderItem.createMany({ data: items.map((it: any) => ({ ...it, purchaseOrderId: po.id })) })
        }
        return NextResponse.json({ item: po })
      }
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Purchase POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'supplier': return NextResponse.json({ item: await db.supplier.update({ where: { id }, data }) })
      case 'purchase-order': return NextResponse.json({ item: await db.purchaseOrder.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Purchase PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'supplier': await db.purchaseOrder.deleteMany({ where: { supplierId: id } }); await db.supplier.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'purchase-order': await db.purchaseOrderItem.deleteMany({ where: { purchaseOrderId: id } }); await db.purchaseOrder.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Purchase DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
