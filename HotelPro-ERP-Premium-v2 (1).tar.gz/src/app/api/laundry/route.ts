import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const orders = await db.laundryOrder.findMany({
      include: { guest: true, items: true },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({ orders })
  } catch (error) {
    console.error('Laundry API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { items, ...data } = body
    const order = await db.laundryOrder.create({ data })
    if (items && items.length > 0) {
      await db.laundryOrderItem.createMany({ data: items.map((it: any) => ({ ...it, orderId: order.id })) })
    }
    return NextResponse.json({ order })
  } catch (error) {
    console.error('Laundry POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, ...data } = body
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    const order = await db.laundryOrder.update({ where: { id }, data })
    return NextResponse.json({ order })
  } catch (error) {
    console.error('Laundry PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    await db.laundryOrderItem.deleteMany({ where: { orderId: id } })
    await db.laundryOrder.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Laundry DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
