import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const restaurantId = searchParams.get('restaurantId')
    const status = searchParams.get('status')
    const type = searchParams.get('type')
    const guestId = searchParams.get('guestId')

    const where: any = {}
    if (restaurantId) where.restaurantId = restaurantId
    if (status) where.status = status
    if (type) where.type = type
    if (guestId) where.guestId = guestId

    const orders = await db.order.findMany({
      where,
      include: {
        restaurant: true,
        items: { include: { menuItem: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    return NextResponse.json({ orders })
  } catch (error) {
    console.error('Orders API error:', error)
    return NextResponse.json({ error: 'Failed to load orders' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.restaurantId || !body.items || !Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json(
        { error: 'Restaurant ID and items array are required' },
        { status: 400 }
      )
    }

    // Calculate totals
    let totalAmount = 0
    for (const item of body.items) {
      totalAmount += item.price * item.quantity
    }

    const discount = body.discount ?? 0
    const taxAmount = body.taxAmount ?? totalAmount * 0.15

    // Generate order number
    const orderCount = await db.order.count()
    const orderNumber = `ORD-${String(orderCount + 1).padStart(6, '0')}`

    const order = await db.order.create({
      data: {
        restaurantId: body.restaurantId,
        reservationId: body.reservationId,
        guestId: body.guestId,
        tableId: body.tableId,
        orderNumber,
        type: body.type ?? 'dine_in',
        status: body.status ?? 'pending',
        totalAmount,
        discount,
        taxAmount,
        notes: body.notes,
        items: {
          create: body.items.map((item: any) => ({
            menuItemId: item.menuItemId,
            quantity: item.quantity ?? 1,
            price: item.price,
            notes: item.notes,
            status: 'pending',
          })),
        },
      },
      include: {
        restaurant: true,
        items: { include: { menuItem: true } },
      },
    })

    return NextResponse.json({ order }, { status: 201 })
  } catch (error) {
    console.error('Orders POST error:', error)
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Order ID is required' }, { status: 400 })
    }

    const existing = await db.order.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    const validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'served', 'cancelled']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const order = await db.order.update({
      where: { id: body.id },
      data: {
        status: body.status,
        notes: body.notes,
        totalAmount: body.totalAmount,
        discount: body.discount,
        taxAmount: body.taxAmount,
      },
      include: {
        restaurant: true,
        items: { include: { menuItem: true } },
      },
    })

    return NextResponse.json({ order })
  } catch (error) {
    console.error('Orders PUT error:', error)
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Order ID is required' }, { status: 400 })
    }

    const existing = await db.order.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    // Delete order items first
    await db.orderItem.deleteMany({ where: { orderId: id } })
    await db.order.delete({ where: { id } })

    return NextResponse.json({ message: 'Order deleted successfully' })
  } catch (error) {
    console.error('Orders DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete order' }, { status: 500 })
  }
}
