import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const buildingId = searchParams.get('buildingId')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (buildingId) where.buildingId = buildingId
    if (isActive !== null) where.isActive = isActive === 'true'

    const floors = await db.floor.findMany({
      where,
      include: {
        building: true,
        _count: { select: { rooms: true } },
      },
      orderBy: [{ number: 'asc' }],
    })

    return NextResponse.json({ floors })
  } catch (error) {
    console.error('Floors API error:', error)
    return NextResponse.json({ error: 'Failed to load floors' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || body.number === undefined || !body.buildingId || !body.hotelId) {
      return NextResponse.json(
        { error: 'Name, number, buildingId, and hotelId are required' },
        { status: 400 }
      )
    }

    const floor = await db.floor.create({
      data: {
        name: body.name,
        number: body.number,
        buildingId: body.buildingId,
        hotelId: body.hotelId,
        isActive: body.isActive ?? true,
      },
      include: { building: true },
    })

    return NextResponse.json({ floor }, { status: 201 })
  } catch (error) {
    console.error('Floors POST error:', error)
    return NextResponse.json({ error: 'Failed to create floor' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Floor ID is required' }, { status: 400 })
    }

    const existing = await db.floor.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Floor not found' }, { status: 404 })
    }

    const floor = await db.floor.update({
      where: { id: body.id },
      data: {
        name: body.name,
        number: body.number,
        buildingId: body.buildingId,
        hotelId: body.hotelId,
        isActive: body.isActive,
      },
      include: { building: true },
    })

    return NextResponse.json({ floor })
  } catch (error) {
    console.error('Floors PUT error:', error)
    return NextResponse.json({ error: 'Failed to update floor' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Floor ID is required' }, { status: 400 })
    }

    const existing = await db.floor.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Floor not found' }, { status: 404 })
    }

    await db.floor.delete({ where: { id } })

    return NextResponse.json({ message: 'Floor deleted successfully' })
  } catch (error) {
    console.error('Floors DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete floor' }, { status: 500 })
  }
}
