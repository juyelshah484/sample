import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const department = searchParams.get('department')
    const status = searchParams.get('status')
    const hotelId = searchParams.get('hotelId')
    const search = searchParams.get('search')

    const where: any = {}
    if (department) where.department = department
    if (status) where.status = status
    if (hotelId) where.hotelId = hotelId
    if (search) {
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { employeeId: { contains: search } },
        { email: { contains: search } },
      ]
    }

    const employees = await db.employee.findMany({
      where,
      include: {
        _count: { select: { attendance: true, leaves: true, payrollRecords: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const departments = await db.employee.groupBy({
      by: ['department'],
      _count: { id: true },
    })

    const stats = {
      total: employees.length,
      active: employees.filter(e => e.status === 'active').length,
      onLeave: employees.filter(e => e.status === 'on_leave').length,
      departments: departments.length,
    }

    return NextResponse.json({ employees, departments, stats })
  } catch (error) {
    console.error('Employees API error:', error)
    return NextResponse.json({ error: 'Failed to load employees' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.firstName || !body.lastName || !body.employeeId) {
      return NextResponse.json(
        { error: 'HotelId, firstName, lastName, and employeeId are required' },
        { status: 400 }
      )
    }

    // Check for unique employeeId
    const existing = await db.employee.findUnique({ where: { employeeId: body.employeeId } })
    if (existing) {
      return NextResponse.json(
        { error: 'Employee ID already exists' },
        { status: 400 }
      )
    }

    const validStatuses = ['active', 'on_leave', 'terminated', 'resigned']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const employee = await db.employee.create({
      data: {
        hotelId: body.hotelId,
        employeeId: body.employeeId,
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        department: body.department,
        position: body.position,
        joinDate: body.joinDate ? new Date(body.joinDate) : null,
        salary: body.salary ?? 0,
        status: body.status ?? 'active',
        address: body.address,
        emergencyContact: body.emergencyContact,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ employee }, { status: 201 })
  } catch (error) {
    console.error('Employees POST error:', error)
    return NextResponse.json({ error: 'Failed to create employee' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Employee ID is required' }, { status: 400 })
    }

    const existing = await db.employee.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Employee not found' }, { status: 404 })
    }

    const validStatuses = ['active', 'on_leave', 'terminated', 'resigned']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const employee = await db.employee.update({
      where: { id: body.id },
      data: {
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        department: body.department,
        position: body.position,
        joinDate: body.joinDate ? new Date(body.joinDate) : undefined,
        salary: body.salary,
        status: body.status,
        address: body.address,
        emergencyContact: body.emergencyContact,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ employee })
  } catch (error) {
    console.error('Employees PUT error:', error)
    return NextResponse.json({ error: 'Failed to update employee' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Employee ID is required' }, { status: 400 })
    }

    const existing = await db.employee.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Employee not found' }, { status: 404 })
    }

    await db.attendance.deleteMany({ where: { employeeId: id } })
    await db.leave.deleteMany({ where: { employeeId: id } })
    await db.payrollRecord.deleteMany({ where: { employeeId: id } })
    await db.employee.delete({ where: { id } })

    return NextResponse.json({ message: 'Employee deleted successfully' })
  } catch (error) {
    console.error('Employees DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete employee' }, { status: 500 })
  }
}
