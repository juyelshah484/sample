import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (isActive !== null) where.isActive = isActive === 'true'

    const bedTypes = await db.bedType.findMany({
      where,
      include: {
        _count: { select: { rooms: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ bedTypes })
  } catch (error) {
    console.error('Bed Types API error:', error)
    return NextResponse.json({ error: 'Failed to load bed types' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code) {
      return NextResponse.json(
        { error: 'Name and code are required' },
        { status: 400 }
      )
    }

    const bedType = await db.bedType.create({
      data: {
        name: body.name,
        code: body.code,
        size: body.size,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ bedType }, { status: 201 })
  } catch (error) {
    console.error('Bed Types POST error:', error)
    return NextResponse.json({ error: 'Failed to create bed type' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Bed type ID is required' }, { status: 400 })
    }

    const existing = await db.bedType.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Bed type not found' }, { status: 404 })
    }

    const bedType = await db.bedType.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        size: body.size,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ bedType })
  } catch (error) {
    console.error('Bed Types PUT error:', error)
    return NextResponse.json({ error: 'Failed to update bed type' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Bed type ID is required' }, { status: 400 })
    }

    const existing = await db.bedType.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Bed type not found' }, { status: 404 })
    }

    await db.bedType.delete({ where: { id } })

    return NextResponse.json({ message: 'Bed type deleted successfully' })
  } catch (error) {
    console.error('Bed Types DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete bed type' }, { status: 500 })
  }
}
