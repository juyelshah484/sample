import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const action = searchParams.get('action')
    const moduleFilter = searchParams.get('module')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const limit = parseInt(searchParams.get('limit') || '100')
    const offset = parseInt(searchParams.get('offset') || '0')

    const where: any = {}
    if (userId) where.userId = userId
    if (action) where.action = action
    if (moduleFilter) where.module = moduleFilter
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) where.createdAt.gte = new Date(startDate)
      if (endDate) where.createdAt.lte = new Date(endDate)
    }

    const [auditLogs, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.auditLog.count({ where }),
    ])

    const byModule = auditLogs.reduce((acc: any, log) => {
      acc[log.module] = (acc[log.module] || 0) + 1
      return acc
    }, {})

    const byAction = auditLogs.reduce((acc: any, log) => {
      acc[log.action] = (acc[log.action] || 0) + 1
      return acc
    }, {})

    return NextResponse.json({
      auditLogs,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
      summary: { byModule, byAction },
    })
  } catch (error) {
    console.error('Audit Logs API error:', error)
    return NextResponse.json({ error: 'Failed to load audit logs' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.action || !body.module) {
      return NextResponse.json(
        { error: 'Action and module are required' },
        { status: 400 }
      )
    }

    const auditLog = await db.auditLog.create({
      data: {
        userId: body.userId,
        action: body.action,
        module: body.module,
        details: body.details,
        ipAddress: body.ipAddress,
      },
    })

    return NextResponse.json({ auditLog }, { status: 201 })
  } catch (error) {
    console.error('Audit Logs POST error:', error)
    return NextResponse.json({ error: 'Failed to create audit log' }, { status: 500 })
  }
}
