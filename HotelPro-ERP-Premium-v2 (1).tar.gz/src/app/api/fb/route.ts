import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'restaurants': {
        const restaurants = await db.restaurant.findMany({ include: { tables: true, menuItems: true }, orderBy: { name: 'asc' } })
        return NextResponse.json({ restaurants })
      }
      case 'orders': {
        const orders = await db.order.findMany({
          include: { restaurant: true, items: { include: { menuItem: true } } },
          orderBy: { createdAt: 'desc' }, take: 50,
        })
        return NextResponse.json({ orders })
      }
      case 'menu-items': {
        const items = await db.menuItem.findMany({ include: { restaurant: true }, orderBy: { name: 'asc' } })
        return NextResponse.json({ items })
      }
      case 'tables': {
        const tables = await db.restaurantTable.findMany({ include: { restaurant: true }, orderBy: { number: 'asc' } })
        return NextResponse.json({ tables })
      }
      default: {
        const restaurants = await db.restaurant.findMany({ include: { tables: true, menuItems: true } })
        const orders = await db.order.findMany({ include: { restaurant: true, items: { include: { menuItem: true } } }, orderBy: { createdAt: 'desc' }, take: 30 })
        return NextResponse.json({ restaurants, orders })
      }
    }
  } catch (error) {
    console.error('F&B API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body

    switch (resource) {
      case 'restaurant': return NextResponse.json({ item: await db.restaurant.create({ data }) })
      case 'menu-item': return NextResponse.json({ item: await db.menuItem.create({ data }) })
      case 'table': return NextResponse.json({ item: await db.restaurantTable.create({ data }) })
      case 'order': {
        const { items, ...orderData } = data
        const orderNum = 'ORD-' + Date.now().toString(36).toUpperCase()
        const order = await db.order.create({ data: { ...orderData, orderNumber: orderNum } })
        if (items && items.length > 0) {
          await db.orderItem.createMany({ data: items.map((it: any) => ({ ...it, orderId: order.id })) })
        }
        return NextResponse.json({ order })
      }
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('F&B POST error:', error)
    return NextResponse.json({ error: 'Failed to create resource' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'restaurant': return NextResponse.json({ item: await db.restaurant.update({ where: { id }, data }) })
      case 'menu-item': return NextResponse.json({ item: await db.menuItem.update({ where: { id }, data }) })
      case 'table': return NextResponse.json({ item: await db.restaurantTable.update({ where: { id }, data }) })
      case 'order': return NextResponse.json({ item: await db.order.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('F&B PUT error:', error)
    return NextResponse.json({ error: 'Failed to update resource' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'restaurant': await db.restaurant.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'menu-item': await db.menuItem.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'table': await db.restaurantTable.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'order': await db.orderItem.deleteMany({ where: { orderId: id } }); await db.order.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('F&B DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete resource' }, { status: 500 })
  }
}
