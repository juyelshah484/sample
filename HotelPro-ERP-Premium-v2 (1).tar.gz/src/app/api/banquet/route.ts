import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'halls': {
        const halls = await db.banquetHall.findMany({ include: { events: true }, orderBy: { name: 'asc' } })
        return NextResponse.json({ halls })
      }
      case 'events': {
        const events = await db.event.findMany({ include: { hall: true }, orderBy: { startDate: 'desc' } })
        return NextResponse.json({ events })
      }
      default: {
        const halls = await db.banquetHall.findMany({ include: { events: true }, orderBy: { name: 'asc' } })
        const events = await db.event.findMany({ include: { hall: true }, orderBy: { startDate: 'desc' } })
        return NextResponse.json({ halls, events })
      }
    }
  } catch (error) {
    console.error('Banquet API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'hall': return NextResponse.json({ item: await db.banquetHall.create({ data }) })
      case 'event': return NextResponse.json({ item: await db.event.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Banquet POST error:', error)
    return NextResponse.json({ error: 'Failed to create resource' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'hall': return NextResponse.json({ item: await db.banquetHall.update({ where: { id }, data }) })
      case 'event': return NextResponse.json({ item: await db.event.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Banquet PUT error:', error)
    return NextResponse.json({ error: 'Failed to update resource' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'hall': await db.event.deleteMany({ where: { hallId: id } }); await db.banquetHall.delete({ where: { id } }); return NextResponse.json({ success: true })
      case 'event': await db.event.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Banquet DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete resource' }, { status: 500 })
  }
}
