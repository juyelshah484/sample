import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const type = searchParams.get('type')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (type) where.type = type
    if (isActive !== null) where.isActive = isActive === 'true'

    const restaurants = await db.restaurant.findMany({
      where,
      include: {
        tables: true,
        menuItems: { where: { isAvailable: true } },
        _count: { select: { orders: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ restaurants })
  } catch (error) {
    console.error('Restaurants API error:', error)
    return NextResponse.json({ error: 'Failed to load restaurants' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.code || !body.hotelId) {
      return NextResponse.json(
        { error: 'Name, code, and hotelId are required' },
        { status: 400 }
      )
    }

    const restaurant = await db.restaurant.create({
      data: {
        name: body.name,
        code: body.code,
        hotelId: body.hotelId,
        type: body.type ?? 'restaurant',
        capacity: body.capacity ?? 50,
        isActive: body.isActive ?? true,
      },
      include: { tables: true, menuItems: true },
    })

    // Create tables if provided
    if (body.tables && Array.isArray(body.tables)) {
      for (const table of body.tables) {
        await db.restaurantTable.create({
          data: {
            restaurantId: restaurant.id,
            number: table.number,
            capacity: table.capacity ?? 4,
            isActive: true,
          },
        })
      }
    }

    // Create menu items if provided
    if (body.menuItems && Array.isArray(body.menuItems)) {
      for (const item of body.menuItems) {
        await db.menuItem.create({
          data: {
            restaurantId: restaurant.id,
            name: item.name,
            description: item.description,
            category: item.category,
            price: item.price,
            isVeg: item.isVeg ?? false,
            isAvailable: item.isAvailable ?? true,
            preparationTime: item.preparationTime,
            image: item.image,
          },
        })
      }
    }

    // Re-fetch with all relations
    const result = await db.restaurant.findUnique({
      where: { id: restaurant.id },
      include: { tables: true, menuItems: true },
    })

    return NextResponse.json({ restaurant: result }, { status: 201 })
  } catch (error) {
    console.error('Restaurants POST error:', error)
    return NextResponse.json({ error: 'Failed to create restaurant' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Restaurant ID is required' }, { status: 400 })
    }

    const existing = await db.restaurant.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Restaurant not found' }, { status: 404 })
    }

    const restaurant = await db.restaurant.update({
      where: { id: body.id },
      data: {
        name: body.name,
        code: body.code,
        type: body.type,
        capacity: body.capacity,
        isActive: body.isActive,
      },
      include: { tables: true, menuItems: true },
    })

    return NextResponse.json({ restaurant })
  } catch (error) {
    console.error('Restaurants PUT error:', error)
    return NextResponse.json({ error: 'Failed to update restaurant' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Restaurant ID is required' }, { status: 400 })
    }

    const existing = await db.restaurant.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Restaurant not found' }, { status: 404 })
    }

    await db.restaurant.delete({ where: { id } })

    return NextResponse.json({ message: 'Restaurant deleted successfully' })
  } catch (error) {
    console.error('Restaurants DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete restaurant' }, { status: 500 })
  }
}
