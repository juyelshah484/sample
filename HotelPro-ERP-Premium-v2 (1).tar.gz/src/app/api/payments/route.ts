import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const reservationId = searchParams.get('reservationId')
    const guestId = searchParams.get('guestId')
    const method = searchParams.get('method')
    const status = searchParams.get('status')
    const folioId = searchParams.get('folioId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    const where: any = {}
    if (reservationId) where.reservationId = reservationId
    if (guestId) where.guestId = guestId
    if (method) where.method = method
    if (status) where.status = status
    if (folioId) where.folioId = folioId
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) where.createdAt.gte = new Date(startDate)
      if (endDate) where.createdAt.lte = new Date(endDate)
    }

    const payments = await db.payment.findMany({
      where,
      include: {
        reservation: { include: { guest: true } },
        folio: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    const totalAmount = payments.reduce((sum, p) => sum + p.amount, 0)
    const byMethod = payments.reduce((acc: any, p) => {
      acc[p.method] = (acc[p.method] || 0) + p.amount
      return acc
    }, {})

    return NextResponse.json({ payments, totalAmount, byMethod })
  } catch (error) {
    console.error('Payments API error:', error)
    return NextResponse.json({ error: 'Failed to load payments' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.reservationId || body.amount === undefined || !body.method) {
      return NextResponse.json(
        { error: 'ReservationId, amount, and method are required' },
        { status: 400 }
      )
    }

    const validMethods = ['cash', 'card', 'bKash', 'nagad', 'rocket', 'sslcommerz', 'stripe', 'paypal', 'bank_transfer']
    if (!validMethods.includes(body.method)) {
      return NextResponse.json(
        { error: `Invalid method. Must be one of: ${validMethods.join(', ')}` },
        { status: 400 }
      )
    }

    const validStatuses = ['pending', 'completed', 'failed', 'refunded']
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` },
        { status: 400 }
      )
    }

    const payment = await db.payment.create({
      data: {
        reservationId: body.reservationId,
        folioId: body.folioId,
        guestId: body.guestId,
        amount: body.amount,
        method: body.method,
        currency: body.currency ?? 'BDT',
        transactionRef: body.transactionRef,
        status: body.status ?? 'completed',
        processedBy: body.processedBy,
        notes: body.notes,
      },
      include: {
        reservation: true,
        folio: true,
      },
    })

    // Update folio paid amount and balance if folioId is provided
    if (body.folioId && payment.status === 'completed') {
      const folio = await db.folio.findUnique({ where: { id: body.folioId } })
      if (folio) {
        const newPaidAmount = folio.paidAmount + body.amount
        await db.folio.update({
          where: { id: body.folioId },
          data: {
            paidAmount: newPaidAmount,
            balance: folio.totalAmount - newPaidAmount,
          },
        })
      }
    }

    return NextResponse.json({ payment }, { status: 201 })
  } catch (error) {
    console.error('Payments POST error:', error)
    return NextResponse.json({ error: 'Failed to create payment' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Payment ID is required' }, { status: 400 })
    }

    const existing = await db.payment.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
    }

    const payment = await db.payment.update({
      where: { id: body.id },
      data: {
        status: body.status,
        transactionRef: body.transactionRef,
        notes: body.notes,
      },
      include: {
        reservation: true,
        folio: true,
      },
    })

    return NextResponse.json({ payment })
  } catch (error) {
    console.error('Payments PUT error:', error)
    return NextResponse.json({ error: 'Failed to update payment' }, { status: 500 })
  }
}
