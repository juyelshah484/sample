import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const hotelId = searchParams.get('hotelId')
    const search = searchParams.get('search')
    const loyaltyTier = searchParams.get('loyaltyTier')
    const blacklist = searchParams.get('blacklist')

    const where: any = {}
    if (type) where.guestType = type
    if (hotelId) where.hotelId = hotelId
    if (loyaltyTier) where.loyaltyTier = loyaltyTier
    if (blacklist !== null) where.blacklist = blacklist === 'true'
    if (search) {
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
        { nationalId: { contains: search } },
        { passportNumber: { contains: search } },
      ]
    }

    const guests = await db.guest.findMany({
      where,
      include: {
        _count: { select: { reservations: true, feedbacks: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    return NextResponse.json({ guests })
  } catch (error) {
    console.error('Guests API error:', error)
    return NextResponse.json({ error: 'Failed to load guests' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.hotelId || !body.firstName || !body.lastName) {
      return NextResponse.json(
        { error: 'HotelId, firstName, and lastName are required' },
        { status: 400 }
      )
    }

    const validGuestTypes = ['individual', 'corporate', 'vip', 'frequent', 'loyalty', 'family', 'blacklist']
    if (body.guestType && !validGuestTypes.includes(body.guestType)) {
      return NextResponse.json(
        { error: `Invalid guestType. Must be one of: ${validGuestTypes.join(', ')}` },
        { status: 400 }
      )
    }

    const validLoyaltyTiers = ['standard', 'silver', 'gold', 'platinum', 'diamond']
    if (body.loyaltyTier && !validLoyaltyTiers.includes(body.loyaltyTier)) {
      return NextResponse.json(
        { error: `Invalid loyaltyTier. Must be one of: ${validLoyaltyTiers.join(', ')}` },
        { status: 400 }
      )
    }

    const guest = await db.guest.create({
      data: {
        hotelId: body.hotelId,
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        nationality: body.nationality,
        passportNumber: body.passportNumber,
        nationalId: body.nationalId,
        visaNumber: body.visaNumber,
        visaExpiry: body.visaExpiry ? new Date(body.visaExpiry) : null,
        dateOfBirth: body.dateOfBirth ? new Date(body.dateOfBirth) : null,
        gender: body.gender,
        address: body.address,
        city: body.city,
        country: body.country,
        postalCode: body.postalCode,
        company: body.company,
        occupation: body.occupation,
        guestType: body.guestType ?? 'individual',
        loyaltyTier: body.loyaltyTier ?? 'standard',
        loyaltyPoints: body.loyaltyPoints ?? 0,
        preferences: body.preferences,
        notes: body.notes,
        blacklist: body.blacklist ?? false,
        blacklistReason: body.blacklistReason,
        isActive: body.isActive ?? true,
      },
    })

    return NextResponse.json({ guest }, { status: 201 })
  } catch (error) {
    console.error('Guests POST error:', error)
    return NextResponse.json({ error: 'Failed to create guest' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Guest ID is required' }, { status: 400 })
    }

    const existing = await db.guest.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Guest not found' }, { status: 404 })
    }

    const guest = await db.guest.update({
      where: { id: body.id },
      data: {
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        nationality: body.nationality,
        passportNumber: body.passportNumber,
        nationalId: body.nationalId,
        visaNumber: body.visaNumber,
        visaExpiry: body.visaExpiry ? new Date(body.visaExpiry) : undefined,
        dateOfBirth: body.dateOfBirth ? new Date(body.dateOfBirth) : undefined,
        gender: body.gender,
        address: body.address,
        city: body.city,
        country: body.country,
        postalCode: body.postalCode,
        company: body.company,
        occupation: body.occupation,
        guestType: body.guestType,
        loyaltyTier: body.loyaltyTier,
        loyaltyPoints: body.loyaltyPoints,
        preferences: body.preferences,
        notes: body.notes,
        blacklist: body.blacklist,
        blacklistReason: body.blacklistReason,
        totalStays: body.totalStays,
        totalSpent: body.totalSpent,
        lastStayDate: body.lastStayDate ? new Date(body.lastStayDate) : undefined,
        isActive: body.isActive,
      },
    })

    return NextResponse.json({ guest })
  } catch (error) {
    console.error('Guests PUT error:', error)
    return NextResponse.json({ error: 'Failed to update guest' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Guest ID is required' }, { status: 400 })
    }

    const existing = await db.guest.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Guest not found' }, { status: 404 })
    }

    await db.guest.delete({ where: { id } })

    return NextResponse.json({ message: 'Guest deleted successfully' })
  } catch (error) {
    console.error('Guests DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete guest' }, { status: 500 })
  }
}
