import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')

    switch (resource) {
      case 'assets': {
        const assets = await db.asset.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ assets })
      }
      case 'maintenance-records': {
        const records = await db.maintenanceRecord.findMany({
          include: { asset: true },
          orderBy: { createdAt: 'desc' },
        })
        return NextResponse.json({ records })
      }
      default: {
        const assets = await db.asset.findMany({ orderBy: { name: 'asc' } })
        return NextResponse.json({ assets })
      }
    }
  } catch (error) {
    console.error('Assets API error:', error)
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { resource, data } = body
    switch (resource) {
      case 'asset': return NextResponse.json({ item: await db.asset.create({ data }) })
      case 'maintenance-record': return NextResponse.json({ item: await db.maintenanceRecord.create({ data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Assets POST error:', error)
    return NextResponse.json({ error: 'Failed to create' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { resource, id, data } = body
    switch (resource) {
      case 'asset': return NextResponse.json({ item: await db.asset.update({ where: { id }, data }) })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Assets PUT error:', error)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const resource = searchParams.get('resource')
    const id = searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })
    switch (resource) {
      case 'asset': await db.maintenanceRecord.deleteMany({ where: { assetId: id } }); await db.asset.delete({ where: { id } }); return NextResponse.json({ success: true })
      default: return NextResponse.json({ error: 'Unknown resource' }, { status: 400 })
    }
  } catch (error) {
    console.error('Assets DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
