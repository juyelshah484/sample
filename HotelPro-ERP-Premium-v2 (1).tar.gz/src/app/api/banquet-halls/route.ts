import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get('hotelId')
    const isActive = searchParams.get('isActive')

    const where: any = {}
    if (hotelId) where.hotelId = hotelId
    if (isActive !== null) where.isActive = isActive === 'true'

    const banquetHalls = await db.banquetHall.findMany({
      where,
      include: {
        events: {
          include: {
            hall: true,
          },
          orderBy: { startDate: 'desc' },
        },
        _count: { select: { events: true } },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ banquetHalls })
  } catch (error) {
    console.error('Banquet Halls API error:', error)
    return NextResponse.json({ error: 'Failed to load banquet halls' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (!body.name || !body.hotelId || body.capacity === undefined || body.pricePerHour === undefined) {
      return NextResponse.json(
        { error: 'Name, hotelId, capacity, and pricePerHour are required' },
        { status: 400 }
      )
    }

    const banquetHall = await db.banquetHall.create({
      data: {
        hotelId: body.hotelId,
        name: body.name,
        capacity: body.capacity,
        pricePerHour: body.pricePerHour,
        amenities: body.amenities,
        isActive: body.isActive ?? true,
      },
    })

    // Create event if provided
    if (body.event) {
      await db.event.create({
        data: {
          hotelId: body.hotelId,
          hallId: banquetHall.id,
          guestId: body.event.guestId,
          title: body.event.title,
          type: body.event.type ?? 'conference',
          startDate: new Date(body.event.startDate),
          endDate: new Date(body.event.endDate),
          expectedGuests: body.event.expectedGuests,
          catering: body.event.catering ?? false,
          decoration: body.event.decoration ?? false,
          soundSystem: body.event.soundSystem ?? false,
          totalAmount: body.event.totalAmount ?? 0,
          paidAmount: body.event.paidAmount ?? 0,
          status: body.event.status ?? 'confirmed',
          notes: body.event.notes,
        },
      })
    }

    const result = await db.banquetHall.findUnique({
      where: { id: banquetHall.id },
      include: { events: true },
    })

    return NextResponse.json({ banquetHall: result }, { status: 201 })
  } catch (error) {
    console.error('Banquet Halls POST error:', error)
    return NextResponse.json({ error: 'Failed to create banquet hall' }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()

    if (!body.id) {
      return NextResponse.json({ error: 'Banquet hall ID is required' }, { status: 400 })
    }

    const existing = await db.banquetHall.findUnique({ where: { id: body.id } })
    if (!existing) {
      return NextResponse.json({ error: 'Banquet hall not found' }, { status: 404 })
    }

    const banquetHall = await db.banquetHall.update({
      where: { id: body.id },
      data: {
        name: body.name,
        capacity: body.capacity,
        pricePerHour: body.pricePerHour,
        amenities: body.amenities,
        isActive: body.isActive,
      },
      include: { events: true },
    })

    return NextResponse.json({ banquetHall })
  } catch (error) {
    console.error('Banquet Halls PUT error:', error)
    return NextResponse.json({ error: 'Failed to update banquet hall' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Banquet hall ID is required' }, { status: 400 })
    }

    const existing = await db.banquetHall.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Banquet hall not found' }, { status: 404 })
    }

    await db.event.deleteMany({ where: { hallId: id } })
    await db.banquetHall.delete({ where: { id } })

    return NextResponse.json({ message: 'Banquet hall deleted successfully' })
  } catch (error) {
    console.error('Banquet Halls DELETE error:', error)
    return NextResponse.json({ error: 'Failed to delete banquet hall' }, { status: 500 })
  }
}
