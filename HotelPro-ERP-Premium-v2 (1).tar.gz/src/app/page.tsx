'use client'

import React, { useState, useEffect } from 'react'
import { useHotelStore, type ModuleId } from '@/store/hotel-store'
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton,
  SidebarMenuItem, SidebarRail, SidebarSeparator, SidebarTrigger,
} from '@/components/ui/sidebar'
import {
  LayoutDashboard, Hotel, DoorOpen, CalendarCheck, UserCheck, Users, Sparkles,
  UtensilsCrossed, PartyPopper, Flower2, WashingMachine, Package, ShoppingCart,
  Wallet, Receipt, UserCog, Wrench, Shield, Gift, Megaphone, Globe, Radio,
  CreditCard, Lock, BarChart3, Smartphone, FileText, Bell, Plug, Settings,
  ChevronDown, ChevronRight, Building2, Search, BellRing, RefreshCw,
  Crown, Star, HotelIcon,
} from 'lucide-react'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible'

// Module imports
import DashboardModule from '@/components/hotel/modules/dashboard'
import HotelSetupModule from '@/components/hotel/modules/hotel-setup'
import RoomManagementModule from '@/components/hotel/modules/room-management'
import ReservationModule from '@/components/hotel/modules/reservation'
import FrontOfficeModule from '@/components/hotel/modules/front-office'
import GuestCrmModule from '@/components/hotel/modules/guest-crm'
import HousekeepingModule from '@/components/hotel/modules/housekeeping'
import RestaurantPosModule from '@/components/hotel/modules/restaurant-pos'
import BanquetModule from '@/components/hotel/modules/banquet'
import SpaModule from '@/components/hotel/modules/spa'
import LaundryModule from '@/components/hotel/modules/laundry'
import InventoryModule from '@/components/hotel/modules/inventory'
import PurchaseModule from '@/components/hotel/modules/purchase'
import FinanceModule from '@/components/hotel/modules/finance'
import BillingModule from '@/components/hotel/modules/billing'
import HrModule from '@/components/hotel/modules/hr'
import AssetModule from '@/components/hotel/modules/asset'
import MaintenanceModule from '@/components/hotel/modules/maintenance'
import LoyaltyModule from '@/components/hotel/modules/loyalty'
import MarketingModule from '@/components/hotel/modules/marketing'
import OnlineBookingModule from '@/components/hotel/modules/online-booking'
import OtaModule from '@/components/hotel/modules/ota'
import PaymentModule from '@/components/hotel/modules/payment'
import SecurityModule from '@/components/hotel/modules/security'
import ReportsModule from '@/components/hotel/modules/reports'
import OtherModules from '@/components/hotel/modules/other'

// ============ MODULE CONFIGURATION ============
interface ModuleConfig {
  id: ModuleId
  label: string
  icon: React.ElementType
  subModules: { id: string; label: string }[]
}

const modules: ModuleConfig[] = [
  { id: 'dashboard', label: 'Dashboard & BI', icon: LayoutDashboard, subModules: [
    { id: 'overview', label: 'Executive Dashboard' },
    { id: 'occupancy', label: 'Occupancy Dashboard' },
    { id: 'revenue', label: 'Revenue Dashboard' },
    { id: 'daily-status', label: 'Daily Hotel Status' },
    { id: 'kpi', label: 'KPI Dashboard' },
  ]},
  { id: 'hotel-setup', label: 'Hotel Setup', icon: Hotel, subModules: [
    { id: 'hotel-info', label: 'Hotel Information' },
    { id: 'buildings', label: 'Building & Floor' },
    { id: 'room-types', label: 'Room Type' },
    { id: 'room-categories', label: 'Room Category' },
    { id: 'bed-types', label: 'Bed Type' },
    { id: 'room-views', label: 'Room View' },
    { id: 'amenities', label: 'Amenities Setup' },
    { id: 'pricing', label: 'Seasonal/Weekend Pricing' },
    { id: 'tax', label: 'Tax & VAT Setup' },
  ]},
  { id: 'room-management', label: 'Room Management', icon: DoorOpen, subModules: [
    { id: 'room-master', label: 'Room Master' },
    { id: 'availability', label: 'Room Availability' },
    { id: 'blocking', label: 'Room Blocking' },
    { id: 'maintenance-rooms', label: 'Room Maintenance' },
    { id: 'inspection', label: 'Room Inspection' },
    { id: 'transfer', label: 'Room Transfer/Upgrade' },
  ]},
  { id: 'reservation', label: 'Reservation', icon: CalendarCheck, subModules: [
    { id: 'all-reservations', label: 'All Reservations' },
    { id: 'direct-booking', label: 'Direct Booking' },
    { id: 'online-booking', label: 'Online Booking' },
    { id: 'walk-in', label: 'Walk-in Booking' },
    { id: 'corporate-booking', label: 'Corporate Booking' },
    { id: 'group-booking', label: 'Group Booking' },
    { id: 'waitlist', label: 'Wait List' },
    { id: 'cancellation', label: 'Cancellation' },
  ]},
  { id: 'front-office', label: 'Front Office', icon: UserCheck, subModules: [
    { id: 'check-in', label: 'Guest Check-in' },
    { id: 'quick-checkin', label: 'Quick Check-in' },
    { id: 'check-out', label: 'Guest Check-out' },
    { id: 'room-change', label: 'Room Change' },
    { id: 'guest-folio', label: 'Guest Folio' },
    { id: 'guest-registration', label: 'Guest Registration' },
  ]},
  { id: 'guest-management', label: 'Guest CRM', icon: Users, subModules: [
    { id: 'guest-list', label: 'Guest List' },
    { id: 'vip-guests', label: 'VIP Guests' },
    { id: 'corporate-guests', label: 'Corporate Guests' },
    { id: 'loyalty-members', label: 'Loyalty Members' },
    { id: 'blacklist', label: 'Blacklist' },
    { id: 'feedback', label: 'Guest Feedback' },
    { id: 'complaints', label: 'Complaints' },
    { id: 'preferences', label: 'Guest Preferences' },
  ]},
  { id: 'housekeeping', label: 'Housekeeping', icon: Sparkles, subModules: [
    { id: 'dashboard', label: 'HK Dashboard' },
    { id: 'cleaning', label: 'Room Cleaning' },
    { id: 'inspection', label: 'Room Inspection' },
    { id: 'linen', label: 'Linen Management' },
    { id: 'lost-found', label: 'Lost & Found' },
    { id: 'schedule', label: 'Cleaning Schedule' },
  ]},
  { id: 'restaurant', label: 'F&B / Restaurant POS', icon: UtensilsCrossed, subModules: [
    { id: 'pos', label: 'Restaurant POS' },
    { id: 'table-reservation', label: 'Table Reservation' },
    { id: 'qr-menu', label: 'QR Menu' },
    { id: 'kot', label: 'Kitchen Order Ticket' },
    { id: 'room-service', label: 'Room Service' },
    { id: 'bar-pos', label: 'Bar POS' },
  ]},
  { id: 'banquet', label: 'Banquet & Events', icon: PartyPopper, subModules: [
    { id: 'hall-booking', label: 'Hall Booking' },
    { id: 'events', label: 'Event Calendar' },
    { id: 'packages', label: 'Event Packages' },
    { id: 'catering', label: 'Catering' },
    { id: 'decoration', label: 'Decoration' },
  ]},
  { id: 'spa', label: 'Spa & Wellness', icon: Flower2, subModules: [
    { id: 'spa-booking', label: 'Spa Booking' },
    { id: 'therapist', label: 'Therapist Management' },
    { id: 'gym', label: 'Gym Membership' },
    { id: 'wellness-packages', label: 'Wellness Packages' },
  ]},
  { id: 'laundry', label: 'Laundry', icon: WashingMachine, subModules: [
    { id: 'guest-laundry', label: 'Guest Laundry' },
    { id: 'internal-laundry', label: 'Internal Laundry' },
    { id: 'linen-stock', label: 'Linen Stock' },
    { id: 'laundry-status', label: 'Laundry Status' },
  ]},
  { id: 'inventory', label: 'Inventory', icon: Package, subModules: [
    { id: 'items', label: 'Item Master' },
    { id: 'stock-levels', label: 'Stock Levels' },
    { id: 'stock-in', label: 'Stock In' },
    { id: 'stock-out', label: 'Stock Out' },
    { id: 'transfer', label: 'Stock Transfer' },
    { id: 'audit', label: 'Stock Audit' },
  ]},
  { id: 'purchase', label: 'Purchase', icon: ShoppingCart, subModules: [
    { id: 'suppliers', label: 'Supplier Management' },
    { id: 'requisition', label: 'Purchase Requisition' },
    { id: 'purchase-order', label: 'Purchase Order' },
    { id: 'goods-receive', label: 'Goods Receive' },
    { id: 'supplier-ledger', label: 'Supplier Ledger' },
  ]},
  { id: 'finance', label: 'Accounts & Finance', icon: Wallet, subModules: [
    { id: 'chart-of-accounts', label: 'Chart of Accounts' },
    { id: 'general-ledger', label: 'General Ledger' },
    { id: 'cash-bank', label: 'Cash & Bank' },
    { id: 'receivable', label: 'Accounts Receivable' },
    { id: 'payable', label: 'Accounts Payable' },
    { id: 'journal', label: 'Journal Voucher' },
    { id: 'trial-balance', label: 'Trial Balance' },
    { id: 'profit-loss', label: 'Profit & Loss' },
    { id: 'balance-sheet', label: 'Balance Sheet' },
  ]},
  { id: 'billing', label: 'Billing & Invoice', icon: Receipt, subModules: [
    { id: 'room-billing', label: 'Room Billing' },
    { id: 'restaurant-billing', label: 'Restaurant Billing' },
    { id: 'spa-billing', label: 'Spa Billing' },
    { id: 'invoice-list', label: 'Invoice List' },
    { id: 'refund', label: 'Refund & Credit Note' },
  ]},
  { id: 'hr', label: 'HR & Payroll', icon: UserCog, subModules: [
    { id: 'employees', label: 'Employee Management' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'leave', label: 'Leave Management' },
    { id: 'payroll', label: 'Payroll' },
    { id: 'performance', label: 'Performance' },
    { id: 'recruitment', label: 'Recruitment' },
  ]},
  { id: 'asset', label: 'Asset Management', icon: Building2, subModules: [
    { id: 'asset-register', label: 'Asset Register' },
    { id: 'allocation', label: 'Asset Allocation' },
    { id: 'depreciation', label: 'Depreciation' },
    { id: 'audit', label: 'Asset Audit' },
  ]},
  { id: 'maintenance', label: 'Maintenance', icon: Wrench, subModules: [
    { id: 'complaints', label: 'Complaints' },
    { id: 'work-orders', label: 'Work Orders' },
    { id: 'preventive', label: 'Preventive Maintenance' },
    { id: 'calendar', label: 'Maintenance Calendar' },
  ]},
  { id: 'loyalty', label: 'Loyalty Program', icon: Gift, subModules: [
    { id: 'members', label: 'Membership' },
    { id: 'points', label: 'Reward Points' },
    { id: 'tiers', label: 'Tier System' },
    { id: 'referral', label: 'Referral Program' },
  ]},
  { id: 'marketing', label: 'Marketing', icon: Megaphone, subModules: [
    { id: 'promotions', label: 'Promotional Packages' },
    { id: 'coupons', label: 'Coupon Management' },
    { id: 'campaigns', label: 'Discount Campaigns' },
    { id: 'email-marketing', label: 'Email/SMS Marketing' },
  ]},
  { id: 'online-booking', label: 'Online Booking Engine', icon: Globe, subModules: [
    { id: 'website-booking', label: 'Website Booking' },
    { id: 'mobile-booking', label: 'Mobile Booking' },
    { id: 'live-pricing', label: 'Live Pricing' },
    { id: 'online-payment', label: 'Online Payment' },
  ]},
  { id: 'ota', label: 'OTA Channel Manager', icon: Radio, subModules: [
    { id: 'channels', label: 'Channel List' },
    { id: 'sync', label: 'Inventory Sync' },
    { id: 'dynamic-pricing', label: 'Dynamic Pricing' },
  ]},
  { id: 'payment', label: 'Payment Gateway', icon: CreditCard, subModules: [
    { id: 'methods', label: 'Payment Methods' },
    { id: 'transactions', label: 'Transactions' },
    { id: 'gateways', label: 'Gateway Config' },
  ]},
  { id: 'security', label: 'Security & Access', icon: Lock, subModules: [
    { id: 'roles', label: 'Role Management' },
    { id: 'users', label: 'User Management' },
    { id: 'permissions', label: 'Permissions' },
    { id: 'audit-log', label: 'Audit Log' },
  ]},
  { id: 'reports', label: 'Reports & Analytics', icon: BarChart3, subModules: [
    { id: 'occupancy-report', label: 'Occupancy Report' },
    { id: 'revenue-report', label: 'Revenue Report' },
    { id: 'sales-report', label: 'Daily Sales Report' },
    { id: 'guest-report', label: 'Guest Report' },
    { id: 'financial', label: 'Financial Statements' },
    { id: 'vat-report', label: 'VAT Report' },
    { id: 'hr-report', label: 'HR Report' },
  ]},
  { id: 'mobile', label: 'Mobile Apps', icon: Smartphone, subModules: [
    { id: 'guest-app', label: 'Guest App' },
    { id: 'staff-app', label: 'Staff App' },
  ]},
  { id: 'documents', label: 'Documents', icon: FileText, subModules: [
    { id: 'guest-docs', label: 'Guest Documents' },
    { id: 'contracts', label: 'Contracts' },
    { id: 'vendor-docs', label: 'Vendor Documents' },
    { id: 'employee-docs', label: 'Employee Documents' },
  ]},
  { id: 'notifications', label: 'Notifications', icon: Bell, subModules: [
    { id: 'all', label: 'All Notifications' },
    { id: 'reminders', label: 'Reminders' },
    { id: 'config', label: 'Notification Config' },
  ]},
  { id: 'integrations', label: 'Integrations', icon: Plug, subModules: [
    { id: 'api-list', label: 'API Management' },
    { id: 'third-party', label: 'Third-Party Integrations' },
    { id: 'webhooks', label: 'Webhooks' },
  ]},
  { id: 'admin', label: 'System Admin', icon: Settings, subModules: [
    { id: 'company-setup', label: 'Company Setup' },
    { id: 'multi-hotel', label: 'Multi Hotel/Branch' },
    { id: 'backup', label: 'Backup & Restore' },
    { id: 'system-logs', label: 'System Logs' },
    { id: 'license', label: 'License Management' },
  ]},
]

// ============ MAIN APP ============
export default function HotelERP() {
  const { activeModule, activeSubModule, navigate } = useHotelStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({ dashboard: true })
  const [mounted, setMounted] = useState(false)

  useEffect(() => { setMounted(true) }, [])

  if (!mounted) return null

  const toggleGroup = (id: string) => setOpenGroups(prev => ({ ...prev, [id]: !prev[id] }))

  const currentModule = modules.find(m => m.id === activeModule)
  const currentSubModule = currentModule?.subModules.find(s => s.id === activeSubModule)

  // Render the correct module component
  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard': return <DashboardModule subModule={activeSubModule} />
      case 'hotel-setup': return <HotelSetupModule subModule={activeSubModule} />
      case 'room-management': return <RoomManagementModule subModule={activeSubModule} />
      case 'reservation': return <ReservationModule subModule={activeSubModule} />
      case 'front-office': return <FrontOfficeModule subModule={activeSubModule} />
      case 'guest-management': return <GuestCrmModule subModule={activeSubModule} />
      case 'housekeeping': return <HousekeepingModule subModule={activeSubModule} />
      case 'restaurant': return <RestaurantPosModule subModule={activeSubModule} />
      case 'banquet': return <BanquetModule subModule={activeSubModule} />
      case 'spa': return <SpaModule subModule={activeSubModule} />
      case 'laundry': return <LaundryModule subModule={activeSubModule} />
      case 'inventory': return <InventoryModule subModule={activeSubModule} />
      case 'purchase': return <PurchaseModule subModule={activeSubModule} />
      case 'finance': return <FinanceModule subModule={activeSubModule} />
      case 'billing': return <BillingModule subModule={activeSubModule} />
      case 'hr': return <HrModule subModule={activeSubModule} />
      case 'asset': return <AssetModule subModule={activeSubModule} />
      case 'maintenance': return <MaintenanceModule subModule={activeSubModule} />
      case 'loyalty': return <LoyaltyModule subModule={activeSubModule} />
      case 'marketing': return <MarketingModule subModule={activeSubModule} />
      case 'online-booking': return <OnlineBookingModule subModule={activeSubModule} />
      case 'ota': return <OtaModule subModule={activeSubModule} />
      case 'payment': return <PaymentModule subModule={activeSubModule} />
      case 'security': return <SecurityModule subModule={activeSubModule} />
      case 'reports': return <ReportsModule subModule={activeSubModule} />
      case 'mobile':
      case 'documents':
      case 'notifications':
      case 'integrations':
      case 'admin':
        return <OtherModules moduleId={activeModule} subModule={activeSubModule} />
      default: return <DashboardModule subModule="overview" />
    }
  }

  return (
    <SidebarProvider>
      <Sidebar collapsible="icon" className="sidebar-premium border-r-0">
        <SidebarHeader className="p-3 pb-2">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-white font-bold text-sm shadow-lg shadow-amber-500/25">
              <Crown className="h-5 w-5" />
            </div>
            <div className="group-data-[collapsible=icon]:hidden">
              <h1 className="text-sm font-bold tracking-tight text-gold-gradient">HotelPro ERP</h1>
              <p className="text-[10px] text-sidebar-foreground/60 flex items-center gap-1">
                <Star className="h-2.5 w-2.5 text-amber-400 fill-amber-400" />
                Grand Palace Hotel & Resort
              </p>
            </div>
          </div>
        </SidebarHeader>

        <SidebarSeparator className="bg-sidebar-border/50" />

        <SidebarContent>
          <ScrollArea className="h-full">
            <div className="px-2 pb-2">
              <div className="relative mb-2 group-data-[collapsible=icon]:hidden">
                <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-sidebar-foreground/40" />
                <Input
                  placeholder="Search modules..."
                  className="pl-8 h-8 text-xs bg-sidebar-accent/50 border-sidebar-border/50 text-sidebar-foreground placeholder:text-sidebar-foreground/40 focus:bg-sidebar-accent focus:border-amber-500/40"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {modules.filter(m => !searchQuery || m.label.toLowerCase().includes(searchQuery.toLowerCase())).map(module => {
              const isOpen = openGroups[module.id] ?? false
              const isActive = activeModule === module.id
              const Icon = module.icon

              return (
                <SidebarGroup key={module.id}>
                  <Collapsible open={isOpen} onOpenChange={() => toggleGroup(module.id)}>
                    <SidebarGroupLabel asChild>
                      <CollapsibleTrigger className="w-full">
                        <div className={`flex items-center gap-2.5 w-full px-2.5 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
                          isActive
                            ? 'bg-amber-500/15 text-amber-300 sidebar-active-indicator'
                            : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/80 hover:text-sidebar-foreground'
                        }`}>
                          <Icon className={`h-4 w-4 shrink-0 transition-colors duration-200 ${isActive ? 'text-amber-400' : 'text-sidebar-foreground/50'}`} />
                          <span className="flex-1 text-left group-data-[collapsible=icon]:hidden">{module.label}</span>
                          {isOpen ? <ChevronDown className="h-3 w-3 text-sidebar-foreground/40 group-data-[collapsible=icon]:hidden" /> : <ChevronRight className="h-3 w-3 text-sidebar-foreground/40 group-data-[collapsible=icon]:hidden" />}
                        </div>
                      </CollapsibleTrigger>
                    </SidebarGroupLabel>
                    <CollapsibleContent>
                      <SidebarGroupContent>
                        <SidebarMenu>
                          {module.subModules.map(sub => {
                            const isSubActive = activeModule === module.id && activeSubModule === sub.id
                            return (
                              <SidebarMenuItem key={sub.id}>
                                <SidebarMenuButton
                                  isActive={isSubActive}
                                  onClick={() => navigate(module.id, sub.id)}
                                  className={`text-xs pl-9 h-7 transition-all duration-200 ${
                                    isSubActive
                                      ? 'bg-amber-500/10 text-amber-300 font-medium hover:bg-amber-500/15'
                                      : 'text-sidebar-foreground/55 hover:text-sidebar-foreground/90 hover:bg-sidebar-accent/50'
                                  }`}
                                >
                                  {sub.label}
                                </SidebarMenuButton>
                              </SidebarMenuItem>
                            )
                          })}
                        </SidebarMenu>
                      </SidebarGroupContent>
                    </CollapsibleContent>
                  </Collapsible>
                </SidebarGroup>
              )
            })}
          </ScrollArea>
        </SidebarContent>

        <SidebarFooter>
          <SidebarSeparator className="bg-sidebar-border/50" />
          <div className="p-2 group-data-[collapsible=icon]:hidden">
            <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg bg-sidebar-accent/40">
              <Avatar className="h-8 w-8 ring-2 ring-amber-500/30">
                <AvatarFallback className="text-xs bg-gradient-to-br from-amber-400 to-amber-600 text-white font-semibold">SA</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-sidebar-foreground truncate">Super Admin</p>
                <p className="text-[10px] text-sidebar-foreground/50 truncate">admin@hotelpro.com</p>
              </div>
            </div>
          </div>
        </SidebarFooter>
        <SidebarRail className="bg-sidebar-border/30" />
      </Sidebar>

      <SidebarInset>
        {/* Premium Header */}
        <header className="header-premium flex h-14 items-center gap-4 px-4 sticky top-0 z-10">
          <SidebarTrigger className="hover:bg-accent/50" />
          <Separator orientation="vertical" className="h-6 bg-border/60" />
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground font-medium">{currentModule?.label}</span>
              {currentSubModule && (
                <>
                  <ChevronRight className="h-3.5 w-3.5 text-amber-500/60" />
                  <span className="font-semibold text-foreground">{currentSubModule.label}</span>
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="text-xs gap-1.5 border-emerald-200 bg-emerald-50 text-emerald-700 font-medium">
              <span className="h-2 w-2 rounded-full bg-emerald-500 badge-pulse" />Live
            </Badge>
            <Button variant="ghost" size="icon" className="relative hover:bg-accent/50 transition-colors duration-200">
              <BellRing className="h-4 w-4 text-muted-foreground" />
              <span className="absolute -top-0.5 -right-0.5 h-4 w-4 bg-gradient-to-br from-red-500 to-red-600 rounded-full text-[9px] text-white flex items-center justify-center font-semibold shadow-sm shadow-red-500/30">3</span>
            </Button>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 p-4 md:p-6 overflow-auto bg-background">
          {renderModule()}
        </div>

        {/* Premium Footer */}
        <footer className="border-t py-3 px-6 text-center text-xs text-muted-foreground/70 bg-gradient-to-r from-background via-card to-background">
          <span className="font-semibold text-foreground/50">HotelPro ERP</span> v2.0 &middot; Complete Hotel Management Software &middot; Multi-Property | Multi-Branch | Bangladesh &amp; International &middot; &copy; 2026
        </footer>
      </SidebarInset>
    </SidebarProvider>
  )
}
