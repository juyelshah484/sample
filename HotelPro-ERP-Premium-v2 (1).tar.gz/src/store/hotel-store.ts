import { create } from 'zustand'

export type ModuleId = 
  | 'dashboard'
  | 'hotel-setup'
  | 'room-management'
  | 'reservation'
  | 'front-office'
  | 'guest-management'
  | 'housekeeping'
  | 'restaurant'
  | 'banquet'
  | 'spa'
  | 'laundry'
  | 'inventory'
  | 'purchase'
  | 'finance'
  | 'billing'
  | 'hr'
  | 'asset'
  | 'maintenance'
  | 'loyalty'
  | 'marketing'
  | 'online-booking'
  | 'ota'
  | 'payment'
  | 'security'
  | 'reports'
  | 'mobile'
  | 'documents'
  | 'notifications'
  | 'integrations'
  | 'admin'

interface HotelStore {
  activeModule: ModuleId
  activeSubModule: string
  sidebarOpen: boolean
  setActiveModule: (module: ModuleId) => void
  setActiveSubModule: (subModule: string) => void
  setSidebarOpen: (open: boolean) => void
  navigate: (module: ModuleId, subModule?: string) => void
}

export const useHotelStore = create<HotelStore>((set) => ({
  activeModule: 'dashboard',
  activeSubModule: 'overview',
  sidebarOpen: true,
  setActiveModule: (module) => set({ activeModule: module, activeSubModule: 'overview' }),
  setActiveSubModule: (subModule) => set({ activeSubModule: subModule }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  navigate: (module, subModule) => set({ 
    activeModule: module, 
    activeSubModule: subModule || 'overview' 
  }),
}))
