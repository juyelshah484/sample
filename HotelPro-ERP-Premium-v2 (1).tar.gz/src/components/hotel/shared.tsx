'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  TrendingUp, TrendingDown, Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Download, ChevronLeft, ChevronRight, Loader2, X,
} from 'lucide-react'
import { toast } from 'sonner'

// ============ FORMAT HELPERS ============
export const formatCurrency = (amount: number) => `BDT ${Number(amount || 0).toLocaleString('en-BD')}`
export const formatDate = (d: string | Date) => d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'
export const formatDateTime = (d: string | Date) => d ? new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-'

export const statusColors: Record<string, string> = {
  available: 'bg-emerald-50 text-emerald-700 border border-emerald-200', occupied: 'bg-sky-50 text-sky-700 border border-sky-200',
  maintenance: 'bg-amber-50 text-amber-700 border border-amber-200', out_of_service: 'bg-red-50 text-red-700 border border-red-200',
  blocked: 'bg-slate-50 text-slate-600 border border-slate-200', confirmed: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  checked_in: 'bg-sky-50 text-sky-700 border border-sky-200', checked_out: 'bg-slate-50 text-slate-600 border border-slate-200',
  cancelled: 'bg-red-50 text-red-700 border border-red-200', no_show: 'bg-amber-50 text-amber-700 border border-amber-200',
  pending: 'bg-amber-50 text-amber-700 border border-amber-200', in_progress: 'bg-sky-50 text-sky-700 border border-sky-200',
  completed: 'bg-emerald-50 text-emerald-700 border border-emerald-200', open: 'bg-sky-50 text-sky-700 border border-sky-200',
  closed: 'bg-slate-50 text-slate-600 border border-slate-200', draft: 'bg-slate-50 text-slate-600 border border-slate-200',
  submitted: 'bg-sky-50 text-sky-700 border border-sky-200', approved: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  received: 'bg-emerald-50 text-emerald-700 border border-emerald-200', active: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  inactive: 'bg-slate-50 text-slate-600 border border-slate-200', posted: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  present: 'bg-emerald-50 text-emerald-700 border border-emerald-200', absent: 'bg-red-50 text-red-700 border border-red-200',
  late: 'bg-amber-50 text-amber-700 border border-amber-200', paid: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  unclaimed: 'bg-amber-50 text-amber-700 border border-amber-200', claimed: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  disposed: 'bg-slate-50 text-slate-600 border border-slate-200', booked: 'bg-sky-50 text-sky-700 border border-sky-200',
  preparing: 'bg-amber-50 text-amber-700 border border-amber-200', ready: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  served: 'bg-slate-50 text-slate-600 border border-slate-200', urgent: 'bg-red-50 text-red-700 border border-red-200',
  high: 'bg-amber-50 text-amber-700 border border-amber-200', normal: 'bg-sky-50 text-sky-700 border border-sky-200',
  low: 'bg-slate-50 text-slate-600 border border-slate-200', resolved: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  assigned: 'bg-sky-50 text-sky-700 border border-sky-200', passed: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  failed: 'bg-red-50 text-red-700 border border-red-200', collected: 'bg-amber-50 text-amber-700 border border-amber-200',
  washing: 'bg-sky-50 text-sky-700 border border-sky-200', ironing: 'bg-violet-50 text-violet-700 border border-violet-200',
  delivered: 'bg-emerald-50 text-emerald-700 border border-emerald-200', standard: 'bg-slate-50 text-slate-600 border border-slate-200',
  silver: 'bg-slate-100 text-slate-700 border border-slate-300', gold: 'bg-amber-50 text-amber-700 border border-amber-300',
  platinum: 'bg-violet-50 text-violet-700 border border-violet-200', diamond: 'bg-sky-50 text-sky-700 border border-sky-300',
  individual: 'bg-sky-50 text-sky-700 border border-sky-200', corporate: 'bg-violet-50 text-violet-700 border border-violet-200',
  vip: 'bg-amber-50 text-amber-700 border border-amber-300', frequent: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  loyalty: 'bg-sky-50 text-sky-700 border border-sky-200', blacklist: 'bg-red-50 text-red-700 border border-red-200',
  family: 'bg-pink-50 text-pink-700 border border-pink-200', asset: 'bg-sky-50 text-sky-700 border border-sky-200',
  liability: 'bg-red-50 text-red-700 border border-red-200', income: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  expense: 'bg-amber-50 text-amber-700 border border-amber-200', equity: 'bg-violet-50 text-violet-700 border border-violet-200',
}

export const COLORS = ['#2563eb', '#d97706', '#059669', '#dc2626', '#7c3aed', '#db2777', '#0891b2', '#ea580c']
// Premium Hotel: Royal Navy, Gold, Emerald, Rich Red, Violet, Rose, Teal, Orange

// ============ API HELPER ============
export async function apiFetch(url: string, options?: RequestInit) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }))
    throw new Error(err.error || `HTTP ${res.status}`)
  }
  return res.json()
}

// ============ KPI CARD ============
export function KPICard({ title, value, subtitle, icon: Icon, trend, trendUp, color = 'emerald' }: {
  title: string; value: string | number; subtitle?: string; icon?: React.ElementType;
  trend?: string; trendUp?: boolean; color?: string
}) {
  const colorMap: Record<string, { bg: string; icon: string; ring: string }> = {
    emerald: { bg: 'bg-emerald-50', icon: 'text-emerald-600', ring: 'ring-emerald-500/20' },
    blue:    { bg: 'bg-sky-50',    icon: 'text-sky-600',    ring: 'ring-sky-500/20' },
    amber:   { bg: 'bg-amber-50',  icon: 'text-amber-600',  ring: 'ring-amber-500/20' },
    red:     { bg: 'bg-red-50',    icon: 'text-red-600',    ring: 'ring-red-500/20' },
    violet:  { bg: 'bg-violet-50', icon: 'text-violet-600', ring: 'ring-violet-500/20' },
    pink:    { bg: 'bg-pink-50',   icon: 'text-pink-600',   ring: 'ring-pink-500/20' },
    orange:  { bg: 'bg-orange-50', icon: 'text-orange-600', ring: 'ring-orange-500/20' },
    teal:    { bg: 'bg-teal-50',   icon: 'text-teal-600',   ring: 'ring-teal-500/20' },
  }
  const c = colorMap[color] || colorMap.emerald
  return (
    <Card className="kpi-card">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1 tracking-tight">{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground mt-1.5">{subtitle}</p>}
          </div>
          {Icon && (
            <div className={`p-2.5 rounded-xl ${c.bg} ring-1 ${c.ring} transition-transform duration-200 hover:scale-105`}>
              <Icon className={`h-5 w-5 ${c.icon}`} />
            </div>
          )}
        </div>
        {trend && (
          <div className="flex items-center gap-1.5 mt-2.5">
            {trendUp ? (
              <div className="flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">
                <TrendingUp className="h-3 w-3" />
                <span className="text-xs font-semibold">{trend}</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 bg-red-50 text-red-700 px-2 py-0.5 rounded-full">
                <TrendingDown className="h-3 w-3" />
                <span className="text-xs font-semibold">{trend}</span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ============ MINI STAT ============
export function MiniStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <Card>
      <CardContent className={`p-4 ${color} rounded-lg`}>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
      </CardContent>
    </Card>
  )
}

// ============ STATUS ROW ============
export function StatusRow({ label, count, total, color }: { label: string; count: number; total: number; color: string }) {
  const safeCount = count || 0
  const safeTotal = total || 1
  const pct = (safeCount / safeTotal) * 100
  const colorMap: Record<string, string> = { emerald: 'bg-emerald-500', blue: 'bg-blue-500', amber: 'bg-amber-500', red: 'bg-red-500' }
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span>{label}</span>
        <span className="font-medium">{safeCount} ({pct.toFixed(1)}%)</span>
      </div>
      <Progress value={pct} className={`h-2 [&>div]:${colorMap[color]}`} />
    </div>
  )
}

// ============ PAGINATION ============
export function Pagination({ page, totalPages, setPage }: { page: number; totalPages: number; setPage: (p: number) => void }) {
  if (totalPages <= 1) return null
  return (
    <div className="flex items-center justify-between py-4">
      <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
      <div className="flex gap-1">
        <Button variant="outline" size="sm" onClick={() => setPage(Math.max(1, page - 1))} disabled={page <= 1}><ChevronLeft className="h-4 w-4" /></Button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i
          if (p > totalPages) return null
          return <Button key={p} variant={p === page ? 'default' : 'outline'} size="sm" onClick={() => setPage(p)} className="w-8">{p}</Button>
        })}
        <Button variant="outline" size="sm" onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page >= totalPages}><ChevronRight className="h-4 w-4" /></Button>
      </div>
    </div>
  )
}

// ============ LOADING SKELETON ============
export function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => <div key={i} className="h-28 rounded-xl shimmer" />)}
      </div>
      <div className="h-80 rounded-xl shimmer" />
    </div>
  )
}

// ============ EMPTY STATE ============
export function EmptyState({ title, description, action, onAction }: { title: string; description?: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-4">
      <div className="p-4 rounded-full bg-muted"><Search className="h-8 w-8 text-muted-foreground" /></div>
      <h3 className="text-lg font-semibold">{title}</h3>
      {description && <p className="text-muted-foreground text-center max-w-sm">{description}</p>}
      {action && onAction && <Button onClick={onAction}><Plus className="h-4 w-4 mr-2" />{action}</Button>}
    </div>
  )
}

// ============ GENERIC CRUD MODULE ============
export function useCrud<T extends { id: string }>(apiPath: string) {
  const [items, setItems] = useState<T[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  const fetchItems = React.useCallback(async () => {
    setLoading(true)
    try {
      const data = await apiFetch(apiPath)
      setItems(data[Object.keys(data)[0]] || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }, [apiPath])

  React.useEffect(() => { fetchItems() }, [fetchItems])

  const createItem = async (item: Partial<T>) => {
    try {
      await apiFetch(apiPath, { method: 'POST', body: JSON.stringify(item) })
      toast.success('Created successfully')
      fetchItems()
      return true
    } catch (e: any) { toast.error(e.message); return false }
  }

  const updateItem = async (id: string, item: Partial<T>) => {
    try {
      await apiFetch(`${apiPath}?id=${id}`, { method: 'PUT', body: JSON.stringify(item) })
      toast.success('Updated successfully')
      fetchItems()
      return true
    } catch (e: any) { toast.error(e.message); return false }
  }

  const deleteItem = async (id: string) => {
    try {
      await apiFetch(`${apiPath}?id=${id}`, { method: 'DELETE' })
      toast.success('Deleted successfully')
      fetchItems()
      return true
    } catch (e: any) { toast.error(e.message); return false }
  }

  const filtered = items.filter((item: any) =>
    !search || Object.values(item).some(v => String(v || '').toLowerCase().includes(search.toLowerCase()))
  )
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return { items, filtered, paginated, loading, search, setSearch, page, setPage, totalPages, fetchItems, createItem, updateItem, deleteItem }
}

// ============ CRUD TABLE MODULE ============
export function CrudTableModule<T extends { id: string }>({
  title, description, apiPath, columns, renderRow, formFields, defaultValues, itemName
}: {
  title: string; description: string; apiPath: string; itemName: string
  columns: string[]
  renderRow: (item: T) => React.ReactNode
  formFields: (formData: any, setFormData: (d: any) => void) => React.ReactNode
  defaultValues: any
}) {
  const crud = useCrud<T>(apiPath)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<T | null>(null)
  const [formData, setFormData] = useState(defaultValues)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const openCreate = () => { setEditItem(null); setFormData(defaultValues); setDialogOpen(true) }
  const openEdit = (item: T) => { setEditItem(item); setFormData(item); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true)
    const ok = editItem ? await crud.updateItem(editItem.id, formData) : await crud.createItem(formData)
    setSaving(false)
    if (ok) setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { await crud.deleteItem(deleteId); setDeleteId(null) }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">{title}</h2><p className="text-muted-foreground">{description}</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={(e) => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add {itemName}</Button>
        </div>
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow>{columns.map(c => <TableHead key={c}>{c}</TableHead>)}</TableRow></TableHeader>
                <TableBody>
                  {crud.paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={columns.length} className="text-center py-8 text-muted-foreground">No records found</TableCell></TableRow>
                  ) : crud.paginated.map((item: T) => renderRow(item))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={crud.page} totalPages={crud.totalPages} setPage={crud.setPage} />
        </>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} {itemName}</DialogTitle><DialogDescription>Fill in the details below.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">{formFields(formData, setFormData)}</div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this {itemName.toLowerCase()}? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

export { toast, Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription, Separator, Progress, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription, AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Download, ChevronLeft, ChevronRight, Loader2, X }
