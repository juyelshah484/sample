'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ====================================================================
// MOBILE APPS MODULE
// ====================================================================
function GuestApp() {
  const [features] = useState([
    { name: 'Mobile Booking', enabled: true, desc: 'Book rooms directly from the app' },
    { name: 'Digital Check-in', enabled: true, desc: 'Complete check-in before arrival' },
    { name: 'Room Service Ordering', enabled: true, desc: 'Order food and amenities' },
    { name: 'Spa & Wellness Booking', enabled: false, desc: 'Book spa treatments' },
    { name: 'In-App Chat', enabled: true, desc: 'Chat with hotel concierge' },
    { name: 'Digital Key', enabled: false, desc: 'Use phone as room key' },
    { name: 'Loyalty Points', enabled: true, desc: 'View and manage loyalty points' },
    { name: 'Push Notifications', enabled: true, desc: 'Receive booking updates' },
    { name: 'Feedback & Rating', enabled: true, desc: 'Rate services and leave feedback' },
    { name: 'Local Guide', enabled: false, desc: 'Explore nearby attractions' },
  ])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="App Downloads" value="3,450" subtitle="Total installs" color="blue" />
        <KPICard title="Active Users" value="1,280" subtitle="Monthly active" color="emerald" />
        <KPICard title="App Rating" value="4.6" subtitle="★ on App Store" color="amber" />
      </div>
      <div><h2 className="text-2xl font-bold">Guest App</h2><p className="text-muted-foreground">Configure guest-facing mobile application features</p></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {features.map(f => (
          <Card key={f.name} className={!f.enabled ? 'opacity-60' : ''}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div><p className="font-medium">{f.name}</p><p className="text-sm text-muted-foreground">{f.desc}</p></div>
                <Badge className={f.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{f.enabled ? 'Enabled' : 'Disabled'}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function StaffApp() {
  const [features] = useState([
    { name: 'Task Management', enabled: true, desc: 'View and update assigned tasks' },
    { name: 'Room Status Update', enabled: true, desc: 'Update room cleaning status' },
    { name: 'Guest Requests', enabled: true, desc: 'Receive and handle guest requests' },
    { name: 'Maintenance Reporting', enabled: true, desc: 'Report and track maintenance issues' },
    { name: 'Attendance & Shifts', enabled: true, desc: 'Clock in/out and view schedule' },
    { name: 'Inventory Check', enabled: false, desc: 'Check and update inventory levels' },
    { name: 'Communication', enabled: true, desc: 'Internal messaging between staff' },
    { name: 'Emergency Alerts', enabled: true, desc: 'Receive emergency notifications' },
  ])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Staff Users" value="85" subtitle="Active accounts" color="blue" />
        <KPICard title="Daily Active" value="62" subtitle="Today" color="emerald" />
        <KPICard title="Tasks Completed" value="156" subtitle="Today via app" color="amber" />
      </div>
      <div><h2 className="text-2xl font-bold">Staff App</h2><p className="text-muted-foreground">Configure staff-facing mobile application features</p></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {features.map(f => (
          <Card key={f.name} className={!f.enabled ? 'opacity-60' : ''}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div><p className="font-medium">{f.name}</p><p className="text-sm text-muted-foreground">{f.desc}</p></div>
                <Badge className={f.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{f.enabled ? 'Enabled' : 'Disabled'}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function MobileModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'guest-app': return <GuestApp />
    case 'staff-app': return <StaffApp />
    default: return <EmptyState title="Unknown Sub-Module" description={`Mobile sub-module "${subModule}" not found.`} />
  }
}

// ====================================================================
// DOCUMENTS MODULE
// ====================================================================
function DocumentCategories() {
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setCategories([
        { id: '1', name: 'Guest Documents', count: 245, size: '128 MB', lastUpdated: '2024-11-15' },
        { id: '2', name: 'Financial Reports', count: 89, size: '56 MB', lastUpdated: '2024-11-14' },
        { id: '3', name: 'HR Documents', count: 156, size: '82 MB', lastUpdated: '2024-11-13' },
        { id: '4', name: 'Legal & Compliance', count: 34, size: '45 MB', lastUpdated: '2024-11-10' },
        { id: '5', name: 'Marketing Materials', count: 67, size: '210 MB', lastUpdated: '2024-11-12' },
        { id: '6', name: 'Maintenance Records', count: 78, size: '34 MB', lastUpdated: '2024-11-15' },
        { id: '7', name: 'Policies & Procedures', count: 45, size: '22 MB', lastUpdated: '2024-10-28' },
      ]); setLoading(false)
    }, 400)
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Documents" value={categories.reduce((s, c) => s + c.count, 0)} subtitle="All categories" color="blue" />
        <KPICard title="Total Size" value="577 MB" subtitle="Storage used" color="amber" />
        <KPICard title="Categories" value={categories.length} subtitle="Document groups" color="emerald" />
      </div>
      <div><h2 className="text-2xl font-bold">Document Categories</h2><p className="text-muted-foreground">Organize documents by category</p></div>
      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map(c => (
            <Card key={c.id} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <h3 className="font-medium">{c.name}</h3>
                <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                  <p>{c.count} documents | {c.size}</p>
                  <p>Last updated: {formatDate(c.lastUpdated)}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function DocumentUpload() {
  const [documents, setDocuments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    setTimeout(() => {
      setDocuments([
        { id: '1', name: 'Guest_Registration_Form_v3.pdf', category: 'Guest Documents', size: '245 KB', uploadedBy: 'Admin', uploadDate: '2024-11-15T10:00:00' },
        { id: '2', name: 'Monthly_Financial_Report_Oct.xlsx', category: 'Financial Reports', size: '1.2 MB', uploadedBy: 'Nasreen', uploadDate: '2024-11-14T09:30:00' },
        { id: '3', name: 'Employee_Handbook_2024.pdf', category: 'HR Documents', size: '3.5 MB', uploadedBy: 'Admin', uploadDate: '2024-11-13T14:00:00' },
        { id: '4', name: 'Fire_Safety_Certificate.pdf', category: 'Legal & Compliance', size: '890 KB', uploadedBy: 'Jalal', uploadDate: '2024-11-10T11:00:00' },
        { id: '5', name: 'Winter_Promo_Banner.png', category: 'Marketing Materials', size: '5.2 MB', uploadedBy: 'Marketing', uploadDate: '2024-11-12T16:00:00' },
        { id: '6', name: 'Elevator_Inspection_Report.pdf', category: 'Maintenance Records', size: '1.8 MB', uploadedBy: 'Alam', uploadDate: '2024-11-15T08:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const filtered = documents.filter(d => !search || Object.values(d).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Document Upload</h2><p className="text-muted-foreground">Upload and manage documents</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search documents..." className="pl-8 w-56" value={search} onChange={e => setSearch(e.target.value)} /></div>
          <Button size="sm"><Plus className="h-4 w-4 mr-1" />Upload</Button>
        </div>
      </div>
      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Category</TableHead><TableHead>Size</TableHead><TableHead>Uploaded By</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {filtered.map(d => (
                  <TableRow key={d.id}>
                    <TableCell className="font-medium">{d.name}</TableCell>
                    <TableCell><Badge variant="outline">{d.category}</Badge></TableCell>
                    <TableCell>{d.size}</TableCell>
                    <TableCell>{d.uploadedBy}</TableCell>
                    <TableCell>{formatDateTime(d.uploadDate)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function DocumentsModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'categories': return <DocumentCategories />
    case 'upload': return <DocumentUpload />
    case 'search': return <DocumentUpload />
    default: return <EmptyState title="Unknown Sub-Module" description={`Documents sub-module "${subModule}" not found.`} />
  }
}

// ====================================================================
// NOTIFICATIONS MODULE
// ====================================================================
function NotificationCenter() {
  const [notifications, setNotifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    setTimeout(() => {
      setNotifications([
        { id: '1', title: 'New Booking - RES-1001', message: 'Ahmed Khan booked Suite 501 for 2 nights', type: 'booking', priority: 'normal', read: false, timestamp: '2024-11-15T14:30:00' },
        { id: '2', title: 'Payment Received', message: 'BDT 45,000 received from Rafiq Islam via SSLCommerz', type: 'payment', priority: 'normal', read: false, timestamp: '2024-11-15T14:00:00' },
        { id: '3', title: 'Urgent Maintenance', message: 'AC not working in Room 205 - guest complaint', type: 'maintenance', priority: 'urgent', read: false, timestamp: '2024-11-15T10:00:00' },
        { id: '4', title: 'Check-out Reminder', message: '3 guests scheduled for check-out today', type: 'reminder', priority: 'normal', read: true, timestamp: '2024-11-15T08:00:00' },
        { id: '5', title: 'Low Stock Alert', message: 'Bath towels stock below minimum level (15 remaining)', type: 'inventory', priority: 'high', read: false, timestamp: '2024-11-14T18:00:00' },
        { id: '6', title: 'Staff Shift Update', message: 'Night shift updated for Housekeeping - Nov 16', type: 'hr', priority: 'normal', read: true, timestamp: '2024-11-14T16:00:00' },
        { id: '7', title: 'OTA Sync Error', message: 'Trip.com sync failed - API key may be expired', type: 'system', priority: 'high', read: false, timestamp: '2024-11-14T14:00:00' },
        { id: '8', title: 'New Review', message: '5-star review from Ahmed Khan on Booking.com', type: 'review', priority: 'normal', read: true, timestamp: '2024-11-14T12:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
  }

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
    toast.success('All notifications marked as read')
  }

  const dismiss = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
    toast.success('Notification dismissed')
  }

  const filtered = filter === 'all' ? notifications : filter === 'unread' ? notifications.filter(n => !n.read) : notifications.filter(n => n.type === filter)
  const unreadCount = notifications.filter(n => !n.read).length

  const typeIcons: Record<string, string> = { booking: '🏨', payment: '💳', maintenance: '🔧', reminder: '⏰', inventory: '📦', hr: '👥', system: '⚙️', review: '⭐' }
  const priorityColors: Record<string, string> = { urgent: 'border-l-red-500', high: 'border-l-amber-500', normal: 'border-l-blue-500' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Unread" value={unreadCount} subtitle="Need attention" color="red" />
        <KPICard title="Total" value={notifications.length} subtitle="All notifications" color="blue" />
        <MiniStat label="Urgent" value={notifications.filter(n => n.priority === 'urgent').length} color="bg-red-50" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Notification Center</h2><p className="text-muted-foreground">View and manage all notifications</p></div>
        <div className="flex gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem><SelectItem value="unread">Unread</SelectItem>
              <SelectItem value="booking">Booking</SelectItem><SelectItem value="payment">Payment</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem><SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={markAllRead}>Mark All Read</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="space-y-2 max-h-[600px] overflow-y-auto">
          {filtered.map(n => (
            <Card key={n.id} className={`border-l-4 ${priorityColors[n.priority] || ''} ${!n.read ? 'bg-blue-50/50' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex gap-3">
                    <span className="text-xl">{typeIcons[n.type] || '📢'}</span>
                    <div>
                      <p className={`font-medium ${!n.read ? '' : 'text-muted-foreground'}`}>{n.title}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{formatDateTime(n.timestamp)}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    {!n.read && <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => markAsRead(n.id)}>Mark Read</Button>}
                    <Button variant="ghost" size="sm" className="h-7" onClick={() => dismiss(n.id)}><X className="h-3 w-3" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 && <EmptyState title="No Notifications" description="You're all caught up!" />}
        </div>
      )}
    </div>
  )
}

function NotificationConfig() {
  const [config, setConfig] = useState({
    bookingConfirm: true, bookingCancel: true, checkInReminder: true, checkOutReminder: true,
    paymentReceived: true, paymentFailed: true, maintenanceUrgent: true, maintenanceAssigned: false,
    lowStock: true, staffShiftChange: false, systemAlerts: true, otaSyncError: true,
    emailChannel: true, smsChannel: false, pushChannel: true, inAppChannel: true,
  })
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Notification configuration saved'); setSaving(false)
  }

  const toggle = (key: string) => setConfig(prev => ({ ...prev, [key]: !(prev as any)[key] }))

  const notificationTypes = [
    { key: 'bookingConfirm', label: 'Booking Confirmation', desc: 'When a new booking is created' },
    { key: 'bookingCancel', label: 'Booking Cancellation', desc: 'When a booking is cancelled' },
    { key: 'checkInReminder', label: 'Check-in Reminder', desc: 'Remind before guest arrival' },
    { key: 'checkOutReminder', label: 'Check-out Reminder', desc: 'Remind before guest departure' },
    { key: 'paymentReceived', label: 'Payment Received', desc: 'When payment is completed' },
    { key: 'paymentFailed', label: 'Payment Failed', desc: 'When a payment attempt fails' },
    { key: 'maintenanceUrgent', label: 'Urgent Maintenance', desc: 'High priority maintenance issues' },
    { key: 'lowStock', label: 'Low Stock Alert', desc: 'When inventory is below threshold' },
    { key: 'systemAlerts', label: 'System Alerts', desc: 'System errors and warnings' },
    { key: 'otaSyncError', label: 'OTA Sync Error', desc: 'Channel manager sync failures' },
  ]

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Notification Configuration</h2><p className="text-muted-foreground">Configure which notifications to receive and how</p></div>

      <Card>
        <CardHeader><CardTitle className="text-base">Notification Types</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3">
            {notificationTypes.map(nt => (
              <div key={nt.key} className="flex items-center justify-between p-3 rounded-lg border">
                <div><p className="font-medium text-sm">{nt.label}</p><p className="text-xs text-muted-foreground">{nt.desc}</p></div>
                <Button variant="outline" size="sm" onClick={() => toggle(nt.key)}>
                  {(config as any)[nt.key] ? 'Enabled' : 'Disabled'}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Delivery Channels</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { key: 'emailChannel', label: 'Email', desc: 'Send notifications via email' },
              { key: 'smsChannel', label: 'SMS', desc: 'Send notifications via SMS' },
              { key: 'pushChannel', label: 'Push Notification', desc: 'Mobile push notifications' },
              { key: 'inAppChannel', label: 'In-App', desc: 'Show in application notification center' },
            ].map(ch => (
              <div key={ch.key} className="flex items-center justify-between p-3 rounded-lg border">
                <div><p className="font-medium text-sm">{ch.label}</p><p className="text-xs text-muted-foreground">{ch.desc}</p></div>
                <Button variant="outline" size="sm" onClick={() => toggle(ch.key)}>
                  {(config as any)[ch.key] ? 'Enabled' : 'Disabled'}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end"><Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save Configuration</Button></div>
    </div>
  )
}

function NotificationsModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'center': return <NotificationCenter />
    case 'config': return <NotificationConfig />
    default: return <NotificationCenter />
  }
}

// ====================================================================
// INTEGRATIONS MODULE
// ====================================================================
function ApiManagement() {
  const [apis, setApis] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setApis([
        { id: '1', name: 'Hotel Management API', version: 'v2.1', endpoints: 48, status: 'active', lastCalled: '2024-11-15T14:30:00', callsToday: 1245 },
        { id: '2', name: 'Booking Engine API', version: 'v1.5', endpoints: 12, status: 'active', lastCalled: '2024-11-15T14:25:00', callsToday: 856 },
        { id: '3', name: 'Payment Gateway API', version: 'v3.0', endpoints: 8, status: 'active', lastCalled: '2024-11-15T14:00:00', callsToday: 234 },
        { id: '4', name: 'Channel Manager API', version: 'v2.0', endpoints: 15, status: 'active', lastCalled: '2024-11-15T10:30:00', callsToday: 189 },
      ]); setLoading(false)
    }, 400)
  }, [])

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">API Management</h2><p className="text-muted-foreground">Monitor and manage system APIs</p></div>
      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {apis.map(a => (
            <Card key={a.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{a.name}</CardTitle>
                  <Badge className="bg-emerald-100 text-emerald-800">{a.status}</Badge>
                </div>
                <CardDescription>Version {a.version} | {a.endpoints} endpoints</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Last Called:</span><span>{formatDateTime(a.lastCalled)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Calls Today:</span><span className="font-medium">{a.callsToday}</span></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function ThirdPartyIntegrations() {
  const [integrations, setIntegrations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setIntegrations([
        { id: '1', name: 'Booking.com', type: 'OTA', status: 'connected', lastSync: '2024-11-15T10:30:00' },
        { id: '2', name: 'Agoda', type: 'OTA', status: 'connected', lastSync: '2024-11-15T10:25:00' },
        { id: '3', name: 'SSLCommerz', type: 'Payment', status: 'connected', lastSync: '2024-11-15T14:00:00' },
        { id: '4', name: 'Google Maps', type: 'Maps', status: 'connected', lastSync: '-' },
        { id: '5', name: 'Mailgun', type: 'Email', status: 'connected', lastSync: '2024-11-15T10:00:00' },
        { id: '6', name: 'Twilio', type: 'SMS', status: 'disconnected', lastSync: '2024-10-15T12:00:00' },
        { id: '7', name: 'Xero', type: 'Accounting', status: 'disconnected', lastSync: '-' },
        { id: '8', name: 'Stripe', type: 'Payment', status: 'connected', lastSync: '2024-11-15T12:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const typeColors: Record<string, string> = { OTA: 'bg-blue-100 text-blue-800', Payment: 'bg-emerald-100 text-emerald-800', Maps: 'bg-amber-100 text-amber-800', Email: 'bg-violet-100 text-violet-800', SMS: 'bg-pink-100 text-pink-800', Accounting: 'bg-teal-100 text-teal-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Connected" value={integrations.filter(i => i.status === 'connected').length} subtitle="Active integrations" color="emerald" />
        <KPICard title="Disconnected" value={integrations.filter(i => i.status === 'disconnected').length} subtitle="Need setup" color="red" />
        <KPICard title="Total" value={integrations.length} subtitle="All integrations" color="blue" />
      </div>
      <div><h2 className="text-2xl font-bold">Third-Party Integrations</h2><p className="text-muted-foreground">Manage external service connections</p></div>
      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead>Status</TableHead><TableHead>Last Sync</TableHead></TableRow></TableHeader>
              <TableBody>
                {integrations.map(i => (
                  <TableRow key={i.id}>
                    <TableCell className="font-medium">{i.name}</TableCell>
                    <TableCell><Badge className={typeColors[i.type] || ''}>{i.type}</Badge></TableCell>
                    <TableCell><Badge className={i.status === 'connected' ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{i.status}</Badge></TableCell>
                    <TableCell>{i.lastSync === '-' ? 'Never' : formatDateTime(i.lastSync)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function WebhookConfig() {
  const [webhooks, setWebhooks] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ event: 'booking.created', url: '', secret: '', active: true })

  useEffect(() => {
    setTimeout(() => {
      setWebhooks([
        { id: '1', event: 'booking.created', url: 'https://api.example.com/webhooks/booking', secret: 'whsec_****1234', active: true, lastTriggered: '2024-11-15T14:30:00', successRate: 99.5 },
        { id: '2', event: 'payment.completed', url: 'https://api.example.com/webhooks/payment', secret: 'whsec_****5678', active: true, lastTriggered: '2024-11-15T14:00:00', successRate: 100 },
        { id: '3', event: 'guest.checkin', url: 'https://api.example.com/webhooks/checkin', secret: 'whsec_****9012', active: true, lastTriggered: '2024-11-15T10:00:00', successRate: 98.2 },
        { id: '4', event: 'maintenance.urgent', url: 'https://api.example.com/webhooks/maintenance', secret: 'whsec_****3456', active: false, lastTriggered: '2024-11-14T08:00:00', successRate: 95.0 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    setWebhooks(prev => [...prev, { ...formData, id: Date.now().toString(), lastTriggered: '-', successRate: 0 }])
    toast.success('Webhook created'); setSaving(false); setDialogOpen(false)
    setFormData({ event: 'booking.created', url: '', secret: '', active: true })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Webhook Configuration</h2><p className="text-muted-foreground">Configure webhook endpoints for event notifications</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Webhook</Button>
      </div>
      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Event</TableHead><TableHead>URL</TableHead><TableHead>Secret</TableHead><TableHead>Last Triggered</TableHead><TableHead>Success Rate</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
              <TableBody>
                {webhooks.map(w => (
                  <TableRow key={w.id}>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{w.event}</code></TableCell>
                    <TableCell className="max-w-[250px] truncate text-sm">{w.url}</TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{w.secret}</code></TableCell>
                    <TableCell>{w.lastTriggered === '-' ? 'Never' : formatDateTime(w.lastTriggered)}</TableCell>
                    <TableCell>{w.successRate}%</TableCell>
                    <TableCell><Badge className={w.active ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{w.active ? 'Active' : 'Inactive'}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Webhook</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Event</Label>
              <Select value={formData.event} onValueChange={v => setFormData({ ...formData, event: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="booking.created">Booking Created</SelectItem><SelectItem value="booking.cancelled">Booking Cancelled</SelectItem>
                  <SelectItem value="payment.completed">Payment Completed</SelectItem><SelectItem value="guest.checkin">Guest Check-in</SelectItem>
                  <SelectItem value="maintenance.urgent">Urgent Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Endpoint URL</Label><Input value={formData.url} onChange={e => setFormData({ ...formData, url: e.target.value })} placeholder="https://..." /></div>
            <div><Label>Webhook Secret</Label><Input value={formData.secret} onChange={e => setFormData({ ...formData, secret: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function IntegrationsModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'api': return <ApiManagement />
    case 'third-party': return <ThirdPartyIntegrations />
    case 'webhooks': return <WebhookConfig />
    default: return <ThirdPartyIntegrations />
  }
}

// ====================================================================
// ADMIN MODULE
// ====================================================================
function CompanySetup() {
  const [config, setConfig] = useState({
    companyName: 'Grand Hotel & Resort Ltd.', address: 'Gulshan-2, Dhaka 1212, Bangladesh',
    phone: '+880-2-8888999', email: 'info@grandhotel.com.bd', website: 'www.grandhotel.com.bd',
    taxId: 'TIN-123456789', regNo: 'C-123456(45/2023)', vatNo: 'VAT-BD-987654',
    currency: 'BDT', timezone: 'Asia/Dhaka', fiscalYear: 'July - June',
    checkInTime: '14:00', checkOutTime: '12:00',
  })
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Company setup saved'); setSaving(false)
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Company Setup</h2><p className="text-muted-foreground">Configure company information and settings</p></div>
      <Card>
        <CardHeader><CardTitle className="text-base">Company Information</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div><Label>Company Name</Label><Input value={config.companyName} onChange={e => setConfig({ ...config, companyName: e.target.value })} /></div>
          <div><Label>Address</Label><Textarea value={config.address} onChange={e => setConfig({ ...config, address: e.target.value })} rows={2} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Phone</Label><Input value={config.phone} onChange={e => setConfig({ ...config, phone: e.target.value })} /></div>
            <div><Label>Email</Label><Input value={config.email} onChange={e => setConfig({ ...config, email: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Website</Label><Input value={config.website} onChange={e => setConfig({ ...config, website: e.target.value })} /></div>
            <div><Label>Tax ID (TIN)</Label><Input value={config.taxId} onChange={e => setConfig({ ...config, taxId: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Registration No.</Label><Input value={config.regNo} onChange={e => setConfig({ ...config, regNo: e.target.value })} /></div>
            <div><Label>VAT Registration No.</Label><Input value={config.vatNo} onChange={e => setConfig({ ...config, vatNo: e.target.value })} /></div>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle className="text-base">Hotel Settings</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Currency</Label>
              <Select value={config.currency} onValueChange={v => setConfig({ ...config, currency: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="BDT">BDT</SelectItem><SelectItem value="USD">USD</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>Timezone</Label>
              <Select value={config.timezone} onValueChange={v => setConfig({ ...config, timezone: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="Asia/Dhaka">Asia/Dhaka (GMT+6)</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Check-in Time</Label><Input value={config.checkInTime} onChange={e => setConfig({ ...config, checkInTime: e.target.value })} /></div>
            <div><Label>Check-out Time</Label><Input value={config.checkOutTime} onChange={e => setConfig({ ...config, checkOutTime: e.target.value })} /></div>
          </div>
          <div><Label>Fiscal Year</Label><Input value={config.fiscalYear} onChange={e => setConfig({ ...config, fiscalYear: e.target.value })} /></div>
        </CardContent>
      </Card>
      <div className="flex justify-end"><Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save Configuration</Button></div>
    </div>
  )
}

function MultiHotelBranch() {
  const [branches, setBranches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setBranches([
        { id: '1', name: 'Grand Hotel Dhaka - Main', location: 'Gulshan-2, Dhaka', rooms: 127, status: 'active', manager: 'Rahim Uddin' },
        { id: '2', name: 'Grand Hotel Chittagong', location: 'GEC Circle, Chattogram', rooms: 85, status: 'active', manager: 'Karim Hossain' },
        { id: '3', name: 'Grand Resort Cox\'s Bazar', location: 'Marine Drive, Cox\'s Bazar', rooms: 65, status: 'active', manager: 'Fatima Begum' },
        { id: '4', name: 'Grand Business Hotel Sylhet', location: 'Zindabazar, Sylhet', rooms: 45, status: 'coming_soon', manager: 'TBD' },
      ]); setLoading(false)
    }, 400)
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Multi-Hotel / Branch Management</h2><p className="text-muted-foreground">Manage hotel branches and properties</p></div>
        <Button size="sm"><Plus className="h-4 w-4 mr-1" />Add Branch</Button>
      </div>
      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {branches.map(b => (
            <Card key={b.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{b.name}</CardTitle>
                  <Badge className={statusColors[b.status === 'coming_soon' ? 'pending' : b.status] || ''}>{b.status.replace('_', ' ')}</Badge>
                </div>
                <CardDescription>{b.location}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Rooms:</span><span>{b.rooms}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Manager:</span><span>{b.manager}</span></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function BackupRestore() {
  const [backups, setBackups] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setBackups([
        { id: '1', name: 'Daily Auto Backup', date: '2024-11-15T03:00:00', size: '245 MB', type: 'auto', status: 'completed' },
        { id: '2', name: 'Daily Auto Backup', date: '2024-11-14T03:00:00', size: '243 MB', type: 'auto', status: 'completed' },
        { id: '3', name: 'Manual Backup - Pre Update', date: '2024-11-12T15:30:00', size: '241 MB', type: 'manual', status: 'completed' },
        { id: '4', name: 'Daily Auto Backup', date: '2024-11-13T03:00:00', size: '244 MB', type: 'auto', status: 'completed' },
        { id: '5', name: 'Monthly Full Backup', date: '2024-11-01T02:00:00', size: '520 MB', type: 'monthly', status: 'completed' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const createBackup = async () => {
    setCreating(true); await new Promise(r => setTimeout(r, 2000))
    setBackups(prev => [{ id: Date.now().toString(), name: 'Manual Backup', date: new Date().toISOString(), size: '246 MB', type: 'manual', status: 'completed' }, ...prev])
    toast.success('Backup created successfully'); setCreating(false)
  }

  const typeColors: Record<string, string> = { auto: 'bg-blue-100 text-blue-800', manual: 'bg-emerald-100 text-emerald-800', monthly: 'bg-violet-100 text-violet-800' }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Backup & Restore</h2><p className="text-muted-foreground">Database backup management</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><RefreshCw className="h-4 w-4 mr-1" />Restore</Button>
          <Button size="sm" onClick={createBackup} disabled={creating}>{creating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Plus className="h-4 w-4 mr-1" />}Create Backup</Button>
        </div>
      </div>
      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Date</TableHead><TableHead>Size</TableHead><TableHead>Type</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
              <TableBody>
                {backups.map(b => (
                  <TableRow key={b.id}>
                    <TableCell className="font-medium">{b.name}</TableCell>
                    <TableCell>{formatDateTime(b.date)}</TableCell>
                    <TableCell>{b.size}</TableCell>
                    <TableCell><Badge className={typeColors[b.type]}>{b.type}</Badge></TableCell>
                    <TableCell><Badge className="bg-emerald-100 text-emerald-800">{b.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function SystemLogs() {
  const [logs, setLogs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setLogs([
        { id: '1', level: 'error', message: 'OTA sync failed for Trip.com - API timeout', source: 'channel-manager', timestamp: '2024-11-15T14:30:00' },
        { id: '2', level: 'warn', message: 'Low disk space on server - 15% remaining', source: 'system', timestamp: '2024-11-15T12:00:00' },
        { id: '3', level: 'info', message: 'Database backup completed successfully', source: 'backup-service', timestamp: '2024-11-15T03:00:00' },
        { id: '4', level: 'error', message: 'Payment gateway timeout - SSLCommerz', source: 'payment-service', timestamp: '2024-11-14T18:30:00' },
        { id: '5', level: 'info', message: 'System update v2.1.5 installed', source: 'system', timestamp: '2024-11-14T02:00:00' },
        { id: '6', level: 'warn', message: 'Failed login attempt from IP 192.168.1.55', source: 'auth-service', timestamp: '2024-11-13T22:00:00' },
        { id: '7', level: 'info', message: 'Scheduled maintenance completed', source: 'maintenance', timestamp: '2024-11-13T06:00:00' },
        { id: '8', level: 'error', message: 'Email service - SMTP connection refused', source: 'email-service', timestamp: '2024-11-12T14:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const levelColors: Record<string, string> = { error: 'bg-red-100 text-red-800', warn: 'bg-amber-100 text-amber-800', info: 'bg-blue-100 text-blue-800' }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">System Logs</h2><p className="text-muted-foreground">View system events, errors, and warnings</p></div>
      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Level</TableHead><TableHead>Timestamp</TableHead><TableHead>Source</TableHead><TableHead>Message</TableHead></TableRow></TableHeader>
              <TableBody>
                {logs.map(l => (
                  <TableRow key={l.id}>
                    <TableCell><Badge className={levelColors[l.level]}>{l.level.toUpperCase()}</Badge></TableCell>
                    <TableCell>{formatDateTime(l.timestamp)}</TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{l.source}</code></TableCell>
                    <TableCell className="max-w-[400px]">{l.message}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function LicenseManagement() {
  const [license, setLicense] = useState({
    product: 'Hotel Management ERP Pro', version: '2.1.5', licenseKey: 'HME-PRO-XXXX-XXXX-XXXX-1234',
    type: 'Enterprise', maxUsers: 50, maxHotels: 5, expiryDate: '2025-12-31',
    supportExpiry: '2025-12-31', activatedDate: '2024-01-15', serverId: 'SRV-DHK-001',
  })

  const daysRemaining = Math.max(0, Math.ceil((new Date(license.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">License Management</h2><p className="text-muted-foreground">View and manage software license</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="License Type" value={license.type} subtitle={license.product} color="blue" />
        <KPICard title="Days Remaining" value={daysRemaining} subtitle={`Expires ${formatDate(license.expiryDate)}`} color={daysRemaining < 90 ? 'amber' : 'emerald'} />
        <KPICard title="Version" value={license.version} subtitle="Current build" color="violet" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">License Details</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-muted-foreground">Product:</span><p className="font-medium">{license.product}</p></div>
              <div><span className="text-muted-foreground">License Key:</span><p><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{license.licenseKey}</code></p></div>
              <div><span className="text-muted-foreground">License Type:</span><p className="font-medium">{license.type}</p></div>
              <div><span className="text-muted-foreground">Server ID:</span><p><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{license.serverId}</code></p></div>
              <div><span className="text-muted-foreground">Max Users:</span><p>{license.maxUsers}</p></div>
              <div><span className="text-muted-foreground">Max Hotels:</span><p>{license.maxHotels}</p></div>
              <div><span className="text-muted-foreground">Activated:</span><p>{formatDate(license.activatedDate)}</p></div>
              <div><span className="text-muted-foreground">Expiry:</span><p className="font-medium">{formatDate(license.expiryDate)}</p></div>
              <div><span className="text-muted-foreground">Support Until:</span><p>{formatDate(license.supportExpiry)}</p></div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Update License Key</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div><Label>New License Key</Label><Input placeholder="HME-PRO-XXXX-XXXX-XXXX-XXXX" /></div>
          <Button>Update License</Button>
        </CardContent>
      </Card>
    </div>
  )
}

function AdminModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'company': return <CompanySetup />
    case 'branches': return <MultiHotelBranch />
    case 'backup': return <BackupRestore />
    case 'logs': return <SystemLogs />
    case 'license': return <LicenseManagement />
    default: return <CompanySetup />
  }
}

// ====================================================================
// MAIN EXPORT - Routes by moduleId
// ====================================================================
export default function OtherModules({ moduleId, subModule }: { moduleId: string, subModule: string }) {
  switch (moduleId) {
    case 'mobile': return <MobileModule subModule={subModule} />
    case 'documents': return <DocumentsModule subModule={subModule} />
    case 'notifications': return <NotificationsModule subModule={subModule} />
    case 'integrations': return <IntegrationsModule subModule={subModule} />
    case 'admin': return <AdminModule subModule={subModule} />
    default: return <EmptyState title="Unknown Module" description={`Module "${moduleId}" not found.`} />
  }
}
