'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ Types ============
interface BanquetHall {
  id: string
  name: string
  capacity: number
  pricePerHour: number
  amenities: string | null
  isActive: boolean
  events?: EventItem[]
  _count?: { events: number }
}

interface EventItem {
  id: string
  hallId: string
  title: string
  type: string
  startDate: string
  endDate: string
  expectedGuests: number | null
  catering: boolean
  decoration: boolean
  soundSystem: boolean
  totalAmount: number
  paidAmount: number
  status: string
  notes: string | null
  hall?: BanquetHall
}

interface Package {
  id: string
  name: string
  description: string
  type: string
  services: string[]
  pricePerPerson: number
  minGuests: number
}

// ============ Hall Booking ============
function HallBooking() {
  const [halls, setHalls] = useState<BanquetHall[]>([])
  const [events, setEvents] = useState<EventItem[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    hallId: '', title: '', type: 'conference', startDate: '', endDate: '',
    expectedGuests: '', catering: false, decoration: false, soundSystem: false, notes: '',
  })

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/banquet-halls')
      const hallList: BanquetHall[] = res.banquetHalls || []
      setHalls(hallList)
      const allEvents: EventItem[] = hallList.flatMap((h: BanquetHall) => h.events || [])
      setEvents(allEvents)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleBook = async () => {
    if (!form.hallId || !form.title || !form.startDate || !form.endDate) {
      toast.error('Hall, title, start and end dates are required'); return
    }
    setSaving(true)
    try {
      const hall = halls.find(h => h.id === form.hallId)
      const start = new Date(form.startDate)
      const end = new Date(form.endDate)
      const hours = Math.max(1, (end.getTime() - start.getTime()) / (1000 * 60 * 60))
      const totalAmount = (hall?.pricePerHour || 0) * hours

      await apiFetch('/api/banquet-halls', {
        method: 'POST',
        body: JSON.stringify({
          hotelId: 'default',
          name: hall?.name || 'Hall',
          capacity: hall?.capacity || 0,
          pricePerHour: hall?.pricePerHour || 0,
          event: {
            title: form.title,
            type: form.type,
            startDate: form.startDate,
            endDate: form.endDate,
            expectedGuests: parseInt(form.expectedGuests) || 0,
            catering: form.catering,
            decoration: form.decoration,
            soundSystem: form.soundSystem,
            totalAmount,
            paidAmount: 0,
            status: 'confirmed',
            notes: form.notes,
          },
        }),
      })
      toast.success('Hall booked successfully!')
      setDialogOpen(false)
      setForm({ hallId: '', title: '', type: 'conference', startDate: '', endDate: '', expectedGuests: '', catering: false, decoration: false, soundSystem: false, notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Hall Booking</h2><p className="text-muted-foreground">Book and manage banquet halls</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Book Hall</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Halls" value={halls.length} color="blue" />
        <KPICard title="Active Events" value={events.filter(e => e.status === 'confirmed').length} color="emerald" />
        <KPICard title="Completed" value={events.filter(e => e.status === 'completed').length} color="violet" />
        <KPICard title="Revenue" value={formatCurrency(events.reduce((s, e) => s + e.totalAmount, 0))} color="amber" />
      </div>

      {/* Hall Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {halls.map(hall => {
          const amenities = hall.amenities ? (typeof hall.amenities === 'string' ? JSON.parse(hall.amenities) : hall.amenities) : []
          return (
            <Card key={hall.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{hall.name}</CardTitle>
                  <Badge className={hall.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{hall.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
                <CardDescription>Capacity: {hall.capacity} guests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Price per hour</span>
                  <span className="font-bold text-lg">{formatCurrency(hall.pricePerHour)}</span>
                </div>
                {amenities.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {(Array.isArray(amenities) ? amenities : []).map((a: string, i: number) => (
                      <Badge key={i} variant="outline" className="text-xs">{a}</Badge>
                    ))}
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Bookings</span>
                  <span className="font-medium">{hall._count?.events || hall.events?.length || 0}</span>
                </div>
                <Button className="w-full" size="sm" onClick={() => { setForm({ ...form, hallId: hall.id }); setDialogOpen(true) }}>
                  Book This Hall
                </Button>
              </CardContent>
            </Card>
          )
        })}
        {halls.length === 0 && <div className="col-span-full"><EmptyState title="No Halls" description="No banquet halls configured yet" action="Add Hall" onAction={() => {}} /></div>}
      </div>

      {/* Events Table */}
      <Card>
        <CardHeader><CardTitle>Events</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Title</TableHead><TableHead>Hall</TableHead><TableHead>Type</TableHead><TableHead>Start</TableHead><TableHead>Guests</TableHead><TableHead>Amount</TableHead><TableHead>Status</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {events.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No events</TableCell></TableRow>
              ) : events.map(event => (
                <TableRow key={event.id}>
                  <TableCell className="font-medium">{event.title}</TableCell>
                  <TableCell>{event.hall?.name || '-'}</TableCell>
                  <TableCell className="capitalize">{event.type}</TableCell>
                  <TableCell>{formatDateTime(event.startDate)}</TableCell>
                  <TableCell>{event.expectedGuests || '-'}</TableCell>
                  <TableCell>{formatCurrency(event.totalAmount)}</TableCell>
                  <TableCell><Badge className={statusColors[event.status] || ''}>{event.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Book Hall</DialogTitle><DialogDescription>Schedule an event at a banquet hall</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Hall *</Label><Select value={form.hallId} onValueChange={v => setForm({ ...form, hallId: v })}><SelectTrigger><SelectValue placeholder="Select hall" /></SelectTrigger><SelectContent>{halls.map(h => <SelectItem key={h.id} value={h.id}>{h.name} ({h.capacity} guests)</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Event Title *</Label><Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. Annual Conference" /></div>
            <div><Label>Event Type</Label><Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="conference">Conference</SelectItem><SelectItem value="wedding">Wedding</SelectItem><SelectItem value="birthday">Birthday</SelectItem><SelectItem value="corporate">Corporate</SelectItem><SelectItem value="other">Other</SelectItem></SelectContent></Select></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Start Date/Time *</Label><Input type="datetime-local" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })} /></div>
              <div><Label>End Date/Time *</Label><Input type="datetime-local" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })} /></div>
            </div>
            <div><Label>Expected Guests</Label><Input type="number" value={form.expectedGuests} onChange={e => setForm({ ...form, expectedGuests: e.target.value })} placeholder="Number of guests" /></div>
            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.catering} onChange={e => setForm({ ...form, catering: e.target.checked })} /><span className="text-sm">Catering</span></label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.decoration} onChange={e => setForm({ ...form, decoration: e.target.checked })} /><span className="text-sm">Decoration</span></label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.soundSystem} onChange={e => setForm({ ...form, soundSystem: e.target.checked })} /><span className="text-sm">Sound System</span></label>
            </div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBook} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Book Now</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Event Calendar ============
function EventCalendar() {
  const [halls, setHalls] = useState<BanquetHall[]>([])
  const [loading, setLoading] = useState(true)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<string | null>(null)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/banquet-halls')
      setHalls(res.banquetHalls || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const allEvents: EventItem[] = halls.flatMap(h => h.events || [])

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1))

  const getEventsForDate = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return allEvents.filter(e => {
      const start = new Date(e.startDate).toISOString().slice(0, 10)
      const end = new Date(e.endDate).toISOString().slice(0, 10)
      return dateStr >= start && dateStr <= end
    })
  }

  const selectedDateEvents = selectedDate ? getEventsForDate(parseInt(selectedDate.split('-')[2])) : []

  if (loading) return <LoadingSkeleton />

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Event Calendar</h2><p className="text-muted-foreground">View events on a monthly calendar</p></div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" onClick={prevMonth}>&lt;</Button>
            <CardTitle>{monthName}</CardTitle>
            <Button variant="outline" size="sm" onClick={nextMonth}>&gt;</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1">
            {dayNames.map(d => <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>)}
            {Array.from({ length: firstDay }, (_, i) => <div key={`empty-${i}`} className="aspect-square" />)}
            {Array.from({ length: daysInMonth }, (_, i) => {
              const day = i + 1
              const dayEvents = getEventsForDate(day)
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
              const isSelected = selectedDate === dateStr
              const isToday = new Date().toDateString() === new Date(year, month, day).toDateString()

              return (
                <button
                  key={day}
                  className={`aspect-square rounded-lg p-1 text-left text-sm transition-colors border ${
                    isSelected ? 'bg-emerald-100 border-emerald-300' :
                    isToday ? 'bg-blue-50 border-blue-200' :
                    'border-transparent hover:bg-muted'
                  }`}
                  onClick={() => setSelectedDate(dateStr)}
                >
                  <span className={`text-xs font-medium ${isToday ? 'text-blue-600' : ''}`}>{day}</span>
                  {dayEvents.length > 0 && (
                    <div className="mt-0.5">
                      {dayEvents.slice(0, 2).map((e, idx) => (
                        <div key={idx} className="text-[9px] bg-emerald-200 text-emerald-800 rounded px-1 truncate">{e.title}</div>
                      ))}
                      {dayEvents.length > 2 && <div className="text-[9px] text-muted-foreground">+{dayEvents.length - 2} more</div>}
                    </div>
                  )}
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {selectedDate && (
        <Card>
          <CardHeader><CardTitle>Events on {selectedDate}</CardTitle></CardHeader>
          <CardContent>
            {selectedDateEvents.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">No events on this date</p>
            ) : (
              <div className="space-y-3">
                {selectedDateEvents.map(event => (
                  <Card key={event.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{event.title}</h4>
                          <p className="text-sm text-muted-foreground capitalize">{event.type} • {event.hall?.name || 'N/A'}</p>
                          <p className="text-sm">{formatDateTime(event.startDate)} — {formatDateTime(event.endDate)}</p>
                          <p className="text-sm">Expected: {event.expectedGuests || 0} guests</p>
                        </div>
                        <div className="text-right">
                          <Badge className={statusColors[event.status] || ''}>{event.status}</Badge>
                          <p className="text-sm font-bold mt-1">{formatCurrency(event.totalAmount)}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2">
                        {event.catering && <Badge variant="outline">Catering</Badge>}
                        {event.decoration && <Badge variant="outline">Decoration</Badge>}
                        {event.soundSystem && <Badge variant="outline">Sound System</Badge>}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ============ Event Packages ============
function EventPackages() {
  const [packages, setPackages] = useState<Package[]>([
    { id: '1', name: 'Basic Package', description: 'Essential setup for small events', type: 'basic', services: ['Venue Setup', 'Basic Lighting', 'Parking'], pricePerPerson: 500, minGuests: 20 },
    { id: '2', name: 'Standard Package', description: 'Complete setup for medium events', type: 'standard', services: ['Venue Setup', 'Sound System', 'Basic Decoration', 'Parking', 'Welcome Drinks'], pricePerPerson: 1200, minGuests: 30 },
    { id: '3', name: 'Premium Package', description: 'Luxury setup for grand events', type: 'premium', services: ['Venue Setup', 'Premium Sound System', 'Full Decoration', 'Stage Setup', 'Parking', 'Welcome Drinks', 'Photo Booth', 'DJ'], pricePerPerson: 2500, minGuests: 50 },
    { id: '4', name: 'Wedding Special', description: 'Everything you need for the perfect wedding', type: 'wedding', services: ['Venue Setup', 'Premium Sound & Light', 'Full Floral Decoration', 'Stage & Mandap', 'Bridal Room', 'Parking', 'Welcome Drinks', 'Live Music', 'Photography'], pricePerPerson: 4000, minGuests: 100 },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ name: '', description: '', type: 'standard', servicesText: '', pricePerPerson: '', minGuests: '' })

  const handleCreate = () => {
    if (!form.name || !form.pricePerPerson) { toast.error('Name and price are required'); return }
    const newPkg: Package = {
      id: String(Date.now()),
      name: form.name,
      description: form.description,
      type: form.type,
      services: form.servicesText.split(',').map(s => s.trim()).filter(Boolean),
      pricePerPerson: parseFloat(form.pricePerPerson) || 0,
      minGuests: parseInt(form.minGuests) || 10,
    }
    setPackages(prev => [...prev, newPkg])
    toast.success('Package created')
    setDialogOpen(false)
    setForm({ name: '', description: '', type: 'standard', servicesText: '', pricePerPerson: '', minGuests: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Event Packages</h2><p className="text-muted-foreground">Pre-configured event packages</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Create Package</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
        {packages.map(pkg => (
          <Card key={pkg.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{pkg.name}</CardTitle>
                <Badge className="capitalize">{pkg.type}</Badge>
              </div>
              <CardDescription>{pkg.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Price per person</span>
                <span className="text-2xl font-bold">{formatCurrency(pkg.pricePerPerson)}</span>
              </div>
              <div className="text-sm text-muted-foreground">Minimum {pkg.minGuests} guests</div>
              <Separator />
              <div className="space-y-1">
                <p className="text-sm font-medium">Included Services:</p>
                <div className="flex flex-wrap gap-1">
                  {pkg.services.map((s, i) => <Badge key={i} variant="outline" className="text-xs">{s}</Badge>)}
                </div>
              </div>
              <Button className="w-full" size="sm" variant="outline">Book This Package</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Create Package</DialogTitle><DialogDescription>Define a new event package</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Package Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Premium Package" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Package description" /></div>
            <div><Label>Type</Label><Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="basic">Basic</SelectItem><SelectItem value="standard">Standard</SelectItem><SelectItem value="premium">Premium</SelectItem><SelectItem value="wedding">Wedding</SelectItem></SelectContent></Select></div>
            <div><Label>Services (comma-separated)</Label><Textarea value={form.servicesText} onChange={e => setForm({ ...form, servicesText: e.target.value })} placeholder="e.g. Venue, Sound, Decoration" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Price/Person *</Label><Input type="number" value={form.pricePerPerson} onChange={e => setForm({ ...form, pricePerPerson: e.target.value })} placeholder="0" /></div>
              <div><Label>Min Guests</Label><Input type="number" value={form.minGuests} onChange={e => setForm({ ...form, minGuests: e.target.value })} placeholder="10" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Catering ============
function Catering() {
  const [cateringMenu, setCateringMenu] = useState([
    { id: '1', name: 'Buffet Basic', description: 'Rice, Dal, 2 Curries, Salad', pricePerPerson: 300, category: 'buffet' },
    { id: '2', name: 'Buffet Premium', description: 'Rice, Dal, 4 Curries, Kebab, Dessert', pricePerPerson: 600, category: 'buffet' },
    { id: '3', name: 'Plated Dinner', description: '3 Course plated dinner', pricePerPerson: 800, category: 'plated' },
    { id: '4', name: 'Cocktail Snacks', description: '8 varieties of snacks', pricePerPerson: 200, category: 'snacks' },
    { id: '5', name: 'Tea & Coffee', description: 'Unlimited tea and coffee service', pricePerPerson: 100, category: 'beverages' },
    { id: '6', name: 'Full Service Premium', description: 'Complete dining experience with waitstaff', pricePerPerson: 1500, category: 'premium' },
  ])
  const [orders, setOrders] = useState([
    { id: '1', eventName: 'Tech Conference 2025', menu: 'Buffet Premium', guests: 80, total: 48000, status: 'confirmed' },
    { id: '2', eventName: 'Smith Wedding', menu: 'Full Service Premium', guests: 150, total: 225000, status: 'pending' },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ eventName: '', menuId: '', guests: '' })

  const handleCreate = () => {
    if (!form.eventName || !form.menuId || !form.guests) { toast.error('All fields are required'); return }
    const menu = cateringMenu.find(m => m.id === form.menuId)
    const guests = parseInt(form.guests) || 0
    setOrders(prev => [...prev, {
      id: String(Date.now()),
      eventName: form.eventName,
      menu: menu?.name || '',
      guests,
      total: (menu?.pricePerPerson || 0) * guests,
      status: 'pending',
    }])
    toast.success('Catering order created')
    setDialogOpen(false)
    setForm({ eventName: '', menuId: '', guests: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Catering</h2><p className="text-muted-foreground">Catering menu and order management</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Order</Button>
      </div>

      <Card>
        <CardHeader><CardTitle>Catering Menu</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Menu</TableHead><TableHead>Description</TableHead><TableHead>Category</TableHead><TableHead>Price/Person</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {cateringMenu.map(item => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.description}</TableCell>
                  <TableCell><Badge variant="outline" className="capitalize">{item.category}</Badge></TableCell>
                  <TableCell>{formatCurrency(item.pricePerPerson)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Catering Orders</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Event</TableHead><TableHead>Menu</TableHead><TableHead>Guests</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No catering orders</TableCell></TableRow>
              ) : orders.map(order => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.eventName}</TableCell>
                  <TableCell>{order.menu}</TableCell>
                  <TableCell>{order.guests}</TableCell>
                  <TableCell>{formatCurrency(order.total)}</TableCell>
                  <TableCell><Badge className={statusColors[order.status] || ''}>{order.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Catering Order</DialogTitle><DialogDescription>Create a catering order for an event</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Event Name *</Label><Input value={form.eventName} onChange={e => setForm({ ...form, eventName: e.target.value })} placeholder="Event name" /></div>
            <div><Label>Menu *</Label><Select value={form.menuId} onValueChange={v => setForm({ ...form, menuId: v })}><SelectTrigger><SelectValue placeholder="Select menu" /></SelectTrigger><SelectContent>{cateringMenu.map(m => <SelectItem key={m.id} value={m.id}>{m.name} ({formatCurrency(m.pricePerPerson)}/person)</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Number of Guests *</Label><Input type="number" value={form.guests} onChange={e => setForm({ ...form, guests: e.target.value })} placeholder="0" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create Order</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Decoration ============
function Decoration() {
  const [options, setOptions] = useState([
    { id: '1', name: 'Basic Floral', description: 'Simple flower arrangements', price: 5000, category: 'floral' },
    { id: '2', name: 'Premium Floral', description: 'Exotic flower arrangements with centerpieces', price: 15000, category: 'floral' },
    { id: '3', name: 'Balloon Arch', description: 'Decorative balloon arch entrance', price: 8000, category: 'balloon' },
    { id: '4', name: 'Stage Decoration', description: 'Full stage setup with backdrop and lighting', price: 25000, category: 'stage' },
    { id: '5', name: 'Lighting Package', description: 'Ambient and decorative lighting', price: 12000, category: 'lighting' },
    { id: '6', name: 'Complete Makeover', description: 'Full venue decoration package', price: 50000, category: 'complete' },
  ])
  const [orders, setOrders] = useState([
    { id: '1', eventName: 'Smith Wedding', option: 'Complete Makeover', total: 50000, status: 'confirmed' },
    { id: '2', eventName: 'Birthday Bash', option: 'Balloon Arch', total: 8000, status: 'pending' },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ eventName: '', optionId: '' })

  const handleCreate = () => {
    if (!form.eventName || !form.optionId) { toast.error('All fields are required'); return }
    const option = options.find(o => o.id === form.optionId)
    setOrders(prev => [...prev, {
      id: String(Date.now()),
      eventName: form.eventName,
      option: option?.name || '',
      total: option?.price || 0,
      status: 'pending',
    }])
    toast.success('Decoration order created')
    setDialogOpen(false)
    setForm({ eventName: '', optionId: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Decoration</h2><p className="text-muted-foreground">Decoration options and ordering</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Order</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {options.map(opt => (
          <Card key={opt.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">{opt.name}</h4>
                <Badge variant="outline" className="capitalize">{opt.category}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{opt.description}</p>
              <p className="text-lg font-bold">{formatCurrency(opt.price)}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle>Decoration Orders</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Event</TableHead><TableHead>Decoration</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No decoration orders</TableCell></TableRow>
              ) : orders.map(order => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.eventName}</TableCell>
                  <TableCell>{order.option}</TableCell>
                  <TableCell>{formatCurrency(order.total)}</TableCell>
                  <TableCell><Badge className={statusColors[order.status] || ''}>{order.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Decoration Order</DialogTitle><DialogDescription>Order decoration for an event</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Event Name *</Label><Input value={form.eventName} onChange={e => setForm({ ...form, eventName: e.target.value })} placeholder="Event name" /></div>
            <div><Label>Decoration Option *</Label><Select value={form.optionId} onValueChange={v => setForm({ ...form, optionId: v })}><SelectTrigger><SelectValue placeholder="Select option" /></SelectTrigger><SelectContent>{options.map(o => <SelectItem key={o.id} value={o.id}>{o.name} ({formatCurrency(o.price)})</SelectItem>)}</SelectContent></Select></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create Order</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Main Component ============
export default function BanquetModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'hall-booking': return <HallBooking />
    case 'events': return <EventCalendar />
    case 'packages': return <EventPackages />
    case 'catering': return <Catering />
    case 'decoration': return <Decoration />
    default: return <EmptyState title="Unknown Sub-module" description={`Sub-module "${subModule}" not found`} />
  }
}
