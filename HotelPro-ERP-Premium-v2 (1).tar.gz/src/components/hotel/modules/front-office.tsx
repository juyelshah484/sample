'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'
import { CalendarCheck, UserCheck, Users, Star, DollarSign, BedDouble, Clock, Phone, Mail, CheckCircle2, XCircle, AlertTriangle, UserRound, ArrowDownRight, ArrowUpRight } from 'lucide-react'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'

// ============ TYPES ============
interface Guest {
  id: string; firstName: string; lastName: string; email?: string; phone?: string;
  nationality?: string; guestType: string; nationalId?: string; passportNumber?: string;
  address?: string; city?: string; country?: string;
}
interface Room {
  id: string; number: string; name?: string; price: number; status: string;
  roomType?: { name: string }; maxGuests: number; hotelId: string;
}
interface ReservationRoom {
  id: string; roomId: string; rate: number; status: string; room: Room;
}
interface FolioItem {
  id: string; description: string; category: string; amount: number; quantity: number; createdAt: string;
}
interface Payment {
  id: string; amount: number; method: string; status: string; createdAt: string; transactionRef?: string;
}
interface Folio {
  id: string; folioNumber: string; status: string; totalAmount: number; paidAmount: number; balance: number;
  folioItems: FolioItem[]; payments: Payment[];
}
interface Reservation {
  id: string; confirmationCode: string; guestId: string; hotelId: string;
  bookingSource: string; status: string; checkInDate: string; checkOutDate: string;
  numberOfGuests: number; numberOfRooms: number; specialRequests?: string; notes?: string;
  totalAmount: number; paidAmount: number; discount: number; taxAmount: number;
  guest: Guest; rooms: ReservationRoom[];
}

const PAYMENT_METHODS = ['cash', 'card', 'bKash', 'nagad', 'rocket', 'sslcommerz', 'bank_transfer'] as const
const FOLIO_CATEGORIES = ['room', 'restaurant', 'spa', 'laundry', 'minibar', 'banquet', 'other'] as const

// ============ GUEST CHECK-IN ============
function GuestCheckIn() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Reservation | null>(null)
  const [idNumber, setIdNumber] = useState('')
  const [checkInNotes, setCheckInNotes] = useState('')
  const [processing, setProcessing] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations?status=confirmed')
        const today = new Date().toISOString().split('T')[0]
        const todayRes = (data.reservations || []).filter((r: Reservation) =>
          r.checkInDate?.split('T')[0] <= today && r.checkOutDate?.split('T')[0] >= today
        )
        setReservations(todayRes)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const filtered = reservations.filter(r =>
    !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    r.confirmationCode.toLowerCase().includes(search.toLowerCase())
  )

  const handleCheckIn = async () => {
    if (!selected) return
    setProcessing(true)
    try {
      await apiFetch('/api/reservations', {
        method: 'PUT',
        body: JSON.stringify({ id: selected.id, status: 'checked_in', notes: checkInNotes ? `ID: ${idNumber}. ${checkInNotes}` : `ID: ${idNumber}` }),
      })
      toast.success(`${selected.guest?.firstName} ${selected.guest?.lastName} checked in successfully!`)
      setSelected(null)
      setIdNumber('')
      setCheckInNotes('')
      // Refresh list
      const data = await apiFetch('/api/reservations?status=confirmed')
      const today = new Date().toISOString().split('T')[0]
      const todayRes = (data.reservations || []).filter((r: Reservation) =>
        r.checkInDate?.split('T')[0] <= today && r.checkOutDate?.split('T')[0] >= today
      )
      setReservations(todayRes)
    } catch (e: any) { toast.error(e.message) }
    finally { setProcessing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Guest Check-in</h2>
          <p className="text-muted-foreground">{filtered.length} reservation(s) expected today</p>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search guest or code..." className="pl-8 w-56" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Reservation List */}
        <div className="lg:col-span-2 space-y-3">
          {filtered.length === 0 ? (
            <EmptyState title="No Check-ins Today" description="No confirmed reservations for today." />
          ) : filtered.map(r => (
            <Card key={r.id} className={`cursor-pointer transition-all hover:shadow-md ${selected?.id === r.id ? 'ring-2 ring-primary' : ''}`}
              onClick={() => setSelected(r)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>{r.guest?.firstName?.[0]}{r.guest?.lastName?.[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{r.guest?.firstName} {r.guest?.lastName}</p>
                      <p className="text-sm text-muted-foreground">{r.confirmationCode} • {r.rooms?.map(rr => rr.room?.number).join(', ')}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={statusColors[r.status]}>{r.status === 'confirmed' ? 'Confirmed' : r.status}</Badge>
                    <p className="text-sm mt-1">{r.rooms?.length} room(s) • {r.numberOfGuests} guest(s)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Check-in Form */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><UserCheck className="h-5 w-5" />Check-in Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selected ? (
                <>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="text-lg">{selected.guest?.firstName?.[0]}{selected.guest?.lastName?.[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{selected.guest?.firstName} {selected.guest?.lastName}</p>
                        <p className="text-sm text-muted-foreground">{selected.confirmationCode}</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><span className="text-muted-foreground">Room:</span><p className="font-medium">{selected.rooms?.map(rr => `${rr.room?.number} (${rr.room?.roomType?.name})`).join(', ')}</p></div>
                      <div><span className="text-muted-foreground">Check-out:</span><p className="font-medium">{formatDate(selected.checkOutDate)}</p></div>
                      <div><span className="text-muted-foreground">Guests:</span><p className="font-medium">{selected.numberOfGuests}</p></div>
                      <div><span className="text-muted-foreground">Total:</span><p className="font-medium">{formatCurrency(selected.totalAmount)}</p></div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <Label>ID / Passport Number</Label>
                      <Input placeholder="Enter ID or passport number" value={idNumber} onChange={e => setIdNumber(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Notes</Label>
                      <Textarea placeholder="Additional check-in notes..." value={checkInNotes} onChange={e => setCheckInNotes(e.target.value)} rows={2} />
                    </div>
                    <Button className="w-full" onClick={handleCheckIn} disabled={processing || !idNumber}>
                      {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                      Complete Check-in
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <UserCheck className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>Select a reservation to check in</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ============ QUICK CHECK-IN ============
function QuickCheckIn() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations?status=confirmed')
        const today = new Date().toISOString().split('T')[0]
        const todayRes = (data.reservations || []).filter((r: Reservation) =>
          r.checkInDate?.split('T')[0] <= today && r.checkOutDate?.split('T')[0] >= today
        )
        setReservations(todayRes)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const filtered = reservations.filter(r =>
    !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    r.confirmationCode.toLowerCase().includes(search.toLowerCase()) ||
    r.rooms?.some(rr => rr.room?.number?.toLowerCase().includes(search.toLowerCase()))
  )

  const handleQuickCheckIn = async (r: Reservation) => {
    setProcessing(true)
    try {
      await apiFetch('/api/reservations', {
        method: 'PUT',
        body: JSON.stringify({ id: r.id, status: 'checked_in' }),
      })
      toast.success(`${r.guest?.firstName} ${r.guest?.lastName} checked in!`)
      setReservations(prev => prev.filter(x => x.id !== r.id))
    } catch (e: any) { toast.error(e.message) }
    finally { setProcessing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Quick Check-in</h2>
        <p className="text-muted-foreground">One-click check-in for confirmed reservations</p>
      </div>
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search by name, code, or room..." className="pl-8 w-full" value={search} onChange={e => setSearch(e.target.value)} />
      </div>
      {filtered.length === 0 ? (
        <EmptyState title="No Check-ins Available" description="No confirmed reservations ready for check-in." />
      ) : (
        <div className="space-y-3">
          {filtered.map(r => (
            <Card key={r.id}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar><AvatarFallback>{r.guest?.firstName?.[0]}{r.guest?.lastName?.[0]}</AvatarFallback></Avatar>
                  <div>
                    <p className="font-semibold">{r.guest?.firstName} {r.guest?.lastName}</p>
                    <p className="text-sm text-muted-foreground">{r.confirmationCode} • Room {r.rooms?.map(rr => rr.room?.number).join(', ')}</p>
                  </div>
                </div>
                <Button onClick={() => handleQuickCheckIn(r)} disabled={processing} size="sm">
                  <CheckCircle2 className="h-4 w-4 mr-1" />Check-in
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

// ============ GUEST CHECK-OUT ============
function GuestCheckOut() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [folios, setFolios] = useState<Folio[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Reservation | null>(null)
  const [paymentAmount, setPaymentAmount] = useState(0)
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [processing, setProcessing] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations?status=checked_in')
        setReservations(data.reservations || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  useEffect(() => {
    if (selected) {
      (async () => {
        try {
          const data = await apiFetch(`/api/folios?reservationId=${selected.id}`)
          const fols = data.folios || []
          setFolios(fols)
          const balance = fols.reduce((s: number, f: Folio) => s + f.balance, 0)
          setPaymentAmount(balance)
        } catch (e: any) { toast.error(e.message) }
      })()
    }
  }, [selected])

  const filtered = reservations.filter(r =>
    !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    r.rooms?.some(rr => rr.room?.number?.toLowerCase().includes(search.toLowerCase()))
  )

  const folioTotal = folios.reduce((s, f) => s + f.totalAmount, 0)
  const folioPaid = folios.reduce((s, f) => s + f.paidAmount, 0)
  const folioBalance = folios.reduce((s, f) => s + f.balance, 0)

  const handleCheckOut = async () => {
    if (!selected) return
    setProcessing(true)
    try {
      // Pay remaining balance if any
      if (paymentAmount > 0 && folios.length > 0) {
        for (const folio of folios) {
          if (folio.balance > 0) {
            await apiFetch('/api/payments', {
              method: 'POST',
              body: JSON.stringify({
                reservationId: selected.id, folioId: folio.id, guestId: selected.guestId,
                amount: Math.min(paymentAmount, folio.balance), method: paymentMethod, status: 'completed',
              }),
            })
          }
        }
      }
      // Close folios
      for (const folio of folios) {
        await apiFetch('/api/folios', {
          method: 'PUT',
          body: JSON.stringify({ id: folio.id, status: 'closed' }),
        })
      }
      // Check out reservation
      await apiFetch('/api/reservations', {
        method: 'PUT',
        body: JSON.stringify({ id: selected.id, status: 'checked_out' }),
      })
      toast.success('Guest checked out successfully!')
      setSelected(null)
      setFolios([])
      setPaymentAmount(0)
      const data = await apiFetch('/api/reservations?status=checked_in')
      setReservations(data.reservations || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setProcessing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Guest Check-out</h2>
        <p className="text-muted-foreground">{filtered.length} guest(s) currently checked in</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search guest or room..." className="pl-8" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="max-h-[600px] overflow-y-auto space-y-2">
            {filtered.map(r => (
              <Card key={r.id} className={`cursor-pointer transition-all hover:shadow-md ${selected?.id === r.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelected(r)}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{r.guest?.firstName?.[0]}{r.guest?.lastName?.[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{r.guest?.firstName} {r.guest?.lastName}</p>
                      <p className="text-xs text-muted-foreground">Room {r.rooms?.map(rr => rr.room?.number).join(', ')}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><XCircle className="h-5 w-5" />Check-out Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selected ? (
                <>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback>{selected.guest?.firstName?.[0]}{selected.guest?.lastName?.[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{selected.guest?.firstName} {selected.guest?.lastName}</p>
                      <p className="text-sm text-muted-foreground">{selected.confirmationCode} • Room {selected.rooms?.map(rr => rr.room?.number).join(', ')}</p>
                    </div>
                  </div>
                  <Separator />

                  {/* Folio Summary */}
                  <div>
                    <h4 className="font-semibold mb-3">Folio Summary</h4>
                    {folios.length === 0 ? (
                      <p className="text-muted-foreground text-sm">No folio found</p>
                    ) : (
                      <>
                        {folios.map(folio => (
                          <div key={folio.id} className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Folio #{folio.folioNumber}</span>
                              <Badge className={statusColors[folio.status]}>{folio.status}</Badge>
                            </div>
                            {folio.folioItems?.map(item => (
                              <div key={item.id} className="flex justify-between text-sm pl-4">
                                <span>{item.description} {item.quantity > 1 ? `x${item.quantity}` : ''}</span>
                                <span>{formatCurrency(item.amount * item.quantity)}</span>
                              </div>
                            ))}
                          </div>
                        ))}
                        <Separator className="my-2" />
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm"><span>Total Charges:</span><span>{formatCurrency(folioTotal)}</span></div>
                          <div className="flex justify-between text-sm text-emerald-600"><span>Paid:</span><span>{formatCurrency(folioPaid)}</span></div>
                          <div className="flex justify-between font-semibold text-red-600"><span>Balance Due:</span><span>{formatCurrency(folioBalance)}</span></div>
                        </div>
                      </>
                    )}
                  </div>

                  {folioBalance > 0 && (
                    <>
                      <Separator />
                      <div>
                        <h4 className="font-semibold mb-3">Payment Collection</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Amount</Label>
                            <Input type="number" min={0} max={folioBalance} value={paymentAmount} onChange={e => setPaymentAmount(parseFloat(e.target.value) || 0)} />
                          </div>
                          <div className="space-y-2">
                            <Label>Payment Method</Label>
                            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {PAYMENT_METHODS.map(m => <SelectItem key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  <Button className="w-full" onClick={handleCheckOut} disabled={processing}>
                    {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <XCircle className="h-4 w-4 mr-2" />}
                    Complete Check-out
                  </Button>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BedDouble className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>Select a guest to check out</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ============ ROOM CHANGE ============
function RoomChange() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [allRooms, setAllRooms] = useState<Room[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Reservation | null>(null)
  const [newRoomId, setNewRoomId] = useState('')
  const [processing, setProcessing] = useState(false)
  const [search, setSearch] = useState('')

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const [resData, roomData] = await Promise.all([
          apiFetch('/api/reservations?status=checked_in'),
          apiFetch('/api/rooms'),
        ])
        setReservations(resData.reservations || [])
        setAllRooms(roomData.rooms || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const availableRooms = allRooms.filter(r => r.status === 'available')
  const filtered = reservations.filter(r =>
    !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    r.rooms?.some(rr => rr.room?.number?.toLowerCase().includes(search.toLowerCase()))
  )

  const handleRoomChange = async () => {
    if (!selected || !newRoomId) return
    setProcessing(true)
    try {
      // Get current room
      const currentResRoom = selected.rooms?.[0]
      if (!currentResRoom) { toast.error('No room assignment found'); return }

      // Update old room to available
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: currentResRoom.roomId, status: 'available' }),
      })

      // Update new room to occupied
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: newRoomId, status: 'occupied' }),
      })

      // Update reservation with new room
      const newRoom = allRooms.find(r => r.id === newRoomId)
      await apiFetch('/api/reservations', {
        method: 'PUT',
        body: JSON.stringify({
          id: selected.id,
          notes: `Room changed from ${currentResRoom.room?.number} to ${newRoom?.number}`,
        }),
      })

      toast.success(`Room changed from ${currentResRoom.room?.number} to ${newRoom?.number}`)
      setSelected(null)
      setNewRoomId('')
      // Refresh
      const [resData, roomData] = await Promise.all([
        apiFetch('/api/reservations?status=checked_in'),
        apiFetch('/api/rooms'),
      ])
      setReservations(resData.reservations || [])
      setAllRooms(roomData.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setProcessing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Room Change</h2>
        <p className="text-muted-foreground">Transfer guests between rooms</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search guest..." className="pl-8" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="max-h-[500px] overflow-y-auto space-y-2">
            {filtered.map(r => (
              <Card key={r.id} className={`cursor-pointer transition-all hover:shadow-md ${selected?.id === r.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => { setSelected(r); setNewRoomId('') }}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8"><AvatarFallback className="text-xs">{r.guest?.firstName?.[0]}{r.guest?.lastName?.[0]}</AvatarFallback></Avatar>
                    <div>
                      <p className="font-medium text-sm">{r.guest?.firstName} {r.guest?.lastName}</p>
                      <p className="text-xs text-muted-foreground">Current: Room {r.rooms?.map(rr => rr.room?.number).join(', ')}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><BedDouble className="h-5 w-5" />Room Transfer</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {selected ? (
                <>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="text-muted-foreground">Guest:</span><p className="font-medium">{selected.guest?.firstName} {selected.guest?.lastName}</p></div>
                    <div><span className="text-muted-foreground">Current Room:</span><p className="font-medium">{selected.rooms?.map(rr => `${rr.room?.number} (${rr.room?.roomType?.name})`).join(', ')}</p></div>
                    <div><span className="text-muted-foreground">Check-in:</span><p className="font-medium">{formatDate(selected.checkInDate)}</p></div>
                    <div><span className="text-muted-foreground">Check-out:</span><p className="font-medium">{formatDate(selected.checkOutDate)}</p></div>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <Label>New Room *</Label>
                    <Select value={newRoomId} onValueChange={setNewRoomId}>
                      <SelectTrigger><SelectValue placeholder="Select available room" /></SelectTrigger>
                      <SelectContent>
                        {availableRooms.map(r => (
                          <SelectItem key={r.id} value={r.id}>
                            {r.number} - {r.roomType?.name} ({formatCurrency(r.price)}/night)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">{availableRooms.length} room(s) available</p>
                  </div>
                  <Button className="w-full" onClick={handleRoomChange} disabled={processing || !newRoomId}>
                    {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <BedDouble className="h-4 w-4 mr-2" />}
                    Confirm Room Change
                  </Button>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BedDouble className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>Select a guest to change room</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ============ GUEST FOLIO ============
function GuestFolio() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedRes, setSelectedRes] = useState<Reservation | null>(null)
  const [folio, setFolio] = useState<Folio | null>(null)
  const [addChargeOpen, setAddChargeOpen] = useState(false)
  const [chargeForm, setChargeForm] = useState({ description: '', category: 'room', amount: 0, quantity: 1 })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations')
        setReservations(data.reservations || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  useEffect(() => {
    if (selectedRes) {
      (async () => {
        try {
          const data = await apiFetch(`/api/folios?reservationId=${selectedRes.id}`)
          const folios = data.folios || []
          setFolio(folios[0] || null)
        } catch (e: any) { toast.error(e.message) }
      })()
    }
  }, [selectedRes])

  const filtered = reservations.filter(r =>
    !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
    r.confirmationCode.toLowerCase().includes(search.toLowerCase())
  )

  const handleAddCharge = async () => {
    if (!folio || !chargeForm.description || !chargeForm.amount) { toast.error('Fill in all fields'); return }
    setSaving(true)
    try {
      await apiFetch('/api/folios', {
        method: 'POST',
        body: JSON.stringify({ folioId: folio.id, ...chargeForm }),
      })
      toast.success('Charge added to folio')
      setAddChargeOpen(false)
      setChargeForm({ description: '', category: 'room', amount: 0, quantity: 1 })
      // Refresh folio
      const data = await apiFetch(`/api/folios?reservationId=${selectedRes!.id}`)
      const folios = data.folios || []
      setFolio(folios[0] || null)
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Guest Folio</h2>
        <p className="text-muted-foreground">View and manage guest charges and payments</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search guest or code..." className="pl-8" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="max-h-[600px] overflow-y-auto space-y-2">
            {filtered.slice(0, 30).map(r => (
              <Card key={r.id} className={`cursor-pointer transition-all hover:shadow-md ${selectedRes?.id === r.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelectedRes(r)}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{r.guest?.firstName} {r.guest?.lastName}</p>
                      <p className="text-xs text-muted-foreground">{r.confirmationCode}</p>
                    </div>
                    <Badge className={statusColors[r.status]}>{r.status}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          {selectedRes && folio ? (
            <>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Folio #{folio.folioNumber}</CardTitle>
                    <div className="flex gap-2">
                      <Badge className={statusColors[folio.status]}>{folio.status}</Badge>
                      <Button size="sm" onClick={() => setAddChargeOpen(true)}><Plus className="h-4 w-4 mr-1" />Add Charge</Button>
                    </div>
                  </div>
                  <CardDescription>{selectedRes.guest?.firstName} {selectedRes.guest?.lastName} • {selectedRes.confirmationCode}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Charges */}
                  <div>
                    <h4 className="font-semibold mb-2">Charges</h4>
                    {folio.folioItems?.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No charges yet</p>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Description</TableHead><TableHead>Category</TableHead>
                            <TableHead>Qty</TableHead><TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {folio.folioItems?.map(item => (
                            <TableRow key={item.id}>
                              <TableCell>{item.description}</TableCell>
                              <TableCell><Badge variant="outline" className="text-xs">{item.category}</Badge></TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell className="text-right">{formatCurrency(item.amount * item.quantity)}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </div>
                  <Separator />
                  {/* Payment History */}
                  <div>
                    <h4 className="font-semibold mb-2">Payment History</h4>
                    {folio.payments?.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No payments yet</p>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Date</TableHead><TableHead>Method</TableHead>
                            <TableHead>Reference</TableHead><TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {folio.payments?.map(p => (
                            <TableRow key={p.id}>
                              <TableCell>{formatDate(p.createdAt)}</TableCell>
                              <TableCell>{p.method}</TableCell>
                              <TableCell>{p.transactionRef || '-'}</TableCell>
                              <TableCell className="text-right">{formatCurrency(p.amount)}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </div>
                  <Separator />
                  {/* Summary */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm"><span>Total Charges:</span><span className="font-medium">{formatCurrency(folio.totalAmount)}</span></div>
                    <div className="flex justify-between text-sm text-emerald-600"><span>Total Paid:</span><span className="font-medium">{formatCurrency(folio.paidAmount)}</span></div>
                    <Separator className="my-1" />
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Balance:</span>
                      <span className={folio.balance > 0 ? 'text-red-600' : 'text-emerald-600'}>{formatCurrency(folio.balance)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Add Charge Dialog */}
              <Dialog open={addChargeOpen} onOpenChange={setAddChargeOpen}>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Add Charge</DialogTitle>
                    <DialogDescription>Add a charge to this folio</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-2">
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Input value={chargeForm.description} onChange={e => setChargeForm(f => ({ ...f, description: e.target.value }))} placeholder="e.g., Room service dinner" />
                    </div>
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select value={chargeForm.category} onValueChange={v => setChargeForm(f => ({ ...f, category: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {FOLIO_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Amount</Label>
                        <Input type="number" min={0} value={chargeForm.amount} onChange={e => setChargeForm(f => ({ ...f, amount: parseFloat(e.target.value) || 0 }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>Quantity</Label>
                        <Input type="number" min={1} value={chargeForm.quantity} onChange={e => setChargeForm(f => ({ ...f, quantity: parseInt(e.target.value) || 1 }))} />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setAddChargeOpen(false)}>Cancel</Button>
                    <Button onClick={handleAddCharge} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Add Charge</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          ) : selectedRes ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <DollarSign className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>No folio found for this reservation</p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <DollarSign className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>Select a reservation to view folio</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

// ============ GUEST REGISTRATION ============
function GuestRegistration() {
  const [form, setForm] = useState({
    hotelId: '', firstName: '', lastName: '', email: '', phone: '',
    nationality: '', nationalId: '', passportNumber: '', visaNumber: '',
    address: '', city: '', country: '', gender: 'male',
    guestType: 'individual', notes: '',
  })
  const [saving, setSaving] = useState(false)
  const [guests, setGuests] = useState<Guest[]>([])

  useEffect(() => {
    (async () => {
      try {
        const data = await apiFetch('/api/guests')
        setGuests(data.guests || [])
        if (data.guests?.[0]?.hotelId) setForm(f => ({ ...f, hotelId: data.guests[0].hotelId }))
      } catch (e: any) { /* ignore */ }
    })()
  }, [])

  const handleSave = async () => {
    if (!form.firstName || !form.lastName) { toast.error('First name and last name are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/guests', { method: 'POST', body: JSON.stringify(form) })
      toast.success('Guest registered successfully!')
      setForm(f => ({ ...f, firstName: '', lastName: '', email: '', phone: '', nationalId: '', passportNumber: '', visaNumber: '', address: '', notes: '' }))
      const data = await apiFetch('/api/guests')
      setGuests(data.guests || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Guest Registration</h2><p className="text-muted-foreground">Register a new guest profile</p></div>
      <Card>
        <CardHeader><CardTitle>Guest Information</CardTitle><CardDescription>Fill in the guest details to create a profile</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2"><Label>First Name *</Label><Input value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Last Name *</Label><Input value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} /></div>
            <div className="space-y-2">
              <Label>Gender</Label>
              <Select value={form.gender} onValueChange={v => setForm(f => ({ ...f, gender: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Phone</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Nationality</Label><Input value={form.nationality} onChange={e => setForm(f => ({ ...f, nationality: e.target.value }))} /></div>
            <div className="space-y-2"><Label>National ID</Label><Input value={form.nationalId} onChange={e => setForm(f => ({ ...f, nationalId: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Passport Number</Label><Input value={form.passportNumber} onChange={e => setForm(f => ({ ...f, passportNumber: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Visa Number</Label><Input value={form.visaNumber} onChange={e => setForm(f => ({ ...f, visaNumber: e.target.value }))} /></div>
            <div className="space-y-2">
              <Label>Guest Type</Label>
              <Select value={form.guestType} onValueChange={v => setForm(f => ({ ...f, guestType: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="corporate">Corporate</SelectItem>
                  <SelectItem value="vip">VIP</SelectItem>
                  <SelectItem value="frequent">Frequent</SelectItem>
                  <SelectItem value="loyalty">Loyalty</SelectItem>
                  <SelectItem value="family">Family</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Separator />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="sm:col-span-2 lg:col-span-3 space-y-2"><Label>Address</Label><Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} /></div>
            <div className="space-y-2"><Label>City</Label><Input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Country</Label><Input value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} /></div>
          </div>
          <div className="space-y-2"><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
          <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <UserRound className="h-4 w-4 mr-2" />}
            Register Guest
          </Button>
        </CardContent>
      </Card>

      {guests.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Recently Registered Guests</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Nationality</TableHead><TableHead>Type</TableHead><TableHead>Contact</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {guests.slice(0, 10).map(g => (
                  <TableRow key={g.id}>
                    <TableCell className="font-medium">{g.firstName} {g.lastName}</TableCell>
                    <TableCell>{g.nationality || '-'}</TableCell>
                    <TableCell><Badge className={statusColors[g.guestType] || 'bg-gray-100'}>{g.guestType}</Badge></TableCell>
                    <TableCell>{g.email || g.phone || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ============ MAIN COMPONENT ============
export default function FrontOfficeModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'check-in': return <GuestCheckIn />
    case 'quick-checkin': return <QuickCheckIn />
    case 'check-out': return <GuestCheckOut />
    case 'room-change': return <RoomChange />
    case 'guest-folio': return <GuestFolio />
    case 'guest-registration': return <GuestRegistration />
    default: return <GuestCheckIn />
  }
}
