'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ PAYMENT METHODS ============
function PaymentMethods() {
  const [methods, setMethods] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '', type: 'cash', accountCode: '', enabled: true, requiresApproval: false, maxAmount: 0, notes: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setMethods([
        { id: '1', name: 'Cash', type: 'cash', accountCode: 'ACC-CASH', enabled: true, requiresApproval: false, maxAmount: 0, notes: 'Accept all cash payments in BDT', transactionCount: 1245, totalAmount: 8500000 },
        { id: '2', name: 'Visa / MasterCard', type: 'card', accountCode: 'ACC-CARD', enabled: true, requiresApproval: true, maxAmount: 500000, notes: 'Debit and credit cards', transactionCount: 856, totalAmount: 12500000 },
        { id: '3', name: 'bKash', type: 'mobile_banking', accountCode: 'ACC-BKASH', enabled: true, requiresApproval: false, maxAmount: 100000, notes: 'bKash mobile payment', transactionCount: 423, totalAmount: 3200000 },
        { id: '4', name: 'Nagad', type: 'mobile_banking', accountCode: 'ACC-NAGAD', enabled: true, requiresApproval: false, maxAmount: 100000, notes: 'Nagad mobile payment', transactionCount: 234, totalAmount: 1800000 },
        { id: '5', name: 'Rocket', type: 'mobile_banking', accountCode: 'ACC-ROCKET', enabled: false, requiresApproval: false, maxAmount: 50000, notes: 'Dutch-Bangla Rocket', transactionCount: 0, totalAmount: 0 },
        { id: '6', name: 'SSLCommerz', type: 'online_gateway', accountCode: 'ACC-SSL', enabled: true, requiresApproval: true, maxAmount: 500000, notes: 'Online payment gateway', transactionCount: 567, totalAmount: 6800000 },
        { id: '7', name: 'Stripe', type: 'international', accountCode: 'ACC-STRIPE', enabled: true, requiresApproval: true, maxAmount: 10000, notes: 'International card payments (USD)', transactionCount: 89, totalAmount: 450000 },
        { id: '8', name: 'PayPal', type: 'international', accountCode: 'ACC-PAYPAL', enabled: false, requiresApproval: true, maxAmount: 5000, notes: 'PayPal international', transactionCount: 0, totalAmount: 0 },
        { id: '9', name: 'Bank Transfer', type: 'bank_transfer', accountCode: 'ACC-BANK', enabled: true, requiresApproval: true, maxAmount: 0, notes: 'Direct bank transfer / wire', transactionCount: 45, totalAmount: 2100000 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ name: '', type: 'cash', accountCode: '', enabled: true, requiresApproval: false, maxAmount: 0, notes: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name, type: item.type, accountCode: item.accountCode, enabled: item.enabled, requiresApproval: item.requiresApproval, maxAmount: item.maxAmount, notes: item.notes }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setMethods(prev => prev.map(m => m.id === editItem.id ? { ...m, ...formData } : m))
      toast.success('Payment method updated')
    } else {
      setMethods(prev => [...prev, { ...formData, id: Date.now().toString(), transactionCount: 0, totalAmount: 0 }])
      toast.success('Payment method added')
    }
    setSaving(false); setDialogOpen(false)
  }

  const toggleMethod = (id: string) => {
    setMethods(prev => prev.map(m => m.id === id ? { ...m, enabled: !m.enabled } : m))
    toast.success('Payment method status updated')
  }

  const typeLabels: Record<string, string> = { cash: 'Cash', card: 'Card', mobile_banking: 'Mobile Banking', online_gateway: 'Online Gateway', international: 'International', bank_transfer: 'Bank Transfer' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Active Methods" value={methods.filter(m => m.enabled).length} subtitle="Accepting payments" color="emerald" />
        <KPICard title="Total Transactions" value={methods.reduce((s, m) => s + m.transactionCount, 0).toLocaleString()} subtitle="All methods" color="blue" />
        <KPICard title="Total Revenue" value={formatCurrency(methods.reduce((s, m) => s + m.totalAmount, 0))} subtitle="All time" color="amber" />
        <KPICard title="Disabled" value={methods.filter(m => !m.enabled).length} subtitle="Not accepting" color="red" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Payment Methods</h2><p className="text-muted-foreground">Configure available payment methods</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Method</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead>Account Code</TableHead><TableHead>Transactions</TableHead><TableHead>Total Amount</TableHead><TableHead>Max Amount</TableHead><TableHead>Approval</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
              </TableHeader>
              <TableBody>
                {methods.map(m => (
                  <TableRow key={m.id} className={!m.enabled ? 'opacity-60' : ''}>
                    <TableCell className="font-medium">{m.name}</TableCell>
                    <TableCell><Badge variant="outline">{typeLabels[m.type]}</Badge></TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{m.accountCode}</code></TableCell>
                    <TableCell>{m.transactionCount.toLocaleString()}</TableCell>
                    <TableCell>{formatCurrency(m.totalAmount)}</TableCell>
                    <TableCell>{m.maxAmount ? formatCurrency(m.maxAmount) : 'Unlimited'}</TableCell>
                    <TableCell>{m.requiresApproval ? 'Required' : 'No'}</TableCell>
                    <TableCell><Badge className={m.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{m.enabled ? 'Active' : 'Inactive'}</Badge></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(m)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toggleMethod(m.id)}>{m.enabled ? 'Disable' : 'Enable'}</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'Add'} Payment Method</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Method Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(typeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Account Code</Label><Input value={formData.accountCode} onChange={e => setFormData({ ...formData, accountCode: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Max Amount (0=Unlimited)</Label><Input type="number" value={formData.maxAmount} onChange={e => setFormData({ ...formData, maxAmount: Number(e.target.value) })} /></div>
              <div><Label>Requires Approval</Label>
                <Select value={formData.requiresApproval ? 'yes' : 'no'} onValueChange={v => setFormData({ ...formData, requiresApproval: v === 'yes' })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Add'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ TRANSACTIONS ============
function Transactions() {
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [page, setPage] = useState(1)

  useEffect(() => {
    setTimeout(() => {
      setTransactions([
        { id: '1', ref: 'PAY-2024-001', bookingRef: 'RES-1001', guest: 'Ahmed Khan', amount: 12500, method: 'Visa / MasterCard', type: 'card', status: 'completed', date: '2024-11-15T14:30:00', description: 'Room charge - 2 nights' },
        { id: '2', ref: 'PAY-2024-002', bookingRef: 'RES-1002', guest: 'Sarah Rahman', amount: 8500, method: 'bKash', type: 'mobile_banking', status: 'completed', date: '2024-11-15T12:00:00', description: 'Room charge - 1 night' },
        { id: '3', ref: 'PAY-2024-003', bookingRef: 'RES-1003', guest: 'Mohammad Ali', amount: 3200, method: 'Cash', type: 'cash', status: 'completed', date: '2024-11-14T18:00:00', description: 'F&B restaurant bill' },
        { id: '4', ref: 'PAY-2024-004', bookingRef: 'RES-1004', guest: 'Rafiq Islam', amount: 45000, method: 'SSLCommerz', type: 'online_gateway', status: 'completed', date: '2024-11-14T10:00:00', description: 'Suite booking - 5 nights' },
        { id: '5', ref: 'PAY-2024-005', bookingRef: 'RES-1005', guest: 'Fatima Begum', amount: 6500, method: 'Nagad', type: 'mobile_banking', status: 'pending', date: '2024-11-14T09:30:00', description: 'Room charge - 1 night' },
        { id: '6', ref: 'PAY-2024-006', bookingRef: 'RES-1006', guest: 'Karim Hossain', amount: 2200, method: 'Cash', type: 'cash', status: 'completed', date: '2024-11-13T20:00:00', description: 'Minibar charges' },
        { id: '7', ref: 'PAY-2024-007', bookingRef: 'RES-1007', guest: 'Nasreen Akter', amount: 15000, method: 'Bank Transfer', type: 'bank_transfer', status: 'pending', date: '2024-11-13T11:00:00', description: 'Corporate booking payment' },
        { id: '8', ref: 'PAY-2024-008', bookingRef: 'RES-1008', guest: 'Taslima Khatun', amount: 5500, method: 'bKash', type: 'mobile_banking', status: 'failed', date: '2024-11-12T16:00:00', description: 'Room charge - insufficient balance' },
        { id: '9', ref: 'PAY-2024-009', bookingRef: 'RES-1009', guest: 'John Smith', amount: 850, method: 'Stripe', type: 'international', status: 'completed', date: '2024-11-12T08:00:00', description: 'Room charge - USD 8.50' },
        { id: '10', ref: 'PAY-2024-010', bookingRef: 'RES-1010', guest: 'Ahmed Khan', amount: 3000, method: 'Visa / MasterCard', type: 'card', status: 'refunded', date: '2024-11-11T14:00:00', description: 'Cancellation refund' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const filtered = transactions.filter(t => {
    const matchSearch = !search || Object.values(t).some(v => String(v || '').toLowerCase().includes(search.toLowerCase()))
    const matchFilter = filter === 'all' || t.status === filter
    return matchSearch && matchFilter
  })
  const pageSize = 10
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalCompleted = transactions.filter(t => t.status === 'completed').reduce((s, t) => s + t.amount, 0)
  const totalPending = transactions.filter(t => t.status === 'pending').reduce((s, t) => s + t.amount, 0)

  const statusBadge: Record<string, string> = { completed: 'bg-emerald-100 text-emerald-800', pending: 'bg-amber-100 text-amber-800', failed: 'bg-red-100 text-red-800', refunded: 'bg-blue-100 text-blue-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Revenue" value={formatCurrency(totalCompleted)} subtitle="Completed payments" color="emerald" />
        <KPICard title="Pending" value={formatCurrency(totalPending)} subtitle="Awaiting confirmation" color="amber" />
        <KPICard title="Transactions" value={transactions.length} subtitle="Total count" color="blue" />
        <KPICard title="Failed" value={transactions.filter(t => t.status === 'failed').length} subtitle="Need attention" color="red" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Payment Transactions</h2><p className="text-muted-foreground">Complete payment history</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Select value={filter} onValueChange={v => { setFilter(v); setPage(1) }}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem><SelectItem value="completed">Completed</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="failed">Failed</SelectItem><SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Reference</TableHead><TableHead>Booking</TableHead><TableHead>Guest</TableHead><TableHead>Amount</TableHead><TableHead>Method</TableHead><TableHead>Date</TableHead><TableHead>Description</TableHead><TableHead>Status</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(t => (
                    <TableRow key={t.id}>
                      <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{t.ref}</code></TableCell>
                      <TableCell>{t.bookingRef}</TableCell>
                      <TableCell className="font-medium">{t.guest}</TableCell>
                      <TableCell className="font-medium">{formatCurrency(t.amount)}</TableCell>
                      <TableCell>{t.method}</TableCell>
                      <TableCell>{formatDateTime(t.date)}</TableCell>
                      <TableCell className="max-w-[200px] truncate text-sm">{t.description}</TableCell>
                      <TableCell><Badge className={statusBadge[t.status] || ''}>{t.status}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============ GATEWAY CONFIG ============
function GatewayConfig() {
  const [gateways, setGateways] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [editGateway, setEditGateway] = useState<any>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setGateways([
        { id: '1', name: 'SSLCommerz', type: 'online_gateway', storeId: 'grand_hotel_live', storePassword: '****3456', apiUrl: 'https://securepay.sslcommerz.com', testMode: false, currency: 'BDT', successUrl: '/api/payment/success', failUrl: '/api/payment/fail', cancelUrl: '/api/payment/cancel', ipnUrl: '/api/payment/ipn' },
        { id: '2', name: 'bKash', type: 'mobile_banking', username: 'grand_hotel', appKey: 'bk_****1234', appSecret: '****5678', apiUrl: 'https://checkout.pay.bka.sh/v1.2', testMode: false, currency: 'BDT', successUrl: '/api/payment/bkash/success', failUrl: '/api/payment/bkash/fail' },
        { id: '3', name: 'Nagad', type: 'mobile_banking', merchantId: 'NG_GRAND_001', merchantKey: '****9012', apiUrl: 'https://api.nagad.com', testMode: false, currency: 'BDT', callbackUrl: '/api/payment/nagad/callback' },
        { id: '4', name: 'Stripe', type: 'international', publishableKey: 'pk_live_****abcd', secretKey: 'sk_live_****efgh', webhookSecret: 'whsec_****ijkl', apiUrl: 'https://api.stripe.com/v1', testMode: false, currency: 'USD', webhookUrl: '/api/payment/stripe/webhook' },
        { id: '5', name: 'PayPal', type: 'international', clientId: 'pp_****mnop', clientSecret: '****qrst', apiUrl: 'https://api-m.paypal.com', testMode: true, currency: 'USD', webhookUrl: '/api/payment/paypal/webhook' },
        { id: '6', name: 'Rocket', type: 'mobile_banking', merchantId: 'RK_GRAND_001', merchantKey: '****uvwx', apiUrl: 'https://api.rocket.com', testMode: true, currency: 'BDT', callbackUrl: '/api/payment/rocket/callback' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Gateway configuration saved'); setSaving(false); setDialogOpen(false)
  }

  const typeLabels: Record<string, string> = { online_gateway: 'Online Gateway', mobile_banking: 'Mobile Banking', international: 'International' }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Gateway Configuration</h2><p className="text-muted-foreground">Configure API keys and settings for each payment gateway</p></div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gateways.map(g => (
            <Card key={g.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{g.name}</CardTitle>
                    <CardDescription>{typeLabels[g.type]} | {g.currency}</CardDescription>
                  </div>
                  {g.testMode && <Badge variant="outline" className="text-amber-600">Test Mode</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {g.storeId && <div className="flex justify-between"><span className="text-muted-foreground">Store ID:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.storeId}</code></div>}
                  {g.appKey && <div className="flex justify-between"><span className="text-muted-foreground">App Key:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.appKey}</code></div>}
                  {g.merchantId && <div className="flex justify-between"><span className="text-muted-foreground">Merchant ID:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.merchantId}</code></div>}
                  {g.publishableKey && <div className="flex justify-between"><span className="text-muted-foreground">Publishable Key:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.publishableKey}</code></div>}
                  {g.clientId && <div className="flex justify-between"><span className="text-muted-foreground">Client ID:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.clientId}</code></div>}
                  <div className="flex justify-between"><span className="text-muted-foreground">API URL:</span><span className="text-xs truncate max-w-[200px]">{g.apiUrl}</span></div>
                </div>
                <Separator className="my-3" />
                <Button variant="outline" size="sm" onClick={() => { setEditGateway(g); setDialogOpen(true) }}><Edit className="h-3 w-3 mr-1" />Configure</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Configure {editGateway?.name}</DialogTitle><DialogDescription>{typeLabels[editGateway?.type]} - {editGateway?.currency}</DialogDescription></DialogHeader>
          {editGateway && (
            <div className="space-y-4 py-2">
              {editGateway.storeId && <div><Label>Store ID</Label><Input value={editGateway.storeId} onChange={e => setEditGateway({ ...editGateway, storeId: e.target.value })} /></div>}
              {editGateway.storePassword && <div><Label>Store Password</Label><Input type="password" value={editGateway.storePassword} onChange={e => setEditGateway({ ...editGateway, storePassword: e.target.value })} /></div>}
              {editGateway.appKey && <div><Label>App Key</Label><Input value={editGateway.appKey} onChange={e => setEditGateway({ ...editGateway, appKey: e.target.value })} /></div>}
              {editGateway.appSecret && <div><Label>App Secret</Label><Input type="password" value={editGateway.appSecret} onChange={e => setEditGateway({ ...editGateway, appSecret: e.target.value })} /></div>}
              {editGateway.merchantId && <div><Label>Merchant ID</Label><Input value={editGateway.merchantId} onChange={e => setEditGateway({ ...editGateway, merchantId: e.target.value })} /></div>}
              {editGateway.merchantKey && <div><Label>Merchant Key</Label><Input type="password" value={editGateway.merchantKey} onChange={e => setEditGateway({ ...editGateway, merchantKey: e.target.value })} /></div>}
              {editGateway.publishableKey && <div><Label>Publishable Key</Label><Input value={editGateway.publishableKey} onChange={e => setEditGateway({ ...editGateway, publishableKey: e.target.value })} /></div>}
              {editGateway.secretKey && <div><Label>Secret Key</Label><Input type="password" value={editGateway.secretKey} onChange={e => setEditGateway({ ...editGateway, secretKey: e.target.value })} /></div>}
              {editGateway.webhookSecret && <div><Label>Webhook Secret</Label><Input type="password" value={editGateway.webhookSecret} onChange={e => setEditGateway({ ...editGateway, webhookSecret: e.target.value })} /></div>}
              {editGateway.clientId && <div><Label>Client ID</Label><Input value={editGateway.clientId} onChange={e => setEditGateway({ ...editGateway, clientId: e.target.value })} /></div>}
              {editGateway.clientSecret && <div><Label>Client Secret</Label><Input type="password" value={editGateway.clientSecret} onChange={e => setEditGateway({ ...editGateway, clientSecret: e.target.value })} /></div>}
              <div><Label>API URL</Label><Input value={editGateway.apiUrl} onChange={e => setEditGateway({ ...editGateway, apiUrl: e.target.value })} /></div>
              <div className="flex items-center justify-between"><Label>Test Mode</Label>
                <Select value={editGateway.testMode ? 'yes' : 'no'} onValueChange={v => setEditGateway({ ...editGateway, testMode: v === 'yes' })}>
                  <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function PaymentModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'methods': return <PaymentMethods />
    case 'transactions': return <Transactions />
    case 'gateways': return <GatewayConfig />
    default: return <EmptyState title="Unknown Sub-Module" description={`Payment sub-module "${subModule}" not found.`} />
  }
}
