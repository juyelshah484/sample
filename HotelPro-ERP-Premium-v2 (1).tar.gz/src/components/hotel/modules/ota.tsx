'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ CHANNEL LIST ============
function ChannelList() {
  const [channels, setChannels] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editChannel, setEditChannel] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '', type: 'ota', apiUrl: '', apiKey: '', hotelId: '', commission: 15, enabled: true, syncEnabled: true,
  })

  useEffect(() => {
    setTimeout(() => {
      setChannels([
        { id: '1', name: 'Booking.com', type: 'ota', apiUrl: 'https://supply-xml.booking.com', apiKey: 'bk_****3456', hotelId: 'GRAND_DH_001', commission: 15, enabled: true, syncEnabled: true, lastSync: '2024-11-15T10:30:00', status: 'connected', bookings: 245, revenue: 3200000 },
        { id: '2', name: 'Agoda', type: 'ota', apiUrl: 'https://partner.agoda.com/api', apiKey: 'ag_****7890', hotelId: 'AG_GRAND_001', commission: 18, enabled: true, syncEnabled: true, lastSync: '2024-11-15T10:25:00', status: 'connected', bookings: 189, revenue: 2100000 },
        { id: '3', name: 'Expedia', type: 'ota', apiUrl: 'https://services.expediapartner.com', apiKey: 'ex_****2345', hotelId: 'EXP_GRAND_01', commission: 20, enabled: true, syncEnabled: true, lastSync: '2024-11-15T10:20:00', status: 'connected', bookings: 112, revenue: 1500000 },
        { id: '4', name: 'Airbnb', type: 'ota', apiUrl: 'https://api.airbnb.com/v2', apiKey: 'ab_****6789', hotelId: '', commission: 3, enabled: false, syncEnabled: false, lastSync: null, status: 'disconnected', bookings: 0, revenue: 0 },
        { id: '5', name: 'Goibibo', type: 'ota', apiUrl: 'https://api.goibibo.com', apiKey: 'gi_****0123', hotelId: 'GO_GRAND_001', commission: 12, enabled: true, syncEnabled: true, lastSync: '2024-11-15T10:15:00', status: 'connected', bookings: 67, revenue: 780000 },
        { id: '6', name: 'Trip.com', type: 'ota', apiUrl: 'https://open.trip.com', apiKey: 'tc_****4567', hotelId: 'TC_GRAND_001', commission: 16, enabled: true, syncEnabled: false, lastSync: '2024-11-14T18:00:00', status: 'sync_error', bookings: 34, revenue: 420000 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditChannel(null); setFormData({ name: '', type: 'ota', apiUrl: '', apiKey: '', hotelId: '', commission: 15, enabled: true, syncEnabled: true }); setDialogOpen(true) }
  const openEdit = (ch: any) => { setEditChannel(ch); setFormData({ name: ch.name, type: ch.type, apiUrl: ch.apiUrl, apiKey: ch.apiKey, hotelId: ch.hotelId, commission: ch.commission, enabled: ch.enabled, syncEnabled: ch.syncEnabled }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    if (editChannel) {
      setChannels(prev => prev.map(c => c.id === editChannel.id ? { ...c, ...formData } : c))
      toast.success('Channel updated')
    } else {
      setChannels(prev => [...prev, { ...formData, id: Date.now().toString(), lastSync: null, status: 'disconnected', bookings: 0, revenue: 0 }])
      toast.success('Channel added')
    }
    setSaving(false); setDialogOpen(false)
  }

  const toggleConnection = (id: string) => {
    setChannels(prev => prev.map(c => c.id === id ? { ...c, enabled: !c.enabled, status: c.enabled ? 'disconnected' : 'connected' } : c))
    toast.success('Connection status updated')
  }

  const statusBadge: Record<string, string> = { connected: 'bg-emerald-100 text-emerald-800', disconnected: 'bg-gray-100 text-gray-800', sync_error: 'bg-red-100 text-red-800', syncing: 'bg-blue-100 text-blue-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Connected Channels" value={channels.filter(c => c.enabled).length} subtitle="Active OTAs" color="emerald" />
        <KPICard title="Total Bookings" value={channels.reduce((s, c) => s + c.bookings, 0)} subtitle="From all channels" color="blue" />
        <KPICard title="Total Revenue" value={formatCurrency(channels.reduce((s, c) => s + c.revenue, 0))} subtitle="Channel bookings" color="amber" />
        <KPICard title="Avg. Commission" value={`${(channels.filter(c => c.enabled).reduce((s, c) => s + c.commission, 0) / channels.filter(c => c.enabled).length).toFixed(1)}%`} subtitle="Across channels" color="violet" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">OTA Channels</h2><p className="text-muted-foreground">Manage Online Travel Agency connections</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Channel</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {channels.map(ch => (
            <Card key={ch.id} className={!ch.enabled ? 'opacity-60' : ''}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{ch.name}</CardTitle>
                  <Badge className={statusBadge[ch.status] || ''}>{ch.status.replace('_', ' ')}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Commission:</span><span className="font-medium">{ch.commission}%</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Hotel ID:</span><span>{ch.hotelId || '-'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Last Sync:</span><span>{ch.lastSync ? formatDateTime(ch.lastSync) : 'Never'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Bookings:</span><span className="font-medium">{ch.bookings}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Revenue:</span><span className="font-medium">{formatCurrency(ch.revenue)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Auto Sync:</span><span>{ch.syncEnabled ? 'Enabled' : 'Disabled'}</span></div>
                </div>
                <Separator className="my-3" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openEdit(ch)}><Edit className="h-3 w-3 mr-1" />Configure</Button>
                  <Button variant="outline" size="sm" onClick={() => toggleConnection(ch.id)}>{ch.enabled ? 'Disconnect' : 'Connect'}</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editChannel ? 'Configure' : 'Add'} Channel</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Channel Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div><Label>API URL</Label><Input value={formData.apiUrl} onChange={e => setFormData({ ...formData, apiUrl: e.target.value })} /></div>
            <div><Label>API Key</Label><Input type="password" value={formData.apiKey} onChange={e => setFormData({ ...formData, apiKey: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Hotel ID on Channel</Label><Input value={formData.hotelId} onChange={e => setFormData({ ...formData, hotelId: e.target.value })} /></div>
              <div><Label>Commission (%)</Label><Input type="number" value={formData.commission} onChange={e => setFormData({ ...formData, commission: Number(e.target.value) })} /></div>
            </div>
            <div className="flex items-center justify-between"><Label>Enable Auto Sync</Label>
              <Select value={formData.syncEnabled ? 'yes' : 'no'} onValueChange={v => setFormData({ ...formData, syncEnabled: v === 'yes' })}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editChannel ? 'Save' : 'Add'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ INVENTORY SYNC ============
function InventorySync() {
  const [syncLogs, setSyncLogs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setSyncLogs([
        { id: '1', channel: 'Booking.com', action: 'availability_update', roomsAffected: 45, status: 'success', timestamp: '2024-11-15T10:30:00', details: 'Updated availability for all room types' },
        { id: '2', channel: 'Agoda', action: 'rate_update', roomsAffected: 45, status: 'success', timestamp: '2024-11-15T10:25:00', details: 'Synced rates for next 90 days' },
        { id: '3', channel: 'Expedia', action: 'booking_import', roomsAffected: 3, status: 'success', timestamp: '2024-11-15T10:20:00', details: 'Imported 3 new bookings' },
        { id: '4', channel: 'Trip.com', action: 'availability_update', roomsAffected: 0, status: 'failed', timestamp: '2024-11-15T10:15:00', details: 'API timeout - connection refused' },
        { id: '5', channel: 'Goibibo', action: 'booking_import', roomsAffected: 2, status: 'success', timestamp: '2024-11-15T10:10:00', details: 'Imported 2 new bookings' },
        { id: '6', channel: 'Booking.com', action: 'rate_update', roomsAffected: 45, status: 'success', timestamp: '2024-11-14T22:00:00', details: 'Seasonal rate update applied' },
        { id: '7', channel: 'Agoda', action: 'restriction_update', roomsAffected: 12, status: 'success', timestamp: '2024-11-14T18:00:00', details: 'Minimum stay restriction updated' },
        { id: '8', channel: 'Expedia', action: 'availability_update', roomsAffected: 45, status: 'partial', timestamp: '2024-11-14T14:00:00', details: '38/45 rooms updated, 7 failed' },
        { id: '9', channel: 'Booking.com', action: 'booking_import', roomsAffected: 5, status: 'success', timestamp: '2024-11-14T10:00:00', details: 'Imported 5 new bookings' },
        { id: '10', channel: 'Trip.com', action: 'rate_update', roomsAffected: 0, status: 'failed', timestamp: '2024-11-14T06:00:00', details: 'Authentication failed - API key expired' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSyncAll = async () => {
    setSyncing(true); await new Promise(r => setTimeout(r, 2000))
    toast.success('All channels synced successfully')
    setSyncing(false)
  }

  const actionLabels: Record<string, string> = { availability_update: 'Availability', rate_update: 'Rates', booking_import: 'Bookings', restriction_update: 'Restrictions' }
  const statusBadge: Record<string, string> = { success: 'bg-emerald-100 text-emerald-800', failed: 'bg-red-100 text-red-800', partial: 'bg-amber-100 text-amber-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Successful Syncs" value={syncLogs.filter(l => l.status === 'success').length} subtitle="Today" color="emerald" />
        <KPICard title="Failed Syncs" value={syncLogs.filter(l => l.status === 'failed').length} subtitle="Need attention" color="red" />
        <KPICard title="Bookings Imported" value={syncLogs.filter(l => l.action === 'booking_import' && l.status === 'success').reduce((s, l) => s + l.roomsAffected, 0)} subtitle="Via sync" color="blue" />
        <KPICard title="Channels Active" value={new Set(syncLogs.filter(l => l.status === 'success').map(l => l.channel)).size} subtitle="Syncing properly" color="violet" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Inventory Sync</h2><p className="text-muted-foreground">Monitor sync status and logs across channels</p></div>
        <Button size="sm" onClick={handleSyncAll} disabled={syncing}>{syncing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-1" />}{syncing ? 'Syncing...' : 'Sync All'}</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-4">
            {['Booking.com', 'Agoda', 'Expedia', 'Goibibo'].map(ch => {
              const lastSync = syncLogs.find(l => l.channel === ch)
              return (
                <Card key={ch}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{ch}</span>
                      {lastSync && <Badge className={statusBadge[lastSync.status] || ''}>{lastSync.status}</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">Last sync: {lastSync ? formatDateTime(lastSync.timestamp) : 'Never'}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Timestamp</TableHead><TableHead>Channel</TableHead><TableHead>Action</TableHead><TableHead>Affected</TableHead><TableHead>Status</TableHead><TableHead>Details</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {syncLogs.map(l => (
                    <TableRow key={l.id}>
                      <TableCell>{formatDateTime(l.timestamp)}</TableCell>
                      <TableCell className="font-medium">{l.channel}</TableCell>
                      <TableCell><Badge variant="outline">{actionLabels[l.action]}</Badge></TableCell>
                      <TableCell>{l.roomsAffected}</TableCell>
                      <TableCell><Badge className={statusBadge[l.status] || ''}>{l.status}</Badge></TableCell>
                      <TableCell className="max-w-[250px] truncate text-sm text-muted-foreground">{l.details}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

// ============ DYNAMIC PRICING ============
function DynamicPricing() {
  const [rules, setRules] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    channel: '', roomType: '', ruleType: 'markup', value: 0, valueType: 'percentage',
    minOccupancy: 0, startDate: '', endDate: '', priority: 1, status: 'active',
  })

  useEffect(() => {
    setTimeout(() => {
      setRules([
        { id: '1', channel: 'Booking.com', roomType: 'All', ruleType: 'markup', value: 5, valueType: 'percentage', minOccupancy: 0, startDate: '2024-01-01', endDate: '2024-12-31', priority: 1, status: 'active' },
        { id: '2', channel: 'Agoda', roomType: 'Deluxe Room', ruleType: 'markup', value: 8, valueType: 'percentage', minOccupancy: 0, startDate: '2024-01-01', endDate: '2024-12-31', priority: 2, status: 'active' },
        { id: '3', channel: 'All', roomType: 'All', ruleType: 'discount', value: 15, valueType: 'percentage', minOccupancy: 0, startDate: '2024-11-01', endDate: '2024-11-30', priority: 3, status: 'active' },
        { id: '4', channel: 'Expedia', roomType: 'Suite', ruleType: 'markup', value: 500, valueType: 'flat', minOccupancy: 0, startDate: '2024-12-15', endDate: '2025-01-05', priority: 5, status: 'active' },
        { id: '5', channel: 'Booking.com', roomType: 'Standard Double', ruleType: 'discount', value: 10, valueType: 'percentage', minOccupancy: 3, startDate: '2024-01-01', endDate: '2024-12-31', priority: 2, status: 'active' },
        { id: '6', channel: 'Goibibo', roomType: 'All', ruleType: 'markup', value: 3, valueType: 'percentage', minOccupancy: 0, startDate: '2024-01-01', endDate: '2024-12-31', priority: 1, status: 'inactive' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ channel: '', roomType: '', ruleType: 'markup', value: 0, valueType: 'percentage', minOccupancy: 0, startDate: '', endDate: '', priority: 1, status: 'active' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setRules(prev => prev.map(r => r.id === editItem.id ? { ...r, ...formData } : r))
      toast.success('Rule updated')
    } else {
      setRules(prev => [...prev, { ...formData, id: Date.now().toString() }])
      toast.success('Rule created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = (id: string) => {
    setRules(prev => prev.filter(r => r.id !== id))
    toast.success('Rule deleted')
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Rules" value={rules.filter(r => r.status === 'active').length} subtitle="Pricing rules" color="emerald" />
        <KPICard title="Markups" value={rules.filter(r => r.ruleType === 'markup' && r.status === 'active').length} subtitle="Price increases" color="amber" />
        <KPICard title="Discounts" value={rules.filter(r => r.ruleType === 'discount' && r.status === 'active').length} subtitle="Price reductions" color="blue" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Dynamic Pricing</h2><p className="text-muted-foreground">Configure rate rules per channel with markup/discount</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Rule</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Channel</TableHead><TableHead>Room Type</TableHead><TableHead>Rule</TableHead><TableHead>Value</TableHead><TableHead>Period</TableHead><TableHead>Priority</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
              </TableHeader>
              <TableBody>
                {rules.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.channel}</TableCell>
                    <TableCell>{r.roomType}</TableCell>
                    <TableCell><Badge variant="outline" className={r.ruleType === 'markup' ? 'border-amber-300 text-amber-700' : 'border-emerald-300 text-emerald-700'}>{r.ruleType}</Badge></TableCell>
                    <TableCell>{r.valueType === 'percentage' ? `${r.value}%` : formatCurrency(r.value)}</TableCell>
                    <TableCell className="text-xs">{formatDate(r.startDate)} - {formatDate(r.endDate)}</TableCell>
                    <TableCell>P{r.priority}</TableCell>
                    <TableCell><Badge className={statusColors[r.status] || ''}>{r.status}</Badge></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(r)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(r.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Pricing Rule</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Channel</Label>
                <Select value={formData.channel} onValueChange={v => setFormData({ ...formData, channel: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent><SelectItem value="All">All Channels</SelectItem><SelectItem value="Booking.com">Booking.com</SelectItem><SelectItem value="Agoda">Agoda</SelectItem><SelectItem value="Expedia">Expedia</SelectItem><SelectItem value="Goibibo">Goibibo</SelectItem><SelectItem value="Trip.com">Trip.com</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Room Type</Label>
                <Select value={formData.roomType} onValueChange={v => setFormData({ ...formData, roomType: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent><SelectItem value="All">All Rooms</SelectItem><SelectItem value="Standard Single">Standard Single</SelectItem><SelectItem value="Standard Double">Standard Double</SelectItem><SelectItem value="Deluxe Room">Deluxe Room</SelectItem><SelectItem value="Suite">Suite</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Rule Type</Label>
                <Select value={formData.ruleType} onValueChange={v => setFormData({ ...formData, ruleType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="markup">Markup</SelectItem><SelectItem value="discount">Discount</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Value Type</Label>
                <Select value={formData.valueType} onValueChange={v => setFormData({ ...formData, valueType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="percentage">Percentage</SelectItem><SelectItem value="flat">Flat Amount</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Value</Label><Input type="number" value={formData.value} onChange={e => setFormData({ ...formData, value: Number(e.target.value) })} /></div>
              <div><Label>Priority</Label><Input type="number" value={formData.priority} onChange={e => setFormData({ ...formData, priority: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function OtaModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'channels': return <ChannelList />
    case 'sync': return <InventorySync />
    case 'dynamic-pricing': return <DynamicPricing />
    default: return <EmptyState title="Unknown Sub-Module" description={`OTA sub-module "${subModule}" not found.`} />
  }
}
