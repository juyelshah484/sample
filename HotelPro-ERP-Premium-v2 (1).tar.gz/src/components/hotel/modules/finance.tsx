'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============================================================
// Chart of Accounts Sub-Module
// ============================================================
function ChartOfAccounts() {
  const crud = useCrud<any>('/api/accounts')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ code: '', name: '', type: 'asset' })

  const accountTypes = ['asset', 'liability', 'income', 'expense', 'equity']

  const openCreate = () => { setEditItem(null); setFormData({ code: '', name: '', type: 'asset' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ code: item.code || '', name: item.name || '', type: item.type || 'asset' }); setDialogOpen(true) }

  const handleSave = async () => {
    if (!formData.code || !formData.name) { toast.error('Code and name are required'); return }
    setSaving(true)
    const ok = editItem ? await crud.updateItem(editItem.id, formData) : await crud.createItem(formData)
    setSaving(false)
    if (ok) setDialogOpen(false)
  }

  const handleDelete = async () => { if (deleteId) { await crud.deleteItem(deleteId); setDeleteId(null) } }

  const groupedAccounts = accountTypes.map(type => ({
    type,
    accounts: crud.filtered.filter((a: any) => a.type === type)
  }))

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Chart of Accounts</h2><p className="text-muted-foreground">Manage account structure</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={e => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Account</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {accountTypes.map(type => (
          <MiniStat key={type} label={type.charAt(0).toUpperCase() + type.slice(1)} value={crud.items.filter((a: any) => a.type === type).length} color="" />
        ))}
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <div className="space-y-4">
          {groupedAccounts.map(group => group.accounts.length > 0 && (
            <Card key={group.type}>
              <CardHeader className="pb-2"><CardTitle className="text-base"><Badge className={statusColors[group.type] || 'bg-gray-100 text-gray-800'}>{group.type.charAt(0).toUpperCase() + group.type.slice(1)}</Badge></CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {group.accounts.map((account: any) => (
                      <TableRow key={account.id}>
                        <TableCell><Badge variant="outline">{account.code}</Badge></TableCell>
                        <TableCell className="font-medium">{account.name}</TableCell>
                        <TableCell><Badge className={statusColors[account.type] || ''}>{account.type}</Badge></TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(account)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(account.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Account</DialogTitle><DialogDescription>Fill in the account details.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Account Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} placeholder="e.g. 1000" /></div>
            <div><Label>Account Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g. Cash" /></div>
            <div><Label>Account Type</Label>
              <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{accountTypes.map(t => <SelectItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this account?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// General Ledger Sub-Module
// ============================================================
function GeneralLedger() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedAccount, setSelectedAccount] = useState<string>('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 15

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/accounts')
        setAccounts(data.accounts || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (!selectedAccount) { setTransactions([]); return }
    const fetchTransactions = async () => {
      setLoading(true)
      try {
        const data = await apiFetch(`/api/journal-entries?accountId=${selectedAccount}`)
        const entries = data.journalEntries || data.entries || []
        let filtered = entries
        if (dateFrom) filtered = filtered.filter((e: any) => new Date(e.date || e.createdAt) >= new Date(dateFrom))
        if (dateTo) filtered = filtered.filter((e: any) => new Date(e.date || e.createdAt) <= new Date(dateTo + 'T23:59:59'))
        setTransactions(filtered)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchTransactions()
  }, [selectedAccount, dateFrom, dateTo])

  let runningBalance = 0
  const enrichedTransactions = transactions.map((t: any) => {
    const debit = Number(t.debit || t.debitAmount || 0)
    const credit = Number(t.credit || t.creditAmount || 0)
    const account = accounts.find((a: any) => a.id === selectedAccount)
    if (account?.type === 'asset' || account?.type === 'expense') {
      runningBalance += debit - credit
    } else {
      runningBalance += credit - debit
    }
    return { ...t, debit, credit, balance: runningBalance }
  })

  const totalPages = Math.max(1, Math.ceil(enrichedTransactions.length / pageSize))
  const paginated = enrichedTransactions.slice((page - 1) * pageSize, page * pageSize)
  const account = accounts.find((a: any) => a.id === selectedAccount)

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">General Ledger</h2><p className="text-muted-foreground">View account transactions and running balance</p></div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1"><Label>Account</Label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger><SelectValue placeholder="Select account" /></SelectTrigger>
                <SelectContent>{accounts.map((a: any) => <SelectItem key={a.id} value={a.id}>{a.code} - {a.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>From</Label><Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} /></div>
            <div><Label>To</Label><Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} /></div>
          </div>
        </CardContent>
      </Card>

      {selectedAccount && account && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KPICard title="Account" value={`${account.code} - ${account.name}`} icon={Eye} color="blue" />
          <KPICard title="Total Debits" value={formatCurrency(enrichedTransactions.reduce((s: number, t: any) => s + t.debit, 0))} icon={Plus} color="amber" />
          <KPICard title="Total Credits" value={formatCurrency(enrichedTransactions.reduce((s: number, t: any) => s + t.credit, 0))} icon={Edit} color="emerald" />
        </div>
      )}

      {selectedAccount && (
        <>
          {loading ? <LoadingSkeleton /> : (
            <>
              <Card>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Description</TableHead><TableHead>Debit</TableHead><TableHead>Credit</TableHead><TableHead>Balance</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {paginated.length === 0 ? (
                        <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No transactions found</TableCell></TableRow>
                      ) : paginated.map((t: any, idx: number) => (
                        <TableRow key={t.id || idx}>
                          <TableCell>{formatDate(t.date || t.createdAt)}</TableCell>
                          <TableCell className="font-medium">{t.description || '-'}</TableCell>
                          <TableCell>{t.debit > 0 ? formatCurrency(t.debit) : '-'}</TableCell>
                          <TableCell>{t.credit > 0 ? formatCurrency(t.credit) : '-'}</TableCell>
                          <TableCell className="font-medium">{formatCurrency(Math.abs(t.balance))}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
              <Pagination page={page} totalPages={totalPages} setPage={setPage} />
            </>
          )}
        </>
      )}
    </div>
  )
}

// ============================================================
// Cash & Bank Sub-Module
// ============================================================
function CashAndBank() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [accountData, entryData] = await Promise.all([apiFetch('/api/accounts'), apiFetch('/api/journal-entries')])
        const allAccounts = accountData.accounts || []
        setAccounts(allAccounts.filter((a: any) => a.type === 'asset'))
        setTransactions((entryData.journalEntries || entryData.entries || []).slice(0, 20))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const cashAccounts = accounts.filter((a: any) => a.name?.toLowerCase().includes('cash') || a.code?.startsWith('1'))
  const bankAccounts = accounts.filter((a: any) => a.name?.toLowerCase().includes('bank') || a.code?.startsWith('11'))
  const totalCash = cashAccounts.reduce((sum: number, a: any) => sum + Number(a.balance || 0), 0)
  const totalBank = bankAccounts.reduce((sum: number, a: any) => sum + Number(a.balance || 0), 0)

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Cash & Bank</h2><p className="text-muted-foreground">Cash and bank account balances</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Cash Balance" value={formatCurrency(totalCash)} icon={Eye} color="emerald" />
        <KPICard title="Bank Balance" value={formatCurrency(totalBank)} icon={Eye} color="blue" />
        <KPICard title="Total Balance" value={formatCurrency(totalCash + totalBank)} icon={Plus} color="violet" />
        <KPICard title="Accounts" value={accounts.length} icon={Edit} color="amber" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Cash Accounts</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Balance</TableHead></TableRow></TableHeader>
                <TableBody>
                  {cashAccounts.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No cash accounts</TableCell></TableRow>
                  ) : cashAccounts.map((a: any) => (
                    <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell className="font-medium">{a.name}</TableCell><TableCell className="font-bold">{formatCurrency(a.balance || 0)}</TableCell></TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Bank Accounts</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Balance</TableHead></TableRow></TableHeader>
                <TableBody>
                  {bankAccounts.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No bank accounts</TableCell></TableRow>
                  ) : bankAccounts.map((a: any) => (
                    <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell className="font-medium">{a.name}</TableCell><TableCell className="font-bold">{formatCurrency(a.balance || 0)}</TableCell></TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Recent Transactions</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Description</TableHead><TableHead>Debit</TableHead><TableHead>Credit</TableHead></TableRow></TableHeader>
                <TableBody>
                  {transactions.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No recent transactions</TableCell></TableRow>
                  ) : transactions.map((t: any, idx: number) => (
                    <TableRow key={t.id || idx}>
                      <TableCell>{formatDate(t.date || t.createdAt)}</TableCell>
                      <TableCell className="font-medium">{t.description || '-'}</TableCell>
                      <TableCell>{Number(t.debit || t.debitAmount || 0) > 0 ? formatCurrency(t.debit || t.debitAmount) : '-'}</TableCell>
                      <TableCell>{Number(t.credit || t.creditAmount || 0) > 0 ? formatCurrency(t.credit || t.creditAmount) : '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

// ============================================================
// Accounts Receivable Sub-Module
// ============================================================
function AccountsReceivable() {
  const [folios, setFolios] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/folios')
        setFolios((data.folios || []).filter((f: any) => Number(f.balance || f.outstanding || 0) > 0))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const now = new Date()
  const aging = { current: 0, days30: 0, days60: 0, days90: 0 }
  folios.forEach((f: any) => {
    const amount = Number(f.balance || f.outstanding || 0)
    const date = new Date(f.createdAt || f.date)
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays <= 30) aging.current += amount
    else if (diffDays <= 60) aging.days30 += amount
    else if (diffDays <= 90) aging.days60 += amount
    else aging.days90 += amount
  })

  const filtered = folios.filter((f: any) => !search || (f.guestName || f.guest_name || '').toLowerCase().includes(search.toLowerCase()) || (f.folioNumber || f.folio_number || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalReceivable = folios.reduce((s: number, f: any) => s + Number(f.balance || f.outstanding || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Accounts Receivable</h2><p className="text-muted-foreground">Outstanding receivables from guests</p></div>
        <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="Total Receivable" value={formatCurrency(totalReceivable)} icon={Eye} color="blue" />
        <KPICard title="Current" value={formatCurrency(aging.current)} icon={Plus} color="emerald" />
        <KPICard title="30 Days" value={formatCurrency(aging.days30)} icon={Edit} color="amber" />
        <KPICard title="60 Days" value={formatCurrency(aging.days60)} icon={Search} color="orange" />
        <KPICard title="90+ Days" value={formatCurrency(aging.days90)} icon={Trash2} color="red" />
      </div>

      <Card>
        <CardHeader><CardTitle>Aging Report</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            {Object.entries(aging).map(([label, amount]) => (
              <div key={label} className="text-center p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">{label === 'current' ? 'Current' : label === 'days30' ? '1-30 Days' : label === 'days60' ? '31-60 Days' : '90+ Days'}</p>
                <p className="text-lg font-bold mt-1">{formatCurrency(amount)}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Folio #</TableHead><TableHead>Guest</TableHead><TableHead>Amount</TableHead><TableHead>Paid</TableHead><TableHead>Balance</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No outstanding receivables</TableCell></TableRow>
                  ) : paginated.map((f: any) => (
                    <TableRow key={f.id}>
                      <TableCell className="font-medium"><Badge variant="outline">{f.folioNumber || f.folio_number || '-'}</Badge></TableCell>
                      <TableCell>{f.guestName || f.guest_name || '-'}</TableCell>
                      <TableCell>{formatCurrency(f.total || f.amount || 0)}</TableCell>
                      <TableCell>{formatCurrency(f.paid || f.amountPaid || 0)}</TableCell>
                      <TableCell className="font-bold text-red-600">{formatCurrency(f.balance || f.outstanding || 0)}</TableCell>
                      <TableCell>{formatDate(f.createdAt || f.date)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============================================================
// Accounts Payable Sub-Module
// ============================================================
function AccountsPayable() {
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/suppliers')
        setSuppliers((data.suppliers || []).filter((s: any) => Number(s.balance || 0) > 0))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const now = new Date()
  const aging = { current: 0, days30: 0, days60: 0, days90: 0 }
  suppliers.forEach((s: any) => {
    const amount = Number(s.balance || 0)
    const date = new Date(s.updatedAt || s.createdAt || s.date)
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays <= 30) aging.current += amount
    else if (diffDays <= 60) aging.days30 += amount
    else if (diffDays <= 90) aging.days60 += amount
    else aging.days90 += amount
  })

  const filtered = suppliers.filter((s: any) => !search || s.name.toLowerCase().includes(search.toLowerCase()) || (s.code || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalPayable = suppliers.reduce((s: number, sup: any) => s + Number(sup.balance || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Accounts Payable</h2><p className="text-muted-foreground">Outstanding payables to suppliers</p></div>
        <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="Total Payable" value={formatCurrency(totalPayable)} icon={Eye} color="red" />
        <KPICard title="Current" value={formatCurrency(aging.current)} icon={Plus} color="emerald" />
        <KPICard title="30 Days" value={formatCurrency(aging.days30)} icon={Edit} color="amber" />
        <KPICard title="60 Days" value={formatCurrency(aging.days60)} icon={Search} color="orange" />
        <KPICard title="90+ Days" value={formatCurrency(aging.days90)} icon={Trash2} color="red" />
      </div>

      <Card>
        <CardHeader><CardTitle>Aging Report</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            {Object.entries(aging).map(([label, amount]) => (
              <div key={label} className="text-center p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">{label === 'current' ? 'Current' : label === 'days30' ? '1-30 Days' : label === 'days60' ? '31-60 Days' : '90+ Days'}</p>
                <p className="text-lg font-bold mt-1">{formatCurrency(amount)}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Supplier</TableHead><TableHead>Balance</TableHead><TableHead>Contact</TableHead><TableHead>Phone</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No outstanding payables</TableCell></TableRow>
                  ) : paginated.map((s: any) => (
                    <TableRow key={s.id}>
                      <TableCell><Badge variant="outline">{s.code}</Badge></TableCell>
                      <TableCell className="font-medium">{s.name}</TableCell>
                      <TableCell className="font-bold text-red-600">{formatCurrency(s.balance || 0)}</TableCell>
                      <TableCell>{s.contactPerson || s.contact_person || '-'}</TableCell>
                      <TableCell>{s.phone || '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============================================================
// Journal Voucher Sub-Module
// ============================================================
function JournalVoucher() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [formData, setFormData] = useState({ date: new Date().toISOString().split('T')[0], debitAccountId: '', creditAccountId: '', amount: '', description: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [accountData, entryData] = await Promise.all([apiFetch('/api/accounts'), apiFetch('/api/journal-entries')])
        setAccounts(accountData.accounts || [])
        setEntries(entryData.journalEntries || entryData.entries || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.debitAccountId || !formData.creditAccountId || !formData.amount || !formData.date) {
      toast.error('All fields are required'); return
    }
    if (formData.debitAccountId === formData.creditAccountId) {
      toast.error('Debit and credit accounts must be different'); return
    }
    if (Number(formData.amount) <= 0) {
      toast.error('Amount must be greater than zero'); return
    }
    setSaving(true)
    try {
      await apiFetch('/api/journal-entries', {
        method: 'POST',
        body: JSON.stringify({
          date: formData.date,
          debitAccountId: formData.debitAccountId,
          creditAccountId: formData.creditAccountId,
          amount: Number(formData.amount),
          description: formData.description
        })
      })
      toast.success('Journal entry created successfully')
      setDialogOpen(false)
      setFormData({ date: new Date().toISOString().split('T')[0], debitAccountId: '', creditAccountId: '', amount: '', description: '' })
      const entryData = await apiFetch('/api/journal-entries')
      setEntries(entryData.journalEntries || entryData.entries || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const filtered = entries.filter((e: any) => !search || (e.description || '').toLowerCase().includes(search.toLowerCase()) || (e.reference || e.voucherNumber || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Journal Voucher</h2><p className="text-muted-foreground">Create and manage journal entries</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Entry</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Entries" value={entries.length} icon={Plus} color="blue" />
        <KPICard title="Total Debits" value={formatCurrency(entries.reduce((s: number, e: any) => s + Number(e.debit || e.debitAmount || e.amount || 0), 0))} icon={Plus} color="amber" />
        <KPICard title="Total Credits" value={formatCurrency(entries.reduce((s: number, e: any) => s + Number(e.credit || e.creditAmount || e.amount || 0), 0))} icon={Edit} color="emerald" />
        <KPICard title="Accounts" value={accounts.length} icon={Eye} color="violet" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Voucher #</TableHead><TableHead>Description</TableHead><TableHead>Debit</TableHead><TableHead>Credit</TableHead><TableHead>Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No journal entries found</TableCell></TableRow>
                  ) : paginated.map((e: any) => (
                    <TableRow key={e.id}>
                      <TableCell>{formatDate(e.date || e.createdAt)}</TableCell>
                      <TableCell><Badge variant="outline">{e.reference || e.voucherNumber || e.voucher_number || '-'}</Badge></TableCell>
                      <TableCell className="font-medium">{e.description || '-'}</TableCell>
                      <TableCell>{e.debitAccountId || e.debit_account_id ? accounts.find((a: any) => a.id === (e.debitAccountId || e.debit_account_id))?.name || '-' : '-'}</TableCell>
                      <TableCell>{e.creditAccountId || e.credit_account_id ? accounts.find((a: any) => a.id === (e.creditAccountId || e.credit_account_id))?.name || '-' : '-'}</TableCell>
                      <TableCell className="font-bold">{formatCurrency(e.amount || 0)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Journal Entry</DialogTitle><DialogDescription>Debit must equal credit</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Date</Label><Input type="date" value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} /></div>
            <div><Label>Debit Account</Label>
              <Select value={formData.debitAccountId} onValueChange={v => setFormData({ ...formData, debitAccountId: v })}>
                <SelectTrigger><SelectValue placeholder="Select debit account" /></SelectTrigger>
                <SelectContent>{accounts.map((a: any) => <SelectItem key={a.id} value={a.id}>{a.code} - {a.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Credit Account</Label>
              <Select value={formData.creditAccountId} onValueChange={v => setFormData({ ...formData, creditAccountId: v })}>
                <SelectTrigger><SelectValue placeholder="Select credit account" /></SelectTrigger>
                <SelectContent>{accounts.map((a: any) => <SelectItem key={a.id} value={a.id}>{a.code} - {a.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Amount</Label><Input type="number" value={formData.amount} onChange={e => setFormData({ ...formData, amount: e.target.value })} placeholder="Enter amount" /></div>
            <div><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Description / narration" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Post Entry</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Trial Balance Sub-Module
// ============================================================
function TrialBalance() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [accountData, entryData] = await Promise.all([apiFetch('/api/accounts'), apiFetch('/api/journal-entries')])
        setAccounts(accountData.accounts || [])
        setEntries(entryData.journalEntries || entryData.entries || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const accountBalances = accounts.map((account: any) => {
    const accountEntries = entries.filter((e: any) => e.debitAccountId === account.id || e.debit_account_id === account.id || e.creditAccountId === account.id || e.credit_account_id === account.id)
    let totalDebit = 0
    let totalCredit = 0
    accountEntries.forEach((e: any) => {
      const amount = Number(e.amount || 0)
      if (e.debitAccountId === account.id || e.debit_account_id === account.id) totalDebit += amount
      if (e.creditAccountId === account.id || e.credit_account_id === account.id) totalCredit += amount
    })
    let debitBalance = 0
    let creditBalance = 0
    if (account.type === 'asset' || account.type === 'expense') {
      if (totalDebit >= totalCredit) debitBalance = totalDebit - totalCredit
      else creditBalance = totalCredit - totalDebit
    } else {
      if (totalCredit >= totalDebit) creditBalance = totalCredit - totalDebit
      else debitBalance = totalDebit - totalCredit
    }
    return { ...account, debitBalance, creditBalance }
  })

  const totalDebits = accountBalances.reduce((s: number, a: any) => s + a.debitBalance, 0)
  const totalCredits = accountBalances.reduce((s: number, a: any) => s + a.creditBalance, 0)
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Trial Balance</h2><p className="text-muted-foreground">Verify total debits equal total credits</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Debits" value={formatCurrency(totalDebits)} icon={Plus} color="amber" />
        <KPICard title="Total Credits" value={formatCurrency(totalCredits)} icon={Edit} color="emerald" />
        <KPICard title="Status" value={isBalanced ? 'Balanced' : 'Unbalanced'} icon={Eye} color={isBalanced ? 'emerald' : 'red'} />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account Name</TableHead><TableHead>Type</TableHead><TableHead className="text-right">Debit Balance</TableHead><TableHead className="text-right">Credit Balance</TableHead></TableRow></TableHeader>
              <TableBody>
                {accountBalances.map((a: any) => (
                  <TableRow key={a.id}>
                    <TableCell><Badge variant="outline">{a.code}</Badge></TableCell>
                    <TableCell className="font-medium">{a.name}</TableCell>
                    <TableCell><Badge className={statusColors[a.type] || ''}>{a.type}</Badge></TableCell>
                    <TableCell className="text-right font-medium">{a.debitBalance > 0 ? formatCurrency(a.debitBalance) : '-'}</TableCell>
                    <TableCell className="text-right font-medium">{a.creditBalance > 0 ? formatCurrency(a.creditBalance) : '-'}</TableCell>
                  </TableRow>
                ))}
                <TableRow className="font-bold border-t-2">
                  <TableCell colSpan={3} className="text-right">Total</TableCell>
                  <TableCell className="text-right">{formatCurrency(totalDebits)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(totalCredits)}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ============================================================
// Profit & Loss Sub-Module
// ============================================================
function ProfitAndLoss() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [accountData, entryData] = await Promise.all([apiFetch('/api/accounts'), apiFetch('/api/journal-entries')])
        setAccounts(accountData.accounts || [])
        setEntries(entryData.journalEntries || entryData.entries || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const incomeAccounts = accounts.filter((a: any) => a.type === 'income')
  const expenseAccounts = accounts.filter((a: any) => a.type === 'expense')

  const calculateBalance = (account: any) => {
    const accountEntries = entries.filter((e: any) => e.debitAccountId === account.id || e.debit_account_id === account.id || e.creditAccountId === account.id || e.credit_account_id === account.id)
    let totalDebit = 0
    let totalCredit = 0
    accountEntries.forEach((e: any) => {
      const amount = Number(e.amount || 0)
      if (e.debitAccountId === account.id || e.debit_account_id === account.id) totalDebit += amount
      if (e.creditAccountId === account.id || e.credit_account_id === account.id) totalCredit += amount
    })
    if (account.type === 'income') return totalCredit - totalDebit
    return totalDebit - totalCredit
  }

  const totalIncome = incomeAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const totalExpense = expenseAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const netProfit = totalIncome - totalExpense

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Profit & Loss</h2><p className="text-muted-foreground">Income vs Expense summary</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Income" value={formatCurrency(totalIncome)} icon={Plus} color="emerald" />
        <KPICard title="Total Expense" value={formatCurrency(totalExpense)} icon={Edit} color="red" />
        <KPICard title="Net Profit/Loss" value={formatCurrency(netProfit)} icon={Eye} color={netProfit >= 0 ? 'emerald' : 'red'} subtitle={netProfit >= 0 ? 'Profit' : 'Loss'} />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle className="text-emerald-600">Income</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {incomeAccounts.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No income accounts</TableCell></TableRow>
                  ) : incomeAccounts.map((a: any) => (
                    <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell>{a.name}</TableCell><TableCell className="text-right font-medium">{formatCurrency(calculateBalance(a))}</TableCell></TableRow>
                  ))}
                  <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Income</TableCell><TableCell className="text-right">{formatCurrency(totalIncome)}</TableCell></TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-red-600">Expenses</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {expenseAccounts.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No expense accounts</TableCell></TableRow>
                  ) : expenseAccounts.map((a: any) => (
                    <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell>{a.name}</TableCell><TableCell className="text-right font-medium">{formatCurrency(calculateBalance(a))}</TableCell></TableRow>
                  ))}
                  <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Expenses</TableCell><TableCell className="text-right">{formatCurrency(totalExpense)}</TableCell></TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div><p className="text-lg font-semibold">Net {netProfit >= 0 ? 'Profit' : 'Loss'}</p><p className="text-sm text-muted-foreground">Income - Expenses</p></div>
                <p className={`text-3xl font-bold ${netProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{formatCurrency(Math.abs(netProfit))}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

// ============================================================
// Balance Sheet Sub-Module
// ============================================================
function BalanceSheet() {
  const [accounts, setAccounts] = useState<any[]>([])
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [accountData, entryData] = await Promise.all([apiFetch('/api/accounts'), apiFetch('/api/journal-entries')])
        setAccounts(accountData.accounts || [])
        setEntries(entryData.journalEntries || entryData.entries || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const calculateBalance = (account: any) => {
    const accountEntries = entries.filter((e: any) => e.debitAccountId === account.id || e.debit_account_id === account.id || e.creditAccountId === account.id || e.credit_account_id === account.id)
    let totalDebit = 0
    let totalCredit = 0
    accountEntries.forEach((e: any) => {
      const amount = Number(e.amount || 0)
      if (e.debitAccountId === account.id || e.debit_account_id === account.id) totalDebit += amount
      if (e.creditAccountId === account.id || e.credit_account_id === account.id) totalCredit += amount
    })
    if (account.type === 'asset' || account.type === 'expense') return totalDebit - totalCredit
    return totalCredit - totalDebit
  }

  const assetAccounts = accounts.filter((a: any) => a.type === 'asset')
  const liabilityAccounts = accounts.filter((a: any) => a.type === 'liability')
  const equityAccounts = accounts.filter((a: any) => a.type === 'equity')
  const incomeAccounts = accounts.filter((a: any) => a.type === 'income')
  const expenseAccounts = accounts.filter((a: any) => a.type === 'expense')

  const totalAssets = assetAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const totalLiabilities = liabilityAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const totalEquity = equityAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const totalIncome = incomeAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const totalExpense = expenseAccounts.reduce((s: number, a: any) => s + calculateBalance(a), 0)
  const retainedEarnings = totalIncome - totalExpense
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity + retainedEarnings
  const isBalanced = Math.abs(totalAssets - totalLiabilitiesAndEquity) < 0.01

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Balance Sheet</h2><p className="text-muted-foreground">Assets = Liabilities + Equity</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Assets" value={formatCurrency(totalAssets)} icon={Plus} color="blue" />
        <KPICard title="Total Liabilities" value={formatCurrency(totalLiabilities)} icon={Edit} color="red" />
        <KPICard title="Total Equity" value={formatCurrency(totalEquity + retainedEarnings)} icon={Eye} color="emerald" />
      </div>

      {!isBalanced && totalAssets > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <p className="text-red-600 font-medium">Balance sheet is not balanced. Difference: {formatCurrency(Math.abs(totalAssets - totalLiabilitiesAndEquity))}</p>
          </CardContent>
        </Card>
      )}

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle className="text-blue-600">Assets</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {assetAccounts.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No asset accounts</TableCell></TableRow>
                  ) : assetAccounts.map((a: any) => (
                    <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell>{a.name}</TableCell><TableCell className="text-right font-medium">{formatCurrency(calculateBalance(a))}</TableCell></TableRow>
                  ))}
                  <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Assets</TableCell><TableCell className="text-right">{formatCurrency(totalAssets)}</TableCell></TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="text-red-600">Liabilities</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {liabilityAccounts.length === 0 ? (
                      <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No liability accounts</TableCell></TableRow>
                    ) : liabilityAccounts.map((a: any) => (
                      <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell>{a.name}</TableCell><TableCell className="text-right font-medium">{formatCurrency(calculateBalance(a))}</TableCell></TableRow>
                    ))}
                    <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Liabilities</TableCell><TableCell className="text-right">{formatCurrency(totalLiabilities)}</TableCell></TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-emerald-600">Equity</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Account</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {equityAccounts.map((a: any) => (
                      <TableRow key={a.id}><TableCell><Badge variant="outline">{a.code}</Badge></TableCell><TableCell>{a.name}</TableCell><TableCell className="text-right font-medium">{formatCurrency(calculateBalance(a))}</TableCell></TableRow>
                    ))}
                    <TableRow><TableCell /><TableCell>Retained Earnings</TableCell><TableCell className="text-right font-medium">{formatCurrency(retainedEarnings)}</TableCell></TableRow>
                    <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Equity</TableCell><TableCell className="text-right">{formatCurrency(totalEquity + retainedEarnings)}</TableCell></TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-4">
                <div className="flex justify-between font-bold text-lg">
                  <span>Liabilities + Equity</span>
                  <span>{formatCurrency(totalLiabilitiesAndEquity)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================
// Main Finance Module Component
// ============================================================
export default function FinanceModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'chart-of-accounts': return <ChartOfAccounts />
    case 'general-ledger': return <GeneralLedger />
    case 'cash-bank': return <CashAndBank />
    case 'receivable': return <AccountsReceivable />
    case 'payable': return <AccountsPayable />
    case 'journal': return <JournalVoucher />
    case 'trial-balance': return <TrialBalance />
    case 'profit-loss': return <ProfitAndLoss />
    case 'balance-sheet': return <BalanceSheet />
    default: return <EmptyState title="Unknown Sub-Module" description={`Sub-module "${subModule}" not found in Finance.`} />
  }
}
