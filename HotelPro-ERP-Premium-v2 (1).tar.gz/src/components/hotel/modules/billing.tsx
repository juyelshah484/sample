'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============================================================
// Room Billing Sub-Module
// ============================================================
function RoomBilling() {
  const [guests, setGuests] = useState<any[]>([])
  const [charges, setCharges] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedGuest, setSelectedGuest] = useState<string>('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [chargeForm, setChargeForm] = useState({ description: '', amount: '', type: 'room' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [guestData, folioData] = await Promise.all([apiFetch('/api/guests'), apiFetch('/api/folios')])
        setGuests((guestData.guests || []).filter((g: any) => g.status === 'checked_in' || g.status === 'checked_in'))
        setCharges(folioData.folios || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const guestCharges = charges.filter((c: any) =>
    (selectedGuest && (c.guestId === selectedGuest || c.guest_id === selectedGuest))
  )

  const roomCharges = guestCharges.filter((c: any) => c.type === 'room' || c.chargeType === 'room' || !c.type)
  const extraCharges = guestCharges.filter((c: any) => c.type !== 'room' && c.chargeType !== 'room' && c.type)
  const totalRoom = roomCharges.reduce((s: number, c: any) => s + Number(c.amount || 0), 0)
  const totalExtra = extraCharges.reduce((s: number, c: any) => s + Number(c.amount || 0), 0)

  const handleAddCharge = async () => {
    if (!selectedGuest || !chargeForm.description || !chargeForm.amount) { toast.error('All fields are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/folios', {
        method: 'POST',
        body: JSON.stringify({ guestId: selectedGuest, description: chargeForm.description, amount: Number(chargeForm.amount), type: chargeForm.type, chargeType: chargeForm.type })
      })
      toast.success('Charge added successfully')
      setDialogOpen(false)
      setChargeForm({ description: '', amount: '', type: 'room' })
      const folioData = await apiFetch('/api/folios')
      setCharges(folioData.folios || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleGenerateBill = async () => {
    if (!selectedGuest) { toast.error('Please select a guest'); return }
    setSaving(true)
    try {
      await apiFetch('/api/folios', {
        method: 'POST',
        body: JSON.stringify({ guestId: selectedGuest, action: 'generate-bill', total: totalRoom + totalExtra })
      })
      toast.success('Bill generated successfully')
      const folioData = await apiFetch('/api/folios')
      setCharges(folioData.folios || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Room Billing</h2><p className="text-muted-foreground">Manage room charges and billing for checked-in guests</p></div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1"><Label>Select Guest</Label>
              <Select value={selectedGuest} onValueChange={setSelectedGuest}>
                <SelectTrigger><SelectValue placeholder="Select checked-in guest" /></SelectTrigger>
                <SelectContent>
                  {guests.map((g: any) => <SelectItem key={g.id} value={g.id}>{g.name || g.guestName || g.guest_name} - Room {g.roomNumber || g.room_number || '?'}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-2">
              <Button size="sm" onClick={() => setDialogOpen(true)} disabled={!selectedGuest}><Plus className="h-4 w-4 mr-1" />Add Charge</Button>
              <Button size="sm" onClick={handleGenerateBill} disabled={!selectedGuest || saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Generate Bill</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedGuest && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KPICard title="Room Charges" value={formatCurrency(totalRoom)} icon={Plus} color="blue" />
          <KPICard title="Extra Charges" value={formatCurrency(totalExtra)} icon={Edit} color="amber" />
          <KPICard title="Total" value={formatCurrency(totalRoom + totalExtra)} icon={Eye} color="emerald" />
        </div>
      )}

      {loading ? <LoadingSkeleton /> : selectedGuest && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Room Charges</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Description</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {roomCharges.length === 0 ? (
                    <TableRow><TableCell colSpan={3} className="text-center py-4 text-muted-foreground">No room charges</TableCell></TableRow>
                  ) : roomCharges.map((c: any, idx: number) => (
                    <TableRow key={c.id || idx}>
                      <TableCell className="font-medium">{c.description || 'Room Charge'}</TableCell>
                      <TableCell>{formatDate(c.date || c.createdAt)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(c.amount || 0)}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="font-bold border-t-2"><TableCell colSpan={2}>Total Room</TableCell><TableCell className="text-right">{formatCurrency(totalRoom)}</TableCell></TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Extra Charges</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Description</TableHead><TableHead>Type</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {extraCharges.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-4 text-muted-foreground">No extra charges</TableCell></TableRow>
                  ) : extraCharges.map((c: any, idx: number) => (
                    <TableRow key={c.id || idx}>
                      <TableCell className="font-medium">{c.description || '-'}</TableCell>
                      <TableCell><Badge variant="outline">{c.type || c.chargeType || '-'}</Badge></TableCell>
                      <TableCell>{formatDate(c.date || c.createdAt)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(c.amount || 0)}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="font-bold border-t-2"><TableCell colSpan={3}>Total Extra</TableCell><TableCell className="text-right">{formatCurrency(totalExtra)}</TableCell></TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Add Extra Charge</DialogTitle><DialogDescription>Add a charge to the guest folio</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Charge Type</Label>
              <Select value={chargeForm.type} onValueChange={v => setChargeForm({ ...chargeForm, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="minibar">Minibar</SelectItem>
                  <SelectItem value="laundry">Laundry</SelectItem>
                  <SelectItem value="restaurant">Restaurant</SelectItem>
                  <SelectItem value="spa">Spa</SelectItem>
                  <SelectItem value="phone">Phone</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Description</Label><Input value={chargeForm.description} onChange={e => setChargeForm({ ...chargeForm, description: e.target.value })} placeholder="Charge description" /></div>
            <div><Label>Amount</Label><Input type="number" value={chargeForm.amount} onChange={e => setChargeForm({ ...chargeForm, amount: e.target.value })} placeholder="Charge amount" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAddCharge} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Add Charge</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Restaurant Billing Sub-Module
// ============================================================
function RestaurantBilling() {
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [viewOrder, setViewOrder] = useState<any>(null)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/folios?type=restaurant')
        setOrders(data.folios || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleGenerateBill = async (orderId: string) => {
    setSaving(true)
    try {
      await apiFetch(`/api/folios?id=${orderId}`, { method: 'PUT', body: JSON.stringify({ status: 'billed' }) })
      toast.success('Restaurant bill generated')
      const data = await apiFetch('/api/folios?type=restaurant')
      setOrders(data.folios || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleLinkFolio = async (orderId: string) => {
    setSaving(true)
    try {
      await apiFetch(`/api/folios?id=${orderId}`, { method: 'PUT', body: JSON.stringify({ linkToFolio: true }) })
      toast.success('Linked to guest folio')
      const data = await apiFetch('/api/folios?type=restaurant')
      setOrders(data.folios || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const filtered = orders.filter((o: any) => !search || (o.orderNumber || o.description || '').toLowerCase().includes(search.toLowerCase()) || (o.guestName || o.guest_name || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalBilled = orders.filter((o: any) => o.status === 'billed' || o.status === 'paid').reduce((s: number, o: any) => s + Number(o.amount || o.total || 0), 0)
  const totalUnbilled = orders.filter((o: any) => o.status !== 'billed' && o.status !== 'paid').reduce((s: number, o: any) => s + Number(o.amount || o.total || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Restaurant Billing</h2><p className="text-muted-foreground">Restaurant orders and billing</p></div>
        <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Orders" value={orders.length} icon={Plus} color="blue" />
        <KPICard title="Unbilled" value={orders.filter((o: any) => o.status !== 'billed' && o.status !== 'paid').length} icon={Edit} color="amber" />
        <KPICard title="Total Billed" value={formatCurrency(totalBilled)} icon={Eye} color="emerald" />
        <KPICard title="Total Unbilled" value={formatCurrency(totalUnbilled)} icon={Search} color="red" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Order #</TableHead><TableHead>Guest</TableHead><TableHead>Items</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No restaurant orders found</TableCell></TableRow>
                  ) : paginated.map((o: any) => (
                    <TableRow key={o.id}>
                      <TableCell className="font-medium"><Badge variant="outline">{o.orderNumber || o.folioNumber || o.id?.slice(0, 8) || '-'}</Badge></TableCell>
                      <TableCell>{o.guestName || o.guest_name || '-'}</TableCell>
                      <TableCell>{o.itemCount || o.items?.length || '-'}</TableCell>
                      <TableCell>{formatCurrency(o.amount || o.total || 0)}</TableCell>
                      <TableCell><Badge className={statusColors[o.status] || 'bg-gray-100 text-gray-800'}>{o.status || 'pending'}</Badge></TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setViewOrder(o)}><Eye className="h-4 w-4 mr-2" />View Details</DropdownMenuItem>
                            {o.status !== 'billed' && o.status !== 'paid' && <DropdownMenuItem onClick={() => handleGenerateBill(o.id)}><Edit className="h-4 w-4 mr-2" />Generate Bill</DropdownMenuItem>}
                            <DropdownMenuItem onClick={() => handleLinkFolio(o.id)}><Plus className="h-4 w-4 mr-2" />Link to Folio</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={!!viewOrder} onOpenChange={() => setViewOrder(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Order Details</DialogTitle></DialogHeader>
          {viewOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="text-muted-foreground">Order #</Label><p className="font-medium">{viewOrder.orderNumber || viewOrder.folioNumber || '-'}</p></div>
                <div><Label className="text-muted-foreground">Guest</Label><p className="font-medium">{viewOrder.guestName || viewOrder.guest_name || '-'}</p></div>
                <div><Label className="text-muted-foreground">Status</Label><Badge className={statusColors[viewOrder.status] || ''}>{viewOrder.status || 'pending'}</Badge></div>
                <div><Label className="text-muted-foreground">Total</Label><p className="font-bold">{formatCurrency(viewOrder.amount || viewOrder.total || 0)}</p></div>
              </div>
              <Separator />
              <div><Label className="text-muted-foreground">Description</Label><p>{viewOrder.description || 'No description'}</p></div>
              <div><Label className="text-muted-foreground">Date</Label><p>{formatDateTime(viewOrder.createdAt || viewOrder.date)}</p></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setViewOrder(null)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Spa Billing Sub-Module
// ============================================================
function SpaBilling() {
  const [bookings, setBookings] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/folios?type=spa')
        setBookings(data.folios || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleGenerateBill = async (bookingId: string) => {
    setSaving(true)
    try {
      await apiFetch(`/api/folios?id=${bookingId}`, { method: 'PUT', body: JSON.stringify({ status: 'billed' }) })
      toast.success('Spa bill generated')
      const data = await apiFetch('/api/folios?type=spa')
      setBookings(data.folios || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const filtered = bookings.filter((b: any) => !search || (b.guestName || b.guest_name || '').toLowerCase().includes(search.toLowerCase()) || (b.description || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalBilled = bookings.filter((b: any) => b.status === 'billed' || b.status === 'paid').reduce((s: number, b: any) => s + Number(b.amount || b.total || 0), 0)
  const totalUnbilled = bookings.filter((b: any) => b.status !== 'billed' && b.status !== 'paid').reduce((s: number, b: any) => s + Number(b.amount || b.total || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Spa Billing</h2><p className="text-muted-foreground">Spa bookings and billing</p></div>
        <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Bookings" value={bookings.length} icon={Plus} color="violet" />
        <KPICard title="Unbilled" value={bookings.filter((b: any) => b.status !== 'billed' && b.status !== 'paid').length} icon={Edit} color="amber" />
        <KPICard title="Total Billed" value={formatCurrency(totalBilled)} icon={Eye} color="emerald" />
        <KPICard title="Total Unbilled" value={formatCurrency(totalUnbilled)} icon={Search} color="red" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Booking #</TableHead><TableHead>Guest</TableHead><TableHead>Service</TableHead><TableHead>Amount</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No spa bookings found</TableCell></TableRow>
                  ) : paginated.map((b: any) => (
                    <TableRow key={b.id}>
                      <TableCell className="font-medium"><Badge variant="outline">{b.bookingNumber || b.folioNumber || b.id?.slice(0, 8) || '-'}</Badge></TableCell>
                      <TableCell>{b.guestName || b.guest_name || '-'}</TableCell>
                      <TableCell>{b.description || b.serviceName || b.service_name || '-'}</TableCell>
                      <TableCell>{formatCurrency(b.amount || b.total || 0)}</TableCell>
                      <TableCell><Badge className={statusColors[b.status] || 'bg-gray-100 text-gray-800'}>{b.status || 'pending'}</Badge></TableCell>
                      <TableCell className="text-right">
                        {b.status !== 'billed' && b.status !== 'paid' && (
                          <Button size="sm" variant="outline" onClick={() => handleGenerateBill(b.id)} disabled={saving}>Generate Bill</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============================================================
// Invoice List Sub-Module
// ============================================================
function InvoiceList() {
  const crud = useCrud<any>('/api/folios')
  const [viewInvoice, setViewInvoice] = useState<any>(null)
  const [filterStatus, setFilterStatus] = useState<string>('all')

  const filteredByStatus = filterStatus === 'all' ? crud.filtered : crud.filtered.filter((f: any) => f.status === filterStatus)

  const totalInvoiced = crud.items.reduce((s: number, f: any) => s + Number(f.total || f.amount || 0), 0)
  const totalPaid = crud.items.reduce((s: number, f: any) => s + Number(f.paid || f.amountPaid || 0), 0)
  const totalOutstanding = totalInvoiced - totalPaid

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Invoice List</h2><p className="text-muted-foreground">All folios and invoices</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={e => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Filter" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Invoices" value={crud.items.length} icon={Plus} color="blue" />
        <KPICard title="Total Invoiced" value={formatCurrency(totalInvoiced)} icon={Eye} color="amber" />
        <KPICard title="Total Paid" value={formatCurrency(totalPaid)} icon={Edit} color="emerald" />
        <KPICard title="Outstanding" value={formatCurrency(totalOutstanding)} icon={Search} color="red" />
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Folio #</TableHead><TableHead>Guest</TableHead><TableHead>Total</TableHead><TableHead>Paid</TableHead><TableHead>Balance</TableHead><TableHead>Status</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {filteredByStatus.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No invoices found</TableCell></TableRow>
                  ) : filteredByStatus.slice((crud.page - 1) * 10, crud.page * 10).map((f: any) => {
                    const total = Number(f.total || f.amount || 0)
                    const paid = Number(f.paid || f.amountPaid || 0)
                    const balance = total - paid
                    return (
                      <TableRow key={f.id}>
                        <TableCell className="font-medium"><Badge variant="outline">{f.folioNumber || f.folio_number || f.id?.slice(0, 8) || '-'}</Badge></TableCell>
                        <TableCell>{f.guestName || f.guest_name || '-'}</TableCell>
                        <TableCell>{formatCurrency(total)}</TableCell>
                        <TableCell>{formatCurrency(paid)}</TableCell>
                        <TableCell className={balance > 0 ? 'text-red-600 font-bold' : ''}>{formatCurrency(balance)}</TableCell>
                        <TableCell><Badge className={statusColors[f.status] || 'bg-gray-100 text-gray-800'}>{f.status || 'open'}</Badge></TableCell>
                        <TableCell>{formatDate(f.createdAt || f.date)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => setViewInvoice(f)}><Eye className="h-4 w-4" /></Button>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}

      <Dialog open={!!viewInvoice} onOpenChange={() => setViewInvoice(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Invoice Details</DialogTitle><DialogDescription>Folio #{viewInvoice?.folioNumber || viewInvoice?.folio_number || '-'}</DialogDescription></DialogHeader>
          {viewInvoice && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="text-muted-foreground">Guest</Label><p className="font-medium">{viewInvoice.guestName || viewInvoice.guest_name || '-'}</p></div>
                <div><Label className="text-muted-foreground">Status</Label><Badge className={statusColors[viewInvoice.status] || ''}>{viewInvoice.status || 'open'}</Badge></div>
                <div><Label className="text-muted-foreground">Date</Label><p className="font-medium">{formatDateTime(viewInvoice.createdAt || viewInvoice.date)}</p></div>
                <div><Label className="text-muted-foreground">Room</Label><p className="font-medium">{viewInvoice.roomNumber || viewInvoice.room_number || '-'}</p></div>
              </div>
              <Separator />
              <div>
                <Label className="text-muted-foreground">Charges</Label>
                <Table className="mt-2">
                  <TableHeader><TableRow><TableHead>Description</TableHead><TableHead>Type</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {(viewInvoice.charges || viewInvoice.lineItems || [{ description: 'Room & Services', type: viewInvoice.type || 'room', amount: viewInvoice.total || viewInvoice.amount }]).map((c: any, idx: number) => (
                      <TableRow key={idx}>
                        <TableCell>{c.description || '-'}</TableCell>
                        <TableCell><Badge variant="outline">{c.type || c.chargeType || '-'}</Badge></TableCell>
                        <TableCell className="text-right">{formatCurrency(c.amount || 0)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="font-bold border-t-2">
                      <TableCell colSpan={2}>Total</TableCell>
                      <TableCell className="text-right">{formatCurrency(viewInvoice.total || viewInvoice.amount || 0)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
              <Separator />
              <div>
                <Label className="text-muted-foreground">Payments</Label>
                <Table className="mt-2">
                  <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Method</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {(viewInvoice.payments || [{ date: viewInvoice.createdAt, method: viewInvoice.paymentMethod || '-', amount: viewInvoice.paid || viewInvoice.amountPaid || 0 }]).map((p: any, idx: number) => (
                      <TableRow key={idx}>
                        <TableCell>{formatDate(p.date || p.createdAt)}</TableCell>
                        <TableCell>{p.method || p.paymentMethod || '-'}</TableCell>
                        <TableCell className="text-right">{formatCurrency(p.amount || 0)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="font-bold border-t-2">
                      <TableCell colSpan={2}>Total Paid</TableCell>
                      <TableCell className="text-right">{formatCurrency(viewInvoice.paid || viewInvoice.amountPaid || 0)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Balance Due</span>
                <span className="text-red-600">{formatCurrency((viewInvoice.total || viewInvoice.amount || 0) - (viewInvoice.paid || viewInvoice.amountPaid || 0))}</span>
              </div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setViewInvoice(null)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Refund & Credit Note Sub-Module
// ============================================================
function RefundCreditNote() {
  const [folios, setFolios] = useState<any[]>([])
  const [refunds, setRefunds] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ folioId: '', amount: '', reason: '', type: 'refund' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const folioData = await apiFetch('/api/folios')
        setFolios((folioData.folios || []).filter((f: any) => Number(f.paid || f.amountPaid || 0) > 0))
        setRefunds((folioData.folios || []).filter((f: any) => f.type === 'refund' || f.type === 'credit-note'))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.folioId || !formData.amount || !formData.reason) { toast.error('All fields are required'); return }
    const folio = folios.find((f: any) => f.id === formData.folioId)
    const maxRefund = Number(folio?.paid || folio?.amountPaid || 0)
    if (Number(formData.amount) > maxRefund) { toast.error(`Refund amount cannot exceed ${formatCurrency(maxRefund)}`); return }
    if (Number(formData.amount) <= 0) { toast.error('Amount must be greater than zero'); return }
    setSaving(true)
    try {
      await apiFetch('/api/folios', {
        method: 'POST',
        body: JSON.stringify({ ...formData, amount: Number(formData.amount), folioNumber: `CN-${Date.now()}` })
      })
      toast.success(formData.type === 'refund' ? 'Refund processed' : 'Credit note created')
      setDialogOpen(false)
      setFormData({ folioId: '', amount: '', reason: '', type: 'refund' })
      const folioData = await apiFetch('/api/folios')
      setRefunds((folioData.folios || []).filter((f: any) => f.type === 'refund' || f.type === 'credit-note'))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const totalRefunds = refunds.filter((r: any) => r.type === 'refund').reduce((s: number, r: any) => s + Number(r.amount || 0), 0)
  const totalCreditNotes = refunds.filter((r: any) => r.type === 'credit-note').reduce((s: number, r: any) => s + Number(r.amount || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Refund & Credit Note</h2><p className="text-muted-foreground">Process refunds and create credit notes</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Refund/Credit Note</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Refunds" value={formatCurrency(totalRefunds)} icon={Plus} color="red" />
        <KPICard title="Total Credit Notes" value={formatCurrency(totalCreditNotes)} icon={Edit} color="amber" />
        <KPICard title="Refund Count" value={refunds.filter((r: any) => r.type === 'refund').length} icon={Eye} color="blue" />
        <KPICard title="Credit Note Count" value={refunds.filter((r: any) => r.type === 'credit-note').length} icon={Search} color="violet" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Reference</TableHead><TableHead>Type</TableHead><TableHead>Folio</TableHead><TableHead>Amount</TableHead><TableHead>Reason</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {refunds.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No refunds or credit notes found</TableCell></TableRow>
                ) : refunds.map((r: any, idx: number) => (
                  <TableRow key={r.id || idx}>
                    <TableCell className="font-medium"><Badge variant="outline">{r.folioNumber || r.folio_number || r.reference || '-'}</Badge></TableCell>
                    <TableCell><Badge className={r.type === 'refund' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}>{r.type || '-'}</Badge></TableCell>
                    <TableCell>{r.folioId || r.original_folio || '-'}</TableCell>
                    <TableCell className="font-bold">{formatCurrency(r.amount || 0)}</TableCell>
                    <TableCell>{r.reason || '-'}</TableCell>
                    <TableCell>{formatDate(r.createdAt || r.date)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Process Refund / Credit Note</DialogTitle><DialogDescription>Select a folio and enter the refund details</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Type</Label>
              <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="refund">Refund</SelectItem>
                  <SelectItem value="credit-note">Credit Note</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Select Folio</Label>
              <Select value={formData.folioId} onValueChange={v => setFormData({ ...formData, folioId: v })}>
                <SelectTrigger><SelectValue placeholder="Select folio" /></SelectTrigger>
                <SelectContent>{folios.map((f: any) => <SelectItem key={f.id} value={f.id}>{f.folioNumber || f.folio_number || f.id?.slice(0, 8)} - {f.guestName || f.guest_name || '-'} ({formatCurrency(f.paid || f.amountPaid || 0)} paid)</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {formData.folioId && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">Max refundable: <span className="font-medium text-foreground">{formatCurrency(folios.find((f: any) => f.id === formData.folioId)?.paid || folios.find((f: any) => f.id === formData.folioId)?.amountPaid || 0)}</span></p>
              </div>
            )}
            <div><Label>Amount</Label><Input type="number" value={formData.amount} onChange={e => setFormData({ ...formData, amount: e.target.value })} placeholder="Refund amount" /></div>
            <div><Label>Reason</Label><Textarea value={formData.reason} onChange={e => setFormData({ ...formData, reason: e.target.value })} placeholder="Reason for refund/credit note" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{formData.type === 'refund' ? 'Process Refund' : 'Create Credit Note'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Main Billing Module Component
// ============================================================
export default function BillingModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'room-billing': return <RoomBilling />
    case 'restaurant-billing': return <RestaurantBilling />
    case 'spa-billing': return <SpaBilling />
    case 'invoice-list': return <InvoiceList />
    case 'refund': return <RefundCreditNote />
    default: return <EmptyState title="Unknown Sub-Module" description={`Sub-module "${subModule}" not found in Billing.`} />
  }
}
