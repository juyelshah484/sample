'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ MEMBERS ============
function Members() {
  const [members, setMembers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [pointsDialogOpen, setPointsDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [selectedMember, setSelectedMember] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', tier: 'standard', points: 0, joinDate: '' })
  const [pointsData, setPointsData] = useState({ type: 'earn', amount: 0, reason: '' })

  useEffect(() => {
    setTimeout(() => {
      setMembers([
        { id: '1', name: 'Ahmed Khan', email: 'ahmed@email.com', phone: '+8801711000001', tier: 'platinum', points: 28500, joinDate: '2022-03-15', totalSpent: 1250000, stays: 32 },
        { id: '2', name: 'Sarah Rahman', email: 'sarah@email.com', phone: '+8801711000002', tier: 'gold', points: 15200, joinDate: '2023-01-10', totalSpent: 680000, stays: 18 },
        { id: '3', name: 'Mohammad Ali', email: 'ali@email.com', phone: '+8801711000003', tier: 'silver', points: 7500, joinDate: '2023-06-20', totalSpent: 320000, stays: 10 },
        { id: '4', name: 'Fatima Begum', email: 'fatima@email.com', phone: '+8801711000004', tier: 'gold', points: 18900, joinDate: '2022-08-05', totalSpent: 850000, stays: 24 },
        { id: '5', name: 'Karim Hossain', email: 'karim@email.com', phone: '+8801711000005', tier: 'standard', points: 2200, joinDate: '2024-02-14', totalSpent: 95000, stays: 3 },
        { id: '6', name: 'Nasreen Akter', email: 'nasreen@email.com', phone: '+8801711000006', tier: 'silver', points: 9800, joinDate: '2023-04-10', totalSpent: 410000, stays: 12 },
        { id: '7', name: 'Rafiq Islam', email: 'rafiq@email.com', phone: '+8801711000007', tier: 'diamond', points: 45000, joinDate: '2021-11-01', totalSpent: 2100000, stays: 48 },
        { id: '8', name: 'Taslima Khatun', email: 'taslima@email.com', phone: '+8801711000008', tier: 'standard', points: 1200, joinDate: '2024-05-20', totalSpent: 55000, stays: 2 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const pageSize = 10
  const filtered = members.filter(m => !search || Object.values(m).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const openCreate = () => { setEditItem(null); setFormData({ name: '', email: '', phone: '', tier: 'standard', points: 0, joinDate: new Date().toISOString().split('T')[0] }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name, email: item.email, phone: item.phone, tier: item.tier, points: item.points, joinDate: item.joinDate }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setMembers(prev => prev.map(m => m.id === editItem.id ? { ...m, ...formData } : m))
      toast.success('Member updated')
    } else {
      setMembers(prev => [...prev, { ...formData, id: Date.now().toString(), totalSpent: 0, stays: 0 }])
      toast.success('Member added')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handlePointsAdjust = async () => {
    if (!selectedMember || pointsData.amount <= 0) return
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    const adj = pointsData.type === 'earn' ? pointsData.amount : -pointsData.amount
    setMembers(prev => prev.map(m => m.id === selectedMember.id ? { ...m, points: Math.max(0, m.points + adj) } : m))
    toast.success(`Points ${pointsData.type === 'earn' ? 'added' : 'redeemed'} successfully`)
    setSaving(false); setPointsDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setMembers(prev => prev.filter(m => m.id !== deleteId)); toast.success('Member removed'); setDeleteId(null) }
  }

  const tierIcons: Record<string, string> = { standard: '⚪', silver: '🩶', gold: '🟡', platinum: '🟣', diamond: '💎' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Members" value={members.length} subtitle="Loyalty program" color="emerald" />
        <KPICard title="Diamond/Platinum" value={members.filter(m => m.tier === 'diamond' || m.tier === 'platinum').length} subtitle="VIP members" color="violet" />
        <KPICard title="Total Points Outstanding" value={members.reduce((s, m) => s + m.points, 0).toLocaleString()} subtitle="Points balance" color="amber" />
        <KPICard title="New This Month" value={2} subtitle="Joined recently" color="blue" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Loyalty Members</h2><p className="text-muted-foreground">Manage loyalty program members</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search members..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Member</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Phone</TableHead><TableHead>Tier</TableHead><TableHead>Points</TableHead><TableHead>Total Spent</TableHead><TableHead>Stays</TableHead><TableHead>Join Date</TableHead><TableHead className="w-10" /></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(m => (
                    <TableRow key={m.id}>
                      <TableCell className="font-medium">{tierIcons[m.tier]} {m.name}</TableCell>
                      <TableCell>{m.email}</TableCell>
                      <TableCell>{m.phone}</TableCell>
                      <TableCell><Badge className={statusColors[m.tier] || ''}>{m.tier}</Badge></TableCell>
                      <TableCell className="font-medium">{m.points.toLocaleString()}</TableCell>
                      <TableCell>{formatCurrency(m.totalSpent)}</TableCell>
                      <TableCell>{m.stays}</TableCell>
                      <TableCell>{formatDate(m.joinDate)}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => { setSelectedMember(m); setPointsData({ type: 'earn', amount: 0, reason: '' }); setPointsDialogOpen(true) }}>Adjust Points</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEdit(m)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(m.id)}><Trash2 className="h-4 w-4 mr-2" />Remove</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'Add'} Member</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Full Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Email</Label><Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Tier</Label>
                <Select value={formData.tier} onValueChange={v => setFormData({ ...formData, tier: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem><SelectItem value="silver">Silver</SelectItem><SelectItem value="gold">Gold</SelectItem><SelectItem value="platinum">Platinum</SelectItem><SelectItem value="diamond">Diamond</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Join Date</Label><Input type="date" value={formData.joinDate} onChange={e => setFormData({ ...formData, joinDate: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Add'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Points Adjustment Dialog */}
      <Dialog open={pointsDialogOpen} onOpenChange={setPointsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Adjust Points - {selectedMember?.name}</DialogTitle><DialogDescription>Current balance: {selectedMember?.points.toLocaleString()} points</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Action Type</Label>
              <Select value={pointsData.type} onValueChange={v => setPointsData({ ...pointsData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="earn">Earn Points</SelectItem><SelectItem value="redeem">Redeem Points</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Amount</Label><Input type="number" value={pointsData.amount} onChange={e => setPointsData({ ...pointsData, amount: Number(e.target.value) })} /></div>
            <div><Label>Reason</Label><Textarea value={pointsData.reason} onChange={e => setPointsData({ ...pointsData, reason: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPointsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handlePointsAdjust} disabled={saving || pointsData.amount <= 0}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{pointsData.type === 'earn' ? 'Add Points' : 'Redeem Points'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Remove</AlertDialogTitle><AlertDialogDescription>Remove this member from the loyalty program?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Remove</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ REWARD POINTS ============
function RewardPoints() {
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    setTimeout(() => {
      setTransactions([
        { id: '1', member: 'Ahmed Khan', type: 'earn', amount: 500, balance: 28500, reason: 'Room booking - Suite', date: '2024-11-15T14:00:00', ref: 'RES-1001' },
        { id: '2', member: 'Sarah Rahman', type: 'earn', amount: 300, balance: 15200, reason: 'Room booking - Deluxe', date: '2024-11-14T10:00:00', ref: 'RES-1002' },
        { id: '3', member: 'Rafiq Islam', type: 'redeem', amount: 5000, balance: 45000, reason: 'Free night redemption', date: '2024-11-13T16:00:00', ref: 'RED-0050' },
        { id: '4', member: 'Fatima Begum', type: 'earn', amount: 750, balance: 18900, reason: 'F&B dining', date: '2024-11-12T20:00:00', ref: 'FNB-2003' },
        { id: '5', member: 'Mohammad Ali', type: 'earn', amount: 200, balance: 7500, reason: 'Spa service', date: '2024-11-11T11:00:00', ref: 'SPA-0045' },
        { id: '6', member: 'Nasreen Akter', type: 'redeem', amount: 2000, balance: 9800, reason: 'Room upgrade', date: '2024-11-10T09:00:00', ref: 'RED-0049' },
        { id: '7', member: 'Ahmed Khan', type: 'earn', amount: 1200, balance: 28000, reason: 'Event hall booking', date: '2024-11-08T15:00:00', ref: 'EVT-0012' },
        { id: '8', member: 'Taslima Khatun', type: 'earn', amount: 100, balance: 1200, reason: 'Restaurant dining', date: '2024-11-07T19:00:00', ref: 'FNB-2004' },
        { id: '9', member: 'Karim Hossain', type: 'adjust', amount: 50, balance: 2200, reason: 'Welcome bonus', date: '2024-11-05T10:00:00', ref: 'ADJ-0010' },
        { id: '10', member: 'Rafiq Islam', type: 'earn', amount: 2000, balance: 50000, reason: 'Extended stay - 7 nights', date: '2024-11-01T08:00:00', ref: 'RES-0998' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const filtered = filter === 'all' ? transactions : transactions.filter(t => t.type === filter)
  const totalEarned = transactions.filter(t => t.type === 'earn').reduce((s, t) => s + t.amount, 0)
  const totalRedeemed = transactions.filter(t => t.type === 'redeem').reduce((s, t) => s + t.amount, 0)

  const typeColors: Record<string, string> = { earn: 'bg-emerald-100 text-emerald-800', redeem: 'bg-red-100 text-red-800', adjust: 'bg-blue-100 text-blue-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Earned" value={totalEarned.toLocaleString()} subtitle="Points earned" color="emerald" />
        <KPICard title="Total Redeemed" value={totalRedeemed.toLocaleString()} subtitle="Points used" color="red" />
        <KPICard title="Transactions" value={transactions.length} subtitle="All time" color="blue" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Points Transactions</h2><p className="text-muted-foreground">History of points earn, redeem, and adjust</p></div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem><SelectItem value="earn">Earn</SelectItem><SelectItem value="redeem">Redeem</SelectItem><SelectItem value="adjust">Adjust</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Date</TableHead><TableHead>Member</TableHead><TableHead>Type</TableHead><TableHead>Amount</TableHead><TableHead>Balance</TableHead><TableHead>Reason</TableHead><TableHead>Reference</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(t => (
                  <TableRow key={t.id}>
                    <TableCell>{formatDateTime(t.date)}</TableCell>
                    <TableCell className="font-medium">{t.member}</TableCell>
                    <TableCell><Badge className={typeColors[t.type]}>{t.type}</Badge></TableCell>
                    <TableCell className={t.type === 'earn' || t.type === 'adjust' ? 'text-emerald-600' : 'text-red-600'}>
                      {t.type === 'earn' || t.type === 'adjust' ? '+' : '-'}{t.amount.toLocaleString()}
                    </TableCell>
                    <TableCell>{t.balance.toLocaleString()}</TableCell>
                    <TableCell>{t.reason}</TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{t.ref}</code></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ============ TIER SYSTEM ============
function TierSystem() {
  const [tiers, setTiers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '', minPoints: 0, maxPoints: 0, pointsMultiplier: 1, discount: 0, freeNights: 0, lateCheckout: false, roomUpgrade: false, benefits: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setTiers([
        { id: '1', name: 'standard', minPoints: 0, maxPoints: 4999, pointsMultiplier: 1, discount: 0, freeNights: 0, lateCheckout: false, roomUpgrade: false, benefits: 'Basic membership, earn 1 point per BDT 100', color: 'bg-gray-100' },
        { id: '2', name: 'silver', minPoints: 5000, maxPoints: 14999, pointsMultiplier: 1.5, discount: 5, freeNights: 1, lateCheckout: true, roomUpgrade: false, benefits: '1.5x points, 5% discount, 1 free night/year, late checkout', color: 'bg-slate-200' },
        { id: '3', name: 'gold', minPoints: 15000, maxPoints: 29999, pointsMultiplier: 2, discount: 10, freeNights: 2, lateCheckout: true, roomUpgrade: true, benefits: '2x points, 10% discount, 2 free nights/year, late checkout, room upgrade', color: 'bg-amber-100' },
        { id: '4', name: 'platinum', minPoints: 30000, maxPoints: 49999, pointsMultiplier: 2.5, discount: 15, freeNights: 3, lateCheckout: true, roomUpgrade: true, benefits: '2.5x points, 15% discount, 3 free nights/year, late checkout, room upgrade, priority booking', color: 'bg-violet-100' },
        { id: '5', name: 'diamond', minPoints: 50000, maxPoints: 999999, pointsMultiplier: 3, discount: 20, freeNights: 5, lateCheckout: true, roomUpgrade: true, benefits: '3x points, 20% discount, 5 free nights/year, late checkout, suite upgrade, priority booking, dedicated concierge', color: 'bg-sky-100' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ name: '', minPoints: 0, maxPoints: 0, pointsMultiplier: 1, discount: 0, freeNights: 0, lateCheckout: false, roomUpgrade: false, benefits: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setTiers(prev => prev.map(t => t.id === editItem.id ? { ...t, ...formData } : t))
      toast.success('Tier updated')
    } else {
      setTiers(prev => [...prev, { ...formData, id: Date.now().toString(), color: 'bg-gray-100' }])
      toast.success('Tier created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const tierBadgeColors: Record<string, string> = { standard: 'bg-gray-100 text-gray-800', silver: 'bg-slate-200 text-slate-800', gold: 'bg-amber-100 text-amber-800', platinum: 'bg-violet-100 text-violet-800', diamond: 'bg-sky-100 text-sky-800' }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Tier System</h2><p className="text-muted-foreground">Configure loyalty tiers and benefits</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Tier</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {tiers.map(tier => (
            <Card key={tier.id} className="relative overflow-hidden">
              <div className={`h-2 ${tier.color}`} />
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg capitalize">{tier.name}</CardTitle>
                  <Badge className={tierBadgeColors[tier.name] || ''}>{tier.name}</Badge>
                </div>
                <CardDescription>{tier.minPoints.toLocaleString()} - {tier.maxPoints.toLocaleString()} points</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Points Multiplier:</span><span className="font-medium">{tier.pointsMultiplier}x</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Discount:</span><span className="font-medium">{tier.discount}%</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Free Nights/Year:</span><span className="font-medium">{tier.freeNights}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Late Checkout:</span><span className="font-medium">{tier.lateCheckout ? '✓' : '✗'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Room Upgrade:</span><span className="font-medium">{tier.roomUpgrade ? '✓' : '✗'}</span></div>
                  <Separator />
                  <p className="text-muted-foreground">{tier.benefits}</p>
                </div>
                <Separator className="my-3" />
                <Button variant="outline" size="sm" onClick={() => openEdit(tier)}><Edit className="h-3 w-3 mr-1" />Edit Tier</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Tier</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Tier Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Min Points</Label><Input type="number" value={formData.minPoints} onChange={e => setFormData({ ...formData, minPoints: Number(e.target.value) })} /></div>
              <div><Label>Max Points</Label><Input type="number" value={formData.maxPoints} onChange={e => setFormData({ ...formData, maxPoints: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Points Multiplier</Label><Input type="number" step="0.5" value={formData.pointsMultiplier} onChange={e => setFormData({ ...formData, pointsMultiplier: Number(e.target.value) })} /></div>
              <div><Label>Discount (%)</Label><Input type="number" value={formData.discount} onChange={e => setFormData({ ...formData, discount: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Free Nights/Year</Label><Input type="number" value={formData.freeNights} onChange={e => setFormData({ ...formData, freeNights: Number(e.target.value) })} /></div>
              <div><Label>Late Checkout</Label>
                <Select value={formData.lateCheckout ? 'yes' : 'no'} onValueChange={v => setFormData({ ...formData, lateCheckout: v === 'yes' })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Room Upgrade</Label>
              <Select value={formData.roomUpgrade ? 'yes' : 'no'} onValueChange={v => setFormData({ ...formData, roomUpgrade: v === 'yes' })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>Benefits Description</Label><Textarea value={formData.benefits} onChange={e => setFormData({ ...formData, benefits: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ REFERRAL PROGRAM ============
function Referral() {
  const [referrals, setReferrals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [formData, setFormData] = useState({ referrer: '', referee: '', referralCode: '', rewardPoints: 500, status: 'pending' })

  useEffect(() => {
    setTimeout(() => {
      setReferrals([
        { id: '1', referrer: 'Ahmed Khan', referee: 'Karim Hossain', referralCode: 'AHMED2024', rewardPoints: 500, status: 'completed', date: '2024-11-01', refereeStays: 3 },
        { id: '2', referrer: 'Rafiq Islam', referee: 'Taslima Khatun', referralCode: 'RAFIQ2024', rewardPoints: 500, status: 'completed', date: '2024-10-15', refereeStays: 2 },
        { id: '3', referrer: 'Sarah Rahman', referee: 'Nasreen Akter', referralCode: 'SARAH2024', rewardPoints: 500, status: 'pending', date: '2024-11-10', refereeStays: 0 },
        { id: '4', referrer: 'Fatima Begum', referee: 'Mohammad Ali', referralCode: 'FATIMA2024', rewardPoints: 750, status: 'completed', date: '2024-09-20', refereeStays: 10 },
        { id: '5', referrer: 'Ahmed Khan', referee: 'Rezwan Ali', referralCode: 'AHMED2024', rewardPoints: 500, status: 'pending', date: '2024-11-12', refereeStays: 0 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setReferrals(prev => [...prev, { ...formData, id: Date.now().toString(), date: new Date().toISOString().split('T')[0], refereeStays: 0 }])
    toast.success('Referral added'); setDialogOpen(false)
    setFormData({ referrer: '', referee: '', referralCode: '', rewardPoints: 500, status: 'pending' })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Referrals" value={referrals.length} subtitle="All time" color="blue" />
        <KPICard title="Completed" value={referrals.filter(r => r.status === 'completed').length} subtitle="Rewards given" color="emerald" />
        <KPICard title="Pending" value={referrals.filter(r => r.status === 'pending').length} subtitle="Awaiting first stay" color="amber" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Referral Program</h2><p className="text-muted-foreground">Track referrals and rewards</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Add Referral</Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Referrer</TableHead><TableHead>Referee</TableHead><TableHead>Code</TableHead><TableHead>Reward Points</TableHead><TableHead>Referee Stays</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {referrals.map(r => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.referrer}</TableCell>
                  <TableCell>{r.referee}</TableCell>
                  <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{r.referralCode}</code></TableCell>
                  <TableCell>{r.rewardPoints}</TableCell>
                  <TableCell>{r.refereeStays}</TableCell>
                  <TableCell>{formatDate(r.date)}</TableCell>
                  <TableCell><Badge className={statusColors[r.status] || ''}>{r.status}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Referral</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Referrer Name</Label><Input value={formData.referrer} onChange={e => setFormData({ ...formData, referrer: e.target.value })} /></div>
            <div><Label>Referee Name</Label><Input value={formData.referee} onChange={e => setFormData({ ...formData, referee: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Referral Code</Label><Input value={formData.referralCode} onChange={e => setFormData({ ...formData, referralCode: e.target.value })} /></div>
              <div><Label>Reward Points</Label><Input type="number" value={formData.rewardPoints} onChange={e => setFormData({ ...formData, rewardPoints: Number(e.target.value) })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function LoyaltyModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'members': return <Members />
    case 'points': return <RewardPoints />
    case 'tiers': return <TierSystem />
    case 'referral': return <Referral />
    default: return <EmptyState title="Unknown Sub-Module" description={`Loyalty sub-module "${subModule}" not found.`} />
  }
}
