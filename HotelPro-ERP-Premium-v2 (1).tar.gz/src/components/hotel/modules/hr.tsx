'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============================================================
// Employee Management Sub-Module
// ============================================================
function EmployeeManagement() {
  const crud = useCrud<any>('/api/employees')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [deptFilter, setDeptFilter] = useState<string>('all')
  const [formData, setFormData] = useState({
    employeeId: '', name: '', department: '', position: '', phone: '', email: '', joinDate: '', salary: '', status: 'active'
  })

  const departments = [...new Set(crud.items.map((e: any) => e.department).filter(Boolean))]

  const openCreate = () => {
    setEditItem(null)
    setFormData({ employeeId: '', name: '', department: '', position: '', phone: '', email: '', joinDate: '', salary: '', status: 'active' })
    setDialogOpen(true)
  }
  const openEdit = (item: any) => {
    setEditItem(item)
    setFormData({
      employeeId: item.employeeId || item.employee_id || '', name: item.name || '', department: item.department || '',
      position: item.position || '', phone: item.phone || '', email: item.email || '',
      joinDate: item.joinDate || item.join_date || '', salary: String(item.salary ?? ''),
      status: item.status || 'active'
    })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.name || !formData.department || !formData.position) { toast.error('Name, department, and position are required'); return }
    setSaving(true)
    const payload = { ...formData, salary: Number(formData.salary) || 0 }
    const ok = editItem ? await crud.updateItem(editItem.id, payload) : await crud.createItem(payload)
    setSaving(false)
    if (ok) setDialogOpen(false)
  }

  const handleDelete = async () => { if (deleteId) { await crud.deleteItem(deleteId); setDeleteId(null) } }

  const filteredByDept = deptFilter === 'all' ? crud.filtered : crud.filtered.filter((e: any) => e.department === deptFilter)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Employee Management</h2><p className="text-muted-foreground">Manage hotel staff</p></div>
        <div className="flex gap-2 flex-wrap">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={e => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Select value={deptFilter} onValueChange={setDeptFilter}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Department" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Employee</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Employees" value={crud.items.length} icon={Plus} color="blue" />
        <KPICard title="Active" value={crud.items.filter((e: any) => e.status === 'active').length} icon={Eye} color="emerald" />
        <KPICard title="Departments" value={departments.length} icon={Edit} color="amber" />
        <KPICard title="Total Payroll" value={formatCurrency(crud.items.reduce((s: number, e: any) => s + Number(e.salary || 0), 0))} icon={Search} color="violet" />
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Emp ID</TableHead><TableHead>Name</TableHead><TableHead>Department</TableHead><TableHead>Position</TableHead><TableHead>Phone</TableHead><TableHead>Salary</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredByDept.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No employees found</TableCell></TableRow>
                  ) : filteredByDept.slice((crud.page - 1) * 10, crud.page * 10).map((item: any) => (
                    <TableRow key={item.id}>
                      <TableCell><Badge variant="outline">{item.employeeId || item.employee_id || '-'}</Badge></TableCell>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.department || '-'}</TableCell>
                      <TableCell>{item.position || '-'}</TableCell>
                      <TableCell>{item.phone || '-'}</TableCell>
                      <TableCell>{formatCurrency(item.salary || 0)}</TableCell>
                      <TableCell><Badge className={statusColors[item.status] || 'bg-gray-100 text-gray-800'}>{item.status}</Badge></TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={crud.page} totalPages={Math.max(1, Math.ceil(filteredByDept.length / 10))} setPage={crud.setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Employee</DialogTitle><DialogDescription>Fill in employee details.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Employee ID</Label><Input value={formData.employeeId} onChange={e => setFormData({ ...formData, employeeId: e.target.value })} placeholder="EMP-001" /></div>
              <div><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Full name" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Department</Label>
                <Input value={formData.department} onChange={e => setFormData({ ...formData, department: e.target.value })} placeholder="e.g. Front Desk, F&B" />
              </div>
              <div><Label>Position</Label><Input value={formData.position} onChange={e => setFormData({ ...formData, position: e.target.value })} placeholder="e.g. Manager, Receptionist" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Phone</Label><Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} placeholder="Phone number" /></div>
              <div><Label>Email</Label><Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="Email address" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Join Date</Label><Input type="date" value={formData.joinDate} onChange={e => setFormData({ ...formData, joinDate: e.target.value })} /></div>
              <div><Label>Salary</Label><Input type="number" value={formData.salary} onChange={e => setFormData({ ...formData, salary: e.target.value })} placeholder="Monthly salary" /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this employee?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Attendance Sub-Module
// ============================================================
function Attendance() {
  const [employees, setEmployees] = useState<any[]>([])
  const [attendanceRecords, setAttendanceRecords] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [viewMonth, setViewMonth] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [empData, attData] = await Promise.all([apiFetch('/api/employees'), apiFetch('/api/attendance')])
        setEmployees((empData.employees || []).filter((e: any) => e.status === 'active'))
        setAttendanceRecords(attData.attendance || attData.records || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const todayRecords = attendanceRecords.filter((r: any) => {
    const rDate = (r.date || r.createdAt || '').split('T')[0]
    return rDate === selectedDate
  })

  const markAttendance = async (employeeId: string, status: string) => {
    setSaving(true)
    try {
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({ employeeId, date: selectedDate, status, checkIn: status === 'present' ? new Date().toISOString() : status === 'late' ? new Date().toISOString() : null, checkOut: null })
      })
      toast.success(`Marked ${status}`)
      const attData = await apiFetch('/api/attendance')
      setAttendanceRecords(attData.attendance || attData.records || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const updateCheckOut = async (recordId: string) => {
    setSaving(true)
    try {
      await apiFetch(`/api/attendance?id=${recordId}`, {
        method: 'PUT',
        body: JSON.stringify({ checkOut: new Date().toISOString() })
      })
      toast.success('Checked out')
      const attData = await apiFetch('/api/attendance')
      setAttendanceRecords(attData.attendance || attData.records || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const presentCount = todayRecords.filter((r: any) => r.status === 'present').length
  const absentCount = todayRecords.filter((r: any) => r.status === 'absent').length
  const lateCount = todayRecords.filter((r: any) => r.status === 'late').length
  const uncheckedCount = employees.length - todayRecords.length

  const monthlySummary = employees.map((emp: any) => {
    const empRecords = attendanceRecords.filter((r: any) => r.employeeId === emp.id || r.employee_id === emp.id)
    const monthDate = new Date(selectedDate)
    const monthRecords = empRecords.filter((r: any) => {
      const d = new Date(r.date || r.createdAt)
      return d.getMonth() === monthDate.getMonth() && d.getFullYear() === monthDate.getFullYear()
    })
    return {
      ...emp,
      presentDays: monthRecords.filter((r: any) => r.status === 'present' || r.status === 'late').length,
      absentDays: monthRecords.filter((r: any) => r.status === 'absent').length,
      lateDays: monthRecords.filter((r: any) => r.status === 'late').length,
    }
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Attendance</h2><p className="text-muted-foreground">Track daily attendance</p></div>
        <div className="flex gap-2">
          <Input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="w-44" />
          <Button variant="outline" size="sm" onClick={() => setViewMonth(!viewMonth)}>{viewMonth ? 'Daily View' : 'Monthly Summary'}</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Present" value={presentCount} icon={Eye} color="emerald" />
        <KPICard title="Absent" value={absentCount} icon={Trash2} color="red" />
        <KPICard title="Late" value={lateCount} icon={Edit} color="amber" />
        <KPICard title="Not Marked" value={uncheckedCount} icon={Search} color="blue" />
      </div>

      {loading ? <LoadingSkeleton /> : viewMonth ? (
        <Card>
          <CardHeader><CardTitle>Monthly Summary - {new Date(selectedDate).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Present Days</TableHead><TableHead>Absent Days</TableHead><TableHead>Late Days</TableHead></TableRow></TableHeader>
              <TableBody>
                {monthlySummary.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No records found</TableCell></TableRow>
                ) : monthlySummary.map((emp: any) => (
                  <TableRow key={emp.id}>
                    <TableCell className="font-medium">{emp.name}</TableCell>
                    <TableCell>{emp.department || '-'}</TableCell>
                    <TableCell className="text-emerald-600 font-medium">{emp.presentDays}</TableCell>
                    <TableCell className="text-red-600 font-medium">{emp.absentDays}</TableCell>
                    <TableCell className="text-amber-600 font-medium">{emp.lateDays}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader><CardTitle>Today&apos;s Attendance - {formatDate(selectedDate)}</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Status</TableHead><TableHead>Check In</TableHead><TableHead>Check Out</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {employees.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No employees found</TableCell></TableRow>
                ) : employees.map((emp: any) => {
                  const record = todayRecords.find((r: any) => r.employeeId === emp.id || r.employee_id === emp.id)
                  return (
                    <TableRow key={emp.id}>
                      <TableCell className="font-medium">{emp.name}</TableCell>
                      <TableCell>{emp.department || '-'}</TableCell>
                      <TableCell>{record ? <Badge className={statusColors[record.status] || ''}>{record.status}</Badge> : <Badge variant="outline">Not Marked</Badge>}</TableCell>
                      <TableCell>{record?.checkIn || record?.check_in ? formatDateTime(record.checkIn || record.check_in) : '-'}</TableCell>
                      <TableCell>{record?.checkOut || record?.check_out ? formatDateTime(record.checkOut || record.check_out) : '-'}</TableCell>
                      <TableCell className="text-right">
                        {!record ? (
                          <div className="flex gap-1 justify-end">
                            <Button size="sm" variant="outline" className="text-emerald-600 border-emerald-300" onClick={() => markAttendance(emp.id, 'present')} disabled={saving}>Present</Button>
                            <Button size="sm" variant="outline" className="text-amber-600 border-amber-300" onClick={() => markAttendance(emp.id, 'late')} disabled={saving}>Late</Button>
                            <Button size="sm" variant="outline" className="text-red-600 border-red-300" onClick={() => markAttendance(emp.id, 'absent')} disabled={saving}>Absent</Button>
                          </div>
                        ) : !record.checkOut && !record.check_out && record.status !== 'absent' ? (
                          <Button size="sm" variant="outline" onClick={() => updateCheckOut(record.id)} disabled={saving}>Check Out</Button>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ============================================================
// Leave Management Sub-Module
// ============================================================
function LeaveManagement() {
  const [leaves, setLeaves] = useState<any[]>([])
  const [employees, setEmployees] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [formData, setFormData] = useState({ employeeId: '', type: 'casual', startDate: '', endDate: '', reason: '' })

  const leaveTypes = ['casual', 'sick', 'annual', 'maternity', 'unpaid']

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [empData, leaveData] = await Promise.all([apiFetch('/api/employees'), apiFetch('/api/attendance?type=leave')])
        setEmployees((empData.employees || []).filter((e: any) => e.status === 'active'))
        setLeaves(leaveData.leaves || leaveData.attendance || leaveData.records || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.employeeId || !formData.startDate || !formData.endDate || !formData.reason) { toast.error('All fields are required'); return }
    if (new Date(formData.endDate) < new Date(formData.startDate)) { toast.error('End date must be after start date'); return }
    setSaving(true)
    try {
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({ ...formData, type: 'leave', status: 'pending' })
      })
      toast.success('Leave application submitted')
      setDialogOpen(false)
      setFormData({ employeeId: '', type: 'casual', startDate: '', endDate: '', reason: '' })
      const leaveData = await apiFetch('/api/attendance?type=leave')
      setLeaves(leaveData.leaves || leaveData.attendance || leaveData.records || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const updateLeaveStatus = async (leaveId: string, status: string) => {
    try {
      await apiFetch(`/api/attendance?id=${leaveId}`, { method: 'PUT', body: JSON.stringify({ status }) })
      toast.success(`Leave ${status}`)
      const leaveData = await apiFetch('/api/attendance?type=leave')
      setLeaves(leaveData.leaves || leaveData.attendance || leaveData.records || [])
    } catch (e: any) { toast.error(e.message) }
  }

  const filtered = leaves.filter((l: any) => !search || (l.type || '').toLowerCase().includes(search.toLowerCase()) || (employees.find((e: any) => e.id === (l.employeeId || l.employee_id))?.name || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Leave Management</h2><p className="text-muted-foreground">Apply and manage employee leaves</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Apply Leave</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Applications" value={leaves.length} icon={Plus} color="blue" />
        <KPICard title="Pending" value={leaves.filter((l: any) => l.status === 'pending').length} icon={Edit} color="amber" />
        <KPICard title="Approved" value={leaves.filter((l: any) => l.status === 'approved').length} icon={Eye} color="emerald" />
        <KPICard title="Rejected" value={leaves.filter((l: any) => l.status === 'rejected').length} icon={Trash2} color="red" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Type</TableHead><TableHead>Start</TableHead><TableHead>End</TableHead><TableHead>Days</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No leave applications found</TableCell></TableRow>
                  ) : paginated.map((l: any) => {
                    const emp = employees.find((e: any) => e.id === (l.employeeId || l.employee_id))
                    const start = new Date(l.startDate || l.start_date || l.date)
                    const end = new Date(l.endDate || l.end_date || l.date)
                    const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1)
                    return (
                      <TableRow key={l.id}>
                        <TableCell className="font-medium">{emp?.name || l.employeeName || '-'}</TableCell>
                        <TableCell><Badge variant="outline">{l.type || l.leaveType || '-'}</Badge></TableCell>
                        <TableCell>{formatDate(l.startDate || l.start_date || l.date)}</TableCell>
                        <TableCell>{formatDate(l.endDate || l.end_date || l.date)}</TableCell>
                        <TableCell>{days}</TableCell>
                        <TableCell><Badge className={statusColors[l.status] || 'bg-gray-100 text-gray-800'}>{l.status}</Badge></TableCell>
                        <TableCell className="text-right">
                          {l.status === 'pending' && (
                            <div className="flex gap-1 justify-end">
                              <Button size="sm" variant="outline" className="text-emerald-600 border-emerald-300" onClick={() => updateLeaveStatus(l.id, 'approved')}>Approve</Button>
                              <Button size="sm" variant="outline" className="text-red-600 border-red-300" onClick={() => updateLeaveStatus(l.id, 'rejected')}>Reject</Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Apply Leave</DialogTitle><DialogDescription>Submit a leave application</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Employee</Label>
              <Select value={formData.employeeId} onValueChange={v => setFormData({ ...formData, employeeId: v })}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>{employees.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.name} - {e.department}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Leave Type</Label>
              <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{leaveTypes.map(t => <SelectItem key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
            <div><Label>Reason</Label><Textarea value={formData.reason} onChange={e => setFormData({ ...formData, reason: e.target.value })} placeholder="Reason for leave" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Submit Application</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Payroll Sub-Module
// ============================================================
function Payroll() {
  const [employees, setEmployees] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date()
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
  })
  const [payrollData, setPayrollData] = useState<any[]>([])
  const [viewPayslip, setViewPayslip] = useState<any>(null)
  const [processed, setProcessed] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/employees')
        const activeEmps = (data.employees || []).filter((e: any) => e.status === 'active')
        setEmployees(activeEmps)
        setPayrollData(activeEmps.map((emp: any) => ({
          employeeId: emp.id,
          name: emp.name,
          department: emp.department || '-',
          position: emp.position || '-',
          basicSalary: Number(emp.salary || 0),
          overtime: 0,
          allowances: 0,
          deductions: 0,
          netSalary: Number(emp.salary || 0),
        })))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const updatePayrollField = (empId: string, field: string, value: number) => {
    setPayrollData(prev => prev.map(p => {
      if (p.employeeId === empId) {
        const updated = { ...p, [field]: value }
        updated.netSalary = updated.basicSalary + updated.overtime + updated.allowances - updated.deductions
        return updated
      }
      return p
    }))
  }

  const handleProcessPayroll = async () => {
    setSaving(true)
    try {
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({ type: 'payroll', month: selectedMonth, payrollData })
      })
      toast.success('Payroll processed successfully')
      setProcessed(true)
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const totalBasic = payrollData.reduce((s: number, p: any) => s + p.basicSalary, 0)
  const totalOvertime = payrollData.reduce((s: number, p: any) => s + p.overtime, 0)
  const totalAllowances = payrollData.reduce((s: number, p: any) => s + p.allowances, 0)
  const totalDeductions = payrollData.reduce((s: number, p: any) => s + p.deductions, 0)
  const totalNet = payrollData.reduce((s: number, p: any) => s + p.netSalary, 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Payroll</h2><p className="text-muted-foreground">Process monthly payroll</p></div>
        <div className="flex gap-2">
          <Input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="w-44" />
          <Button size="sm" onClick={handleProcessPayroll} disabled={saving || processed}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{processed ? 'Processed' : 'Process Payroll'}</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="Total Basic" value={formatCurrency(totalBasic)} icon={Plus} color="blue" />
        <KPICard title="Overtime" value={formatCurrency(totalOvertime)} icon={Edit} color="amber" />
        <KPICard title="Allowances" value={formatCurrency(totalAllowances)} icon={Eye} color="emerald" />
        <KPICard title="Deductions" value={formatCurrency(totalDeductions)} icon={Trash2} color="red" />
        <KPICard title="Net Salary" value={formatCurrency(totalNet)} icon={Search} color="violet" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Basic</TableHead><TableHead>Overtime</TableHead><TableHead>Allowances</TableHead><TableHead>Deductions</TableHead><TableHead>Net Salary</TableHead><TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payrollData.length === 0 ? (
                  <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No employees found</TableCell></TableRow>
                ) : payrollData.map((p: any) => (
                  <TableRow key={p.employeeId}>
                    <TableCell className="font-medium">{p.name}</TableCell>
                    <TableCell>{p.department}</TableCell>
                    <TableCell>{formatCurrency(p.basicSalary)}</TableCell>
                    <TableCell><Input type="number" value={p.overtime} onChange={e => updatePayrollField(p.employeeId, 'overtime', Number(e.target.value))} className="w-24 h-8 text-sm" /></TableCell>
                    <TableCell><Input type="number" value={p.allowances} onChange={e => updatePayrollField(p.employeeId, 'allowances', Number(e.target.value))} className="w-24 h-8 text-sm" /></TableCell>
                    <TableCell><Input type="number" value={p.deductions} onChange={e => updatePayrollField(p.employeeId, 'deductions', Number(e.target.value))} className="w-24 h-8 text-sm" /></TableCell>
                    <TableCell className="font-bold">{formatCurrency(p.netSalary)}</TableCell>
                    <TableCell className="text-right"><Button variant="ghost" size="sm" onClick={() => setViewPayslip(p)}><Eye className="h-4 w-4" /></Button></TableCell>
                  </TableRow>
                ))}
                <TableRow className="font-bold border-t-2">
                  <TableCell colSpan={2}>Total</TableCell>
                  <TableCell>{formatCurrency(totalBasic)}</TableCell>
                  <TableCell>{formatCurrency(totalOvertime)}</TableCell>
                  <TableCell>{formatCurrency(totalAllowances)}</TableCell>
                  <TableCell>{formatCurrency(totalDeductions)}</TableCell>
                  <TableCell>{formatCurrency(totalNet)}</TableCell>
                  <TableCell />
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!viewPayslip} onOpenChange={() => setViewPayslip(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Payslip</DialogTitle><DialogDescription>Month: {selectedMonth}</DialogDescription></DialogHeader>
          {viewPayslip && (
            <div className="space-y-4">
              <div className="text-center">
                <h3 className="text-lg font-bold">Hotel Management ERP</h3>
                <p className="text-sm text-muted-foreground">Salary Slip - {new Date(selectedMonth + '-01').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-2">
                <div><Label className="text-muted-foreground">Name</Label><p className="font-medium">{viewPayslip.name}</p></div>
                <div><Label className="text-muted-foreground">Department</Label><p className="font-medium">{viewPayslip.department}</p></div>
                <div><Label className="text-muted-foreground">Position</Label><p className="font-medium">{viewPayslip.position}</p></div>
              </div>
              <Separator />
              <div className="space-y-2">
                <div className="flex justify-between"><span>Basic Salary</span><span>{formatCurrency(viewPayslip.basicSalary)}</span></div>
                <div className="flex justify-between"><span>Overtime</span><span>{formatCurrency(viewPayslip.overtime)}</span></div>
                <div className="flex justify-between"><span>Allowances</span><span>{formatCurrency(viewPayslip.allowances)}</span></div>
                <div className="flex justify-between text-red-600"><span>Deductions</span><span>-{formatCurrency(viewPayslip.deductions)}</span></div>
                <Separator />
                <div className="flex justify-between text-lg font-bold"><span>Net Salary</span><span>{formatCurrency(viewPayslip.netSalary)}</span></div>
              </div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setViewPayslip(null)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Performance Sub-Module
// ============================================================
function Performance() {
  const [employees, setEmployees] = useState<any[]>([])
  const [evaluations, setEvaluations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [formData, setFormData] = useState({
    employeeId: '', period: '', jobKnowledge: '5', workQuality: '5', attendance: '5', communication: '5', teamwork: '5', initiative: '5', comments: ''
  })

  const ratingCategories = [
    { key: 'jobKnowledge', label: 'Job Knowledge' },
    { key: 'workQuality', label: 'Work Quality' },
    { key: 'attendance', label: 'Attendance' },
    { key: 'communication', label: 'Communication' },
    { key: 'teamwork', label: 'Teamwork' },
    { key: 'initiative', label: 'Initiative' },
  ]

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [empData, evalData] = await Promise.all([apiFetch('/api/employees'), apiFetch('/api/attendance?type=performance')])
        setEmployees((empData.employees || []).filter((e: any) => e.status === 'active'))
        setEvaluations(evalData.evaluations || evalData.attendance || evalData.records || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.employeeId || !formData.period) { toast.error('Employee and period are required'); return }
    setSaving(true)
    const ratings = ratingCategories.map(c => Number(formData[c.key as keyof typeof formData]))
    const averageRating = ratings.reduce((s, r) => s + r, 0) / ratings.length
    try {
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({ ...formData, type: 'performance', averageRating: averageRating.toFixed(1) })
      })
      toast.success('Evaluation submitted successfully')
      setDialogOpen(false)
      setFormData({ employeeId: '', period: '', jobKnowledge: '5', workQuality: '5', attendance: '5', communication: '5', teamwork: '5', initiative: '5', comments: '' })
      const evalData = await apiFetch('/api/attendance?type=performance')
      setEvaluations(evalData.evaluations || evalData.attendance || evalData.records || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const filtered = evaluations.filter((ev: any) => !search || (employees.find((e: any) => e.id === (ev.employeeId || ev.employee_id))?.name || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Performance</h2><p className="text-muted-foreground">Employee evaluation and ratings</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Evaluation</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Evaluations" value={evaluations.length} icon={Plus} color="blue" />
        <KPICard title="Avg Rating" value={evaluations.length > 0 ? (evaluations.reduce((s: number, e: any) => s + Number(e.averageRating || e.average_rating || 0), 0) / evaluations.length).toFixed(1) : '0'} icon={Eye} color="emerald" />
        <KPICard title="Top Performers" value={evaluations.filter((e: any) => Number(e.averageRating || e.average_rating || 0) >= 8).length} icon={Edit} color="violet" />
        <KPICard title="Needs Improvement" value={evaluations.filter((e: any) => Number(e.averageRating || e.average_rating || 0) < 5).length} icon={Search} color="red" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Period</TableHead><TableHead>Job Knowledge</TableHead><TableHead>Work Quality</TableHead><TableHead>Teamwork</TableHead><TableHead>Average</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No evaluations found</TableCell></TableRow>
                  ) : paginated.map((ev: any) => {
                    const emp = employees.find((e: any) => e.id === (ev.employeeId || ev.employee_id))
                    const avg = Number(ev.averageRating || ev.average_rating || 0)
                    return (
                      <TableRow key={ev.id}>
                        <TableCell className="font-medium">{emp?.name || ev.employeeName || '-'}</TableCell>
                        <TableCell>{ev.period || '-'}</TableCell>
                        <TableCell>{ev.jobKnowledge || ev.job_knowledge || '-'}</TableCell>
                        <TableCell>{ev.workQuality || ev.work_quality || '-'}</TableCell>
                        <TableCell>{ev.teamwork || '-'}</TableCell>
                        <TableCell>
                          <Badge className={avg >= 7 ? 'bg-emerald-100 text-emerald-800' : avg >= 5 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'}>
                            {avg.toFixed(1)}/10
                          </Badge>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Evaluation</DialogTitle><DialogDescription>Rate employee performance</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Employee</Label>
              <Select value={formData.employeeId} onValueChange={v => setFormData({ ...formData, employeeId: v })}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>{employees.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.name} - {e.department}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Period</Label><Input value={formData.period} onChange={e => setFormData({ ...formData, period: e.target.value })} placeholder="e.g. Q1 2024, January 2024" /></div>
            <Separator />
            <Label className="text-base font-semibold">Rating (1-10)</Label>
            {ratingCategories.map(cat => (
              <div key={cat.key} className="flex items-center justify-between">
                <Label className="text-sm">{cat.label}</Label>
                <div className="flex items-center gap-2">
                  <Input type="number" min="1" max="10" value={formData[cat.key as keyof typeof formData]} onChange={e => setFormData({ ...formData, [cat.key]: e.target.value })} className="w-20 h-8 text-sm" />
                  <span className="text-sm text-muted-foreground">/10</span>
                </div>
              </div>
            ))}
            <div><Label>Comments</Label><Textarea value={formData.comments} onChange={e => setFormData({ ...formData, comments: e.target.value })} placeholder="Additional comments" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Submit Evaluation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Recruitment Sub-Module
// ============================================================
function Recruitment() {
  const [jobs, setJobs] = useState<any[]>([])
  const [applications, setApplications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [appDialogOpen, setAppDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [tab, setTab] = useState<'jobs' | 'applications'>('jobs')
  const [jobForm, setJobForm] = useState({ title: '', department: '', description: '', requirements: '', salary: '', employmentType: 'full-time', status: 'open' })
  const [appForm, setAppForm] = useState({ jobId: '', candidateName: '', email: '', phone: '', resume: '', coverLetter: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [empData, jobData] = await Promise.all([apiFetch('/api/employees'), apiFetch('/api/attendance?type=recruitment')])
        setJobs(jobData.jobs || jobData.attendance || jobData.records || [])
        setApplications(jobData.applications || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleCreateJob = async () => {
    if (!jobForm.title || !jobForm.department) { toast.error('Title and department are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/attendance', { method: 'POST', body: JSON.stringify({ ...jobForm, employmentType: jobForm.employmentType, type: 'recruitment', subtype: 'job' }) })
      toast.success('Job posting created')
      setDialogOpen(false)
      setJobForm({ title: '', department: '', description: '', requirements: '', salary: '', employmentType: 'full-time', status: 'open' })
      const jobData = await apiFetch('/api/attendance?type=recruitment')
      setJobs(jobData.jobs || jobData.attendance || jobData.records || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleApply = async () => {
    if (!appForm.jobId || !appForm.candidateName || !appForm.email) { toast.error('Job, name, and email are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/attendance', { method: 'POST', body: JSON.stringify({ type: 'recruitment', subtype: 'application', ...appForm }) })
      toast.success('Application submitted')
      setAppDialogOpen(false)
      setAppForm({ jobId: '', candidateName: '', email: '', phone: '', resume: '', coverLetter: '' })
      const jobData = await apiFetch('/api/attendance?type=recruitment')
      setApplications(jobData.applications || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const updateApplicationStatus = async (appId: string, status: string) => {
    try {
      await apiFetch(`/api/attendance?id=${appId}`, { method: 'PUT', body: JSON.stringify({ status }) })
      toast.success(`Application ${status}`)
      const jobData = await apiFetch('/api/attendance?type=recruitment')
      setApplications(jobData.applications || [])
    } catch (e: any) { toast.error(e.message) }
  }

  const filteredJobs = jobs.filter((j: any) => !search || (j.title || '').toLowerCase().includes(search.toLowerCase()) || (j.department || '').toLowerCase().includes(search.toLowerCase()))
  const filteredApps = applications.filter((a: any) => !search || (a.candidateName || a.candidate_name || '').toLowerCase().includes(search.toLowerCase()))
  const displayData = tab === 'jobs' ? filteredJobs : filteredApps
  const totalPages = Math.max(1, Math.ceil(displayData.length / pageSize))
  const paginated = displayData.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Recruitment</h2><p className="text-muted-foreground">Job postings and application tracking</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" variant="outline" onClick={() => setAppDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Apply</Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Post Job</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Open Positions" value={jobs.filter((j: any) => j.status === 'open').length} icon={Plus} color="blue" />
        <KPICard title="Total Applications" value={applications.length} icon={Eye} color="violet" />
        <KPICard title="Shortlisted" value={applications.filter((a: any) => a.status === 'shortlisted').length} icon={Edit} color="emerald" />
        <KPICard title="Interviews" value={applications.filter((a: any) => a.status === 'interview').length} icon={Search} color="amber" />
      </div>

      <div className="flex gap-2">
        <Button variant={tab === 'jobs' ? 'default' : 'outline'} size="sm" onClick={() => { setTab('jobs'); setPage(1) }}>Job Postings</Button>
        <Button variant={tab === 'applications' ? 'default' : 'outline'} size="sm" onClick={() => { setTab('applications'); setPage(1) }}>Applications</Button>
      </div>

      {loading ? <LoadingSkeleton /> : tab === 'jobs' ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>Department</TableHead><TableHead>Type</TableHead><TableHead>Salary</TableHead><TableHead>Status</TableHead><TableHead>Applicants</TableHead></TableRow></TableHeader>
              <TableBody>
                {paginated.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No job postings found</TableCell></TableRow>
                ) : paginated.map((j: any) => (
                  <TableRow key={j.id}>
                    <TableCell className="font-medium">{j.title}</TableCell>
                    <TableCell>{j.department || '-'}</TableCell>
                    <TableCell><Badge variant="outline">{j.employmentType || j.type || 'full-time'}</Badge></TableCell>
                    <TableCell>{j.salary ? formatCurrency(Number(j.salary)) : '-'}</TableCell>
                    <TableCell><Badge className={statusColors[j.status] || 'bg-gray-100 text-gray-800'}>{j.status || 'open'}</Badge></TableCell>
                    <TableCell>{applications.filter((a: any) => a.jobId === j.id || a.job_id === j.id).length}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Candidate</TableHead><TableHead>Position</TableHead><TableHead>Email</TableHead><TableHead>Phone</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {paginated.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No applications found</TableCell></TableRow>
                ) : paginated.map((a: any) => {
                  const job = jobs.find((j: any) => j.id === (a.jobId || a.job_id))
                  return (
                    <TableRow key={a.id}>
                      <TableCell className="font-medium">{a.candidateName || a.candidate_name || '-'}</TableCell>
                      <TableCell>{job?.title || '-'}</TableCell>
                      <TableCell>{a.email || '-'}</TableCell>
                      <TableCell>{a.phone || '-'}</TableCell>
                      <TableCell><Badge className={statusColors[a.status] || 'bg-gray-100 text-gray-800'}>{a.status || 'applied'}</Badge></TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => updateApplicationStatus(a.id, 'shortlisted')}>Shortlist</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateApplicationStatus(a.id, 'interview')}>Schedule Interview</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateApplicationStatus(a.id, 'rejected')}>Reject</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => updateApplicationStatus(a.id, 'hired')}>Hire</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
      <Pagination page={page} totalPages={totalPages} setPage={setPage} />

      {/* Job Posting Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Post Job</DialogTitle><DialogDescription>Create a new job posting</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Title</Label><Input value={jobForm.title} onChange={e => setJobForm({ ...jobForm, title: e.target.value })} placeholder="Job title" /></div>
            <div><Label>Department</Label><Input value={jobForm.department} onChange={e => setJobForm({ ...jobForm, department: e.target.value })} placeholder="Department" /></div>
            <div><Label>Description</Label><Textarea value={jobForm.description} onChange={e => setJobForm({ ...jobForm, description: e.target.value })} placeholder="Job description" /></div>
            <div><Label>Requirements</Label><Textarea value={jobForm.requirements} onChange={e => setJobForm({ ...jobForm, requirements: e.target.value })} placeholder="Job requirements" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Salary</Label><Input type="number" value={jobForm.salary} onChange={e => setJobForm({ ...jobForm, salary: e.target.value })} placeholder="Salary range" /></div>
              <div><Label>Type</Label>
                <Select value={jobForm.employmentType} onValueChange={v => setJobForm({ ...jobForm, employmentType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateJob} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Post Job</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Application Dialog */}
      <Dialog open={appDialogOpen} onOpenChange={setAppDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Submit Application</DialogTitle><DialogDescription>Apply for an open position</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Position</Label>
              <Select value={appForm.jobId} onValueChange={v => setAppForm({ ...appForm, jobId: v })}>
                <SelectTrigger><SelectValue placeholder="Select position" /></SelectTrigger>
                <SelectContent>{jobs.filter((j: any) => j.status === 'open').map((j: any) => <SelectItem key={j.id} value={j.id}>{j.title} - {j.department}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Candidate Name</Label><Input value={appForm.candidateName} onChange={e => setAppForm({ ...appForm, candidateName: e.target.value })} placeholder="Full name" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Email</Label><Input type="email" value={appForm.email} onChange={e => setAppForm({ ...appForm, email: e.target.value })} placeholder="Email" /></div>
              <div><Label>Phone</Label><Input value={appForm.phone} onChange={e => setAppForm({ ...appForm, phone: e.target.value })} placeholder="Phone" /></div>
            </div>
            <div><Label>Cover Letter</Label><Textarea value={appForm.coverLetter} onChange={e => setAppForm({ ...appForm, coverLetter: e.target.value })} placeholder="Cover letter" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAppDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleApply} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Submit Application</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Main HR Module Component
// ============================================================
export default function HRModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'employees': return <EmployeeManagement />
    case 'attendance': return <Attendance />
    case 'leave': return <LeaveManagement />
    case 'payroll': return <Payroll />
    case 'performance': return <Performance />
    case 'recruitment': return <Recruitment />
    default: return <EmptyState title="Unknown Sub-Module" description={`Sub-module "${subModule}" not found in HR.`} />
  }
}
