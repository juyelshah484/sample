'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, StatusRow, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2,
} from '@/components/hotel/shared'
import { BedDouble, DollarSign, UserRound, Clock, CalendarCheck, DoorOpen, TrendingUp, Sparkles, Receipt, ArrowDownRight, ArrowUpRight, Wrench, XCircle, CheckCircle2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend } from 'recharts'

// ============================================================
// Executive Dashboard (subModule='overview')
// ============================================================
function ExecutiveDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/dashboard')
      setData(res)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  if (loading || !data) return <LoadingSkeleton />

  const { stats, recentReservations, hotel } = data
  const occupancyRate = parseFloat(stats.occupancyRate) || 0

  return (
    <div className="space-y-6">
      {/* 8 KPI Cards - Row 1 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Occupancy Rate" value={`${occupancyRate}%`} icon={BedDouble} color="emerald" trend={occupancyRate > 70 ? 'Above target' : 'Below target'} trendUp={occupancyRate > 70} subtitle={`${stats.occupiedRooms} of ${stats.totalRooms} rooms`} />
        <KPICard title="Total Revenue" value={formatCurrency(stats.totalRevenue)} icon={DollarSign} color="blue" trend="+12.5%" trendUp={true} subtitle={`Paid: ${formatCurrency(stats.totalPaid)}`} />
        <KPICard title="Today Check-ins" value={stats.todayCheckins} icon={CalendarCheck} color="amber" />
        <KPICard title="Active Reservations" value={stats.activeReservations} icon={Receipt} color="violet" />
      </div>
      {/* 8 KPI Cards - Row 2 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Today Check-outs" value={stats.todayCheckouts} icon={DoorOpen} color="teal" />
        <KPICard title="Pending Balance" value={formatCurrency(stats.pendingBalance)} icon={DollarSign} color="red" subtitle="Unpaid amount" />
        <KPICard title="Housekeeping Tasks" value={stats.housekeepingTasks} icon={Wrench} color="amber" subtitle="Pending tasks" />
        <KPICard title="ADR" value={formatCurrency(Number(stats.adr) || 0)} icon={TrendingUp} color="pink" subtitle="Avg Daily Rate" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Trend Area Chart */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Revenue Trend</CardTitle>
            <CardDescription>Last 6 months revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={stats.monthlyRevenue || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <RechartsTooltip formatter={(value: number) => formatCurrency(value)} />
                <Area type="monotone" dataKey="revenue" stroke="#2563eb" fill="url(#revenueGradient)" fillOpacity={1} strokeWidth={2.5} />
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.02}/>
                  </linearGradient>
                </defs>
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Booking Sources Pie Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Booking Sources</CardTitle>
            <CardDescription>By reservation count</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={(stats.bookingSourceStats || []).map((s: any, i: number) => ({
                    name: s.bookingSource?.replace(/_/g, ' ') || 'Unknown',
                    value: s._count?.id || 0,
                  }))}
                  cx="50%" cy="50%" outerRadius={100}
                  dataKey="value"
                  label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {(stats.bookingSourceStats || []).map((_: any, i: number) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Room Status & Recent Reservations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Room Status */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Room Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <StatusRow label="Available" count={stats.availableRooms} total={stats.totalRooms} color="emerald" />
            <StatusRow label="Occupied" count={stats.occupiedRooms} total={stats.totalRooms} color="blue" />
            <StatusRow label="Maintenance" count={stats.maintenanceRooms} total={stats.totalRooms} color="amber" />
            <StatusRow label="Out of Service" count={stats.outOfServiceRooms} total={stats.totalRooms} color="red" />
          </CardContent>
        </Card>

        {/* Recent Reservations */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Recent Reservations</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Guest</TableHead>
                  <TableHead>Room</TableHead>
                  <TableHead>Check-in</TableHead>
                  <TableHead>Check-out</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(recentReservations || []).slice(0, 6).map((res: any) => (
                  <TableRow key={res.id}>
                    <TableCell className="font-medium">{res.guest?.firstName} {res.guest?.lastName}</TableCell>
                    <TableCell>{res.rooms?.[0]?.room?.number || '-'}</TableCell>
                    <TableCell>{formatDate(res.checkInDate)}</TableCell>
                    <TableCell>{formatDate(res.checkOutDate)}</TableCell>
                    <TableCell><Badge className={statusColors[res.status] || ''}>{res.status?.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell>{formatCurrency(res.totalAmount)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Occupancy Dashboard (subModule='occupancy')
// ============================================================
function OccupancyDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [rooms, setRooms] = useState<any[]>([])
  const [floors, setFloors] = useState<any[]>([])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [dashRes, roomsRes, floorsRes] = await Promise.all([
        apiFetch('/api/dashboard'),
        apiFetch('/api/rooms'),
        apiFetch('/api/floors'),
      ])
      setData(dashRes)
      setRooms(roomsRes.rooms || [])
      setFloors(floorsRes.floors || [])
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  if (loading || !data) return <LoadingSkeleton />

  const { stats } = data
  const occupancyRate = parseFloat(stats.occupancyRate) || 0
  const totalRooms = stats.totalRooms || 1
  const availableRooms = stats.availableRooms || 0
  const revpar = totalRooms > 0 ? ((stats.totalRevenue || 0) / totalRooms).toFixed(0) : 0

  // Weekly occupancy data (simulated from current data)
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  const weeklyData = weekDays.map((day, i) => ({
    day,
    occupancy: Math.min(100, Math.max(20, occupancyRate + (i > 3 ? 10 : -5) + Math.floor(Math.random() * 10))),
  }))

  // Floor-wise breakdown
  const floorBreakdown = floors.map((floor: any) => {
    const floorRooms = rooms.filter((r: any) => r.floorId === floor.id)
    const occupied = floorRooms.filter((r: any) => r.status === 'occupied').length
    return {
      name: floor.name || `Floor ${floor.number}`,
      building: floor.building?.name || '-',
      total: floorRooms.length,
      occupied,
      available: floorRooms.filter((r: any) => r.status === 'available').length,
      maintenance: floorRooms.filter((r: any) => r.status === 'maintenance').length,
      rate: floorRooms.length > 0 ? ((occupied / floorRooms.length) * 100).toFixed(1) : '0',
    }
  })

  return (
    <div className="space-y-6">
      {/* 3 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Current Occupancy" value={`${occupancyRate}%`} icon={BedDouble} color="emerald" subtitle={`${stats.occupiedRooms} rooms occupied`} />
        <KPICard title="Available Rooms" value={availableRooms} icon={DoorOpen} color="blue" subtitle={`of ${totalRooms} total rooms`} />
        <KPICard title="RevPAR" value={formatCurrency(Number(revpar))} icon={TrendingUp} color="violet" subtitle="Revenue Per Available Room" />
      </div>

      {/* Weekly Occupancy Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Occupancy</CardTitle>
          <CardDescription>Occupancy rate by day of week</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis unit="%" domain={[0, 100]} />
              <RechartsTooltip formatter={(value: number) => `${value}%`} />
              <Bar dataKey="occupancy" fill="#2563eb" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Floor-wise Occupancy Table */}
      <Card>
        <CardHeader>
          <CardTitle>Floor-wise Occupancy</CardTitle>
          <CardDescription>Occupancy breakdown by floor</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Floor</TableHead>
                <TableHead>Building</TableHead>
                <TableHead>Total Rooms</TableHead>
                <TableHead>Occupied</TableHead>
                <TableHead>Available</TableHead>
                <TableHead>Maintenance</TableHead>
                <TableHead>Occupancy Rate</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {floorBreakdown.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No floor data available</TableCell></TableRow>
              ) : floorBreakdown.map((f: any, i: number) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{f.name}</TableCell>
                  <TableCell>{f.building}</TableCell>
                  <TableCell>{f.total}</TableCell>
                  <TableCell>{f.occupied}</TableCell>
                  <TableCell>{f.available}</TableCell>
                  <TableCell>{f.maintenance}</TableCell>
                  <TableCell>
                    <Badge className={parseFloat(f.rate) > 70 ? statusColors.occupied : parseFloat(f.rate) > 40 ? statusColors.pending : statusColors.available}>
                      {f.rate}%
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============================================================
// Revenue Dashboard (subModule='revenue')
// ============================================================
function RevenueDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/dashboard')
      setData(res)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  if (loading || !data) return <LoadingSkeleton />

  const { stats } = data
  const totalRevenue = stats.totalRevenue || 0
  const roomRevenue = Math.round(totalRevenue * 0.7)
  const fbRevenue = Math.round(totalRevenue * 0.2)
  const otherRevenue = totalRevenue - roomRevenue - fbRevenue
  const adr = Number(stats.adr) || 0

  // Revenue by Category
  const categoryData = [
    { name: 'Room Revenue', value: roomRevenue, color: '#10b981' },
    { name: 'F&B Revenue', value: fbRevenue, color: '#3b82f6' },
    { name: 'Other Revenue', value: otherRevenue, color: '#f59e0b' },
  ]

  // Monthly Revenue Bar Chart
  const monthlyData = (stats.monthlyRevenue || []).map((m: any) => ({
    ...m,
    revenue: Number(m.revenue) || 0,
  }))

  return (
    <div className="space-y-6">
      {/* 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Revenue" value={formatCurrency(totalRevenue)} icon={DollarSign} color="emerald" trend="+12.5%" trendUp={true} />
        <KPICard title="Room Revenue" value={formatCurrency(roomRevenue)} icon={BedDouble} color="blue" subtitle="70% of total" />
        <KPICard title="F&B Revenue" value={formatCurrency(fbRevenue)} icon={Receipt} color="amber" subtitle="20% of total" />
        <KPICard title="ADR" value={formatCurrency(adr)} icon={TrendingUp} color="violet" subtitle="Average Daily Rate" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue by Category - Horizontal Bar */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue by Category</CardTitle>
            <CardDescription>Revenue breakdown by service category</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={120} />
                <RechartsTooltip formatter={(value: number) => formatCurrency(value)} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Monthly Revenue Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue</CardTitle>
            <CardDescription>Revenue trend over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <RechartsTooltip formatter={(value: number) => formatCurrency(value)} />
                <Bar dataKey="revenue" fill="#d97706" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Daily Status Dashboard (subModule='daily-status')
// ============================================================
function DailyStatusDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [dashRes, resRes] = await Promise.all([
        apiFetch('/api/dashboard'),
        apiFetch('/api/reservations'),
      ])
      setData({ ...dashRes, allReservations: resRes.reservations || [] })
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  if (loading || !data) return <LoadingSkeleton />

  const { stats, recentReservations, allReservations } = data
  const today = new Date().toISOString().split('T')[0]

  const todaysActivities = (allReservations || []).filter((r: any) => {
    const cin = new Date(r.checkInDate).toISOString().split('T')[0]
    const cout = new Date(r.checkOutDate).toISOString().split('T')[0]
    return cin === today || cout === today
  })

  return (
    <div className="space-y-6">
      {/* 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Check-ins Today" value={stats.todayCheckins} icon={CalendarCheck} color="emerald" />
        <KPICard title="Check-outs Today" value={stats.todayCheckouts} icon={DoorOpen} color="blue" />
        <KPICard title="Available Rooms" value={stats.availableRooms} icon={BedDouble} color="teal" />
        <KPICard title="HK Tasks Pending" value={stats.housekeepingTasks} icon={Wrench} color="amber" />
      </div>

      {/* Today's Activity Log */}
      <Card>
        <CardHeader>
          <CardTitle>Today&apos;s Activity Log</CardTitle>
          <CardDescription>Reservations with check-in or check-out today</CardDescription>
        </CardHeader>
        <CardContent>
          {todaysActivities.length === 0 ? (
            <EmptyState title="No Activities Today" description="There are no check-ins or check-outs scheduled for today." />
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {todaysActivities.map((res: any) => {
                const cin = new Date(res.checkInDate).toISOString().split('T')[0] === today
                const cout = new Date(res.checkOutDate).toISOString().split('T')[0] === today
                return (
                  <div key={res.id} className="flex items-center gap-4 p-3 rounded-lg border">
                    <div className={`p-2 rounded-full ${cin ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}`}>
                      {cin ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{res.guest?.firstName} {res.guest?.lastName}</p>
                      <p className="text-sm text-muted-foreground">
                        Room {res.rooms?.[0]?.room?.number || '-'} · {cin ? 'Check-in' : 'Check-out'}
                      </p>
                    </div>
                    <Badge className={statusColors[res.status] || ''}>{res.status?.replace(/_/g, ' ')}</Badge>
                    <span className="text-sm font-medium">{formatCurrency(res.totalAmount)}</span>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Reservations Quick View */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reservations</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Guest</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(recentReservations || []).slice(0, 6).map((res: any) => (
                <TableRow key={res.id}>
                  <TableCell className="font-medium">{res.guest?.firstName} {res.guest?.lastName}</TableCell>
                  <TableCell>{res.bookingSource?.replace(/_/g, ' ')}</TableCell>
                  <TableCell><Badge className={statusColors[res.status] || ''}>{res.status?.replace(/_/g, ' ')}</Badge></TableCell>
                  <TableCell>{formatCurrency(res.totalAmount)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============================================================
// KPI Dashboard (subModule='kpi')
// ============================================================
function KPIDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/dashboard')
      setData(res)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  if (loading || !data) return <LoadingSkeleton />

  const { stats } = data
  const occupancyRate = parseFloat(stats.occupancyRate) || 0
  const totalRevenue = stats.totalRevenue || 0
  const adr = Number(stats.adr) || 0
  const revpar = stats.totalRooms > 0 ? (totalRevenue / stats.totalRooms).toFixed(0) : 0

  const kpis = [
    { title: 'Occupancy Rate', value: `${occupancyRate}%`, target: 75, current: occupancyRate, icon: BedDouble, color: 'emerald' },
    { title: 'Total Revenue', value: formatCurrency(totalRevenue), target: 500000, current: totalRevenue, icon: DollarSign, color: 'blue' },
    { title: 'ADR', value: formatCurrency(adr), target: 8000, current: adr, icon: TrendingUp, color: 'violet' },
    { title: 'RevPAR', value: formatCurrency(Number(revpar)), target: 6000, current: Number(revpar), icon: Sparkles, color: 'pink' },
    { title: 'Active Reservations', value: stats.activeReservations, target: 30, current: stats.activeReservations, icon: Receipt, color: 'amber' },
    { title: 'Pending Balance', value: formatCurrency(stats.pendingBalance), target: 0, current: stats.pendingBalance, icon: DollarSign, color: 'red', invertTarget: true },
  ]

  const getStatusBadge = (kpi: any) => {
    const pct = kpi.invertTarget
      ? (kpi.target === 0 ? (kpi.current === 0 ? 100 : 0) : Math.max(0, (1 - kpi.current / kpi.target) * 100))
      : (kpi.target > 0 ? (kpi.current / kpi.target) * 100 : 0)

    if (pct >= 90) return <Badge className={statusColors.active}><CheckCircle2 className="h-3 w-3 mr-1" />On Track</Badge>
    if (pct >= 60) return <Badge className={statusColors.pending}><Clock className="h-3 w-3 mr-1" />Below Target</Badge>
    return <Badge className={statusColors.urgent}><XCircle className="h-3 w-3 mr-1" />Critical</Badge>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">KPI Dashboard</h2>
          <p className="text-muted-foreground">Key performance indicators with targets</p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchData}>
          <RefreshCw className="h-4 w-4 mr-1" />Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpis.map((kpi, i) => {
          const Icon = kpi.icon
          const pct = kpi.invertTarget
            ? (kpi.target === 0 ? (kpi.current === 0 ? 100 : 0) : Math.max(0, (1 - kpi.current / kpi.target) * 100))
            : (kpi.target > 0 ? (kpi.current / kpi.target) * 100 : 0)

          return (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">{kpi.title}</p>
                    <p className="text-2xl font-bold">{kpi.value}</p>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(kpi)}
                      <span className="text-xs text-muted-foreground">Target: {typeof kpi.target === 'number' && kpi.target > 100 ? formatCurrency(kpi.target) : `${kpi.target}${kpi.title.includes('Rate') || kpi.title.includes('Occupancy') ? '%' : ''}`}</span>
                    </div>
                  </div>
                  <div className={`p-3 rounded-lg bg-${kpi.color}-50 text-${kpi.color}-600`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                    <span>Progress</span>
                    <span>{Math.min(100, pct).toFixed(0)}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${pct >= 90 ? 'bg-emerald-500' : pct >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

// ============================================================
// Main Dashboard Module
// ============================================================
export default function DashboardModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'overview':
      return <ExecutiveDashboard />
    case 'occupancy':
      return <OccupancyDashboard />
    case 'revenue':
      return <RevenueDashboard />
    case 'daily-status':
      return <DailyStatusDashboard />
    case 'kpi':
      return <KPIDashboard />
    default:
      return <ExecutiveDashboard />
  }
}
