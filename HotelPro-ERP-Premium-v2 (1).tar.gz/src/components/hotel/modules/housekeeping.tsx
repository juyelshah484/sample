'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ Types ============
interface HousekeepingTask {
  id: string
  roomId: string
  type: string
  status: string
  priority: string
  assignedTo: string | null
  notes: string | null
  startedAt: string | null
  completedAt: string | null
  createdAt: string
  updatedAt: string
  room?: { id: string; number: string; name?: string; roomType?: { name: string } }
}

interface LostFoundItem {
  id: string
  item: string
  description: string | null
  location: string | null
  foundDate: string
  foundBy: string | null
  status: string
  claimedBy: string | null
  claimedDate: string | null
}

interface LinenItem {
  id: string
  category: string
  name: string
  stockIn: number
  stockOut: number
  available: number
}

// ============ Priority Badge ============
function PriorityBadge({ priority }: { priority: string }) {
  const colorMap: Record<string, string> = {
    urgent: 'bg-red-100 text-red-800',
    high: 'bg-amber-100 text-amber-800',
    normal: 'bg-blue-100 text-blue-800',
    low: 'bg-gray-100 text-gray-800',
  }
  return <Badge className={colorMap[priority] || 'bg-gray-100 text-gray-800'}>{priority}</Badge>
}

// ============ HK Dashboard ============
function HKDashboard() {
  const [tasks, setTasks] = useState<HousekeepingTask[]>([])
  const [stats, setStats] = useState<any>({})
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ roomId: '', type: 'cleaning', priority: 'normal', assignedTo: '', notes: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [hkRes, roomsRes] = await Promise.all([apiFetch('/api/housekeeping'), apiFetch('/api/rooms')])
      setTasks(hkRes.tasks || [])
      setStats(hkRes.stats || {})
      setRooms(roomsRes.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleCreate = async () => {
    if (!form.roomId) { toast.error('Please select a room'); return }
    setSaving(true)
    try {
      await apiFetch('/api/housekeeping', { method: 'POST', body: JSON.stringify(form) })
      toast.success('Task created')
      setDialogOpen(false)
      setForm({ roomId: '', type: 'cleaning', priority: 'normal', assignedTo: '', notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleStatusChange = async (taskId: string, newStatus: string) => {
    try {
      await apiFetch('/api/housekeeping', { method: 'PUT', body: JSON.stringify({ id: taskId, status: newStatus }) })
      toast.success(`Task marked as ${newStatus.replace('_', ' ')}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleDelete = async (taskId: string) => {
    try {
      await apiFetch(`/api/housekeeping?id=${taskId}`, { method: 'DELETE' })
      toast.success('Task deleted')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Housekeeping Dashboard</h2>
          <p className="text-muted-foreground">Manage cleaning, inspection, and maintenance tasks</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Add Task</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Pending" value={stats.pending || 0} color="amber" />
        <KPICard title="In Progress" value={stats.inProgress || 0} color="blue" />
        <KPICard title="Completed" value={stats.completed || 0} color="emerald" />
        <KPICard title="Total Tasks" value={stats.total || 0} color="violet" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Assigned To</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tasks.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No tasks found</TableCell></TableRow>
              ) : tasks.map(task => (
                <TableRow key={task.id}>
                  <TableCell className="font-medium">{task.room?.number || '-'}{task.room?.roomType ? ` (${task.room.roomType.name})` : ''}</TableCell>
                  <TableCell className="capitalize">{task.type?.replace('_', ' ')}</TableCell>
                  <TableCell><Badge className={statusColors[task.status] || ''}>{task.status?.replace('_', ' ')}</Badge></TableCell>
                  <TableCell><PriorityBadge priority={task.priority} /></TableCell>
                  <TableCell>{task.assignedTo || '-'}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{task.notes || '-'}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {task.status === 'pending' && <DropdownMenuItem onClick={() => handleStatusChange(task.id, 'in_progress')}>Start Task</DropdownMenuItem>}
                        {task.status === 'in_progress' && <DropdownMenuItem onClick={() => handleStatusChange(task.id, 'completed')}>Complete Task</DropdownMenuItem>}
                        <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(task.id)}>Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Housekeeping Task</DialogTitle><DialogDescription>Create a new housekeeping task</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Room *</Label><Select value={form.roomId} onValueChange={v => setForm({ ...form, roomId: v })}><SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger><SelectContent>{rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Type</Label><Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="cleaning">Cleaning</SelectItem><SelectItem value="inspection">Inspection</SelectItem><SelectItem value="deep_clean">Deep Clean</SelectItem></SelectContent></Select></div>
            <div><Label>Priority</Label><Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem></SelectContent></Select></div>
            <div><Label>Assigned To</Label><Input value={form.assignedTo} onChange={e => setForm({ ...form, assignedTo: e.target.value })} placeholder="Staff name" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Room Cleaning ============
function RoomCleaning() {
  const [tasks, setTasks] = useState<HousekeepingTask[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ roomId: '', priority: 'normal', assignedTo: '', notes: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [hkRes, roomsRes] = await Promise.all([
        apiFetch('/api/housekeeping?type=cleaning'),
        apiFetch('/api/rooms'),
      ])
      setTasks(hkRes.tasks || [])
      setRooms(roomsRes.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleCreate = async () => {
    if (!form.roomId) { toast.error('Please select a room'); return }
    setSaving(true)
    try {
      await apiFetch('/api/housekeeping', { method: 'POST', body: JSON.stringify({ ...form, type: 'cleaning' }) })
      toast.success('Cleaning task created')
      setDialogOpen(false)
      setForm({ roomId: '', priority: 'normal', assignedTo: '', notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleStatusChange = async (taskId: string, newStatus: string) => {
    try {
      await apiFetch('/api/housekeeping', { method: 'PUT', body: JSON.stringify({ id: taskId, status: newStatus }) })
      toast.success(`Task marked as ${newStatus.replace('_', ' ')}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Cleaning</h2><p className="text-muted-foreground">Manage room cleaning tasks</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Cleaning Task</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MiniStat label="Pending" value={tasks.filter(t => t.status === 'pending').length} color="bg-amber-50" />
        <MiniStat label="In Progress" value={tasks.filter(t => t.status === 'in_progress').length} color="bg-blue-50" />
        <MiniStat label="Completed" value={tasks.filter(t => t.status === 'completed').length} color="bg-emerald-50" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Room</TableHead><TableHead>Status</TableHead><TableHead>Priority</TableHead><TableHead>Assigned To</TableHead><TableHead>Notes</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {tasks.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No cleaning tasks</TableCell></TableRow>
              ) : tasks.map(task => (
                <TableRow key={task.id}>
                  <TableCell className="font-medium">{task.room?.number || '-'}</TableCell>
                  <TableCell><Badge className={statusColors[task.status] || ''}>{task.status?.replace('_', ' ')}</Badge></TableCell>
                  <TableCell><PriorityBadge priority={task.priority} /></TableCell>
                  <TableCell>{task.assignedTo || '-'}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{task.notes || '-'}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-1 justify-end">
                      {task.status === 'pending' && <Button size="sm" variant="outline" onClick={() => handleStatusChange(task.id, 'in_progress')}>Start</Button>}
                      {task.status === 'in_progress' && <Button size="sm" variant="outline" className="text-emerald-600" onClick={() => handleStatusChange(task.id, 'completed')}>Complete</Button>}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Cleaning Task</DialogTitle><DialogDescription>Create a room cleaning task</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Room *</Label><Select value={form.roomId} onValueChange={v => setForm({ ...form, roomId: v })}><SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger><SelectContent>{rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Priority</Label><Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem></SelectContent></Select></div>
            <div><Label>Assigned To</Label><Input value={form.assignedTo} onChange={e => setForm({ ...form, assignedTo: e.target.value })} placeholder="Staff name" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Room Inspection ============
function RoomInspection() {
  const [tasks, setTasks] = useState<HousekeepingTask[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ roomId: '', priority: 'normal', assignedTo: '', notes: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [hkRes, roomsRes] = await Promise.all([
        apiFetch('/api/housekeeping?type=inspection'),
        apiFetch('/api/rooms'),
      ])
      setTasks(hkRes.tasks || [])
      setRooms(roomsRes.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleCreate = async () => {
    if (!form.roomId) { toast.error('Please select a room'); return }
    setSaving(true)
    try {
      await apiFetch('/api/housekeeping', { method: 'POST', body: JSON.stringify({ ...form, type: 'inspection' }) })
      toast.success('Inspection task created')
      setDialogOpen(false)
      setForm({ roomId: '', priority: 'normal', assignedTo: '', notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleResult = async (taskId: string, status: string) => {
    try {
      await apiFetch('/api/housekeeping', { method: 'PUT', body: JSON.stringify({ id: taskId, status: 'completed', notes: `Inspection ${status}` }) })
      toast.success(`Inspection marked as ${status}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Inspection</h2><p className="text-muted-foreground">Room quality inspections</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Inspection</Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Room</TableHead><TableHead>Status</TableHead><TableHead>Priority</TableHead><TableHead>Assigned To</TableHead><TableHead>Notes</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {tasks.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No inspection tasks</TableCell></TableRow>
              ) : tasks.map(task => (
                <TableRow key={task.id}>
                  <TableCell className="font-medium">{task.room?.number || '-'}</TableCell>
                  <TableCell><Badge className={statusColors[task.status] || ''}>{task.status?.replace('_', ' ')}</Badge></TableCell>
                  <TableCell><PriorityBadge priority={task.priority} /></TableCell>
                  <TableCell>{task.assignedTo || '-'}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{task.notes || '-'}</TableCell>
                  <TableCell className="text-right">
                    {task.status !== 'completed' && task.status !== 'cancelled' && (
                      <div className="flex gap-1 justify-end">
                        <Button size="sm" variant="outline" className="text-emerald-600" onClick={() => handleResult(task.id, 'passed')}>Pass</Button>
                        <Button size="sm" variant="outline" className="text-red-600" onClick={() => handleResult(task.id, 'failed')}>Fail</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Inspection</DialogTitle><DialogDescription>Create a room inspection task</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Room *</Label><Select value={form.roomId} onValueChange={v => setForm({ ...form, roomId: v })}><SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger><SelectContent>{rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Priority</Label><Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem></SelectContent></Select></div>
            <div><Label>Assigned To</Label><Input value={form.assignedTo} onChange={e => setForm({ ...form, assignedTo: e.target.value })} placeholder="Inspector name" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Inspection notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Linen Management ============
function LinenManagement() {
  const [linenItems, setLinenItems] = useState<LinenItem[]>([
    { id: '1', category: 'Bed Sheet', name: 'Single Bed Sheet', stockIn: 200, stockOut: 85, available: 115 },
    { id: '2', category: 'Bed Sheet', name: 'Double Bed Sheet', stockIn: 150, stockOut: 60, available: 90 },
    { id: '3', category: 'Towel', name: 'Bath Towel', stockIn: 300, stockOut: 120, available: 180 },
    { id: '4', category: 'Towel', name: 'Hand Towel', stockIn: 250, stockOut: 90, available: 160 },
    { id: '5', category: 'Towel', name: 'Face Towel', stockIn: 200, stockOut: 70, available: 130 },
    { id: '6', category: 'Pillow Case', name: 'Pillow Case', stockIn: 400, stockOut: 180, available: 220 },
    { id: '7', category: 'Blanket', name: 'Wool Blanket', stockIn: 100, stockOut: 30, available: 70 },
    { id: '8', category: 'Duvet', name: 'Duvet Cover', stockIn: 120, stockOut: 45, available: 75 },
    { id: '9', category: 'Duvet', name: 'Duvet Insert', stockIn: 100, stockOut: 20, available: 80 },
  ])
  const [stockDialogOpen, setStockDialogOpen] = useState(false)
  const [stockForm, setStockForm] = useState({ itemId: '', type: 'in', quantity: '', notes: '' })

  const categories = [...new Set(linenItems.map(i => i.category))]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Linen Management</h2><p className="text-muted-foreground">Track linen inventory and stock movements</p></div>
        <Button size="sm" onClick={() => setStockDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Stock In/Out</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {categories.map(cat => {
          const catItems = linenItems.filter(i => i.category === cat)
          const totalAvail = catItems.reduce((s, i) => s + i.available, 0)
          return <KPICard key={cat} title={cat} value={totalAvail} subtitle={`${catItems.length} items`} color="emerald" />
        })}
      </div>

      <Card>
        <CardHeader><CardTitle>Linen Inventory</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Category</TableHead><TableHead>Name</TableHead><TableHead>Stock In</TableHead><TableHead>Stock Out</TableHead><TableHead>Available</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {linenItems.map(item => (
                <TableRow key={item.id}>
                  <TableCell>{item.category}</TableCell>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.stockIn}</TableCell>
                  <TableCell>{item.stockOut}</TableCell>
                  <TableCell><Badge className={item.available < 50 ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}>{item.available}</Badge></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={stockDialogOpen} onOpenChange={setStockDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Stock In/Out</DialogTitle><DialogDescription>Record linen stock movement</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Item</Label><Select value={stockForm.itemId} onValueChange={v => setStockForm({ ...stockForm, itemId: v })}><SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger><SelectContent>{linenItems.map(i => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Type</Label><Select value={stockForm.type} onValueChange={v => setStockForm({ ...stockForm, type: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="in">Stock In</SelectItem><SelectItem value="out">Stock Out</SelectItem></SelectContent></Select></div>
            <div><Label>Quantity</Label><Input type="number" value={stockForm.quantity} onChange={e => setStockForm({ ...stockForm, quantity: e.target.value })} placeholder="Enter quantity" /></div>
            <div><Label>Notes</Label><Textarea value={stockForm.notes} onChange={e => setStockForm({ ...stockForm, notes: e.target.value })} placeholder="Reason for stock movement" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStockDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => {
              const qty = parseInt(stockForm.quantity) || 0
              if (!stockForm.itemId || qty <= 0) { toast.error('Select item and enter valid quantity'); return }
              setLinenItems(prev => prev.map(i => i.id === stockForm.itemId ? {
                ...i,
                stockIn: stockForm.type === 'in' ? i.stockIn + qty : i.stockIn,
                stockOut: stockForm.type === 'out' ? i.stockOut + qty : i.stockOut,
                available: stockForm.type === 'in' ? i.available + qty : Math.max(0, i.available - qty),
              } : i))
              toast.success(`Stock ${stockForm.type === 'in' ? 'added' : 'removed'} successfully`)
              setStockDialogOpen(false)
              setStockForm({ itemId: '', type: 'in', quantity: '', notes: '' })
            }}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Lost & Found ============
function LostFound() {
  const [items, setItems] = useState<LostFoundItem[]>([
    { id: '1', item: 'Gold Ring', description: '22k gold ring with diamond', location: 'Room 301', foundDate: '2025-01-15', foundBy: 'Staff A', status: 'unclaimed', claimedBy: null, claimedDate: null },
    { id: '2', item: 'iPhone 15', description: 'Black iPhone with case', location: 'Lobby', foundDate: '2025-01-14', foundBy: 'Staff B', status: 'claimed', claimedBy: 'John Doe', claimedDate: '2025-01-16' },
    { id: '3', item: 'Passport', description: 'Bangladeshi passport', location: 'Restaurant', foundDate: '2025-01-13', foundBy: 'Staff C', status: 'unclaimed', claimedBy: null, claimedDate: null },
    { id: '4', item: 'Laptop Charger', description: 'Dell charger', location: 'Conference Room A', foundDate: '2025-01-12', foundBy: 'Staff D', status: 'disposed', claimedBy: null, claimedDate: null },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [claimDialogOpen, setClaimDialogOpen] = useState(false)
  const [claimForm, setClaimForm] = useState({ itemId: '', claimedBy: '' })
  const [form, setForm] = useState({ item: '', description: '', location: '', foundBy: '' })

  const handleRegister = () => {
    if (!form.item) { toast.error('Item name is required'); return }
    const newItem: LostFoundItem = {
      id: String(Date.now()),
      ...form,
      foundDate: new Date().toISOString(),
      status: 'unclaimed',
      claimedBy: null,
      claimedDate: null,
    }
    setItems(prev => [newItem, ...prev])
    toast.success('Item registered')
    setDialogOpen(false)
    setForm({ item: '', description: '', location: '', foundBy: '' })
  }

  const handleClaim = () => {
    if (!claimForm.claimedBy) { toast.error('Claimant name is required'); return }
    setItems(prev => prev.map(i => i.id === claimForm.itemId ? { ...i, status: 'claimed', claimedBy: claimForm.claimedBy, claimedDate: new Date().toISOString() } : i))
    toast.success('Item claimed')
    setClaimDialogOpen(false)
    setClaimForm({ itemId: '', claimedBy: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Lost & Found</h2><p className="text-muted-foreground">Track lost and found items</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Register Item</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MiniStat label="Unclaimed" value={items.filter(i => i.status === 'unclaimed').length} color="bg-amber-50" />
        <MiniStat label="Claimed" value={items.filter(i => i.status === 'claimed').length} color="bg-emerald-50" />
        <MiniStat label="Disposed" value={items.filter(i => i.status === 'disposed').length} color="bg-gray-50" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Item</TableHead><TableHead>Description</TableHead><TableHead>Location</TableHead><TableHead>Found Date</TableHead><TableHead>Found By</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No items found</TableCell></TableRow>
              ) : items.map(item => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.item}</TableCell>
                  <TableCell className="max-w-[150px] truncate">{item.description || '-'}</TableCell>
                  <TableCell>{item.location || '-'}</TableCell>
                  <TableCell>{formatDate(item.foundDate)}</TableCell>
                  <TableCell>{item.foundBy || '-'}</TableCell>
                  <TableCell><Badge className={statusColors[item.status] || ''}>{item.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    {item.status === 'unclaimed' && (
                      <div className="flex gap-1 justify-end">
                        <Button size="sm" variant="outline" onClick={() => { setClaimForm({ itemId: item.id, claimedBy: '' }); setClaimDialogOpen(true) }}>Claim</Button>
                        <Button size="sm" variant="outline" className="text-gray-600" onClick={() => {
                          setItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'disposed' } : i))
                          toast.success('Item marked as disposed')
                        }}>Dispose</Button>
                      </div>
                    )}
                    {item.status === 'claimed' && <span className="text-xs text-muted-foreground">By {item.claimedBy}</span>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Register Found Item</DialogTitle><DialogDescription>Record a new lost and found item</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Item Name *</Label><Input value={form.item} onChange={e => setForm({ ...form, item: e.target.value })} placeholder="e.g. Gold Ring" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the item" /></div>
            <div><Label>Location Found</Label><Input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Room 301" /></div>
            <div><Label>Found By</Label><Input value={form.foundBy} onChange={e => setForm({ ...form, foundBy: e.target.value })} placeholder="Staff name" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleRegister}>Register</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={claimDialogOpen} onOpenChange={setClaimDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Claim Item</DialogTitle><DialogDescription>Enter the claimant details</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Claimant Name *</Label><Input value={claimForm.claimedBy} onChange={e => setClaimForm({ ...claimForm, claimedBy: e.target.value })} placeholder="Enter claimant name" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClaimDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleClaim}>Confirm Claim</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Cleaning Schedule ============
function CleaningSchedule() {
  const [tasks, setTasks] = useState<HousekeepingTask[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ roomId: '', assignedTo: '', notes: '' })
  const [selectedDay, setSelectedDay] = useState(0)

  const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  const today = new Date()
  const currentDay = today.getDay()
  const weekStart = new Date(today)
  weekStart.setDate(today.getDate() - ((currentDay + 6) % 7))

  const weekDates = weekDays.map((_, i) => {
    const d = new Date(weekStart)
    d.setDate(weekStart.getDate() + i)
    return d
  })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [hkRes, roomsRes] = await Promise.all([apiFetch('/api/housekeeping?type=cleaning'), apiFetch('/api/rooms')])
      setTasks(hkRes.tasks || [])
      setRooms(roomsRes.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleCreate = async () => {
    if (!form.roomId) { toast.error('Please select a room'); return }
    setSaving(true)
    try {
      const scheduledDate = new Date(weekDates[selectedDay])
      scheduledDate.setHours(9, 0, 0, 0)
      await apiFetch('/api/housekeeping', {
        method: 'POST',
        body: JSON.stringify({ ...form, type: 'cleaning', priority: 'normal', scheduledDate: scheduledDate.toISOString() }),
      })
      toast.success('Cleaning task scheduled')
      setDialogOpen(false)
      setForm({ roomId: '', assignedTo: '', notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Cleaning Schedule</h2><p className="text-muted-foreground">Weekly room cleaning schedule</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Assign Cleaning</Button>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {weekDays.map((day, i) => (
          <button
            key={day}
            className={`p-3 rounded-lg text-center transition-colors ${selectedDay === i ? 'bg-emerald-100 text-emerald-800 border-2 border-emerald-300' : 'bg-muted hover:bg-muted/80'}`}
            onClick={() => setSelectedDay(i)}
          >
            <p className="text-xs font-medium">{day.slice(0, 3)}</p>
            <p className="text-lg font-bold">{weekDates[i].getDate()}</p>
          </button>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle>{weekDays[selectedDay]} — {formatDate(weekDates[selectedDay].toISOString())}</CardTitle><CardDescription>Scheduled cleaning tasks</CardDescription></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Room</TableHead><TableHead>Status</TableHead><TableHead>Assigned To</TableHead><TableHead>Notes</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {tasks.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No tasks scheduled</TableCell></TableRow>
              ) : tasks.map(task => (
                <TableRow key={task.id}>
                  <TableCell className="font-medium">{task.room?.number || '-'}</TableCell>
                  <TableCell><Badge className={statusColors[task.status] || ''}>{task.status?.replace('_', ' ')}</Badge></TableCell>
                  <TableCell>{task.assignedTo || '-'}</TableCell>
                  <TableCell>{task.notes || '-'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Assign Cleaning Task</DialogTitle><DialogDescription>Schedule a cleaning task for {weekDays[selectedDay]}</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Room *</Label><Select value={form.roomId} onValueChange={v => setForm({ ...form, roomId: v })}><SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger><SelectContent>{rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Assigned To</Label><Input value={form.assignedTo} onChange={e => setForm({ ...form, assignedTo: e.target.value })} placeholder="Staff name" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Schedule</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Main Component ============
export default function HousekeepingModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'dashboard': return <HKDashboard />
    case 'cleaning': return <RoomCleaning />
    case 'inspection': return <RoomInspection />
    case 'linen': return <LinenManagement />
    case 'lost-found': return <LostFound />
    case 'schedule': return <CleaningSchedule />
    default: return <EmptyState title="Unknown Sub-module" description={`Sub-module "${subModule}" not found`} />
  }
}
