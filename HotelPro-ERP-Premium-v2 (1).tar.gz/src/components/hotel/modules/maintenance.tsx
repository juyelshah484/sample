'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ COMPLAINTS ============
function Complaints() {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [viewItem, setViewItem] = useState<any>(null)
  const [formData, setFormData] = useState({
    title: '', description: '', type: 'electrical', priority: 'normal', location: '', roomNumber: '', reportedBy: '', status: 'open',
  })

  const seedData = [
    { id: '1', title: 'AC not cooling', description: 'Room 205 AC is blowing warm air. Guest complained at 10 AM.', type: 'hvac', priority: 'urgent', location: 'Room 205', roomNumber: '205', reportedBy: 'Front Desk', status: 'assigned', createdAt: '2024-11-15T10:00:00' },
    { id: '2', title: 'Leaking faucet', description: 'Bathroom faucet dripping constantly, water waste concern.', type: 'plumbing', priority: 'normal', location: 'Room 310', roomNumber: '310', reportedBy: 'Housekeeping', status: 'open', createdAt: '2024-11-15T08:30:00' },
    { id: '3', title: 'Power outlet not working', description: 'Desk power outlet dead, guest cannot charge devices.', type: 'electrical', priority: 'high', location: 'Room 102', roomNumber: '102', reportedBy: 'Guest', status: 'in_progress', createdAt: '2024-11-14T14:00:00' },
    { id: '4', title: 'Elevator door sensor issue', description: 'Main elevator door not detecting obstruction properly.', type: 'electrical', priority: 'urgent', location: 'Building A', roomNumber: '', reportedBy: 'Security', status: 'resolved', createdAt: '2024-11-14T09:00:00' },
    { id: '5', title: 'Broken window lock', description: 'Window lock broken on 3rd floor, security concern.', type: 'equipment', priority: 'high', location: 'Room 301', roomNumber: '301', reportedBy: 'Housekeeping', status: 'open', createdAt: '2024-11-13T16:00:00' },
    { id: '6', title: 'Hot water not available', description: 'No hot water in shower, lasted 2 hours. Guest very unhappy.', type: 'plumbing', priority: 'urgent', location: 'Room 415', roomNumber: '415', reportedBy: 'Guest', status: 'assigned', createdAt: '2024-11-15T07:00:00' },
    { id: '7', title: 'TV remote not working', description: 'Batteries died, guest requesting replacement.', type: 'equipment', priority: 'low', location: 'Room 208', roomNumber: '208', reportedBy: 'Guest', status: 'resolved', createdAt: '2024-11-14T20:00:00' },
  ]

  useEffect(() => {
    setTimeout(() => { setItems(seedData); setLoading(false) }, 400)
  }, [])

  const pageSize = 10
  const filtered = items.filter(i => !search || Object.values(i).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const openCount = items.filter(i => i.status === 'open').length
  const inProgressCount = items.filter(i => i.status === 'in_progress' || i.status === 'assigned').length
  const urgentCount = items.filter(i => i.priority === 'urgent').length

  const openCreate = () => { setEditItem(null); setFormData({ title: '', description: '', type: 'electrical', priority: 'normal', location: '', roomNumber: '', reportedBy: '', status: 'open' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setItems(prev => prev.map(i => i.id === editItem.id ? { ...i, ...formData } : i))
      toast.success('Complaint updated')
    } else {
      setItems(prev => [...prev, { ...formData, id: Date.now().toString(), createdAt: new Date().toISOString() }])
      toast.success('Complaint created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setItems(prev => prev.filter(i => i.id !== deleteId)); toast.success('Complaint deleted'); setDeleteId(null) }
  }

  const types: Record<string, string> = { electrical: 'Electrical', plumbing: 'Plumbing', hvac: 'HVAC', equipment: 'Equipment', other: 'Other' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Open Complaints" value={openCount} subtitle="Awaiting action" color="red" />
        <KPICard title="In Progress" value={inProgressCount} subtitle="Being worked on" color="amber" />
        <KPICard title="Urgent" value={urgentCount} subtitle="Immediate attention" color="red" />
        <KPICard title="Total Complaints" value={items.length} subtitle="All time" color="blue" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Complaints</h2><p className="text-muted-foreground">Track and manage maintenance complaints</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => { setLoading(true); setTimeout(() => setLoading(false), 400) }}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Complaint</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Title</TableHead><TableHead>Type</TableHead><TableHead>Priority</TableHead><TableHead>Location</TableHead><TableHead>Reported By</TableHead><TableHead>Status</TableHead><TableHead>Created</TableHead><TableHead className="w-10" /></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No complaints found</TableCell></TableRow>
                  ) : paginated.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.title}</TableCell>
                      <TableCell><Badge variant="outline">{types[item.type] || item.type}</Badge></TableCell>
                      <TableCell><Badge className={statusColors[item.priority] || ''}>{item.priority}</Badge></TableCell>
                      <TableCell>{item.location}</TableCell>
                      <TableCell>{item.reportedBy}</TableCell>
                      <TableCell><Badge className={statusColors[item.status] || ''}>{item.status.replace('_', ' ')}</Badge></TableCell>
                      <TableCell>{formatDateTime(item.createdAt)}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setViewItem(item)}><Eye className="h-4 w-4 mr-2" />View</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Complaint</DialogTitle><DialogDescription>Fill in complaint details.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Title</Label><Input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} /></div>
            <div><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={3} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(types).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Priority</Label>
                <Select value={formData.priority} onValueChange={v => setFormData({ ...formData, priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Location</Label><Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} /></div>
              <div><Label>Room Number</Label><Input value={formData.roomNumber} onChange={e => setFormData({ ...formData, roomNumber: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Reported By</Label><Input value={formData.reportedBy} onChange={e => setFormData({ ...formData, reportedBy: e.target.value })} /></div>
              {editItem && <div><Label>Status</Label>
                <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem><SelectItem value="assigned">Assigned</SelectItem><SelectItem value="in_progress">In Progress</SelectItem><SelectItem value="resolved">Resolved</SelectItem><SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewItem} onOpenChange={() => setViewItem(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Complaint Details</DialogTitle></DialogHeader>
          {viewItem && (
            <div className="space-y-3">
              <div><span className="text-sm text-muted-foreground">Title:</span><p className="font-medium">{viewItem.title}</p></div>
              <div><span className="text-sm text-muted-foreground">Description:</span><p>{viewItem.description}</p></div>
              <div className="grid grid-cols-2 gap-4">
                <div><span className="text-sm text-muted-foreground">Type:</span><p>{types[viewItem.type]}</p></div>
                <div><span className="text-sm text-muted-foreground">Priority:</span><Badge className={statusColors[viewItem.priority] || ''}>{viewItem.priority}</Badge></div>
                <div><span className="text-sm text-muted-foreground">Location:</span><p>{viewItem.location}</p></div>
                <div><span className="text-sm text-muted-foreground">Status:</span><Badge className={statusColors[viewItem.status] || ''}>{viewItem.status.replace('_', ' ')}</Badge></div>
                <div><span className="text-sm text-muted-foreground">Reported By:</span><p>{viewItem.reportedBy}</p></div>
                <div><span className="text-sm text-muted-foreground">Created:</span><p>{formatDateTime(viewItem.createdAt)}</p></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this complaint?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ WORK ORDERS ============
function WorkOrders() {
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    complaintRef: '', title: '', description: '', type: 'electrical', priority: 'normal',
    assignedTo: '', scheduledDate: '', estimatedHours: 2, status: 'pending', notes: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setOrders([
        { id: '1', complaintRef: 'CMP-001', title: 'Fix AC cooling - Room 205', description: 'AC unit blowing warm air', type: 'hvac', priority: 'urgent', assignedTo: 'Alam Hossain', scheduledDate: '2024-11-15', estimatedHours: 2, status: 'in_progress', notes: 'Parts ordered', createdAt: '2024-11-15T10:30:00' },
        { id: '2', complaintRef: 'CMP-003', title: 'Replace power outlet - Room 102', description: 'Dead power outlet at desk', type: 'electrical', priority: 'high', assignedTo: 'Rafiq Islam', scheduledDate: '2024-11-16', estimatedHours: 1, status: 'pending', notes: '', createdAt: '2024-11-14T15:00:00' },
        { id: '3', complaintRef: 'CMP-006', title: 'Fix hot water supply - Room 415', description: 'No hot water in shower', type: 'plumbing', priority: 'urgent', assignedTo: 'Jalal Miah', scheduledDate: '2024-11-15', estimatedHours: 3, status: 'assigned', notes: 'Boiler inspection needed', createdAt: '2024-11-15T07:30:00' },
        { id: '4', complaintRef: 'CMP-004', title: 'Fix elevator door sensor', description: 'Sensor not detecting obstruction', type: 'electrical', priority: 'urgent', assignedTo: 'Rafiq Islam', scheduledDate: '2024-11-14', estimatedHours: 4, status: 'completed', notes: 'Sensor replaced and tested', createdAt: '2024-11-14T09:30:00' },
        { id: '5', complaintRef: 'CMP-005', title: 'Replace window lock - Room 301', description: 'Broken window lock', type: 'equipment', priority: 'high', assignedTo: 'Alam Hossain', scheduledDate: '2024-11-16', estimatedHours: 1, status: 'pending', notes: 'Lock ordered from supplier', createdAt: '2024-11-13T17:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ complaintRef: '', title: '', description: '', type: 'electrical', priority: 'normal', assignedTo: '', scheduledDate: '', estimatedHours: 2, status: 'pending', notes: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setOrders(prev => prev.map(i => i.id === editItem.id ? { ...i, ...formData } : i))
      toast.success('Work order updated')
    } else {
      setOrders(prev => [...prev, { ...formData, id: Date.now().toString(), createdAt: new Date().toISOString() }])
      toast.success('Work order created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const types: Record<string, string> = { electrical: 'Electrical', plumbing: 'Plumbing', hvac: 'HVAC', equipment: 'Equipment' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Pending" value={orders.filter(o => o.status === 'pending').length} subtitle="Not started" color="amber" />
        <KPICard title="In Progress" value={orders.filter(o => o.status === 'in_progress' || o.status === 'assigned').length} subtitle="Being worked on" color="blue" />
        <KPICard title="Completed" value={orders.filter(o => o.status === 'completed').length} subtitle="Finished" color="emerald" />
        <KPICard title="Total Work Orders" value={orders.length} subtitle="All time" color="violet" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Work Orders</h2><p className="text-muted-foreground">Manage maintenance work orders</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Work Order</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Ref</TableHead><TableHead>Title</TableHead><TableHead>Type</TableHead><TableHead>Priority</TableHead><TableHead>Assigned To</TableHead><TableHead>Scheduled</TableHead><TableHead>Est. Hours</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
              </TableHeader>
              <TableBody>
                {orders.map(o => (
                  <TableRow key={o.id}>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{o.complaintRef}</code></TableCell>
                    <TableCell className="font-medium">{o.title}</TableCell>
                    <TableCell><Badge variant="outline">{types[o.type]}</Badge></TableCell>
                    <TableCell><Badge className={statusColors[o.priority] || ''}>{o.priority}</Badge></TableCell>
                    <TableCell>{o.assignedTo || '-'}</TableCell>
                    <TableCell>{formatDate(o.scheduledDate)}</TableCell>
                    <TableCell>{o.estimatedHours}h</TableCell>
                    <TableCell><Badge className={statusColors[o.status] || ''}>{o.status.replace('_', ' ')}</Badge></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(o)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Work Order</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Complaint Reference</Label><Input value={formData.complaintRef} onChange={e => setFormData({ ...formData, complaintRef: e.target.value })} placeholder="CMP-001" /></div>
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(types).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Title</Label><Input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} /></div>
            <div><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={3} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Priority</Label>
                <Select value={formData.priority} onValueChange={v => setFormData({ ...formData, priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem><SelectItem value="normal">Normal</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Assigned To</Label><Input value={formData.assignedTo} onChange={e => setFormData({ ...formData, assignedTo: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Scheduled Date</Label><Input type="date" value={formData.scheduledDate} onChange={e => setFormData({ ...formData, scheduledDate: e.target.value })} /></div>
              <div><Label>Estimated Hours</Label><Input type="number" value={formData.estimatedHours} onChange={e => setFormData({ ...formData, estimatedHours: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem><SelectItem value="assigned">Assigned</SelectItem><SelectItem value="in_progress">In Progress</SelectItem><SelectItem value="completed">Completed</SelectItem><SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ PREVENTIVE MAINTENANCE ============
function Preventive() {
  const [schedules, setSchedules] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    task: '', type: 'electrical', frequency: 'monthly', location: '', assignedTo: '',
    nextDue: '', duration: 1, status: 'active', description: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setSchedules([
        { id: '1', task: 'HVAC Filter Cleaning', type: 'hvac', frequency: 'monthly', location: 'All Rooms', assignedTo: 'Alam Hossain', nextDue: '2024-12-01', duration: 4, status: 'active', description: 'Clean or replace AC filters across all rooms', lastDone: '2024-11-01' },
        { id: '2', task: 'Fire Extinguisher Check', type: 'equipment', frequency: 'quarterly', location: 'All Floors', assignedTo: 'Security Team', nextDue: '2025-01-15', duration: 2, status: 'active', description: 'Inspect pressure and expiry dates', lastDone: '2024-10-15' },
        { id: '3', task: 'Elevator Inspection', type: 'electrical', frequency: 'quarterly', location: 'Building A', assignedTo: 'Rafiq Islam', nextDue: '2025-02-01', duration: 3, status: 'active', description: 'Full safety inspection per regulations', lastDone: '2024-11-01' },
        { id: '4', task: 'Plumbing Pressure Test', type: 'plumbing', frequency: 'biannual', location: 'All Bathrooms', assignedTo: 'Jalal Miah', nextDue: '2025-05-01', duration: 6, status: 'active', description: 'Test water pressure and check for leaks', lastDone: '2024-11-01' },
        { id: '5', task: 'Generator Load Test', type: 'electrical', frequency: 'monthly', location: 'Basement', assignedTo: 'Rafiq Islam', nextDue: '2024-12-15', duration: 2, status: 'active', description: 'Run generator under load for 30 minutes', lastDone: '2024-11-15' },
        { id: '6', task: 'Pool Chemical Balance', type: 'equipment', frequency: 'weekly', location: 'Pool Area', assignedTo: 'Maintenance Team', nextDue: '2024-11-22', duration: 1, status: 'active', description: 'Test and adjust chemical levels', lastDone: '2024-11-15' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ task: '', type: 'electrical', frequency: 'monthly', location: '', assignedTo: '', nextDue: '', duration: 1, status: 'active', description: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setSchedules(prev => prev.map(i => i.id === editItem.id ? { ...i, ...formData } : i))
      toast.success('Schedule updated')
    } else {
      setSchedules(prev => [...prev, { ...formData, id: Date.now().toString(), lastDone: '-' }])
      toast.success('Schedule created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const types: Record<string, string> = { electrical: 'Electrical', plumbing: 'Plumbing', hvac: 'HVAC', equipment: 'Equipment' }
  const freqs: Record<string, string> = { weekly: 'Weekly', monthly: 'Monthly', quarterly: 'Quarterly', biannual: 'Biannual', annual: 'Annual' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Schedules" value={schedules.filter(s => s.status === 'active').length} subtitle="Recurring tasks" color="emerald" />
        <KPICard title="Due This Month" value={3} subtitle="Upcoming tasks" color="amber" />
        <KPICard title="Total Tasks" value={schedules.length} subtitle="All schedules" color="blue" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Preventive Maintenance</h2><p className="text-muted-foreground">Schedule and track recurring maintenance tasks</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Schedule</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {schedules.map(s => (
            <Card key={s.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{s.task}</CardTitle>
                    <CardDescription>{types[s.type]} | {freqs[s.frequency]}</CardDescription>
                  </div>
                  <Badge className={statusColors[s.status] || ''}>{s.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Location:</span><span>{s.location}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Assigned To:</span><span>{s.assignedTo}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Next Due:</span><span className="font-medium">{formatDate(s.nextDue)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Last Done:</span><span>{s.lastDone ? formatDate(s.lastDone) : '-'}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Duration:</span><span>{s.duration} hour(s)</span></div>
                  {s.description && <p className="text-muted-foreground pt-1">{s.description}</p>}
                </div>
                <Separator className="my-3" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openEdit(s)}><Edit className="h-3 w-3 mr-1" />Edit</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Maintenance Schedule</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Task Name</Label><Input value={formData.task} onChange={e => setFormData({ ...formData, task: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(types).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Frequency</Label>
                <Select value={formData.frequency} onValueChange={v => setFormData({ ...formData, frequency: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(freqs).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Location</Label><Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} /></div>
              <div><Label>Assigned To</Label><Input value={formData.assignedTo} onChange={e => setFormData({ ...formData, assignedTo: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Next Due Date</Label><Input type="date" value={formData.nextDue} onChange={e => setFormData({ ...formData, nextDue: e.target.value })} /></div>
              <div><Label>Duration (hours)</Label><Input type="number" value={formData.duration} onChange={e => setFormData({ ...formData, duration: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} /></div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAINTENANCE CALENDAR ============
function MaintenanceCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [tasks] = useState([
    { id: '1', date: '2024-11-15', title: 'Fix AC - Room 205', type: 'hvac', priority: 'urgent', status: 'in_progress' },
    { id: '2', date: '2024-11-15', title: 'Fix hot water - Room 415', type: 'plumbing', priority: 'urgent', status: 'assigned' },
    { id: '3', date: '2024-11-16', title: 'Replace outlet - Room 102', type: 'electrical', priority: 'high', status: 'pending' },
    { id: '4', date: '2024-11-16', title: 'Window lock - Room 301', type: 'equipment', priority: 'high', status: 'pending' },
    { id: '5', date: '2024-12-01', title: 'HVAC Filter Cleaning', type: 'hvac', priority: 'normal', status: 'scheduled' },
    { id: '6', date: '2024-12-15', title: 'Generator Load Test', type: 'electrical', priority: 'normal', status: 'scheduled' },
    { id: '7', date: '2024-11-22', title: 'Pool Chemical Balance', type: 'equipment', priority: 'normal', status: 'scheduled' },
    { id: '8', date: '2024-11-20', title: 'Pool Chemical Balance', type: 'equipment', priority: 'normal', status: 'scheduled' },
    { id: '9', date: '2025-01-15', title: 'Fire Extinguisher Check', type: 'equipment', priority: 'normal', status: 'scheduled' },
    { id: '10', date: '2025-02-01', title: 'Elevator Inspection', type: 'electrical', priority: 'high', status: 'scheduled' },
  ])

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const firstDayOfWeek = new Date(year, month, 1).getDay()
  const monthName = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1))

  const getTasksForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return tasks.filter(t => t.date === dateStr)
  }

  const typeColors: Record<string, string> = { electrical: 'bg-amber-200 text-amber-800', plumbing: 'bg-blue-200 text-blue-800', hvac: 'bg-emerald-200 text-emerald-800', equipment: 'bg-violet-200 text-violet-800' }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Maintenance Calendar</h2><p className="text-muted-foreground">Visual schedule of maintenance tasks</p></div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" onClick={prevMonth}>← Previous</Button>
            <CardTitle>{monthName}</CardTitle>
            <Button variant="outline" size="sm" onClick={nextMonth}>Next →</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} className="bg-muted p-2 text-center text-sm font-medium">{d}</div>
            ))}
            {Array.from({ length: firstDayOfWeek }, (_, i) => (
              <div key={`empty-${i}`} className="bg-background p-2 min-h-[80px]" />
            ))}
            {Array.from({ length: daysInMonth }, (_, i) => {
              const day = i + 1
              const dayTasks = getTasksForDay(day)
              const isToday = new Date().getDate() === day && new Date().getMonth() === month && new Date().getFullYear() === year
              return (
                <div key={day} className={`bg-background p-1.5 min-h-[80px] ${isToday ? 'ring-2 ring-primary ring-inset' : ''}`}>
                  <span className={`text-xs font-medium ${isToday ? 'bg-primary text-primary-foreground rounded-full px-1.5 py-0.5' : ''}`}>{day}</span>
                  <div className="mt-1 space-y-0.5">
                    {dayTasks.slice(0, 2).map(t => (
                      <div key={t.id} className={`text-[10px] px-1 py-0.5 rounded truncate ${typeColors[t.type] || 'bg-gray-200'}`}>
                        {t.title}
                      </div>
                    ))}
                    {dayTasks.length > 2 && <div className="text-[10px] text-muted-foreground">+{dayTasks.length - 2} more</div>}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Legend</CardTitle></CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {Object.entries(typeColors).map(([type, cls]) => (
              <div key={type} className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded ${cls.split(' ')[0]}`} />
                <span className="text-sm capitalize">{type}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function MaintenanceModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'complaints': return <Complaints />
    case 'work-orders': return <WorkOrders />
    case 'preventive': return <Preventive />
    case 'calendar': return <MaintenanceCalendar />
    default: return <EmptyState title="Unknown Sub-Module" description={`Maintenance sub-module "${subModule}" not found.`} />
  }
}
