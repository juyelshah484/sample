'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend } from 'recharts'

// ============ OCCUPANCY REPORT ============
function OccupancyReport() {
  const [loading, setLoading] = useState(true)
  const [dateFrom, setDateFrom] = useState('2024-11-01')
  const [dateTo, setDateTo] = useState('2024-11-15')

  const [occupancyTrend] = useState([
    { date: 'Nov 1', occupied: 85, available: 15 },
    { date: 'Nov 2', occupied: 88, available: 12 },
    { date: 'Nov 3', occupied: 72, available: 28 },
    { date: 'Nov 4', occupied: 65, available: 35 },
    { date: 'Nov 5', occupied: 78, available: 22 },
    { date: 'Nov 6', occupied: 82, available: 18 },
    { date: 'Nov 7', occupied: 90, available: 10 },
    { date: 'Nov 8', occupied: 92, available: 8 },
    { date: 'Nov 9', occupied: 88, available: 12 },
    { date: 'Nov 10', occupied: 70, available: 30 },
    { date: 'Nov 11', occupied: 68, available: 32 },
    { date: 'Nov 12', occupied: 75, available: 25 },
    { date: 'Nov 13', occupied: 80, available: 20 },
    { date: 'Nov 14', occupied: 86, available: 14 },
    { date: 'Nov 15', occupied: 91, available: 9 },
  ])

  const [roomTypeBreakdown] = useState([
    { name: 'Standard Single', occupied: 28, total: 40, rate: 70 },
    { name: 'Standard Double', occupied: 35, total: 45, rate: 77.8 },
    { name: 'Deluxe Room', occupied: 22, total: 30, rate: 73.3 },
    { name: 'Suite', occupied: 8, total: 10, rate: 80 },
    { name: 'Presidential', occupied: 1, total: 2, rate: 50 },
  ])

  const [floorWise] = useState([
    { floor: '1st Floor', occupied: 18, total: 25, rate: 72 },
    { floor: '2nd Floor', occupied: 20, total: 25, rate: 80 },
    { floor: '3rd Floor', occupied: 22, total: 27, rate: 81.5 },
    { floor: '4th Floor', occupied: 19, total: 25, rate: 76 },
    { floor: '5th Floor', occupied: 15, total: 25, rate: 60 },
  ])

  const pieData = roomTypeBreakdown.map(r => ({ name: r.name, value: r.occupied }))

  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const avgOccupancy = Math.round(occupancyTrend.reduce((s, d) => s + d.occupied, 0) / occupancyTrend.length)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Occupancy Report</h2><p className="text-muted-foreground">Room occupancy analysis and trends</p></div>
        <div className="flex gap-2 items-center">
          <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-36" />
          <span className="text-muted-foreground">to</span>
          <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-36" />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Avg. Occupancy" value={`${avgOccupancy}%`} subtitle="Period average" color="emerald" />
        <KPICard title="Peak Occupancy" value="92%" subtitle="Nov 8" color="blue" />
        <KPICard title="Lowest Occupancy" value="65%" subtitle="Nov 4" color="amber" />
        <KPICard title="Total Room Nights" value="1,275" subtitle="Period total" color="violet" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Occupancy Trend</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={occupancyTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" fontSize={12} />
              <YAxis fontSize={12} />
              <RechartsTooltip />
              <Legend />
              <Area type="monotone" dataKey="occupied" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.6} name="Occupied %" />
              <Area type="monotone" dataKey="available" stackId="1" stroke="#94a3b8" fill="#e2e8f0" fillOpacity={0.6} name="Available %" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Room Type Breakdown</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <RechartsTooltip />
              </PieChart>
            </ResponsiveContainer>
            <Table>
              <TableHeader><TableRow><TableHead>Type</TableHead><TableHead>Occupied</TableHead><TableHead>Total</TableHead><TableHead>Rate</TableHead></TableRow></TableHeader>
              <TableBody>
                {roomTypeBreakdown.map(r => (
                  <TableRow key={r.name}><TableCell className="font-medium">{r.name}</TableCell><TableCell>{r.occupied}</TableCell><TableCell>{r.total}</TableCell><TableCell>{r.rate}%</TableCell></TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Floor-wise Analysis</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={floorWise}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="floor" fontSize={12} />
                <YAxis fontSize={12} />
                <RechartsTooltip />
                <Legend />
                <Bar dataKey="occupied" fill="#10b981" name="Occupied" />
                <Bar dataKey="total" fill="#e2e8f0" name="Total" />
              </BarChart>
            </ResponsiveContainer>
            <Table>
              <TableHeader><TableRow><TableHead>Floor</TableHead><TableHead>Occupied</TableHead><TableHead>Total</TableHead><TableHead>Rate</TableHead></TableRow></TableHeader>
              <TableBody>
                {floorWise.map(f => (
                  <TableRow key={f.floor}><TableCell className="font-medium">{f.floor}</TableCell><TableCell>{f.occupied}</TableCell><TableCell>{f.total}</TableCell><TableCell>{f.rate}%</TableCell></TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============ REVENUE REPORT ============
function RevenueReport() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const revenueByCategory = [
    { category: 'Room Revenue', amount: 4500000, color: '#10b981' },
    { category: 'F&B Revenue', amount: 1200000, color: '#3b82f6' },
    { category: 'Banquet', amount: 800000, color: '#f59e0b' },
    { category: 'Spa & Wellness', amount: 350000, color: '#8b5cf6' },
    { category: 'Laundry', amount: 120000, color: '#ec4899' },
    { category: 'Other', amount: 230000, color: '#94a3b8' },
  ]

  const monthlyComparison = [
    { month: 'Jun', thisYear: 5200000, lastYear: 4500000 },
    { month: 'Jul', thisYear: 5800000, lastYear: 4800000 },
    { month: 'Aug', thisYear: 6100000, lastYear: 5200000 },
    { month: 'Sep', thisYear: 5500000, lastYear: 4900000 },
    { month: 'Oct', thisYear: 5900000, lastYear: 5100000 },
    { month: 'Nov', thisYear: 7200000, lastYear: 5600000 },
  ]

  const adrRevpar = [
    { month: 'Jun', adr: 4500, revpar: 3150 },
    { month: 'Jul', adr: 4700, revpar: 3470 },
    { month: 'Aug', adr: 4900, revpar: 3720 },
    { month: 'Sep', adr: 4600, revpar: 3320 },
    { month: 'Oct', adr: 4800, revpar: 3580 },
    { month: 'Nov', adr: 5200, revpar: 4160 },
  ]

  const totalRevenue = revenueByCategory.reduce((s, r) => s + r.amount, 0)
  const totalLastYear = monthlyComparison.reduce((s, m) => s + m.lastYear, 0)
  const totalThisYear = monthlyComparison.reduce((s, m) => s + m.thisYear, 0)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Revenue Report</h2><p className="text-muted-foreground">Revenue analysis, monthly comparison, and KPI trends</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Revenue" value={formatCurrency(totalThisYear)} subtitle="Last 6 months" color="emerald" trend={`${((totalThisYear / totalLastYear - 1) * 100).toFixed(1)}% YoY`} trendUp={true} />
        <KPICard title="Room Revenue" value={formatCurrency(4500000)} subtitle="Primary source" color="blue" />
        <KPICard title="Current ADR" value={formatCurrency(5200)} subtitle="Average Daily Rate" color="amber" />
        <KPICard title="Current RevPAR" value={formatCurrency(4160)} subtitle="Revenue Per Available Room" color="violet" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Revenue by Category</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={revenueByCategory} cx="50%" cy="50%" innerRadius={70} outerRadius={110} dataKey="amount" label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}>
                  {revenueByCategory.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Monthly Comparison (This Year vs Last Year)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyComparison}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" fontSize={12} />
                <YAxis fontSize={12} />
                <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend />
                <Bar dataKey="thisYear" fill="#10b981" name="This Year" />
                <Bar dataKey="lastYear" fill="#94a3b8" name="Last Year" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">ADR & RevPAR Trends</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={adrRevpar}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" fontSize={12} />
              <YAxis fontSize={12} />
              <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
              <Legend />
              <Area type="monotone" dataKey="adr" stroke="#10b981" fill="#10b981" fillOpacity={0.2} name="ADR" />
              <Area type="monotone" dataKey="revpar" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} name="RevPAR" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ DAILY SALES ============
function DailySales() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const salesByCategory = [
    { category: 'Room Charges', amount: 285000 },
    { category: 'Restaurant', amount: 45000 },
    { category: 'Room Service', amount: 18000 },
    { category: 'Bar & Lounge', amount: 32000 },
    { category: 'Spa', amount: 15000 },
    { category: 'Laundry', amount: 8000 },
    { category: 'Banquet', amount: 65000 },
    { category: 'Other', amount: 12000 },
  ]

  const paymentMethodSummary = [
    { method: 'Cash', amount: 95000, count: 45 },
    { method: 'Card', amount: 180000, count: 32 },
    { method: 'bKash', amount: 85000, count: 28 },
    { method: 'Nagad', amount: 42000, count: 15 },
    { method: 'SSLCommerz', amount: 58000, count: 12 },
    { method: 'Bank Transfer', amount: 100000, count: 3 },
  ]

  const totalSales = salesByCategory.reduce((s, c) => s + c.amount, 0)
  const totalPayments = paymentMethodSummary.reduce((s, p) => s + p.amount, 0)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Daily Sales Report</h2><p className="text-muted-foreground">Today&apos;s sales breakdown by category and payment method</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Sales" value={formatCurrency(totalSales)} subtitle="Today" color="emerald" />
        <KPICard title="Transactions" value={paymentMethodSummary.reduce((s, p) => s + p.count, 0)} subtitle="Today" color="blue" />
        <KPICard title="Avg. Transaction" value={formatCurrency(Math.round(totalPayments / paymentMethodSummary.reduce((s, p) => s + p.count, 0)))} subtitle="Per transaction" color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Sales by Category</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salesByCategory} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" fontSize={12} />
                <YAxis type="category" dataKey="category" fontSize={11} width={100} />
                <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
                <Bar dataKey="amount" fill="#10b981">
                  {salesByCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Payment Method Summary</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={paymentMethodSummary} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="amount" label={({ method, percent }) => `${method} ${(percent * 100).toFixed(0)}%`}>
                  {paymentMethodSummary.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Detailed Breakdown</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Category</TableHead><TableHead>Amount</TableHead><TableHead>% of Total</TableHead></TableRow></TableHeader>
            <TableBody>
              {salesByCategory.map(c => (
                <TableRow key={c.category}>
                  <TableCell className="font-medium">{c.category}</TableCell>
                  <TableCell>{formatCurrency(c.amount)}</TableCell>
                  <TableCell>{((c.amount / totalSales) * 100).toFixed(1)}%</TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold"><TableCell>Total</TableCell><TableCell>{formatCurrency(totalSales)}</TableCell><TableCell>100%</TableCell></TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ GUEST REPORT ============
function GuestReport() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const nationalityBreakdown = [
    { nationality: 'Bangladeshi', count: 320, percentage: 64 },
    { nationality: 'Indian', count: 65, percentage: 13 },
    { nationality: 'Chinese', count: 35, percentage: 7 },
    { nationality: 'American', count: 25, percentage: 5 },
    { nationality: 'British', count: 18, percentage: 3.6 },
    { nationality: 'Japanese', count: 12, percentage: 2.4 },
    { nationality: 'Other', count: 25, percentage: 5 },
  ]

  const guestTypeData = [
    { type: 'Business', count: 180 },
    { type: 'Leisure', count: 150 },
    { type: 'Corporate', count: 85 },
    { type: 'Group', count: 55 },
    { type: 'VIP', count: 30 },
  ]

  const demographics = [
    { age: '18-25', male: 35, female: 28 },
    { age: '26-35', male: 85, female: 65 },
    { age: '36-45', male: 72, female: 58 },
    { age: '46-55', male: 45, female: 38 },
    { age: '56+', male: 30, female: 22 },
  ]

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Guest Report</h2><p className="text-muted-foreground">Guest demographics, nationality, and behavior analysis</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Guests" value="500" subtitle="This period" color="blue" />
        <KPICard title="Repeat Guests" value="185" subtitle="37% return rate" color="emerald" />
        <KPICard title="New Guests" value="315" subtitle="63% first time" color="amber" />
        <KPICard title="VIP Count" value="30" subtitle="High-value guests" color="violet" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Nationality Breakdown</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={nationalityBreakdown} cx="50%" cy="50%" innerRadius={60} outerRadius={110} dataKey="count" label={({ nationality, percentage }) => `${nationality} ${percentage}%`}>
                  {nationalityBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <RechartsTooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Guest Type Distribution</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={guestTypeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="type" fontSize={12} />
                <YAxis fontSize={12} />
                <RechartsTooltip />
                <Bar dataKey="count" fill="#3b82f6">
                  {guestTypeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Age Demographics (by Gender)</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={demographics}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="age" fontSize={12} />
              <YAxis fontSize={12} />
              <RechartsTooltip />
              <Legend />
              <Bar dataKey="male" fill="#3b82f6" name="Male" />
              <Bar dataKey="female" fill="#ec4899" name="Female" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Nationality Details</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Nationality</TableHead><TableHead>Count</TableHead><TableHead>Percentage</TableHead></TableRow></TableHeader>
            <TableBody>
              {nationalityBreakdown.map(n => (
                <TableRow key={n.nationality}><TableCell className="font-medium">{n.nationality}</TableCell><TableCell>{n.count}</TableCell><TableCell>{n.percentage}%</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ FINANCIAL STATEMENTS ============
function FinancialStatements() {
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState('month')
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Financial Statements</h2><p className="text-muted-foreground">Profit & Loss and Balance Sheet</p></div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="month">This Month</SelectItem><SelectItem value="quarter">This Quarter</SelectItem><SelectItem value="year">This Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Profit & Loss Statement</CardTitle><CardDescription>Period: November 2024</CardDescription></CardHeader>
        <CardContent>
          <div className="space-y-1">
            <div className="font-bold text-lg mb-2">Revenue</div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Room Revenue</span><span className="text-right font-medium">BDT 4,500,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>F&B Revenue</span><span className="text-right font-medium">BDT 1,200,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Banquet Revenue</span><span className="text-right font-medium">BDT 800,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Spa & Wellness</span><span className="text-right font-medium">BDT 350,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Other Revenue</span><span className="text-right font-medium">BDT 350,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-2 border-b-2 font-bold bg-emerald-50 px-2 rounded"><span>Total Revenue</span><span className="text-right">BDT 7,200,000</span></div>

            <div className="font-bold text-lg mt-4 mb-2">Expenses</div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Staff Salaries</span><span className="text-right font-medium">BDT 2,100,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Utilities</span><span className="text-right font-medium">BDT 450,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>F&B Cost</span><span className="text-right font-medium">BDT 480,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Maintenance</span><span className="text-right font-medium">BDT 180,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Marketing</span><span className="text-right font-medium">BDT 120,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>OTA Commissions</span><span className="text-right font-medium">BDT 520,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Depreciation</span><span className="text-right font-medium">BDT 250,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Other Expenses</span><span className="text-right font-medium">BDT 300,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-2 border-b-2 font-bold bg-red-50 px-2 rounded"><span>Total Expenses</span><span className="text-right">BDT 4,400,000</span></div>

            <div className="grid grid-cols-2 gap-x-4 py-3 font-bold text-lg bg-emerald-100 px-2 rounded mt-2"><span>Net Profit</span><span className="text-right text-emerald-700">BDT 2,800,000</span></div>
            <div className="grid grid-cols-2 gap-x-4 py-1 text-sm text-muted-foreground"><span>Profit Margin</span><span className="text-right">38.9%</span></div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Balance Sheet (As of November 15, 2024)</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="font-bold text-lg mb-2">Assets</div>
              <div className="space-y-1">
                <div className="font-semibold mt-2 mb-1">Current Assets</div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Cash & Bank</span><span className="text-right font-medium">BDT 5,200,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Accounts Receivable</span><span className="text-right font-medium">BDT 1,800,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Inventory</span><span className="text-right font-medium">BDT 950,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Prepaid Expenses</span><span className="text-right font-medium">BDT 300,000</span></div>
                <div className="font-semibold mt-3 mb-1">Non-Current Assets</div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Property & Equipment</span><span className="text-right font-medium">BDT 45,000,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Less: Depreciation</span><span className="text-right font-medium">(BDT 8,500,000)</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-2 font-bold bg-blue-50 px-2 rounded"><span>Total Assets</span><span className="text-right">BDT 44,750,000</span></div>
              </div>
            </div>
            <div>
              <div className="font-bold text-lg mb-2">Liabilities & Equity</div>
              <div className="space-y-1">
                <div className="font-semibold mt-2 mb-1">Current Liabilities</div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Accounts Payable</span><span className="text-right font-medium">BDT 1,200,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Accrued Expenses</span><span className="text-right font-medium">BDT 850,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Guest Deposits</span><span className="text-right font-medium">BDT 450,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>VAT Payable</span><span className="text-right font-medium">BDT 750,000</span></div>
                <div className="font-semibold mt-3 mb-1">Non-Current Liabilities</div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Bank Loan</span><span className="text-right font-medium">BDT 12,000,000</span></div>
                <div className="font-semibold mt-3 mb-1">Equity</div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Owner&apos;s Equity</span><span className="text-right font-medium">BDT 28,500,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-1 border-b"><span>Retained Earnings</span><span className="text-right font-medium">BDT 1,000,000</span></div>
                <div className="grid grid-cols-2 gap-x-4 py-2 font-bold bg-blue-50 px-2 rounded"><span>Total Liabilities & Equity</span><span className="text-right">BDT 44,750,000</span></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ VAT REPORT ============
function VatReport() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const vatData = [
    { month: 'Jun', outputVat: 780000, inputVat: 120000, netVat: 660000 },
    { month: 'Jul', outputVat: 870000, inputVat: 135000, netVat: 735000 },
    { month: 'Aug', outputVat: 915000, inputVat: 142000, netVat: 773000 },
    { month: 'Sep', outputVat: 825000, inputVat: 128000, netVat: 697000 },
    { month: 'Oct', outputVat: 885000, inputVat: 138000, netVat: 747000 },
    { month: 'Nov', outputVat: 1080000, inputVat: 155000, netVat: 925000 },
  ]

  const totalOutput = vatData.reduce((s, d) => s + d.outputVat, 0)
  const totalInput = vatData.reduce((s, d) => s + d.inputVat, 0)
  const totalNet = vatData.reduce((s, d) => s + d.netVat, 0)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">VAT Report</h2><p className="text-muted-foreground">Tax calculation, VAT liability, and input/output VAT</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Output VAT (Collected)" value={formatCurrency(totalOutput)} subtitle="From sales" color="blue" />
        <KPICard title="Input VAT (Paid)" value={formatCurrency(totalInput)} subtitle="On purchases" color="amber" />
        <KPICard title="Net VAT Liability" value={formatCurrency(totalNet)} subtitle="Payable to NBR" color="red" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">VAT Trends (Last 6 Months)</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={vatData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" fontSize={12} />
              <YAxis fontSize={12} />
              <RechartsTooltip formatter={(v: number) => formatCurrency(v)} />
              <Legend />
              <Bar dataKey="outputVat" fill="#3b82f6" name="Output VAT" />
              <Bar dataKey="inputVat" fill="#f59e0b" name="Input VAT" />
              <Bar dataKey="netVat" fill="#ef4444" name="Net VAT" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Detailed VAT Calculation</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Month</TableHead><TableHead>Output VAT</TableHead><TableHead>Input VAT</TableHead><TableHead>Net VAT Liability</TableHead><TableHead>VAT Rate</TableHead></TableRow></TableHeader>
            <TableBody>
              {vatData.map(d => (
                <TableRow key={d.month}>
                  <TableCell className="font-medium">{d.month}</TableCell>
                  <TableCell>{formatCurrency(d.outputVat)}</TableCell>
                  <TableCell>{formatCurrency(d.inputVat)}</TableCell>
                  <TableCell className="font-medium">{formatCurrency(d.netVat)}</TableCell>
                  <TableCell>15%</TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold">
                <TableCell>Total</TableCell>
                <TableCell>{formatCurrency(totalOutput)}</TableCell>
                <TableCell>{formatCurrency(totalInput)}</TableCell>
                <TableCell>{formatCurrency(totalNet)}</TableCell>
                <TableCell>-</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ HR REPORT ============
function HrReport() {
  const [loading, setLoading] = useState(true)
  useEffect(() => { setTimeout(() => setLoading(false), 500) }, [])

  const attendanceData = [
    { department: 'Front Office', present: 18, absent: 2, late: 3, total: 23 },
    { department: 'Housekeeping', present: 28, absent: 4, late: 2, total: 34 },
    { department: 'Kitchen', present: 15, absent: 1, late: 1, total: 17 },
    { department: 'F&B Service', present: 20, absent: 3, late: 2, total: 25 },
    { department: 'Maintenance', present: 8, absent: 1, late: 1, total: 10 },
    { department: 'Management', present: 6, absent: 0, late: 0, total: 6 },
    { department: 'Security', present: 10, absent: 2, late: 1, total: 13 },
    { department: 'Accounts', present: 4, absent: 0, late: 1, total: 5 },
  ]

  const payrollData = [
    { department: 'Front Office', gross: 850000, deductions: 85000, net: 765000, headcount: 23 },
    { department: 'Housekeeping', gross: 680000, deductions: 68000, net: 612000, headcount: 34 },
    { department: 'Kitchen', gross: 920000, deductions: 92000, net: 828000, headcount: 17 },
    { department: 'F&B Service', gross: 750000, deductions: 75000, net: 675000, headcount: 25 },
    { department: 'Maintenance', gross: 350000, deductions: 35000, net: 315000, headcount: 10 },
    { department: 'Management', gross: 1200000, deductions: 120000, net: 1080000, headcount: 6 },
    { department: 'Security', gross: 390000, deductions: 39000, net: 351000, headcount: 13 },
    { department: 'Accounts', gross: 280000, deductions: 28000, net: 252000, headcount: 5 },
  ]

  const totalPresent = attendanceData.reduce((s, d) => s + d.present, 0)
  const totalStaff = attendanceData.reduce((s, d) => s + d.total, 0)
  const totalPayroll = payrollData.reduce((s, d) => s + d.net, 0)
  const totalHeadcount = payrollData.reduce((s, d) => s + d.headcount, 0)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">HR Report</h2><p className="text-muted-foreground">Attendance, payroll, and department headcount</p></div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <KPICard title="Total Staff" value={totalHeadcount} subtitle="Active employees" color="blue" />
        <KPICard title="Attendance Rate" value={`${((totalPresent / totalStaff) * 100).toFixed(1)}%`} subtitle="Today" color="emerald" />
        <KPICard title="Monthly Payroll" value={formatCurrency(totalPayroll)} subtitle="Net salary" color="amber" />
        <KPICard title="Absent Today" value={attendanceData.reduce((s, d) => s + d.absent, 0)} subtitle="Need follow-up" color="red" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Department Headcount</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={payrollData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="department" fontSize={11} />
              <YAxis fontSize={12} />
              <RechartsTooltip />
              <Bar dataKey="headcount" fill="#3b82f6" name="Headcount">
                {payrollData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Attendance Summary</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Department</TableHead><TableHead>Present</TableHead><TableHead>Absent</TableHead><TableHead>Late</TableHead><TableHead>Total</TableHead><TableHead>Rate</TableHead></TableRow></TableHeader>
            <TableBody>
              {attendanceData.map(d => (
                <TableRow key={d.department}>
                  <TableCell className="font-medium">{d.department}</TableCell>
                  <TableCell className="text-emerald-600">{d.present}</TableCell>
                  <TableCell className="text-red-600">{d.absent}</TableCell>
                  <TableCell className="text-amber-600">{d.late}</TableCell>
                  <TableCell>{d.total}</TableCell>
                  <TableCell>{((d.present / d.total) * 100).toFixed(1)}%</TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold">
                <TableCell>Total</TableCell>
                <TableCell className="text-emerald-600">{totalPresent}</TableCell>
                <TableCell className="text-red-600">{attendanceData.reduce((s, d) => s + d.absent, 0)}</TableCell>
                <TableCell className="text-amber-600">{attendanceData.reduce((s, d) => s + d.late, 0)}</TableCell>
                <TableCell>{totalStaff}</TableCell>
                <TableCell>{((totalPresent / totalStaff) * 100).toFixed(1)}%</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Payroll Summary</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Department</TableHead><TableHead>Headcount</TableHead><TableHead>Gross Salary</TableHead><TableHead>Deductions</TableHead><TableHead>Net Salary</TableHead></TableRow></TableHeader>
            <TableBody>
              {payrollData.map(d => (
                <TableRow key={d.department}>
                  <TableCell className="font-medium">{d.department}</TableCell>
                  <TableCell>{d.headcount}</TableCell>
                  <TableCell>{formatCurrency(d.gross)}</TableCell>
                  <TableCell>{formatCurrency(d.deductions)}</TableCell>
                  <TableCell className="font-medium">{formatCurrency(d.net)}</TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold">
                <TableCell>Total</TableCell>
                <TableCell>{totalHeadcount}</TableCell>
                <TableCell>{formatCurrency(payrollData.reduce((s, d) => s + d.gross, 0))}</TableCell>
                <TableCell>{formatCurrency(payrollData.reduce((s, d) => s + d.deductions, 0))}</TableCell>
                <TableCell>{formatCurrency(totalPayroll)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function ReportsModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'occupancy-report': return <OccupancyReport />
    case 'revenue-report': return <RevenueReport />
    case 'sales-report': return <DailySales />
    case 'guest-report': return <GuestReport />
    case 'financial': return <FinancialStatements />
    case 'vat-report': return <VatReport />
    case 'hr-report': return <HrReport />
    default: return <EmptyState title="Unknown Sub-Module" description={`Report sub-module "${subModule}" not found.`} />
  }
}
