'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============================================================
// Supplier Management Sub-Module
// ============================================================
function SupplierManagement() {
  const crud = useCrud<any>('/api/suppliers')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ name: '', code: '', contactPerson: '', email: '', phone: '', address: '', balance: '' })

  const openCreate = () => { setEditItem(null); setFormData({ name: '', code: '', contactPerson: '', email: '', phone: '', address: '', balance: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => {
    setEditItem(item)
    setFormData({ name: item.name || '', code: item.code || '', contactPerson: item.contactPerson || item.contact_person || '', email: item.email || '', phone: item.phone || '', address: item.address || '', balance: String(item.balance ?? '') })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    if (!formData.name || !formData.code) { toast.error('Name and code are required'); return }
    setSaving(true)
    const payload = { ...formData, balance: Number(formData.balance) || 0 }
    const ok = editItem ? await crud.updateItem(editItem.id, payload) : await crud.createItem(payload)
    setSaving(false)
    if (ok) setDialogOpen(false)
  }

  const handleDelete = async () => { if (deleteId) { await crud.deleteItem(deleteId); setDeleteId(null) } }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Supplier Management</h2><p className="text-muted-foreground">Manage suppliers and vendors</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={e => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Supplier</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Suppliers" value={crud.items.length} icon={Plus} color="blue" />
        <KPICard title="Active" value={crud.items.filter((i: any) => i.status !== 'inactive').length} icon={Eye} color="emerald" />
        <KPICard title="Total Balance" value={formatCurrency(crud.items.reduce((s: number, i: any) => s + Number(i.balance || 0), 0))} icon={Edit} color="amber" />
        <KPICard title="With Outstanding" value={crud.items.filter((i: any) => Number(i.balance || 0) > 0).length} icon={Search} color="red" />
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Contact Person</TableHead><TableHead>Email</TableHead><TableHead>Phone</TableHead><TableHead>Balance</TableHead><TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {crud.paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No suppliers found</TableCell></TableRow>
                  ) : crud.paginated.map((item: any) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell><Badge variant="outline">{item.code}</Badge></TableCell>
                      <TableCell>{item.contactPerson || item.contact_person || '-'}</TableCell>
                      <TableCell>{item.email || '-'}</TableCell>
                      <TableCell>{item.phone || '-'}</TableCell>
                      <TableCell>{formatCurrency(item.balance || 0)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={crud.page} totalPages={crud.totalPages} setPage={crud.setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Supplier</DialogTitle><DialogDescription>Fill in the supplier details.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Supplier name" /></div>
            <div><Label>Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} placeholder="Supplier code" /></div>
            <div><Label>Contact Person</Label><Input value={formData.contactPerson} onChange={e => setFormData({ ...formData, contactPerson: e.target.value })} placeholder="Contact person name" /></div>
            <div><Label>Email</Label><Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="Email address" /></div>
            <div><Label>Phone</Label><Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} placeholder="Phone number" /></div>
            <div><Label>Address</Label><Textarea value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} placeholder="Address" /></div>
            <div><Label>Opening Balance</Label><Input type="number" value={formData.balance} onChange={e => setFormData({ ...formData, balance: e.target.value })} placeholder="Outstanding balance" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this supplier? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Purchase Requisition Sub-Module
// ============================================================
function PurchaseRequisition() {
  const [requisitions, setRequisitions] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [formData, setFormData] = useState({ title: '', notes: '', lineItems: [{ itemId: '', quantity: '', unitPrice: '' }] as { itemId: string; quantity: string; unitPrice: string }[] })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [reqData, itemData] = await Promise.all([apiFetch('/api/purchase-orders'), apiFetch('/api/items')])
        setRequisitions((reqData.purchaseOrders || reqData.orders || []).filter((o: any) => o.type === 'requisition' || o.requisition))
        setItems(itemData.items || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const addLineItem = () => setFormData({ ...formData, lineItems: [...formData.lineItems, { itemId: '', quantity: '', unitPrice: '' }] })
  const removeLineItem = (idx: number) => setFormData({ ...formData, lineItems: formData.lineItems.filter((_, i) => i !== idx) })
  const updateLineItem = (idx: number, field: string, value: string) => {
    const updated = [...formData.lineItems]
    updated[idx] = { ...updated[idx], [field]: value }
    setFormData({ ...formData, lineItems: updated })
  }

  const handleSubmit = async () => {
    if (!formData.title) { toast.error('Title is required'); return }
    const validItems = formData.lineItems.filter(li => li.itemId && li.quantity)
    if (validItems.length === 0) { toast.error('At least one line item is required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/purchase-orders', {
        method: 'POST',
        body: JSON.stringify({ type: 'requisition', title: formData.title, notes: formData.notes, lineItems: validItems.map(li => ({ ...li, quantity: Number(li.quantity), unitPrice: Number(li.unitPrice) || 0 })), status: 'draft' })
      })
      toast.success('Requisition created successfully')
      setDialogOpen(false)
      setFormData({ title: '', notes: '', lineItems: [{ itemId: '', quantity: '', unitPrice: '' }] })
      const reqData = await apiFetch('/api/purchase-orders')
      setRequisitions((reqData.purchaseOrders || reqData.orders || []).filter((o: any) => o.type === 'requisition' || o.requisition))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const submitRequisition = async (id: string) => {
    try {
      await apiFetch(`/api/purchase-orders?id=${id}`, { method: 'PUT', body: JSON.stringify({ status: 'submitted' }) })
      toast.success('Requisition submitted')
      const reqData = await apiFetch('/api/purchase-orders')
      setRequisitions((reqData.purchaseOrders || reqData.orders || []).filter((o: any) => o.type === 'requisition' || o.requisition))
    } catch (e: any) { toast.error(e.message) }
  }

  const filtered = requisitions.filter((r: any) => !search || (r.title || r.poNumber || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Purchase Requisition</h2><p className="text-muted-foreground">Create and manage purchase requisitions</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Requisition</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Requisitions" value={requisitions.length} icon={Plus} color="blue" />
        <KPICard title="Draft" value={requisitions.filter((r: any) => r.status === 'draft').length} icon={Edit} color="gray" />
        <KPICard title="Submitted" value={requisitions.filter((r: any) => r.status === 'submitted').length} icon={Eye} color="blue" />
        <KPICard title="Approved" value={requisitions.filter((r: any) => r.status === 'approved').length} icon={Search} color="emerald" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>PO Number</TableHead><TableHead>Status</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No requisitions found</TableCell></TableRow>
                  ) : paginated.map((r: any) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">{r.title || '-'}</TableCell>
                      <TableCell><Badge variant="outline">{r.poNumber || r.po_number || '-'}</Badge></TableCell>
                      <TableCell><Badge className={statusColors[r.status] || 'bg-gray-100 text-gray-800'}>{r.status}</Badge></TableCell>
                      <TableCell>{formatDate(r.createdAt || r.date)}</TableCell>
                      <TableCell className="text-right">
                        {r.status === 'draft' && <Button size="sm" variant="outline" onClick={() => submitRequisition(r.id)}>Submit</Button>}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Requisition</DialogTitle><DialogDescription>Create a new purchase requisition</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Title</Label><Input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="Requisition title" /></div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Notes" /></div>
            <Separator />
            <div className="flex items-center justify-between"><Label className="text-base font-semibold">Line Items</Label><Button type="button" size="sm" variant="outline" onClick={addLineItem}><Plus className="h-4 w-4 mr-1" />Add Item</Button></div>
            {formData.lineItems.map((li, idx) => (
              <div key={idx} className="flex gap-2 items-end">
                <div className="flex-1"><Label className="text-xs">Item</Label>
                  <Select value={li.itemId} onValueChange={v => updateLineItem(idx, 'itemId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="w-24"><Label className="text-xs">Qty</Label><Input type="number" value={li.quantity} onChange={e => updateLineItem(idx, 'quantity', e.target.value)} /></div>
                <div className="w-32"><Label className="text-xs">Unit Price</Label><Input type="number" value={li.unitPrice} onChange={e => updateLineItem(idx, 'unitPrice', e.target.value)} /></div>
                {formData.lineItems.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => removeLineItem(idx)}><X className="h-4 w-4" /></Button>}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create Requisition</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Purchase Order Sub-Module
// ============================================================
function PurchaseOrder() {
  const [orders, setOrders] = useState<any[]>([])
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10
  const [formData, setFormData] = useState({ supplierId: '', lineItems: [{ itemId: '', quantity: '', unitPrice: '' }] as { itemId: string; quantity: string; unitPrice: string }[] })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [orderData, supplierData, itemData] = await Promise.all([apiFetch('/api/purchase-orders'), apiFetch('/api/suppliers'), apiFetch('/api/items')])
        setOrders(orderData.purchaseOrders || orderData.orders || [])
        setSuppliers(supplierData.suppliers || [])
        setItems(itemData.items || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const addLineItem = () => setFormData({ ...formData, lineItems: [...formData.lineItems, { itemId: '', quantity: '', unitPrice: '' }] })
  const removeLineItem = (idx: number) => setFormData({ ...formData, lineItems: formData.lineItems.filter((_, i) => i !== idx) })
  const updateLineItem = (idx: number, field: string, value: string) => {
    const updated = [...formData.lineItems]
    updated[idx] = { ...updated[idx], [field]: value }
    setFormData({ ...formData, lineItems: updated })
  }

  const totalAmount = formData.lineItems.reduce((sum, li) => sum + (Number(li.quantity) || 0) * (Number(li.unitPrice) || 0), 0)

  const handleSubmit = async () => {
    if (!formData.supplierId) { toast.error('Please select a supplier'); return }
    const validItems = formData.lineItems.filter(li => li.itemId && li.quantity)
    if (validItems.length === 0) { toast.error('At least one line item is required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/purchase-orders', {
        method: 'POST',
        body: JSON.stringify({ supplierId: formData.supplierId, lineItems: validItems.map(li => ({ ...li, quantity: Number(li.quantity), unitPrice: Number(li.unitPrice) || 0 })), total: totalAmount, status: 'draft' })
      })
      toast.success('Purchase order created successfully')
      setDialogOpen(false)
      setFormData({ supplierId: '', lineItems: [{ itemId: '', quantity: '', unitPrice: '' }] })
      const orderData = await apiFetch('/api/purchase-orders')
      setOrders(orderData.purchaseOrders || orderData.orders || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const updateStatus = async (id: string, status: string) => {
    try {
      await apiFetch(`/api/purchase-orders?id=${id}`, { method: 'PUT', body: JSON.stringify({ status }) })
      toast.success(`PO status updated to ${status}`)
      const orderData = await apiFetch('/api/purchase-orders')
      setOrders(orderData.purchaseOrders || orderData.orders || [])
    } catch (e: any) { toast.error(e.message) }
  }

  const filtered = orders.filter((o: any) => !search || (o.poNumber || o.po_number || '').toLowerCase().includes(search.toLowerCase()) || (o.supplierName || '').toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Purchase Orders</h2><p className="text-muted-foreground">Manage purchase orders with approval workflow</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => window.location.reload()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New PO</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total POs" value={orders.length} icon={Plus} color="blue" />
        <KPICard title="Draft" value={orders.filter((o: any) => o.status === 'draft').length} icon={Edit} color="amber" />
        <KPICard title="Approved" value={orders.filter((o: any) => o.status === 'approved').length} icon={Eye} color="emerald" />
        <KPICard title="Received" value={orders.filter((o: any) => o.status === 'received').length} icon={Search} color="violet" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader><TableRow><TableHead>PO Number</TableHead><TableHead>Supplier</TableHead><TableHead>Date</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No purchase orders found</TableCell></TableRow>
                  ) : paginated.map((o: any) => (
                    <TableRow key={o.id}>
                      <TableCell className="font-medium"><Badge variant="outline">{o.poNumber || o.po_number || '-'}</Badge></TableCell>
                      <TableCell>{o.supplierName || suppliers.find((s: any) => s.id === o.supplierId)?.name || '-'}</TableCell>
                      <TableCell>{formatDate(o.createdAt || o.date)}</TableCell>
                      <TableCell>{formatCurrency(o.total || 0)}</TableCell>
                      <TableCell><Badge className={statusColors[o.status] || 'bg-gray-100 text-gray-800'}>{o.status}</Badge></TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {o.status === 'draft' && <DropdownMenuItem onClick={() => updateStatus(o.id, 'submitted')}>Submit</DropdownMenuItem>}
                            {o.status === 'submitted' && <DropdownMenuItem onClick={() => updateStatus(o.id, 'approved')}>Approve</DropdownMenuItem>}
                            {o.status === 'approved' && <DropdownMenuItem onClick={() => updateStatus(o.id, 'received')}>Mark Received</DropdownMenuItem>}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Purchase Order</DialogTitle><DialogDescription>Create a new purchase order</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Supplier</Label>
              <Select value={formData.supplierId} onValueChange={v => setFormData({ ...formData, supplierId: v })}>
                <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>{suppliers.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <Separator />
            <div className="flex items-center justify-between"><Label className="text-base font-semibold">Line Items</Label><Button type="button" size="sm" variant="outline" onClick={addLineItem}><Plus className="h-4 w-4 mr-1" />Add Item</Button></div>
            {formData.lineItems.map((li, idx) => (
              <div key={idx} className="flex gap-2 items-end">
                <div className="flex-1"><Label className="text-xs">Item</Label>
                  <Select value={li.itemId} onValueChange={v => updateLineItem(idx, 'itemId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="w-24"><Label className="text-xs">Qty</Label><Input type="number" value={li.quantity} onChange={e => updateLineItem(idx, 'quantity', e.target.value)} /></div>
                <div className="w-32"><Label className="text-xs">Unit Price</Label><Input type="number" value={li.unitPrice} onChange={e => updateLineItem(idx, 'unitPrice', e.target.value)} /></div>
                {formData.lineItems.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => removeLineItem(idx)}><X className="h-4 w-4" /></Button>}
              </div>
            ))}
            <div className="text-right text-lg font-bold">Total: {formatCurrency(totalAmount)}</div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create PO</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Goods Receive Sub-Module
// ============================================================
function GoodsReceive() {
  const [orders, setOrders] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [selectedPO, setSelectedPO] = useState<any>(null)
  const [receivedQty, setReceivedQty] = useState<Record<string, string>>({})

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [orderData, itemData] = await Promise.all([apiFetch('/api/purchase-orders'), apiFetch('/api/items')])
        setOrders((orderData.purchaseOrders || orderData.orders || []).filter((o: any) => o.status === 'approved' || o.status === 'received'))
        setItems(itemData.items || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleReceive = async () => {
    if (!selectedPO) { toast.error('Please select a purchase order'); return }
    setSaving(true)
    try {
      const lineItems = (selectedPO.lineItems || []).map((li: any) => ({
        ...li,
        receivedQty: Number(receivedQty[li.itemId || li.item_id] || li.quantity)
      }))
      await apiFetch(`/api/purchase-orders?id=${selectedPO.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status: 'received', lineItems, type: 'goods-receive' })
      })
      toast.success('Goods received and stock updated')
      setSelectedPO(null)
      setReceivedQty({})
      const orderData = await apiFetch('/api/purchase-orders')
      setOrders((orderData.purchaseOrders || orderData.orders || []).filter((o: any) => o.status === 'approved' || o.status === 'received'))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Goods Receive</h2><p className="text-muted-foreground">Receive goods against purchase orders</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Select Purchase Order</CardTitle><CardDescription>Choose an approved PO to receive goods</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            {loading ? <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div> : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {orders.filter((o: any) => o.status === 'approved').length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No approved purchase orders</p>
                ) : orders.filter((o: any) => o.status === 'approved').map((o: any) => (
                  <div key={o.id} className={`p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${selectedPO?.id === o.id ? 'border-primary bg-primary/5' : ''}`} onClick={() => { setSelectedPO(o); setReceivedQty({}) }}>
                    <div className="flex justify-between"><span className="font-medium">{o.poNumber || o.po_number}</span><Badge className={statusColors[o.status]}>{o.status}</Badge></div>
                    <p className="text-sm text-muted-foreground">{o.supplierName || 'Unknown Supplier'} | {formatCurrency(o.total || 0)}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {selectedPO && (
          <Card>
            <CardHeader><CardTitle>Enter Received Quantities</CardTitle><CardDescription>PO: {selectedPO.poNumber || selectedPO.po_number}</CardDescription></CardHeader>
            <CardContent className="space-y-4">
              <Table>
                <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>Ordered</TableHead><TableHead>Received</TableHead></TableRow></TableHeader>
                <TableBody>
                  {(selectedPO.lineItems || []).map((li: any, idx: number) => {
                    const item = items.find((i: any) => i.id === li.itemId || i.id === li.item_id)
                    return (
                      <TableRow key={idx}>
                        <TableCell className="font-medium">{item?.name || li.itemName || '-'}</TableCell>
                        <TableCell>{li.quantity}</TableCell>
                        <TableCell><Input type="number" value={receivedQty[li.itemId || li.item_id] ?? String(li.quantity)} onChange={e => setReceivedQty({ ...receivedQty, [li.itemId || li.item_id]: e.target.value })} className="w-24" /></TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
              <Button onClick={handleReceive} disabled={saving} className="w-full">{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Confirm Receipt</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

// ============================================================
// Supplier Ledger Sub-Module
// ============================================================
function SupplierLedger() {
  const [suppliers, setSuppliers] = useState<any[]>([])
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedSupplier, setSelectedSupplier] = useState<string>('')
  const [page, setPage] = useState(1)
  const pageSize = 15

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supplierData = await apiFetch('/api/suppliers')
        setSuppliers(supplierData.suppliers || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (!selectedSupplier) { setTransactions([]); return }
    const fetchTransactions = async () => {
      setLoading(true)
      try {
        const data = await apiFetch(`/api/purchase-orders?supplierId=${selectedSupplier}`)
        setTransactions(data.purchaseOrders || data.orders || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchTransactions()
  }, [selectedSupplier])

  let runningBalance = 0
  const enrichedTransactions = transactions.map((t: any) => {
    const debit = Number(t.total || 0)
    const credit = Number(t.payment || t.amountPaid || 0)
    runningBalance += debit - credit
    return { ...t, debit, credit, balance: runningBalance }
  })

  const totalPages = Math.max(1, Math.ceil(enrichedTransactions.length / pageSize))
  const paginated = enrichedTransactions.slice((page - 1) * pageSize, page * pageSize)

  const supplier = suppliers.find((s: any) => s.id === selectedSupplier)

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Supplier Ledger</h2><p className="text-muted-foreground">View supplier transactions and running balance</p></div>

      <Card>
        <CardHeader><CardTitle>Select Supplier</CardTitle></CardHeader>
        <CardContent>
          <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
            <SelectTrigger className="w-full max-w-sm"><SelectValue placeholder="Choose a supplier" /></SelectTrigger>
            <SelectContent>{suppliers.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name} ({s.code})</SelectItem>)}</SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedSupplier && supplier && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KPICard title="Opening Balance" value={formatCurrency(Number(supplier.balance || 0))} icon={Eye} color="blue" />
          <KPICard title="Total Debit" value={formatCurrency(enrichedTransactions.reduce((s: number, t: any) => s + t.debit, 0))} icon={Plus} color="amber" />
          <KPICard title="Total Credit" value={formatCurrency(enrichedTransactions.reduce((s: number, t: any) => s + t.credit, 0))} icon={Edit} color="emerald" />
        </div>
      )}

      {selectedSupplier && (
        <>
          {loading ? <LoadingSkeleton /> : (
            <>
              <Card>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Description</TableHead><TableHead>Debit</TableHead><TableHead>Credit</TableHead><TableHead>Balance</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {paginated.length === 0 ? (
                        <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No transactions found</TableCell></TableRow>
                      ) : paginated.map((t: any, idx: number) => (
                        <TableRow key={t.id || idx}>
                          <TableCell>{formatDate(t.createdAt || t.date)}</TableCell>
                          <TableCell className="font-medium">{t.poNumber || t.description || 'Purchase Order'}</TableCell>
                          <TableCell>{t.debit > 0 ? formatCurrency(t.debit) : '-'}</TableCell>
                          <TableCell>{t.credit > 0 ? formatCurrency(t.credit) : '-'}</TableCell>
                          <TableCell className="font-medium">{formatCurrency(Math.abs(t.balance))} {t.balance < 0 ? 'Cr' : 'Dr'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
              <Pagination page={page} totalPages={totalPages} setPage={setPage} />
            </>
          )}
        </>
      )}
    </div>
  )
}

// ============================================================
// Main Purchase Module Component
// ============================================================
export default function PurchaseModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'suppliers': return <SupplierManagement />
    case 'requisition': return <PurchaseRequisition />
    case 'purchase-order': return <PurchaseOrder />
    case 'goods-receive': return <GoodsReceive />
    case 'supplier-ledger': return <SupplierLedger />
    default: return <EmptyState title="Unknown Sub-Module" description={`Sub-module "${subModule}" not found in Purchase.`} />
  }
}
