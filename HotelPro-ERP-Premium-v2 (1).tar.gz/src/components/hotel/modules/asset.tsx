'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ ASSET REGISTER ============
function AssetRegister() {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '', code: '', category: 'furniture', location: '',
    purchaseDate: '', price: 0, currentValue: 0, depreciationRate: 10, status: 'active',
  })

  const seedData = [
    { id: '1', name: 'King Bed Frame', code: 'AST-001', category: 'furniture', location: 'Room 101', purchaseDate: '2024-01-15', price: 85000, currentValue: 68000, depreciationRate: 20, status: 'active' },
    { id: '2', name: 'Samsung AC Unit', code: 'AST-002', category: 'hvac', location: 'Room 205', purchaseDate: '2024-03-10', price: 65000, currentValue: 52000, depreciationRate: 15, status: 'active' },
    { id: '3', name: 'LED Smart TV 55"', code: 'AST-003', category: 'electronics', location: 'Room 302', purchaseDate: '2024-02-20', price: 55000, currentValue: 44000, depreciationRate: 25, status: 'active' },
    { id: '4', name: 'Commercial Dishwasher', code: 'AST-004', category: 'equipment', location: 'Kitchen', purchaseDate: '2023-06-15', price: 250000, currentValue: 175000, depreciationRate: 15, status: 'active' },
    { id: '5', name: 'Office Desk Set', code: 'AST-005', category: 'furniture', location: 'Front Office', purchaseDate: '2023-09-01', price: 35000, currentValue: 24500, depreciationRate: 10, status: 'disposed' },
    { id: '6', name: 'Elevator Motor', code: 'AST-006', category: 'equipment', location: 'Building A', purchaseDate: '2022-01-10', price: 500000, currentValue: 350000, depreciationRate: 10, status: 'active' },
    { id: '7', name: 'Laundry Machine', code: 'AST-007', category: 'equipment', location: 'Laundry Room', purchaseDate: '2023-11-05', price: 180000, currentValue: 144000, depreciationRate: 20, status: 'maintenance' },
    { id: '8', name: 'Security Camera System', code: 'AST-008', category: 'electronics', location: 'All Floors', purchaseDate: '2024-05-20', price: 320000, currentValue: 288000, depreciationRate: 10, status: 'active' },
  ]

  useEffect(() => {
    setTimeout(() => { setItems(seedData); setLoading(false) }, 400)
  }, [])

  const pageSize = 10
  const filtered = items.filter(i => !search || Object.values(i).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const totalValue = items.reduce((s, i) => s + Number(i.price || 0), 0)
  const currentValue = items.reduce((s, i) => s + Number(i.currentValue || 0), 0)
  const totalDepreciation = totalValue - currentValue

  const openCreate = () => { setEditItem(null); setFormData({ name: '', code: '', category: 'furniture', location: '', purchaseDate: '', price: 0, currentValue: 0, depreciationRate: 10, status: 'active' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setItems(prev => prev.map(i => i.id === editItem.id ? { ...i, ...formData } : i))
      toast.success('Asset updated successfully')
    } else {
      setItems(prev => [...prev, { ...formData, id: Date.now().toString() }])
      toast.success('Asset created successfully')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setItems(prev => prev.filter(i => i.id !== deleteId)); toast.success('Asset deleted'); setDeleteId(null) }
  }

  const categories: Record<string, string> = { furniture: 'Furniture', hvac: 'HVAC', electronics: 'Electronics', equipment: 'Equipment', vehicle: 'Vehicle', other: 'Other' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Assets" value={items.length} subtitle="Registered assets" color="emerald" />
        <KPICard title="Purchase Value" value={formatCurrency(totalValue)} subtitle="Total cost" color="blue" />
        <KPICard title="Current Value" value={formatCurrency(currentValue)} subtitle="After depreciation" color="amber" />
        <KPICard title="Total Depreciation" value={formatCurrency(totalDepreciation)} subtitle="Accumulated" color="red" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Asset Register</h2><p className="text-muted-foreground">Manage hotel assets and inventory</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search assets..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => { setLoading(true); setTimeout(() => setLoading(false), 400) }}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Asset</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Category</TableHead>
                    <TableHead>Location</TableHead><TableHead>Purchase Date</TableHead><TableHead>Price</TableHead>
                    <TableHead>Current Value</TableHead><TableHead>Dep. Rate</TableHead><TableHead>Status</TableHead><TableHead className="w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">No assets found</TableCell></TableRow>
                  ) : paginated.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{item.code}</code></TableCell>
                      <TableCell>{categories[item.category] || item.category}</TableCell>
                      <TableCell>{item.location}</TableCell>
                      <TableCell>{formatDate(item.purchaseDate)}</TableCell>
                      <TableCell>{formatCurrency(item.price)}</TableCell>
                      <TableCell>{formatCurrency(item.currentValue)}</TableCell>
                      <TableCell>{item.depreciationRate}%</TableCell>
                      <TableCell><Badge className={statusColors[item.status] || ''}>{item.status}</Badge></TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Asset</DialogTitle><DialogDescription>Enter asset details below.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Asset Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
              <div><Label>Asset Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Category</Label>
                <Select value={formData.category} onValueChange={v => setFormData({ ...formData, category: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(categories).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Location</Label><Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Purchase Date</Label><Input type="date" value={formData.purchaseDate} onChange={e => setFormData({ ...formData, purchaseDate: e.target.value })} /></div>
              <div><Label>Purchase Price (BDT)</Label><Input type="number" value={formData.price} onChange={e => setFormData({ ...formData, price: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Current Value (BDT)</Label><Input type="number" value={formData.currentValue} onChange={e => setFormData({ ...formData, currentValue: Number(e.target.value) })} /></div>
              <div><Label>Depreciation Rate (%)</Label><Input type="number" value={formData.depreciationRate} onChange={e => setFormData({ ...formData, depreciationRate: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="disposed">Disposed</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this asset? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ ALLOCATION ============
function Allocation() {
  const [allocations, setAllocations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [formData, setFormData] = useState({ assetName: '', assetCode: '', assignTo: '', assignType: 'room', assignDate: '', returnDate: '', status: 'active', notes: '' })

  useEffect(() => {
    setTimeout(() => {
      setAllocations([
        { id: '1', assetName: 'King Bed Frame', assetCode: 'AST-001', assignTo: 'Room 101', assignType: 'room', assignDate: '2024-01-15', returnDate: '', status: 'active', notes: 'Primary bed' },
        { id: '2', assetName: 'Samsung AC Unit', assetCode: 'AST-002', assignTo: 'Room 205', assignType: 'room', assignDate: '2024-03-10', returnDate: '', status: 'active', notes: '' },
        { id: '3', assetName: 'Commercial Dishwasher', assetCode: 'AST-004', assignTo: 'Kitchen', assignType: 'department', assignDate: '2023-06-15', returnDate: '', status: 'active', notes: 'F&B Department' },
        { id: '4', assetName: 'Office Desk Set', assetCode: 'AST-005', assignTo: 'Front Office', assignType: 'department', assignDate: '2023-09-01', returnDate: '2024-06-01', status: 'returned', notes: 'Replaced with new desk' },
        { id: '5', assetName: 'Walkie Talkie Set', assetCode: 'AST-009', assignTo: 'Security Team', assignType: 'staff', assignDate: '2024-02-01', returnDate: '', status: 'active', notes: '4 units assigned' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setAllocations(prev => [...prev, { ...formData, id: Date.now().toString() }])
    toast.success('Allocation created'); setDialogOpen(false)
    setFormData({ assetName: '', assetCode: '', assignTo: '', assignType: 'room', assignDate: '', returnDate: '', status: 'active', notes: '' })
  }

  const assignTypes: Record<string, string> = { room: 'Room', department: 'Department', staff: 'Staff' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Allocations" value={allocations.filter(a => a.status === 'active').length} subtitle="Currently assigned" color="emerald" />
        <KPICard title="Room Assignments" value={allocations.filter(a => a.assignType === 'room').length} subtitle="Assets in rooms" color="blue" />
        <KPICard title="Department Assignments" value={allocations.filter(a => a.assignType === 'department').length} subtitle="Assets in departments" color="amber" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Asset Allocation</h2><p className="text-muted-foreground">Assign assets to rooms, departments, and staff</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Allocate Asset</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Asset</TableHead><TableHead>Code</TableHead><TableHead>Assigned To</TableHead><TableHead>Type</TableHead><TableHead>Assign Date</TableHead><TableHead>Return Date</TableHead><TableHead>Status</TableHead><TableHead>Notes</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {allocations.map(a => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.assetName}</TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{a.assetCode}</code></TableCell>
                    <TableCell>{a.assignTo}</TableCell>
                    <TableCell><Badge variant="outline">{assignTypes[a.assignType]}</Badge></TableCell>
                    <TableCell>{formatDate(a.assignDate)}</TableCell>
                    <TableCell>{a.returnDate ? formatDate(a.returnDate) : '-'}</TableCell>
                    <TableCell><Badge className={statusColors[a.status] || ''}>{a.status}</Badge></TableCell>
                    <TableCell className="max-w-[150px] truncate">{a.notes || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Allocate Asset</DialogTitle><DialogDescription>Assign an asset to a room, department, or staff member.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Asset Name</Label><Input value={formData.assetName} onChange={e => setFormData({ ...formData, assetName: e.target.value })} /></div>
              <div><Label>Asset Code</Label><Input value={formData.assetCode} onChange={e => setFormData({ ...formData, assetCode: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Assign To</Label><Input value={formData.assignTo} onChange={e => setFormData({ ...formData, assignTo: e.target.value })} placeholder="e.g. Room 101" /></div>
              <div><Label>Assignment Type</Label>
                <Select value={formData.assignType} onValueChange={v => setFormData({ ...formData, assignType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="room">Room</SelectItem><SelectItem value="department">Department</SelectItem><SelectItem value="staff">Staff</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Assign Date</Label><Input type="date" value={formData.assignDate} onChange={e => setFormData({ ...formData, assignDate: e.target.value })} /></div>
              <div><Label>Return Date (Optional)</Label><Input type="date" value={formData.returnDate} onChange={e => setFormData({ ...formData, returnDate: e.target.value })} /></div>
            </div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Allocate</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ DEPRECIATION ============
function Depreciation() {
  const [assets, setAssets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setTimeout(() => {
      setAssets([
        { id: '1', name: 'King Bed Frame', code: 'AST-001', purchaseDate: '2024-01-15', price: 85000, currentValue: 68000, depreciationRate: 20, method: 'straight_line', usefulLife: 5 },
        { id: '2', name: 'Samsung AC Unit', code: 'AST-002', purchaseDate: '2024-03-10', price: 65000, currentValue: 52000, depreciationRate: 15, method: 'straight_line', usefulLife: 7 },
        { id: '3', name: 'LED Smart TV 55"', code: 'AST-003', purchaseDate: '2024-02-20', price: 55000, currentValue: 44000, depreciationRate: 25, method: 'declining_balance', usefulLife: 4 },
        { id: '4', name: 'Commercial Dishwasher', code: 'AST-004', purchaseDate: '2023-06-15', price: 250000, currentValue: 175000, depreciationRate: 15, method: 'straight_line', usefulLife: 7 },
        { id: '5', name: 'Elevator Motor', code: 'AST-006', purchaseDate: '2022-01-10', price: 500000, currentValue: 350000, depreciationRate: 10, method: 'straight_line', usefulLife: 10 },
        { id: '6', name: 'Security Camera System', code: 'AST-008', purchaseDate: '2024-05-20', price: 320000, currentValue: 288000, depreciationRate: 10, method: 'straight_line', usefulLife: 10 },
      ]); setLoading(false)
    }, 400)
  }, [])

  const generateSchedule = (asset: any): { year: number; depreciation: number; accumulated: number; bookValue: number }[] => {
    const schedule: { year: number; depreciation: number; accumulated: number; bookValue: number }[] = []
    const annualDep = (asset.price * asset.depreciationRate) / 100
    let remaining = asset.price
    for (let y = 1; y <= asset.usefulLife; y++) {
      const dep = asset.method === 'declining_balance' ? remaining * (asset.depreciationRate / 100) : annualDep
      remaining = Math.max(0, remaining - dep)
      schedule.push({ year: y, depreciation: Math.round(dep), accumulated: Math.round(asset.price - remaining), bookValue: Math.round(remaining) })
      if (remaining <= 0) break
    }
    return schedule
  }

  const [expandedAsset, setExpandedAsset] = useState<string | null>(null)

  const totalPurchase = assets.reduce((s, a) => s + a.price, 0)
  const totalCurrent = assets.reduce((s, a) => s + a.currentValue, 0)
  const totalDepreciation = totalPurchase - totalCurrent

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Purchase Value" value={formatCurrency(totalPurchase)} subtitle="Original cost" color="blue" />
        <KPICard title="Current Book Value" value={formatCurrency(totalCurrent)} subtitle="After depreciation" color="emerald" />
        <KPICard title="Accumulated Depreciation" value={formatCurrency(totalDepreciation)} subtitle="Total written off" color="red" />
      </div>

      <div><h2 className="text-2xl font-bold">Depreciation Schedule</h2><p className="text-muted-foreground">View and calculate asset depreciation</p></div>

      {loading ? <LoadingSkeleton /> : (
        <div className="space-y-4">
          {assets.map(asset => {
            const schedule = generateSchedule(asset)
            const isExpanded = expandedAsset === asset.id
            return (
              <Card key={asset.id}>
                <CardHeader className="pb-3 cursor-pointer" onClick={() => setExpandedAsset(isExpanded ? null : asset.id)}>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{asset.name}</CardTitle>
                      <CardDescription>{asset.code} | {asset.method === 'straight_line' ? 'Straight Line' : 'Declining Balance'} | Rate: {asset.depreciationRate}%</CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{formatCurrency(asset.currentValue)}</p>
                      <p className="text-xs text-muted-foreground">of {formatCurrency(asset.price)}</p>
                    </div>
                  </div>
                </CardHeader>
                {isExpanded && (
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow><TableHead>Year</TableHead><TableHead>Annual Depreciation</TableHead><TableHead>Accumulated Dep.</TableHead><TableHead>Book Value</TableHead></TableRow>
                      </TableHeader>
                      <TableBody>
                        {schedule.map(s => (
                          <TableRow key={s.year}>
                            <TableCell>Year {s.year}</TableCell>
                            <TableCell>{formatCurrency(s.depreciation)}</TableCell>
                            <TableCell>{formatCurrency(s.accumulated)}</TableCell>
                            <TableCell>{formatCurrency(s.bookValue)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                )}
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ============ AUDIT ============
function Audit() {
  const [audits, setAudits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [formData, setFormData] = useState({ assetName: '', assetCode: '', auditor: '', auditDate: '', condition: 'good', location: '', notes: '' })

  useEffect(() => {
    setTimeout(() => {
      setAudits([
        { id: '1', assetName: 'King Bed Frame', assetCode: 'AST-001', auditor: 'Rahim Uddin', auditDate: '2024-11-15', condition: 'good', location: 'Room 101', notes: 'In good condition, minor wear' },
        { id: '2', assetName: 'Samsung AC Unit', assetCode: 'AST-002', auditor: 'Karim Hossain', auditDate: '2024-11-15', condition: 'needs_repair', location: 'Room 205', notes: 'Cooling efficiency reduced, needs servicing' },
        { id: '3', assetName: 'Commercial Dishwasher', assetCode: 'AST-004', auditor: 'Fatima Begum', auditDate: '2024-11-10', condition: 'good', location: 'Kitchen', notes: 'Running well after last service' },
        { id: '4', assetName: 'Office Desk Set', assetCode: 'AST-005', auditor: 'Rahim Uddin', auditDate: '2024-11-10', condition: 'disposed', location: 'Storage', notes: 'Disposed per management decision' },
        { id: '5', assetName: 'Elevator Motor', assetCode: 'AST-006', auditor: 'Karim Hossain', auditDate: '2024-11-05', condition: 'good', location: 'Building A', notes: 'Annual inspection completed' },
        { id: '6', assetName: 'Laundry Machine', assetCode: 'AST-007', auditor: 'Fatima Begum', auditDate: '2024-11-05', condition: 'needs_repair', location: 'Laundry Room', notes: 'Bearing noise, scheduled for repair' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setAudits(prev => [...prev, { ...formData, id: Date.now().toString() }])
    toast.success('Audit record created'); setDialogOpen(false)
    setFormData({ assetName: '', assetCode: '', auditor: '', auditDate: '', condition: 'good', location: '', notes: '' })
  }

  const conditions: Record<string, string> = { good: 'Good', needs_repair: 'Needs Repair', disposed: 'Disposed', missing: 'Missing' }
  const condColors: Record<string, string> = { good: 'bg-emerald-100 text-emerald-800', needs_repair: 'bg-amber-100 text-amber-800', disposed: 'bg-gray-100 text-gray-800', missing: 'bg-red-100 text-red-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <MiniStat label="Total Audits" value={audits.length} color="bg-blue-50" />
        <MiniStat label="Good Condition" value={audits.filter(a => a.condition === 'good').length} color="bg-emerald-50" />
        <MiniStat label="Needs Repair" value={audits.filter(a => a.condition === 'needs_repair').length} color="bg-amber-50" />
        <MiniStat label="Disposed/Missing" value={audits.filter(a => a.condition === 'disposed' || a.condition === 'missing').length} color="bg-red-50" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Asset Audit</h2><p className="text-muted-foreground">Verification and condition tracking</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Audit</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Asset</TableHead><TableHead>Code</TableHead><TableHead>Auditor</TableHead><TableHead>Audit Date</TableHead><TableHead>Condition</TableHead><TableHead>Location</TableHead><TableHead>Notes</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {audits.map(a => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.assetName}</TableCell>
                    <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{a.assetCode}</code></TableCell>
                    <TableCell>{a.auditor}</TableCell>
                    <TableCell>{formatDate(a.auditDate)}</TableCell>
                    <TableCell><Badge className={condColors[a.condition] || ''}>{conditions[a.condition]}</Badge></TableCell>
                    <TableCell>{a.location}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{a.notes || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Audit Record</DialogTitle><DialogDescription>Record asset verification and condition.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Asset Name</Label><Input value={formData.assetName} onChange={e => setFormData({ ...formData, assetName: e.target.value })} /></div>
              <div><Label>Asset Code</Label><Input value={formData.assetCode} onChange={e => setFormData({ ...formData, assetCode: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Auditor</Label><Input value={formData.auditor} onChange={e => setFormData({ ...formData, auditor: e.target.value })} /></div>
              <div><Label>Audit Date</Label><Input type="date" value={formData.auditDate} onChange={e => setFormData({ ...formData, auditDate: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Condition</Label>
                <Select value={formData.condition} onValueChange={v => setFormData({ ...formData, condition: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(conditions).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Location</Label><Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} /></div>
            </div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save Audit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function AssetModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'asset-register': return <AssetRegister />
    case 'allocation': return <Allocation />
    case 'depreciation': return <Depreciation />
    case 'audit': return <Audit />
    default: return <EmptyState title="Unknown Sub-Module" description={`Asset sub-module "${subModule}" not found.`} />
  }
}
