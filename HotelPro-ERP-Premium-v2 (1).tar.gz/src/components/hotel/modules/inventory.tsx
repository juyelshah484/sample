'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============================================================
// Item Master Sub-Module
// ============================================================
function ItemMaster() {
  const crud = useCrud<any>('/api/items')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ name: '', code: '', category: '', unit: '', reorderLevel: '' })

  const openCreate = () => { setEditItem(null); setFormData({ name: '', code: '', category: '', unit: '', reorderLevel: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name || '', code: item.code || '', category: item.category || '', unit: item.unit || '', reorderLevel: String(item.reorderLevel ?? '') }); setDialogOpen(true) }

  const handleSave = async () => {
    if (!formData.name || !formData.code) { toast.error('Name and code are required'); return }
    setSaving(true)
    const payload = { ...formData, reorderLevel: Number(formData.reorderLevel) || 0 }
    const ok = editItem ? await crud.updateItem(editItem.id, payload) : await crud.createItem(payload)
    setSaving(false)
    if (ok) setDialogOpen(false)
  }

  const handleDelete = async () => { if (deleteId) { await crud.deleteItem(deleteId); setDeleteId(null) } }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Item Master</h2><p className="text-muted-foreground">Manage inventory items</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={crud.search} onChange={e => { crud.setSearch(e.target.value); crud.setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => crud.fetchItems()}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Item</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Items" value={crud.items.length} icon={Plus} color="blue" />
        <KPICard title="Categories" value={new Set(crud.items.map((i: any) => i.category).filter(Boolean)).size} icon={Search} color="emerald" />
        <KPICard title="Low Stock" value={crud.items.filter((i: any) => Number(i.reorderLevel) > 0).length} icon={Edit} color="amber" />
        <KPICard title="Active" value={crud.items.filter((i: any) => i.status !== 'inactive').length} icon={Eye} color="violet" />
      </div>

      {crud.loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Category</TableHead><TableHead>Unit</TableHead><TableHead>Reorder Level</TableHead><TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {crud.paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No items found</TableCell></TableRow>
                  ) : crud.paginated.map((item: any) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell><Badge variant="outline">{item.code}</Badge></TableCell>
                      <TableCell>{item.category || '-'}</TableCell>
                      <TableCell>{item.unit || '-'}</TableCell>
                      <TableCell>{item.reorderLevel ?? '-'}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={crud.page} totalPages={crud.totalPages} setPage={crud.setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Item</DialogTitle><DialogDescription>Fill in the item details below.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Item name" /></div>
            <div><Label>Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} placeholder="Item code" /></div>
            <div><Label>Category</Label><Input value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })} placeholder="e.g. Food, Beverage, Supply" /></div>
            <div><Label>Unit</Label><Input value={formData.unit} onChange={e => setFormData({ ...formData, unit: e.target.value })} placeholder="e.g. kg, liter, piece" /></div>
            <div><Label>Reorder Level</Label><Input type="number" value={formData.reorderLevel} onChange={e => setFormData({ ...formData, reorderLevel: e.target.value })} placeholder="Minimum stock level" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this item? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Stock Levels Sub-Module
// ============================================================
function StockLevels() {
  const [stocks, setStocks] = useState<any[]>([])
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [stockData, itemData] = await Promise.all([apiFetch('/api/stock'), apiFetch('/api/items')])
        setStocks(stockData.stocks || stockData.stock || [])
        setItems(itemData.items || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const enrichedStocks = stocks.map((s: any) => {
    const item = items.find((i: any) => i.id === s.itemId || i.id === s.item_id)
    const isLow = item && s.quantity < (item.reorderLevel || 0)
    return { ...s, itemName: item?.name || s.itemName || s.item_name || '-', itemCode: item?.code || s.itemCode || s.item_code || '-', category: item?.category || s.category || '-', reorderLevel: item?.reorderLevel || s.reorderLevel || 0, isLow }
  })

  const filtered = enrichedStocks.filter((s: any) =>
    !search || s.itemName.toLowerCase().includes(search.toLowerCase()) || s.itemCode.toLowerCase().includes(search.toLowerCase())
  )
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const lowStockCount = enrichedStocks.filter((s: any) => s.isLow).length

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Stock Levels</h2><p className="text-muted-foreground">Current stock per store</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={() => window.location.reload()}><RefreshCw className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total SKUs" value={enrichedStocks.length} icon={Eye} color="blue" />
        <KPICard title="Low Stock Items" value={lowStockCount} icon={Search} color="red" />
        <KPICard title="Total Quantity" value={enrichedStocks.reduce((sum: number, s: any) => sum + Number(s.quantity || 0), 0)} icon={Plus} color="emerald" />
        <KPICard title="Stores" value={new Set(enrichedStocks.map((s: any) => s.store || s.storeName || s.store_name || 'Main')).size} icon={Edit} color="violet" />
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead><TableHead>Code</TableHead><TableHead>Category</TableHead><TableHead>Store</TableHead><TableHead>Quantity</TableHead><TableHead>Reorder Level</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No stock records found</TableCell></TableRow>
                  ) : paginated.map((s: any, idx: number) => (
                    <TableRow key={s.id || idx} className={s.isLow ? 'bg-red-50' : ''}>
                      <TableCell className="font-medium">{s.itemName}</TableCell>
                      <TableCell><Badge variant="outline">{s.itemCode}</Badge></TableCell>
                      <TableCell>{s.category}</TableCell>
                      <TableCell>{s.store || s.storeName || s.store_name || 'Main'}</TableCell>
                      <TableCell className={s.isLow ? 'text-red-600 font-bold' : ''}>{s.quantity}</TableCell>
                      <TableCell>{s.reorderLevel}</TableCell>
                      <TableCell>{s.isLow ? <Badge className="bg-red-100 text-red-800">Low Stock</Badge> : <Badge className="bg-emerald-100 text-emerald-800">In Stock</Badge>}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============================================================
// Stock In Sub-Module
// ============================================================
function StockIn() {
  const [items, setItems] = useState<any[]>([])
  const [recentRecords, setRecentRecords] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ itemId: '', store: 'Main', quantity: '', reference: '', notes: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [itemData, stockData] = await Promise.all([apiFetch('/api/items'), apiFetch('/api/stock')])
        setItems(itemData.items || [])
        setRecentRecords((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'in' || s.recentIn).slice(0, 20))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.itemId || !formData.quantity) { toast.error('Item and quantity are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/stock', { method: 'POST', body: JSON.stringify({ ...formData, type: 'in', quantity: Number(formData.quantity) }) })
      toast.success('Stock in recorded successfully')
      setFormData({ itemId: '', store: 'Main', quantity: '', reference: '', notes: '' })
      const stockData = await apiFetch('/api/stock')
      setRecentRecords((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'in' || s.recentIn).slice(0, 20))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Stock In</h2><p className="text-muted-foreground">Record incoming stock</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Stock In Entry</CardTitle><CardDescription>Record new stock received</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Item</Label>
              <Select value={formData.itemId} onValueChange={v => setFormData({ ...formData, itemId: v })}>
                <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name} ({item.code})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Store</Label><Input value={formData.store} onChange={e => setFormData({ ...formData, store: e.target.value })} placeholder="Store name" /></div>
            <div><Label>Quantity</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="Quantity received" /></div>
            <div><Label>Reference</Label><Input value={formData.reference} onChange={e => setFormData({ ...formData, reference: e.target.value })} placeholder="PO number or reference" /></div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Additional notes" /></div>
            <Button onClick={handleSubmit} disabled={saving} className="w-full">{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Record Stock In</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Recent Stock In Records</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>Store</TableHead><TableHead>Qty</TableHead><TableHead>Reference</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin mx-auto" /></TableCell></TableRow>
                ) : recentRecords.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No records found</TableCell></TableRow>
                ) : recentRecords.map((r: any, idx: number) => (
                  <TableRow key={r.id || idx}>
                    <TableCell className="font-medium">{r.itemName || r.item_name || '-'}</TableCell>
                    <TableCell>{r.store || r.storeName || '-'}</TableCell>
                    <TableCell>{r.quantity}</TableCell>
                    <TableCell>{r.reference || '-'}</TableCell>
                    <TableCell>{formatDate(r.createdAt || r.date)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Stock Out Sub-Module
// ============================================================
function StockOut() {
  const [items, setItems] = useState<any[]>([])
  const [recentRecords, setRecentRecords] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ itemId: '', store: 'Main', quantity: '', reference: '', notes: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [itemData, stockData] = await Promise.all([apiFetch('/api/items'), apiFetch('/api/stock')])
        setItems(itemData.items || [])
        setRecentRecords((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'out' || s.recentOut).slice(0, 20))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.itemId || !formData.quantity) { toast.error('Item and quantity are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/stock', { method: 'POST', body: JSON.stringify({ ...formData, type: 'out', quantity: Number(formData.quantity) }) })
      toast.success('Stock out recorded successfully')
      setFormData({ itemId: '', store: 'Main', quantity: '', reference: '', notes: '' })
      const stockData = await apiFetch('/api/stock')
      setRecentRecords((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'out' || s.recentOut).slice(0, 20))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Stock Out</h2><p className="text-muted-foreground">Record stock consumption and usage</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Stock Out Entry</CardTitle><CardDescription>Record stock issued or consumed</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Item</Label>
              <Select value={formData.itemId} onValueChange={v => setFormData({ ...formData, itemId: v })}>
                <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name} ({item.code})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Store</Label><Input value={formData.store} onChange={e => setFormData({ ...formData, store: e.target.value })} placeholder="Store name" /></div>
            <div><Label>Quantity</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="Quantity issued" /></div>
            <div><Label>Reference</Label><Input value={formData.reference} onChange={e => setFormData({ ...formData, reference: e.target.value })} placeholder="Department or reference" /></div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Reason for stock out" /></div>
            <Button onClick={handleSubmit} disabled={saving} className="w-full">{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Record Stock Out</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Recent Stock Out Records</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>Store</TableHead><TableHead>Qty</TableHead><TableHead>Reference</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin mx-auto" /></TableCell></TableRow>
                ) : recentRecords.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No records found</TableCell></TableRow>
                ) : recentRecords.map((r: any, idx: number) => (
                  <TableRow key={r.id || idx}>
                    <TableCell className="font-medium">{r.itemName || r.item_name || '-'}</TableCell>
                    <TableCell>{r.store || r.storeName || '-'}</TableCell>
                    <TableCell>{r.quantity}</TableCell>
                    <TableCell>{r.reference || '-'}</TableCell>
                    <TableCell>{formatDate(r.createdAt || r.date)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Stock Transfer Sub-Module
// ============================================================
function StockTransfer() {
  const [items, setItems] = useState<any[]>([])
  const [transfers, setTransfers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ itemId: '', fromStore: '', toStore: '', quantity: '', notes: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [itemData, stockData] = await Promise.all([apiFetch('/api/items'), apiFetch('/api/stock')])
        setItems(itemData.items || [])
        setTransfers((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'transfer').slice(0, 20))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const handleSubmit = async () => {
    if (!formData.itemId || !formData.fromStore || !formData.toStore || !formData.quantity) { toast.error('All fields are required'); return }
    if (formData.fromStore === formData.toStore) { toast.error('From and To stores must be different'); return }
    setSaving(true)
    try {
      await apiFetch('/api/stock', { method: 'POST', body: JSON.stringify({ ...formData, type: 'transfer', quantity: Number(formData.quantity) }) })
      toast.success('Stock transfer recorded successfully')
      setFormData({ itemId: '', fromStore: '', toStore: '', quantity: '', notes: '' })
      const stockData = await apiFetch('/api/stock')
      setTransfers((stockData.stocks || stockData.stock || []).filter((s: any) => s.type === 'transfer').slice(0, 20))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Stock Transfer</h2><p className="text-muted-foreground">Transfer stock between stores</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>New Transfer</CardTitle><CardDescription>Move stock from one store to another</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Item</Label>
              <Select value={formData.itemId} onValueChange={v => setFormData({ ...formData, itemId: v })}>
                <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name} ({item.code})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>From Store</Label><Input value={formData.fromStore} onChange={e => setFormData({ ...formData, fromStore: e.target.value })} placeholder="Source store" /></div>
            <div><Label>To Store</Label><Input value={formData.toStore} onChange={e => setFormData({ ...formData, toStore: e.target.value })} placeholder="Destination store" /></div>
            <div><Label>Quantity</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="Quantity to transfer" /></div>
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Transfer notes" /></div>
            <Button onClick={handleSubmit} disabled={saving} className="w-full">{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Record Transfer</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Transfer History</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>From</TableHead><TableHead>To</TableHead><TableHead>Qty</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin mx-auto" /></TableCell></TableRow>
                ) : transfers.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No transfers found</TableCell></TableRow>
                ) : transfers.map((t: any, idx: number) => (
                  <TableRow key={t.id || idx}>
                    <TableCell className="font-medium">{t.itemName || t.item_name || '-'}</TableCell>
                    <TableCell>{t.fromStore || t.from_store || '-'}</TableCell>
                    <TableCell>{t.toStore || t.to_store || '-'}</TableCell>
                    <TableCell>{t.quantity}</TableCell>
                    <TableCell>{formatDate(t.createdAt || t.date)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Stock Audit Sub-Module
// ============================================================
function StockAudit() {
  const [items, setItems] = useState<any[]>([])
  const [stocks, setStocks] = useState<any[]>([])
  const [audits, setAudits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ itemId: '', store: 'Main', physicalCount: '', notes: '' })

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [itemData, stockData] = await Promise.all([apiFetch('/api/items'), apiFetch('/api/stock')])
        setItems(itemData.items || [])
        const allStocks = stockData.stocks || stockData.stock || []
        setStocks(allStocks)
        setAudits(allStocks.filter((s: any) => s.type === 'audit' || s.audit))
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const enrichedStocks = stocks.map((s: any) => {
    const item = items.find((i: any) => i.id === s.itemId || i.id === s.item_id)
    return { ...s, itemName: item?.name || s.itemName || '-', systemCount: Number(s.quantity || 0) }
  })

  const handleSubmit = async () => {
    if (!formData.itemId || formData.physicalCount === '') { toast.error('Item and physical count are required'); return }
    setSaving(true)
    const physicalCount = Number(formData.physicalCount)
    const stock = enrichedStocks.find((s: any) => s.itemId === formData.itemId || s.item_id === formData.itemId)
    const systemCount = stock?.systemCount || 0
    const variance = physicalCount - systemCount
    try {
      await apiFetch('/api/stock', { method: 'POST', body: JSON.stringify({ ...formData, type: 'audit', physicalCount, systemCount, variance, quantity: physicalCount }) })
      toast.success(`Audit recorded. Variance: ${variance >= 0 ? '+' : ''}${variance}`)
      setFormData({ itemId: '', store: 'Main', physicalCount: '', notes: '' })
      const stockData = await apiFetch('/api/stock')
      const allStocks = stockData.stocks || stockData.stock || []
      setStocks(allStocks)
      setAudits(allStocks.filter((s: any) => s.type === 'audit' || s.audit))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Stock Audit</h2><p className="text-muted-foreground">Physical count vs system count</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Audit Entry</CardTitle><CardDescription>Record physical count and adjust stock</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Item</Label>
              <Select value={formData.itemId} onValueChange={v => setFormData({ ...formData, itemId: v })}>
                <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                <SelectContent>{items.map((item: any) => <SelectItem key={item.id} value={item.id}>{item.name} ({item.code})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Store</Label><Input value={formData.store} onChange={e => setFormData({ ...formData, store: e.target.value })} placeholder="Store name" /></div>
            <div><Label>Physical Count</Label><Input type="number" value={formData.physicalCount} onChange={e => setFormData({ ...formData, physicalCount: e.target.value })} placeholder="Actual counted quantity" /></div>
            {formData.itemId && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">System Count: <span className="font-medium text-foreground">{enrichedStocks.find((s: any) => s.itemId === formData.itemId || s.item_id === formData.itemId)?.systemCount ?? 'N/A'}</span></p>
                {formData.physicalCount !== '' && (
                  <p className="text-sm text-muted-foreground mt-1">Variance: <span className={`font-bold ${Number(formData.physicalCount) - (enrichedStocks.find((s: any) => s.itemId === formData.itemId)?.systemCount || 0) >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {Number(formData.physicalCount) - (enrichedStocks.find((s: any) => s.itemId === formData.itemId)?.systemCount || 0)}
                  </span></p>
                )}
              </div>
            )}
            <div><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Audit notes / reason for variance" /></div>
            <Button onClick={handleSubmit} disabled={saving} className="w-full">{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Submit Audit</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Audit History</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader><TableRow><TableHead>Item</TableHead><TableHead>Store</TableHead><TableHead>System</TableHead><TableHead>Physical</TableHead><TableHead>Variance</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin mx-auto" /></TableCell></TableRow>
                ) : audits.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No audit records found</TableCell></TableRow>
                ) : audits.map((a: any, idx: number) => {
                  const variance = (a.physicalCount ?? a.physical_count ?? 0) - (a.systemCount ?? a.system_count ?? 0)
                  return (
                    <TableRow key={a.id || idx}>
                      <TableCell className="font-medium">{a.itemName || a.item_name || '-'}</TableCell>
                      <TableCell>{a.store || a.storeName || '-'}</TableCell>
                      <TableCell>{a.systemCount ?? a.system_count ?? '-'}</TableCell>
                      <TableCell>{a.physicalCount ?? a.physical_count ?? '-'}</TableCell>
                      <TableCell className={variance !== 0 ? (variance > 0 ? 'text-emerald-600 font-bold' : 'text-red-600 font-bold') : ''}>{variance >= 0 ? '+' : ''}{variance}</TableCell>
                      <TableCell>{formatDate(a.createdAt || a.date)}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============================================================
// Main Inventory Module Component
// ============================================================
export default function InventoryModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'items': return <ItemMaster />
    case 'stock-levels': return <StockLevels />
    case 'stock-in': return <StockIn />
    case 'stock-out': return <StockOut />
    case 'transfer': return <StockTransfer />
    case 'audit': return <StockAudit />
    default: return <EmptyState title="Unknown Sub-Module" description={`Sub-module "${subModule}" not found in Inventory.`} />
  }
}
