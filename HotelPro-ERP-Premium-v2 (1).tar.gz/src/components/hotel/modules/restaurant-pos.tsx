'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ Types ============
interface MenuItem {
  id: string
  name: string
  description: string | null
  category: string | null
  price: number
  isVeg: boolean
  isAvailable: boolean
  preparationTime: number | null
  image: string | null
}

interface CartItem {
  menuItem: MenuItem
  quantity: number
  notes: string
}

interface Order {
  id: string
  orderNumber: string
  type: string
  status: string
  totalAmount: number
  discount: number
  taxAmount: number
  notes: string | null
  createdAt: string
  restaurant?: { name: string }
  items: { id: string; menuItemId: string; menuItem: { name: string }; quantity: number; price: number; notes: string | null; status: string }[]
}

interface RestaurantTable {
  id: string
  number: string
  capacity: number
  status: string
  isActive: boolean
}

interface Restaurant {
  id: string
  name: string
  code: string
  type: string
  capacity: number
  tables: RestaurantTable[]
  menuItems: MenuItem[]
}

// ============ Restaurant POS ============
function RestaurantPOS() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [selectedRestaurant, setSelectedRestaurant] = useState<string>('')
  const [cart, setCart] = useState<CartItem[]>([])
  const [discount, setDiscount] = useState(0)
  const [orderNotes, setOrderNotes] = useState('')
  const [tableNumber, setTableNumber] = useState('')
  const [placing, setPlacing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [orders, setOrders] = useState<Order[]>([])
  const [activeCategory, setActiveCategory] = useState('All')

  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const res = await apiFetch('/api/restaurants')
        const rList: Restaurant[] = res.restaurants || []
        setRestaurants(rList)
        if (rList.length > 0 && !selectedRestaurant) {
          setSelectedRestaurant(rList[0].id)
        }
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchRestaurants()
  }, [])

  const currentRestaurant = restaurants.find(r => r.id === selectedRestaurant)
  const menuItems = currentRestaurant?.menuItems || []
  const categories = ['All', ...Array.from(new Set(menuItems.map(m => m.category || 'Other')))]

  const filteredMenu = activeCategory === 'All' ? menuItems : menuItems.filter(m => (m.category || 'Other') === activeCategory)

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.menuItem.id === item.id)
      if (existing) return prev.map(c => c.menuItem.id === item.id ? { ...c, quantity: c.quantity + 1 } : c)
      return [...prev, { menuItem: item, quantity: 1, notes: '' }]
    })
  }

  const updateQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) { setCart(prev => prev.filter(c => c.menuItem.id !== itemId)); return }
    setCart(prev => prev.map(c => c.menuItem.id === itemId ? { ...c, quantity: qty } : c))
  }

  const removeFromCart = (itemId: string) => setCart(prev => prev.filter(c => c.menuItem.id !== itemId))

  const subtotal = cart.reduce((s, c) => s + c.menuItem.price * c.quantity, 0)
  const taxAmount = (subtotal - discount) * 0.15
  const total = subtotal - discount + taxAmount

  const placeOrder = async () => {
    if (cart.length === 0) { toast.error('Cart is empty'); return }
    if (!selectedRestaurant) { toast.error('Select a restaurant'); return }
    setPlacing(true)
    try {
      const table = currentRestaurant?.tables.find(t => t.number === tableNumber)
      await apiFetch('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          restaurantId: selectedRestaurant,
          tableId: table?.id || null,
          type: 'dine_in',
          items: cart.map(c => ({ menuItemId: c.menuItem.id, quantity: c.quantity, price: c.menuItem.price, notes: c.notes })),
          discount,
          notes: orderNotes,
        }),
      })
      toast.success('Order placed successfully!')
      setCart([])
      setDiscount(0)
      setOrderNotes('')
      setTableNumber('')
      fetchOrders()
    } catch (e: any) { toast.error(e.message) }
    finally { setPlacing(false) }
  }

  const fetchOrders = async () => {
    try {
      const res = await apiFetch(`/api/orders?restaurantId=${selectedRestaurant}`)
      setOrders(res.orders || [])
    } catch (e: any) { toast.error(e.message) }
  }

  useEffect(() => {
    if (selectedRestaurant) fetchOrders()
  }, [selectedRestaurant])

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Restaurant POS</h2><p className="text-muted-foreground">Place and manage orders</p></div>
        <Select value={selectedRestaurant} onValueChange={setSelectedRestaurant}>
          <SelectTrigger className="w-56"><SelectValue placeholder="Select Restaurant" /></SelectTrigger>
          <SelectContent>{restaurants.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Menu Panel */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <Button key={cat} variant={activeCategory === cat ? 'default' : 'outline'} size="sm" onClick={() => setActiveCategory(cat)}>{cat}</Button>
            ))}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[60vh] overflow-y-auto">
            {filteredMenu.map(item => (
              <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => addToCart(item)}>
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{item.name}</p>
                      <p className="text-xs text-muted-foreground mt-1">{formatCurrency(item.price)}</p>
                    </div>
                    <Badge className={`ml-1 text-[10px] shrink-0 ${item.isVeg ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                      {item.isVeg ? 'VEG' : 'NON-VEG'}
                    </Badge>
                  </div>
                  {item.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.description}</p>}
                </CardContent>
              </Card>
            ))}
            {filteredMenu.length === 0 && <div className="col-span-full py-8 text-center text-muted-foreground">No menu items available</div>}
          </div>
        </div>

        {/* Cart Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-lg">Order Cart</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div><Label>Table</Label><Select value={tableNumber} onValueChange={setTableNumber}><SelectTrigger><SelectValue placeholder="Select table" /></SelectTrigger><SelectContent>{currentRestaurant?.tables.map(t => <SelectItem key={t.id} value={t.number}>Table {t.number} ({t.capacity}pax)</SelectItem>)}</SelectContent></Select></div>
              <Separator />
              {cart.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Cart is empty</p>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {cart.map(c => (
                    <div key={c.menuItem.id} className="flex items-center justify-between gap-2 p-2 bg-muted rounded-lg">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{c.menuItem.name}</p>
                        <p className="text-xs text-muted-foreground">{formatCurrency(c.menuItem.price)}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity - 1)}>-</Button>
                        <span className="w-6 text-center text-sm">{c.quantity}</span>
                        <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity + 1)}>+</Button>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-red-500" onClick={() => removeFromCart(c.menuItem.id)}><X className="h-3 w-3" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <Separator />
              <div className="space-y-1 text-sm">
                <div className="flex justify-between"><span>Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
                <div className="flex items-center justify-between gap-2"><span>Discount</span><Input type="number" className="w-24 h-7 text-sm" value={discount || ''} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} /></div>
                <div className="flex justify-between"><span>Tax (15%)</span><span>{formatCurrency(taxAmount)}</span></div>
                <Separator />
                <div className="flex justify-between font-bold text-base"><span>Total</span><span>{formatCurrency(total)}</span></div>
              </div>
              <div><Label>Notes</Label><Textarea className="h-16" value={orderNotes} onChange={e => setOrderNotes(e.target.value)} placeholder="Order notes..." /></div>
              <Button className="w-full" onClick={placeOrder} disabled={placing || cart.length === 0}>
                {placing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Place Order
              </Button>
            </CardContent>
          </Card>

          {/* Active Orders */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Active Orders</CardTitle>
                <Button variant="ghost" size="sm" onClick={fetchOrders}><RefreshCw className="h-4 w-4" /></Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-60 overflow-y-auto">
              {orders.filter(o => !['served', 'cancelled'].includes(o.status)).length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-2">No active orders</p>
              ) : orders.filter(o => !['served', 'cancelled'].includes(o.status)).map(o => (
                <div key={o.id} className="p-2 bg-muted rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{o.orderNumber}</span>
                    <Badge className={statusColors[o.status] || ''}>{o.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{o.items.length} items — {formatCurrency(o.totalAmount)}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// ============ Table Reservation ============
function TableReservation() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [selectedRestaurant, setSelectedRestaurant] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [reserveDialogOpen, setReserveDialogOpen] = useState(false)
  const [form, setForm] = useState({ tableId: '', guestName: '', time: '', partySize: '' })

  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const res = await apiFetch('/api/restaurants')
        const rList = res.restaurants || []
        setRestaurants(rList)
        if (rList.length > 0) setSelectedRestaurant(rList[0].id)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchRestaurants()
  }, [])

  const currentRestaurant = restaurants.find(r => r.id === selectedRestaurant)
  const tables = currentRestaurant?.tables || []

  const statusColorMap: Record<string, string> = {
    available: 'bg-emerald-100 border-emerald-300 text-emerald-800',
    occupied: 'bg-red-100 border-red-300 text-red-800',
    reserved: 'bg-amber-100 border-amber-300 text-amber-800',
    maintenance: 'bg-gray-100 border-gray-300 text-gray-800',
  }

  const handleReserve = () => {
    if (!form.tableId || !form.guestName) { toast.error('Table and guest name are required'); return }
    toast.success('Table reserved successfully')
    setReserveDialogOpen(false)
    setForm({ tableId: '', guestName: '', time: '', partySize: '' })
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Table Reservation</h2><p className="text-muted-foreground">Manage table bookings</p></div>
        <div className="flex gap-2">
          <Select value={selectedRestaurant} onValueChange={setSelectedRestaurant}>
            <SelectTrigger className="w-56"><SelectValue placeholder="Select Restaurant" /></SelectTrigger>
            <SelectContent>{restaurants.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
          </Select>
          <Button size="sm" onClick={() => setReserveDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Reserve Table</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MiniStat label="Available" value={tables.filter(t => t.status === 'available').length} color="bg-emerald-50" />
        <MiniStat label="Occupied" value={tables.filter(t => t.status === 'occupied').length} color="bg-red-50" />
        <MiniStat label="Reserved" value={tables.filter(t => t.status === 'reserved').length} color="bg-amber-50" />
      </div>

      {/* Visual Table Layout */}
      <Card>
        <CardHeader><CardTitle>Table Layout</CardTitle><CardDescription>Click on a table to manage its status</CardDescription></CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            {tables.map(table => (
              <button
                key={table.id}
                className={`p-3 rounded-lg border-2 text-center transition-colors ${statusColorMap[table.status] || 'bg-gray-100 border-gray-300'}`}
                onClick={() => setReserveDialogOpen(true)}
              >
                <p className="text-sm font-bold">T{table.number}</p>
                <p className="text-xs">{table.capacity}pax</p>
                <p className="text-[10px] capitalize mt-1">{table.status}</p>
              </button>
            ))}
            {tables.length === 0 && <div className="col-span-full py-8 text-center text-muted-foreground">No tables configured</div>}
          </div>
        </CardContent>
      </Card>

      {/* Table List */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Table</TableHead><TableHead>Capacity</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {tables.map(table => (
                <TableRow key={table.id}>
                  <TableCell className="font-medium">Table {table.number}</TableCell>
                  <TableCell>{table.capacity} persons</TableCell>
                  <TableCell><Badge className={statusColors[table.status] || ''}>{table.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-1 justify-end">
                      {table.status !== 'available' && (
                        <Button size="sm" variant="outline" onClick={async () => {
                          try {
                            await apiFetch('/api/restaurants', { method: 'PUT', body: JSON.stringify({ id: currentRestaurant?.id, tableId: table.id, tableStatus: 'available' }) })
                            toast.success('Table marked as available')
                            const res = await apiFetch('/api/restaurants')
                            setRestaurants(res.restaurants || [])
                          } catch (e: any) { toast.error(e.message) }
                        }}>Set Available</Button>
                      )}
                      {table.status === 'available' && (
                        <Button size="sm" variant="outline" onClick={async () => {
                          try {
                            await apiFetch('/api/restaurants', { method: 'PUT', body: JSON.stringify({ id: currentRestaurant?.id, tableId: table.id, tableStatus: 'occupied' }) })
                            toast.success('Table marked as occupied')
                            const res = await apiFetch('/api/restaurants')
                            setRestaurants(res.restaurants || [])
                          } catch (e: any) { toast.error(e.message) }
                        }}>Set Occupied</Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={reserveDialogOpen} onOpenChange={setReserveDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Reserve Table</DialogTitle><DialogDescription>Book a table for a guest</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Table *</Label><Select value={form.tableId} onValueChange={v => setForm({ ...form, tableId: v })}><SelectTrigger><SelectValue placeholder="Select table" /></SelectTrigger><SelectContent>{tables.filter(t => t.status === 'available').map(t => <SelectItem key={t.id} value={t.id}>Table {t.number} ({t.capacity}pax)</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Guest Name *</Label><Input value={form.guestName} onChange={e => setForm({ ...form, guestName: e.target.value })} placeholder="Guest name" /></div>
            <div><Label>Reservation Time</Label><Input type="datetime-local" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} /></div>
            <div><Label>Party Size</Label><Input type="number" value={form.partySize} onChange={e => setForm({ ...form, partySize: e.target.value })} placeholder="Number of guests" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReserveDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleReserve}>Reserve</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ QR Menu ============
function QRMenu() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [selectedRestaurant, setSelectedRestaurant] = useState<string>('')
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState('Starters')

  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const res = await apiFetch('/api/restaurants')
        const rList = res.restaurants || []
        setRestaurants(rList)
        if (rList.length > 0) setSelectedRestaurant(rList[0].id)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchRestaurants()
  }, [])

  const currentRestaurant = restaurants.find(r => r.id === selectedRestaurant)
  const menuItems = currentRestaurant?.menuItems || []
  const categories = ['Starters', 'Main Course', 'Desserts', 'Beverages']
  const filteredItems = menuItems.filter(m => {
    const cat = m.category || 'Other'
    if (activeCategory === 'Starters') return cat.toLowerCase().includes('starter') || cat.toLowerCase().includes('appetizer')
    if (activeCategory === 'Main Course') return cat.toLowerCase().includes('main') || cat.toLowerCase().includes('course')
    if (activeCategory === 'Desserts') return cat.toLowerCase().includes('dessert') || cat.toLowerCase().includes('sweet')
    if (activeCategory === 'Beverages') return cat.toLowerCase().includes('beverage') || cat.toLowerCase().includes('drink')
    return true
  })

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">QR Menu</h2><p className="text-muted-foreground">Mobile-friendly menu display</p></div>
        <Select value={selectedRestaurant} onValueChange={setSelectedRestaurant}>
          <SelectTrigger className="w-56"><SelectValue placeholder="Select Restaurant" /></SelectTrigger>
          <SelectContent>{restaurants.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <div className="flex gap-2 border-b pb-2 overflow-x-auto">
        {categories.map(cat => (
          <Button key={cat} variant={activeCategory === cat ? 'default' : 'ghost'} size="sm" onClick={() => setActiveCategory(cat)} className="shrink-0">{cat}</Button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map(item => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{item.name}</h3>
                    <span className={`inline-block w-3 h-3 rounded-sm ${item.isVeg ? 'bg-emerald-500' : 'bg-red-500'}`} />
                  </div>
                  {item.description && <p className="text-sm text-muted-foreground mt-1">{item.description}</p>}
                  <p className="text-lg font-bold mt-2">{formatCurrency(item.price)}</p>
                  {item.preparationTime && <p className="text-xs text-muted-foreground">~{item.preparationTime} min</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {filteredItems.length === 0 && (
          <div className="col-span-full"><EmptyState title="No items" description={`No items found in ${activeCategory}`} /></div>
        )}
      </div>
    </div>
  )
}

// ============ Kitchen Order Ticket ============
function KitchenOrderTicket() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  const fetchOrders = async () => {
    try {
      const res = await apiFetch('/api/orders?status=pending')
      const confirmedRes = await apiFetch('/api/orders?status=confirmed')
      const preparingRes = await apiFetch('/api/orders?status=preparing')
      const all = [...(res.orders || []), ...(confirmedRes.orders || []), ...(preparingRes.orders || [])]
      all.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
      setOrders(all)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => {
    fetchOrders()
    const interval = setInterval(fetchOrders, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      await apiFetch('/api/orders', { method: 'PUT', body: JSON.stringify({ id: orderId, status: newStatus }) })
      toast.success(`Order marked as ${newStatus}`)
      fetchOrders()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  const statusProgression: Record<string, string[]> = {
    pending: ['confirmed'],
    confirmed: ['preparing'],
    preparing: ['ready'],
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Kitchen Order Tickets</h2><p className="text-muted-foreground">Active orders — auto-refreshes every 30s</p></div>
        <Button variant="outline" size="sm" onClick={fetchOrders}><RefreshCw className="h-4 w-4 mr-1" />Refresh</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {orders.length === 0 ? (
          <div className="col-span-full"><EmptyState title="No active orders" description="All caught up!" /></div>
        ) : orders.map(order => (
          <Card key={order.id} className="hover:shadow-md">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{order.orderNumber}</CardTitle>
                <Badge className={statusColors[order.status] || ''}>{order.status}</Badge>
              </div>
              <CardDescription>{formatDateTime(order.createdAt)}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1">
                {order.items.map((item, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="font-medium">{item.quantity}x {item.menuItem?.name || 'Item'}</span>
                    <span className="text-muted-foreground">{formatCurrency(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>
              {order.notes && <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded">Note: {order.notes}</p>}
              <Separator />
              <div className="flex items-center justify-between">
                <span className="font-bold">{formatCurrency(order.totalAmount)}</span>
                <div className="flex gap-1">
                  {(statusProgression[order.status] || []).map(nextStatus => (
                    <Button key={nextStatus} size="sm" onClick={() => handleStatusUpdate(order.id, nextStatus)} className="capitalize">
                      {nextStatus === 'confirmed' && 'Confirm'}
                      {nextStatus === 'preparing' && 'Preparing'}
                      {nextStatus === 'ready' && 'Ready'}
                      {!['confirmed', 'preparing', 'ready'].includes(nextStatus) && nextStatus}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

// ============ Room Service ============
function RoomService() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [selectedRoom, setSelectedRoom] = useState<string>('')
  const [selectedRestaurant, setSelectedRestaurant] = useState<string>('')
  const [cart, setCart] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [placing, setPlacing] = useState(false)
  const [notes, setNotes] = useState('')

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [restRes, roomsRes] = await Promise.all([apiFetch('/api/restaurants'), apiFetch('/api/rooms')])
        setRestaurants(restRes.restaurants || [])
        const occupied = (roomsRes.rooms || []).filter((r: any) => r.status === 'occupied')
        setRooms(occupied)
        if (restRes.restaurants?.length > 0) setSelectedRestaurant(restRes.restaurants[0].id)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchData()
  }, [])

  const currentRestaurant = restaurants.find(r => r.id === selectedRestaurant)
  const menuItems = currentRestaurant?.menuItems || []

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.menuItem.id === item.id)
      if (existing) return prev.map(c => c.menuItem.id === item.id ? { ...c, quantity: c.quantity + 1 } : c)
      return [...prev, { menuItem: item, quantity: 1, notes: '' }]
    })
  }

  const updateQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) { setCart(prev => prev.filter(c => c.menuItem.id !== itemId)); return }
    setCart(prev => prev.map(c => c.menuItem.id === itemId ? { ...c, quantity: qty } : c))
  }

  const total = cart.reduce((s, c) => s + c.menuItem.price * c.quantity, 0)

  const placeOrder = async () => {
    if (!selectedRoom) { toast.error('Select a room'); return }
    if (cart.length === 0) { toast.error('Add items to cart'); return }
    setPlacing(true)
    try {
      await apiFetch('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          restaurantId: selectedRestaurant,
          type: 'room_service',
          items: cart.map(c => ({ menuItemId: c.menuItem.id, quantity: c.quantity, price: c.menuItem.price, notes: c.notes })),
          notes: `Room: ${rooms.find((r: any) => r.id === selectedRoom)?.number}. ${notes}`,
        }),
      })
      toast.success('Room service order placed!')
      setCart([])
      setNotes('')
    } catch (e: any) { toast.error(e.message) }
    finally { setPlacing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Room Service</h2><p className="text-muted-foreground">Order food to guest rooms</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex gap-3">
            <div className="flex-1"><Label>Room</Label><Select value={selectedRoom} onValueChange={setSelectedRoom}><SelectTrigger><SelectValue placeholder="Select occupied room" /></SelectTrigger><SelectContent>{rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>Room {r.number}</SelectItem>)}</SelectContent></Select></div>
            <div className="flex-1"><Label>Restaurant</Label><Select value={selectedRestaurant} onValueChange={setSelectedRestaurant}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{restaurants.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select></div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[50vh] overflow-y-auto">
            {menuItems.map(item => (
              <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => addToCart(item)}>
                <CardContent className="p-3">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{formatCurrency(item.price)}</p>
                  <Badge className={`mt-1 text-[10px] ${item.isVeg ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                    {item.isVeg ? 'VEG' : 'NON-VEG'}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-lg">Cart</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {cart.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Add items to cart</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {cart.map(c => (
                  <div key={c.menuItem.id} className="flex items-center justify-between gap-2 p-2 bg-muted rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{c.menuItem.name}</p>
                      <p className="text-xs text-muted-foreground">{formatCurrency(c.menuItem.price * c.quantity)}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity - 1)}>-</Button>
                      <span className="w-6 text-center text-sm">{c.quantity}</span>
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity + 1)}>+</Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <Separator />
            <div className="flex justify-between font-bold"><span>Total</span><span>{formatCurrency(total)}</span></div>
            <div><Label>Notes</Label><Textarea className="h-16" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Special instructions..." /></div>
            <Button className="w-full" onClick={placeOrder} disabled={placing || cart.length === 0 || !selectedRoom}>
              {placing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Place Room Service Order
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============ Bar POS ============
function BarPOS() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [selectedBar, setSelectedBar] = useState<string>('')
  const [cart, setCart] = useState<CartItem[]>([])
  const [discount, setDiscount] = useState(0)
  const [orderNotes, setOrderNotes] = useState('')
  const [loading, setLoading] = useState(true)
  const [placing, setPlacing] = useState(false)
  const [happyHour, setHappyHour] = useState(false)

  useEffect(() => {
    const fetchBars = async () => {
      try {
        const res = await apiFetch('/api/restaurants?type=bar')
        const rList = res.restaurants || []
        setRestaurants(rList)
        if (rList.length === 0) {
          const allRes = await apiFetch('/api/restaurants')
          const all = allRes.restaurants || []
          setRestaurants(all)
          if (all.length > 0) setSelectedBar(all[0].id)
        } else {
          setSelectedBar(rList[0].id)
        }
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    fetchBars()
  }, [])

  const currentBar = restaurants.find(r => r.id === selectedBar)
  const menuItems = (currentBar?.menuItems || []).filter(m => {
    const cat = (m.category || '').toLowerCase()
    return cat.includes('beverage') || cat.includes('drink') || cat.includes('cocktail') || cat.includes('beer') || cat.includes('wine') || cat.includes('spirit') || true
  })

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.menuItem.id === item.id)
      if (existing) return prev.map(c => c.menuItem.id === item.id ? { ...c, quantity: c.quantity + 1 } : c)
      return [...prev, { menuItem: item, quantity: 1, notes: '' }]
    })
  }

  const updateQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) { setCart(prev => prev.filter(c => c.menuItem.id !== itemId)); return }
    setCart(prev => prev.map(c => c.menuItem.id === itemId ? { ...c, quantity: qty } : c))
  }

  const removeFromCart = (itemId: string) => setCart(prev => prev.filter(c => c.menuItem.id !== itemId))

  const getItemPrice = (item: MenuItem) => happyHour ? item.price * 0.8 : item.price
  const subtotal = cart.reduce((s, c) => s + getItemPrice(c.menuItem) * c.quantity, 0)
  const taxAmount = (subtotal - discount) * 0.15
  const total = subtotal - discount + taxAmount

  const placeOrder = async () => {
    if (cart.length === 0) { toast.error('Cart is empty'); return }
    if (!selectedBar) { toast.error('Select a bar'); return }
    setPlacing(true)
    try {
      await apiFetch('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          restaurantId: selectedBar,
          type: 'dine_in',
          items: cart.map(c => ({ menuItemId: c.menuItem.id, quantity: c.quantity, price: getItemPrice(c.menuItem), notes: c.notes })),
          discount,
          notes: orderNotes,
        }),
      })
      toast.success('Order placed!')
      setCart([])
      setDiscount(0)
      setOrderNotes('')
    } catch (e: any) { toast.error(e.message) }
    finally { setPlacing(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Bar POS</h2><p className="text-muted-foreground">Beverage order management</p></div>
        <div className="flex gap-2 items-center">
          <Select value={selectedBar} onValueChange={setSelectedBar}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Select Bar" /></SelectTrigger>
            <SelectContent>{restaurants.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
          </Select>
          <Button variant={happyHour ? 'default' : 'outline'} size="sm" onClick={() => setHappyHour(!happyHour)}>
            {happyHour ? '🎉 Happy Hour ON' : 'Happy Hour OFF'}
          </Button>
        </div>
      </div>

      {happyHour && (
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-3"><p className="text-sm font-medium text-amber-800">Happy Hour Active — 20% off all beverages!</p></CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[60vh] overflow-y-auto">
            {menuItems.map(item => (
              <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => addToCart(item)}>
                <CardContent className="p-3">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-xs">{formatCurrency(getItemPrice(item))}</p>
                    {happyHour && <p className="text-xs line-through text-muted-foreground">{formatCurrency(item.price)}</p>}
                  </div>
                  {item.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{item.description}</p>}
                </CardContent>
              </Card>
            ))}
            {menuItems.length === 0 && <div className="col-span-full py-8 text-center text-muted-foreground">No beverages available</div>}
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-lg">Cart</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {cart.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Cart is empty</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {cart.map(c => (
                  <div key={c.menuItem.id} className="flex items-center justify-between gap-2 p-2 bg-muted rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{c.menuItem.name}</p>
                      <p className="text-xs text-muted-foreground">{formatCurrency(getItemPrice(c.menuItem))}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity - 1)}>-</Button>
                      <span className="w-6 text-center text-sm">{c.quantity}</span>
                      <Button size="sm" variant="outline" className="h-6 w-6 p-0" onClick={() => updateQuantity(c.menuItem.id, c.quantity + 1)}>+</Button>
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-red-500" onClick={() => removeFromCart(c.menuItem.id)}><X className="h-3 w-3" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <Separator />
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span>Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
              <div className="flex items-center justify-between gap-2"><span>Discount</span><Input type="number" className="w-24 h-7 text-sm" value={discount || ''} onChange={e => setDiscount(parseFloat(e.target.value) || 0)} /></div>
              <div className="flex justify-between"><span>Tax (15%)</span><span>{formatCurrency(taxAmount)}</span></div>
              <Separator />
              <div className="flex justify-between font-bold text-base"><span>Total</span><span>{formatCurrency(total)}</span></div>
            </div>
            <div><Label>Notes</Label><Textarea className="h-16" value={orderNotes} onChange={e => setOrderNotes(e.target.value)} placeholder="Order notes..." /></div>
            <Button className="w-full" onClick={placeOrder} disabled={placing || cart.length === 0}>
              {placing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Place Order
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ============ Main Component ============
export default function RestaurantPOSModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'pos': return <RestaurantPOS />
    case 'table-reservation': return <TableReservation />
    case 'qr-menu': return <QRMenu />
    case 'kot': return <KitchenOrderTicket />
    case 'room-service': return <RoomService />
    case 'bar-pos': return <BarPOS />
    default: return <EmptyState title="Unknown Sub-module" description={`Sub-module "${subModule}" not found`} />
  }
}
