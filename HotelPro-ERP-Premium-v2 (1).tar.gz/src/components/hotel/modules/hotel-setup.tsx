'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, StatusRow, Pagination, LoadingSkeleton, EmptyState, useCrud, CrudTableModule,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2,
} from '@/components/hotel/shared'
import { BedDouble, DollarSign, UserRound, Clock, CalendarCheck, DoorOpen, TrendingUp, Sparkles, Receipt, ArrowDownRight, ArrowUpRight, Wrench, XCircle, CheckCircle2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend } from 'recharts'

// ============================================================
// Hotel Information (subModule='hotel-info')
// ============================================================
function HotelInformation() {
  const [hotel, setHotel] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [editOpen, setEditOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState<any>({})

  const fetchHotel = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/hotel-setup?resource=hotel')
      setHotel(res.hotel)
      setFormData(res.hotel || {})
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchHotel() }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      const { id, createdAt, updatedAt, buildings, rooms, reservations, guests, ...data } = formData
      await apiFetch('/api/hotel-setup', {
        method: 'POST',
        body: JSON.stringify({ resource: 'hotel', data }),
      })
      toast.success('Hotel information updated')
      setEditOpen(false)
      fetchHotel()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />
  if (!hotel) return <EmptyState title="No Hotel Found" description="No hotel information has been set up yet." action="Setup Hotel" onAction={() => setEditOpen(true)} />

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Hotel Information</h2>
          <p className="text-muted-foreground">Manage your hotel details</p>
        </div>
        <Button onClick={() => { setFormData(hotel); setEditOpen(true) }}><Edit className="h-4 w-4 mr-1" />Edit</Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div><Label className="text-muted-foreground">Hotel Name</Label><p className="font-medium text-lg">{hotel.name}</p></div>
            <div><Label className="text-muted-foreground">Code</Label><p className="font-medium">{hotel.code}</p></div>
            <div><Label className="text-muted-foreground">Star Rating</Label><p className="font-medium">{'★'.repeat(hotel.starRating || 5)}</p></div>
            <div><Label className="text-muted-foreground">Address</Label><p className="font-medium">{hotel.address || '-'}</p></div>
            <div><Label className="text-muted-foreground">City</Label><p className="font-medium">{hotel.city || '-'}</p></div>
            <div><Label className="text-muted-foreground">Country</Label><p className="font-medium">{hotel.country || '-'}</p></div>
            <div><Label className="text-muted-foreground">Phone</Label><p className="font-medium">{hotel.phone || '-'}</p></div>
            <div><Label className="text-muted-foreground">Email</Label><p className="font-medium">{hotel.email || '-'}</p></div>
            <div><Label className="text-muted-foreground">Website</Label><p className="font-medium">{hotel.website || '-'}</p></div>
            <div><Label className="text-muted-foreground">Currency</Label><p className="font-medium">{hotel.currency || 'BDT'}</p></div>
            <div><Label className="text-muted-foreground">Tax Rate</Label><p className="font-medium">{hotel.taxRate}%</p></div>
            <div><Label className="text-muted-foreground">VAT Rate</Label><p className="font-medium">{hotel.vatRate}%</p></div>
          </div>
        </CardContent>
      </Card>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Edit Hotel Information</DialogTitle><DialogDescription>Update your hotel details below.</DialogDescription></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-2"><Label>Hotel Name</Label><Input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Code</Label><Input value={formData.code || ''} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
            <div className="space-y-2 md:col-span-2"><Label>Address</Label><Input value={formData.address || ''} onChange={e => setFormData({ ...formData, address: e.target.value })} /></div>
            <div className="space-y-2"><Label>City</Label><Input value={formData.city || ''} onChange={e => setFormData({ ...formData, city: e.target.value })} /></div>
            <div className="space-y-2"><Label>Country</Label><Input value={formData.country || ''} onChange={e => setFormData({ ...formData, country: e.target.value })} /></div>
            <div className="space-y-2"><Label>Phone</Label><Input value={formData.phone || ''} onChange={e => setFormData({ ...formData, phone: e.target.value })} /></div>
            <div className="space-y-2"><Label>Email</Label><Input value={formData.email || ''} onChange={e => setFormData({ ...formData, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Website</Label><Input value={formData.website || ''} onChange={e => setFormData({ ...formData, website: e.target.value })} /></div>
            <div className="space-y-2"><Label>Star Rating</Label><Select value={String(formData.starRating || 5)} onValueChange={v => setFormData({ ...formData, starRating: Number(v) })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4,5].map(n=><SelectItem key={n} value={String(n)}>{'★'.repeat(n)}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label>Currency</Label><Input value={formData.currency || 'BDT'} onChange={e => setFormData({ ...formData, currency: e.target.value })} /></div>
            <div className="space-y-2"><Label>Tax Rate (%)</Label><Input type="number" step="0.1" value={formData.taxRate ?? 15} onChange={e => setFormData({ ...formData, taxRate: Number(e.target.value) })} /></div>
            <div className="space-y-2"><Label>VAT Rate (%)</Label><Input type="number" step="0.1" value={formData.vatRate ?? 5} onChange={e => setFormData({ ...formData, vatRate: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Building & Floor (subModule='buildings')
// ============================================================
function BuildingFloor() {
  const [buildings, setBuildings] = useState<any[]>([])
  const [floors, setFloors] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [dialogType, setDialogType] = useState<'building' | 'floor'>('building')
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [deleteType, setDeleteType] = useState<'building' | 'floor'>('building')
  const [buildingForm, setBuildingForm] = useState({ name: '', code: '', floors: 1 })
  const [floorForm, setFloorForm] = useState({ name: '', number: 1, buildingId: '', hotelId: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [bRes, fRes] = await Promise.all([
        apiFetch('/api/hotel-setup?resource=buildings'),
        apiFetch('/api/hotel-setup?resource=floors'),
      ])
      setBuildings(bRes.buildings || [])
      setFloors(fRes.floors || [])
      // Set default hotelId for floor form
      const hotelRes = await apiFetch('/api/hotel-setup?resource=hotel')
      if (hotelRes.hotel) setFloorForm(prev => ({ ...prev, hotelId: hotelRes.hotel.id }))
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const openCreateBuilding = () => {
    setDialogType('building')
    setEditItem(null)
    setBuildingForm({ name: '', code: '', floors: 1 })
    setDialogOpen(true)
  }

  const openEditBuilding = (b: any) => {
    setDialogType('building')
    setEditItem(b)
    setBuildingForm({ name: b.name, code: b.code, floors: b.floors })
    setDialogOpen(true)
  }

  const openCreateFloor = () => {
    setDialogType('floor')
    setEditItem(null)
    setFloorForm(prev => ({ ...prev, name: '', number: 1, buildingId: buildings[0]?.id || '' }))
    setDialogOpen(true)
  }

  const openEditFloor = (f: any) => {
    setDialogType('floor')
    setEditItem(f)
    setFloorForm({ name: f.name, number: f.number, buildingId: f.buildingId, hotelId: f.hotelId })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (dialogType === 'building') {
        if (editItem) {
          await apiFetch('/api/hotel-setup', {
            method: 'PUT',
            body: JSON.stringify({ resource: 'building', id: editItem.id, data: buildingForm }),
          })
        } else {
          const hotelRes = await apiFetch('/api/hotel-setup?resource=hotel')
          await apiFetch('/api/hotel-setup', {
            method: 'POST',
            body: JSON.stringify({ resource: 'building', data: { ...buildingForm, hotelId: hotelRes.hotel?.id } }),
          })
        }
      } else {
        if (editItem) {
          await apiFetch('/api/hotel-setup', {
            method: 'PUT',
            body: JSON.stringify({ resource: 'floor', id: editItem.id, data: floorForm }),
          })
        } else {
          await apiFetch('/api/hotel-setup', {
            method: 'POST',
            body: JSON.stringify({ resource: 'floor', data: floorForm }),
          })
        }
      }
      toast.success(editItem ? 'Updated successfully' : 'Created successfully')
      setDialogOpen(false)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleDelete = async () => {
    try {
      if (deleteType === 'building') {
        await apiFetch(`/api/hotel-setup?resource=building&id=${deleteId}`, { method: 'DELETE' })
      } else {
        await apiFetch(`/api/hotel-setup?resource=floor&id=${deleteId}`, { method: 'DELETE' })
      }
      toast.success('Deleted successfully')
      setDeleteId(null)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const filteredBuildings = buildings.filter(b =>
    !search || b.name.toLowerCase().includes(search.toLowerCase()) || b.code.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Buildings & Floors</h2><p className="text-muted-foreground">Manage building and floor configuration</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-48" value={search} onChange={e => setSearch(e.target.value)} /></div>
          <Button size="sm" onClick={openCreateFloor}><Plus className="h-4 w-4 mr-1" />Add Floor</Button>
          <Button size="sm" onClick={openCreateBuilding}><Plus className="h-4 w-4 mr-1" />Add Building</Button>
        </div>
      </div>

      {/* Buildings Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Floors</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBuildings.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No buildings found</TableCell></TableRow>
              ) : filteredBuildings.map(b => (
                <TableRow key={b.id}>
                  <TableCell className="font-medium">{b.name}</TableCell>
                  <TableCell>{b.code}</TableCell>
                  <TableCell>{b.floors}</TableCell>
                  <TableCell><Badge className={b.isActive ? statusColors.active : statusColors.inactive}>{b.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditBuilding(b)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => { setDeleteId(b.id); setDeleteType('building') }}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Floors Grouped by Building */}
      {buildings.map(b => {
        const bFloors = floors.filter(f => f.buildingId === b.id)
        if (bFloors.length === 0) return null
        return (
          <Card key={b.id}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{b.name} - Floors</CardTitle>
              <CardDescription>{bFloors.length} floor(s)</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Floor Name</TableHead>
                    <TableHead>Number</TableHead>
                    <TableHead>Rooms</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bFloors.map(f => (
                    <TableRow key={f.id}>
                      <TableCell className="font-medium">{f.name}</TableCell>
                      <TableCell>{f.number}</TableCell>
                      <TableCell>{f._count?.rooms || 0}</TableCell>
                      <TableCell><Badge className={f.isActive ? statusColors.active : statusColors.inactive}>{f.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditFloor(f)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => { setDeleteId(f.id); setDeleteType('floor') }}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )
      })}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editItem ? 'Edit' : 'New'} {dialogType === 'building' ? 'Building' : 'Floor'}</DialogTitle>
            <DialogDescription>Fill in the details below.</DialogDescription>
          </DialogHeader>
          {dialogType === 'building' ? (
            <div className="space-y-4 py-2">
              <div className="space-y-2"><Label>Name</Label><Input value={buildingForm.name} onChange={e => setBuildingForm({ ...buildingForm, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Code</Label><Input value={buildingForm.code} onChange={e => setBuildingForm({ ...buildingForm, code: e.target.value })} /></div>
              <div className="space-y-2"><Label>Number of Floors</Label><Input type="number" value={buildingForm.floors} onChange={e => setBuildingForm({ ...buildingForm, floors: Number(e.target.value) })} /></div>
            </div>
          ) : (
            <div className="space-y-4 py-2">
              <div className="space-y-2"><Label>Floor Name</Label><Input value={floorForm.name} onChange={e => setFloorForm({ ...floorForm, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Floor Number</Label><Input type="number" value={floorForm.number} onChange={e => setFloorForm({ ...floorForm, number: Number(e.target.value) })} /></div>
              <div className="space-y-2">
                <Label>Building</Label>
                <Select value={floorForm.buildingId} onValueChange={v => setFloorForm({ ...floorForm, buildingId: v })}>
                  <SelectTrigger><SelectValue placeholder="Select building" /></SelectTrigger>
                  <SelectContent>{buildings.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this {deleteType}? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Room Type (subModule='room-types')
// ============================================================
function RoomTypes() {
  return (
    <CrudTableModule
      title="Room Types"
      description="Manage room type configurations"
      apiPath="/api/room-types"
      itemName="Room Type"
      columns={['Name', 'Code', 'Base Price', 'Max Occupancy', 'Rooms', 'Status', 'Actions']}
      renderRow={(item: any) => (
        <TableRow key={item.id}>
          <TableCell className="font-medium">{item.name}</TableCell>
          <TableCell>{item.code}</TableCell>
          <TableCell>{formatCurrency(item.basePrice)}</TableCell>
          <TableCell>{item.maxOccupancy}</TableCell>
          <TableCell>{item._count?.rooms || 0}</TableCell>
          <TableCell><Badge className={item.isActive ? statusColors.active : statusColors.inactive}>{item.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
          <TableCell>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => { /* edit handled by CrudTableModule */ }}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>
      )}
      formFields={(formData: any, setFormData: any) => (
        <>
          <div className="space-y-2"><Label>Name</Label><Input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
          <div className="space-y-2"><Label>Code</Label><Input value={formData.code || ''} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
          <div className="space-y-2"><Label>Base Price</Label><Input type="number" value={formData.basePrice ?? 0} onChange={e => setFormData({ ...formData, basePrice: Number(e.target.value) })} /></div>
          <div className="space-y-2"><Label>Max Occupancy</Label><Input type="number" value={formData.maxOccupancy ?? 2} onChange={e => setFormData({ ...formData, maxOccupancy: Number(e.target.value) })} /></div>
        </>
      )}
      defaultValues={{ name: '', code: '', basePrice: 0, maxOccupancy: 2 }}
    />
  )
}

// ============================================================
// Room Category (subModule='room-categories')
// ============================================================
function RoomCategories() {
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formData, setFormData] = useState({ name: '', code: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/hotel-setup?resource=room-categories')
      setCategories(res.categories || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const openCreate = () => { setEditItem(null); setFormData({ name: '', code: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name, code: item.code }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (editItem) {
        await apiFetch('/api/hotel-setup', {
          method: 'PUT',
          body: JSON.stringify({ resource: 'room-category', id: editItem.id, data: formData }),
        })
      } else {
        const hotelRes = await apiFetch('/api/hotel-setup?resource=hotel')
        await apiFetch('/api/hotel-setup', {
          method: 'POST',
          body: JSON.stringify({ resource: 'room-category', data: { ...formData, hotelId: hotelRes.hotel?.id } }),
        })
      }
      toast.success(editItem ? 'Updated successfully' : 'Created successfully')
      setDialogOpen(false)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleDelete = async () => {
    try {
      await apiFetch(`/api/hotel-setup?resource=room-category&id=${deleteId}`, { method: 'DELETE' })
      toast.success('Deleted successfully')
      setDeleteId(null)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const filtered = categories.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.code.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Categories</h2><p className="text-muted-foreground">Manage room categories</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-48" value={search} onChange={e => setSearch(e.target.value)} /></div>
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Category</Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Status</TableHead><TableHead className="w-[100px]">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No categories found</TableCell></TableRow>
              ) : filtered.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell>{c.code}</TableCell>
                  <TableCell><Badge className={c.isActive ? statusColors.active : statusColors.inactive}>{c.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEdit(c)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(c.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Room Category</DialogTitle><DialogDescription>Fill in the details below.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this category? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Bed Type (subModule='bed-types')
// ============================================================
function BedTypes() {
  return (
    <CrudTableModule
      title="Bed Types"
      description="Manage bed type configurations"
      apiPath="/api/bed-types"
      itemName="Bed Type"
      columns={['Name', 'Code', 'Size', 'Rooms', 'Status', 'Actions']}
      renderRow={(item: any) => (
        <TableRow key={item.id}>
          <TableCell className="font-medium">{item.name}</TableCell>
          <TableCell>{item.code}</TableCell>
          <TableCell>{item.size || '-'}</TableCell>
          <TableCell>{item._count?.rooms || 0}</TableCell>
          <TableCell><Badge className={item.isActive ? statusColors.active : statusColors.inactive}>{item.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
          <TableCell>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>
      )}
      formFields={(formData: any, setFormData: any) => (
        <>
          <div className="space-y-2"><Label>Name</Label><Input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
          <div className="space-y-2"><Label>Code</Label><Input value={formData.code || ''} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
          <div className="space-y-2"><Label>Size</Label><Input value={formData.size || ''} onChange={e => setFormData({ ...formData, size: e.target.value })} placeholder="e.g., King, Queen, Twin" /></div>
        </>
      )}
      defaultValues={{ name: '', code: '', size: '' }}
    />
  )
}

// ============================================================
// Room View (subModule='room-views')
// ============================================================
function RoomViews() {
  return (
    <CrudTableModule
      title="Room Views"
      description="Manage room view configurations"
      apiPath="/api/room-views"
      itemName="Room View"
      columns={['Name', 'Code', 'Rooms', 'Status', 'Actions']}
      renderRow={(item: any) => (
        <TableRow key={item.id}>
          <TableCell className="font-medium">{item.name}</TableCell>
          <TableCell>{item.code}</TableCell>
          <TableCell>{item._count?.rooms || 0}</TableCell>
          <TableCell><Badge className={item.isActive ? statusColors.active : statusColors.inactive}>{item.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
          <TableCell>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>
      )}
      formFields={(formData: any, setFormData: any) => (
        <>
          <div className="space-y-2"><Label>Name</Label><Input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
          <div className="space-y-2"><Label>Code</Label><Input value={formData.code || ''} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
        </>
      )}
      defaultValues={{ name: '', code: '' }}
    />
  )
}

// ============================================================
// Amenities (subModule='amenities')
// ============================================================
function Amenities() {
  return (
    <CrudTableModule
      title="Amenities"
      description="Manage room amenities"
      apiPath="/api/amenities"
      itemName="Amenity"
      columns={['Name', 'Code', 'Category', 'Icon', 'Rooms', 'Status', 'Actions']}
      renderRow={(item: any) => (
        <TableRow key={item.id}>
          <TableCell className="font-medium">{item.name}</TableCell>
          <TableCell>{item.code}</TableCell>
          <TableCell>{item.category || '-'}</TableCell>
          <TableCell>{item.icon || '-'}</TableCell>
          <TableCell>{item._count?.roomAmenities || 0}</TableCell>
          <TableCell><Badge className={item.isActive ? statusColors.active : statusColors.inactive}>{item.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
          <TableCell>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>
      )}
      formFields={(formData: any, setFormData: any) => (
        <>
          <div className="space-y-2"><Label>Name</Label><Input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
          <div className="space-y-2"><Label>Code</Label><Input value={formData.code || ''} onChange={e => setFormData({ ...formData, code: e.target.value })} /></div>
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={formData.category || 'general'} onValueChange={v => setFormData({ ...formData, category: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="bathroom">Bathroom</SelectItem>
                <SelectItem value="entertainment">Entertainment</SelectItem>
                <SelectItem value="comfort">Comfort</SelectItem>
                <SelectItem value="safety">Safety</SelectItem>
                <SelectItem value="kitchen">Kitchen</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2"><Label>Icon</Label><Input value={formData.icon || ''} onChange={e => setFormData({ ...formData, icon: e.target.value })} placeholder="e.g., wifi, tv, ac" /></div>
        </>
      )}
      defaultValues={{ name: '', code: '', category: 'general', icon: '' }}
    />
  )
}

// ============================================================
// Seasonal/Weekend Pricing (subModule='pricing')
// ============================================================
function SeasonalPricing() {
  const [pricings, setPricings] = useState<any[]>([])
  const [roomTypes, setRoomTypes] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formData, setFormData] = useState({ name: '', roomTypeId: '', startDate: '', endDate: '', priceModifier: 0, type: 'percentage' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [pRes, rtRes] = await Promise.all([
        apiFetch('/api/hotel-setup?resource=seasonal-pricing'),
        apiFetch('/api/room-types'),
      ])
      setPricings(pRes.pricings || [])
      setRoomTypes(rtRes.roomTypes || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const openCreate = () => { setEditItem(null); setFormData({ name: '', roomTypeId: '', startDate: '', endDate: '', priceModifier: 0, type: 'percentage' }); setDialogOpen(true) }
  const openEdit = (item: any) => {
    setEditItem(item)
    setFormData({
      name: item.name,
      roomTypeId: item.roomTypeId,
      startDate: item.startDate ? new Date(item.startDate).toISOString().split('T')[0] : '',
      endDate: item.endDate ? new Date(item.endDate).toISOString().split('T')[0] : '',
      priceModifier: item.priceModifier,
      type: item.type,
    })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      if (editItem) {
        await apiFetch('/api/hotel-setup', {
          method: 'PUT',
          body: JSON.stringify({ resource: 'seasonal-pricing', id: editItem.id, data: { ...formData, startDate: new Date(formData.startDate), endDate: new Date(formData.endDate) } }),
        })
      } else {
        await apiFetch('/api/hotel-setup', {
          method: 'POST',
          body: JSON.stringify({ resource: 'seasonal-pricing', data: { ...formData, startDate: new Date(formData.startDate), endDate: new Date(formData.endDate) } }),
        })
      }
      toast.success(editItem ? 'Updated successfully' : 'Created successfully')
      setDialogOpen(false)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleDelete = async () => {
    try {
      await apiFetch(`/api/hotel-setup?resource=seasonal-pricing&id=${deleteId}`, { method: 'DELETE' })
      toast.success('Deleted successfully')
      setDeleteId(null)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Seasonal / Weekend Pricing</h2><p className="text-muted-foreground">Manage seasonal pricing rules</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Pricing Rule</Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Room Type</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>End Date</TableHead>
                <TableHead>Modifier</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pricings.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No pricing rules found</TableCell></TableRow>
              ) : pricings.map(p => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>{p.roomType?.name || '-'}</TableCell>
                  <TableCell>{formatDate(p.startDate)}</TableCell>
                  <TableCell>{formatDate(p.endDate)}</TableCell>
                  <TableCell>{p.type === 'percentage' ? `${p.priceModifier}%` : formatCurrency(p.priceModifier)}</TableCell>
                  <TableCell><Badge className={statusColors[p.type === 'percentage' ? 'normal' : 'active']}>{p.type}</Badge></TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEdit(p)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(p.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Pricing Rule</DialogTitle><DialogDescription>Set seasonal or weekend pricing rules.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="e.g., Summer Season, Weekend Rate" /></div>
            <div className="space-y-2">
              <Label>Room Type</Label>
              <Select value={formData.roomTypeId} onValueChange={v => setFormData({ ...formData, roomTypeId: v })}>
                <SelectTrigger><SelectValue placeholder="Select room type" /></SelectTrigger>
                <SelectContent>{roomTypes.map(rt => <SelectItem key={rt.id} value={rt.id}>{rt.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div className="space-y-2"><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Price Modifier</Label><Input type="number" step="0.1" value={formData.priceModifier} onChange={e => setFormData({ ...formData, priceModifier: Number(e.target.value) })} /></div>
              <div className="space-y-2">
                <Label>Modifier Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this pricing rule? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Tax & VAT (subModule='tax')
// ============================================================
function TaxVAT() {
  const [hotel, setHotel] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [taxRate, setTaxRate] = useState(15)
  const [vatRate, setVatRate] = useState(5)
  const [saving, setSaving] = useState(false)

  const fetchHotel = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/hotel-setup?resource=hotel')
      setHotel(res.hotel)
      setTaxRate(res.hotel?.taxRate ?? 15)
      setVatRate(res.hotel?.vatRate ?? 5)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchHotel() }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      await apiFetch('/api/hotel-setup', {
        method: 'POST',
        body: JSON.stringify({ resource: 'hotel', data: { taxRate, vatRate } }),
      })
      toast.success('Tax & VAT rates updated')
      setEditing(false)
      fetchHotel()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Tax & VAT</h2>
          <p className="text-muted-foreground">Configure tax and VAT rates</p>
        </div>
        {!editing && <Button onClick={() => setEditing(true)}><Edit className="h-4 w-4 mr-1" />Edit Rates</Button>}
      </div>

      <Card>
        <CardContent className="p-6">
          {editing ? (
            <div className="space-y-6 max-w-md">
              <div className="space-y-2">
                <Label>Tax Rate (%)</Label>
                <Input type="number" step="0.1" value={taxRate} onChange={e => setTaxRate(Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">Applied to room rates and services</p>
              </div>
              <div className="space-y-2">
                <Label>VAT Rate (%)</Label>
                <Input type="number" step="0.1" value={vatRate} onChange={e => setVatRate(Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">Value Added Tax on all billable items</p>
              </div>
              <Separator />
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => { setEditing(false); setTaxRate(hotel?.taxRate ?? 15); setVatRate(hotel?.vatRate ?? 5) }}>Cancel</Button>
                <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save Changes</Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <Label className="text-muted-foreground">Current Tax Rate</Label>
                <p className="text-4xl font-bold">{hotel?.taxRate ?? 15}%</p>
                <p className="text-sm text-muted-foreground">Applied to room rates and services</p>
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Current VAT Rate</Label>
                <p className="text-4xl font-bold">{hotel?.vatRate ?? 5}%</p>
                <p className="text-sm text-muted-foreground">Value Added Tax on all billable items</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Impact Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Tax Impact Summary</CardTitle>
          <CardDescription>How tax rates apply to billing</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <span className="text-sm">Room Rate (Base)</span>
              <span className="font-medium">100%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50">
              <span className="text-sm">Tax ({hotel?.taxRate ?? 15}%)</span>
              <span className="font-medium text-amber-700">+{hotel?.taxRate ?? 15}%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50">
              <span className="text-sm">VAT ({hotel?.vatRate ?? 5}%)</span>
              <span className="font-medium text-blue-700">+{hotel?.vatRate ?? 5}%</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50">
              <span className="font-medium">Total Charge</span>
              <span className="font-bold text-emerald-700">{100 + (hotel?.taxRate ?? 15) + (hotel?.vatRate ?? 5)}% of base rate</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ============================================================
// Main Hotel Setup Module
// ============================================================
export default function HotelSetupModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'hotel-info':
      return <HotelInformation />
    case 'buildings':
      return <BuildingFloor />
    case 'room-types':
      return <RoomTypes />
    case 'room-categories':
      return <RoomCategories />
    case 'bed-types':
      return <BedTypes />
    case 'room-views':
      return <RoomViews />
    case 'amenities':
      return <Amenities />
    case 'pricing':
      return <SeasonalPricing />
    case 'tax':
      return <TaxVAT />
    default:
      return <HotelInformation />
  }
}
