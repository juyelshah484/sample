'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ Types ============
interface SpaService {
  id: string
  name: string
  category: string
  duration: number
  price: number
  description: string | null
  isActive: boolean
  bookings?: SpaBooking[]
}

interface SpaBooking {
  id: string
  serviceId: string
  guestId: string
  therapistId: string | null
  dateTime: string
  status: string
  notes: string | null
  service?: SpaService
  guest?: { id: string; firstName: string; lastName: string }
}

interface Therapist {
  id: string
  name: string
  specialization: string
  availability: string
  isActive: boolean
}

interface GymMember {
  id: string
  name: string
  email: string
  phone: string
  plan: string
  startDate: string
  endDate: string
  status: string
}

interface WellnessPackage {
  id: string
  name: string
  description: string
  services: string[]
  duration: number
  price: number
  minSessions: number
}

// ============ Spa Booking ============
function SpaBookingView() {
  const [services, setServices] = useState<SpaService[]>([])
  const [guests, setGuests] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ serviceId: '', guestId: '', dateTime: '', therapist: '', notes: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const [spaRes, guestRes] = await Promise.all([apiFetch('/api/spa-services'), apiFetch('/api/guests')])
      setServices(spaRes.spaServices || [])
      setGuests(guestRes.guests || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const allBookings = services.flatMap(s => s.bookings || [])
  const selectedService = services.find(s => s.id === form.serviceId)

  const handleBook = async () => {
    if (!form.serviceId || !form.guestId || !form.dateTime) { toast.error('Service, guest, and date/time are required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/spa-services', {
        method: 'POST',
        body: JSON.stringify({
          hotelId: 'default',
          name: selectedService?.name || 'Service',
          duration: selectedService?.duration || 60,
          price: selectedService?.price || 0,
          booking: {
            guestId: form.guestId,
            therapistId: form.therapist || null,
            dateTime: form.dateTime,
            status: 'booked',
            notes: form.notes,
          },
        }),
      })
      toast.success('Spa booking created!')
      setDialogOpen(false)
      setForm({ serviceId: '', guestId: '', dateTime: '', therapist: '', notes: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  const categories = [...new Set(services.map(s => s.category))]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Spa Booking</h2><p className="text-muted-foreground">Book spa and wellness services</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Book Service</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Services" value={services.length} color="emerald" />
        <KPICard title="Bookings" value={allBookings.length} color="blue" />
        <KPICard title="Confirmed" value={allBookings.filter(b => b.status === 'booked').length} color="amber" />
        <KPICard title="Completed" value={allBookings.filter(b => b.status === 'completed').length} color="violet" />
      </div>

      {/* Service Cards by Category */}
      {categories.map(cat => (
        <div key={cat}>
          <h3 className="text-lg font-semibold mb-3 capitalize">{cat}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.filter(s => s.category === cat).map(service => (
              <Card key={service.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{service.name}</CardTitle>
                    <Badge className={service.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{service.isActive ? 'Active' : 'Inactive'}</Badge>
                  </div>
                  <CardDescription>{service.description || 'No description'}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Duration</span>
                    <span className="font-medium">{service.duration} min</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Price</span>
                    <span className="text-lg font-bold">{formatCurrency(service.price)}</span>
                  </div>
                  <Button className="w-full" size="sm" onClick={() => { setForm({ ...form, serviceId: service.id }); setDialogOpen(true) }}>
                    Book Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}

      {/* Booking List */}
      <Card>
        <CardHeader><CardTitle>Recent Bookings</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Service</TableHead><TableHead>Guest</TableHead><TableHead>Date/Time</TableHead><TableHead>Status</TableHead><TableHead>Notes</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {allBookings.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No bookings yet</TableCell></TableRow>
              ) : allBookings.slice(0, 20).map(booking => (
                <TableRow key={booking.id}>
                  <TableCell className="font-medium">{booking.service?.name || '-'}</TableCell>
                  <TableCell>{booking.guest ? `${booking.guest.firstName} ${booking.guest.lastName}` : '-'}</TableCell>
                  <TableCell>{formatDateTime(booking.dateTime)}</TableCell>
                  <TableCell><Badge className={statusColors[booking.status] || ''}>{booking.status}</Badge></TableCell>
                  <TableCell className="max-w-[150px] truncate">{booking.notes || '-'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Book Spa Service</DialogTitle><DialogDescription>Schedule a spa appointment</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Service *</Label><Select value={form.serviceId} onValueChange={v => setForm({ ...form, serviceId: v })}><SelectTrigger><SelectValue placeholder="Select service" /></SelectTrigger><SelectContent>{services.filter(s => s.isActive).map(s => <SelectItem key={s.id} value={s.id}>{s.name} ({formatCurrency(s.price)} / {s.duration}min)</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Guest *</Label><Select value={form.guestId} onValueChange={v => setForm({ ...form, guestId: v })}><SelectTrigger><SelectValue placeholder="Select guest" /></SelectTrigger><SelectContent>{guests.map((g: any) => <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Date/Time *</Label><Input type="datetime-local" value={form.dateTime} onChange={e => setForm({ ...form, dateTime: e.target.value })} /></div>
            <div><Label>Therapist</Label><Input value={form.therapist} onChange={e => setForm({ ...form, therapist: e.target.value })} placeholder="Preferred therapist" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Special requests" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBook} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Book</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Therapist Management ============
function TherapistManagement() {
  const [therapists, setTherapists] = useState<Therapist[]>([
    { id: '1', name: 'Anita Sharma', specialization: 'Swedish Massage', availability: 'available', isActive: true },
    { id: '2', name: 'Raj Patel', specialization: 'Deep Tissue Massage', availability: 'busy', isActive: true },
    { id: '3', name: 'Priya Singh', specialization: 'Aromatherapy', availability: 'available', isActive: true },
    { id: '4', name: 'Kumar Rao', specialization: 'Hot Stone Therapy', availability: 'off-duty', isActive: true },
    { id: '5', name: 'Meera Joshi', specialization: 'Facial Treatments', availability: 'available', isActive: true },
    { id: '6', name: 'David Chen', specialization: 'Thai Massage', availability: 'busy', isActive: false },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ name: '', specialization: '', availability: 'available' })

  const handleCreate = () => {
    if (!form.name || !form.specialization) { toast.error('Name and specialization are required'); return }
    setTherapists(prev => [...prev, { id: String(Date.now()), name: form.name, specialization: form.specialization, availability: form.availability, isActive: true }])
    toast.success('Therapist added')
    setDialogOpen(false)
    setForm({ name: '', specialization: '', availability: 'available' })
  }

  const availabilityColors: Record<string, string> = {
    available: 'bg-emerald-100 text-emerald-800',
    busy: 'bg-amber-100 text-amber-800',
    'off-duty': 'bg-gray-100 text-gray-800',
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Therapist Management</h2><p className="text-muted-foreground">Manage spa therapists and assignments</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Add Therapist</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MiniStat label="Available" value={therapists.filter(t => t.availability === 'available').length} color="bg-emerald-50" />
        <MiniStat label="Busy" value={therapists.filter(t => t.availability === 'busy').length} color="bg-amber-50" />
        <MiniStat label="Off Duty" value={therapists.filter(t => t.availability === 'off-duty').length} color="bg-gray-50" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {therapists.map(therapist => (
          <Card key={therapist.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">{therapist.name}</h4>
                <Badge className={availabilityColors[therapist.availability] || ''}>{therapist.availability}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{therapist.specialization}</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => {
                  setTherapists(prev => prev.map(t => t.id === therapist.id ? { ...t, availability: 'busy' } : t))
                  toast.success(`${therapist.name} marked as busy`)
                }}>Assign</Button>
                <Button size="sm" variant="outline" onClick={() => {
                  setTherapists(prev => prev.map(t => t.id === therapist.id ? { ...t, availability: 'available' } : t))
                  toast.success(`${therapist.name} marked as available`)
                }}>Free</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle>All Therapists</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Name</TableHead><TableHead>Specialization</TableHead><TableHead>Availability</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {therapists.map(therapist => (
                <TableRow key={therapist.id}>
                  <TableCell className="font-medium">{therapist.name}</TableCell>
                  <TableCell>{therapist.specialization}</TableCell>
                  <TableCell><Badge className={availabilityColors[therapist.availability] || ''}>{therapist.availability}</Badge></TableCell>
                  <TableCell><Badge className={therapist.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}>{therapist.isActive ? 'Active' : 'Inactive'}</Badge></TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setTherapists(prev => prev.map(t => t.id === therapist.id ? { ...t, availability: 'available' } : t))
                          toast.success('Marked as available')
                        }}>Set Available</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setTherapists(prev => prev.map(t => t.id === therapist.id ? { ...t, availability: 'busy' } : t))
                          toast.success('Marked as busy')
                        }}>Set Busy</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setTherapists(prev => prev.map(t => t.id === therapist.id ? { ...t, isActive: !t.isActive } : t))
                          toast.success('Status toggled')
                        }}>Toggle Active</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Therapist</DialogTitle><DialogDescription>Register a new spa therapist</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Therapist name" /></div>
            <div><Label>Specialization *</Label><Input value={form.specialization} onChange={e => setForm({ ...form, specialization: e.target.value })} placeholder="e.g. Swedish Massage" /></div>
            <div><Label>Availability</Label><Select value={form.availability} onValueChange={v => setForm({ ...form, availability: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="available">Available</SelectItem><SelectItem value="busy">Busy</SelectItem><SelectItem value="off-duty">Off Duty</SelectItem></SelectContent></Select></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Gym Membership ============
function GymMembership() {
  const [members, setMembers] = useState<GymMember[]>([
    { id: '1', name: 'Ahmed Khan', email: 'ahmed@email.com', phone: '+8801711000001', plan: 'gold', startDate: '2025-01-01', endDate: '2025-12-31', status: 'active' },
    { id: '2', name: 'Sarah Lee', email: 'sarah@email.com', phone: '+8801711000002', plan: 'platinum', startDate: '2025-02-01', endDate: '2026-01-31', status: 'active' },
    { id: '3', name: 'Mike Johnson', email: 'mike@email.com', phone: '+8801711000003', plan: 'standard', startDate: '2024-06-01', endDate: '2024-12-01', status: 'expired' },
    { id: '4', name: 'Fatima Begum', email: 'fatima@email.com', phone: '+8801711000004', plan: 'silver', startDate: '2025-01-15', endDate: '2025-07-15', status: 'active' },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', phone: '', plan: 'standard', startDate: '', endDate: '' })

  const plans = [
    { name: 'standard', price: 2000, features: ['Gym Access', 'Locker'] },
    { name: 'silver', price: 3500, features: ['Gym Access', 'Locker', 'Pool Access', '2 Trainer Sessions'] },
    { name: 'gold', price: 5000, features: ['Gym Access', 'Locker', 'Pool Access', '8 Trainer Sessions', 'Sauna'] },
    { name: 'platinum', price: 8000, features: ['Full Access', 'Personal Trainer', 'Diet Plan', 'Spa Discount', 'Priority Booking'] },
  ]

  const handleCreate = () => {
    if (!form.name || !form.plan || !form.startDate || !form.endDate) { toast.error('All required fields must be filled'); return }
    setMembers(prev => [...prev, { id: String(Date.now()), ...form, status: 'active' }])
    toast.success('Member added')
    setDialogOpen(false)
    setForm({ name: '', email: '', phone: '', plan: 'standard', startDate: '', endDate: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Gym Membership</h2><p className="text-muted-foreground">Manage gym memberships</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Add Member</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Active Members" value={members.filter(m => m.status === 'active').length} color="emerald" />
        <KPICard title="Expired" value={members.filter(m => m.status === 'expired').length} color="red" />
        <KPICard title="Plans" value={plans.length} color="blue" />
        <KPICard title="Monthly Revenue" value={formatCurrency(members.filter(m => m.status === 'active').reduce((s, m) => s + (plans.find(p => p.name === m.plan)?.price || 0), 0))} color="amber" />
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map(plan => (
          <Card key={plan.name} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="capitalize text-lg">{plan.name}</CardTitle>
              <CardDescription>
                <span className="text-2xl font-bold">{formatCurrency(plan.price)}</span>
                <span className="text-sm">/month</span>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {plan.features.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <span className="text-emerald-500">✓</span>
                  <span>{f}</span>
                </div>
              ))}
              <div className="text-sm text-muted-foreground mt-2">
                {members.filter(m => m.plan === plan.name && m.status === 'active').length} active members
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Member List */}
      <Card>
        <CardHeader><CardTitle>Members</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Name</TableHead><TableHead>Plan</TableHead><TableHead>Start</TableHead><TableHead>End</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {members.map(member => (
                <TableRow key={member.id}>
                  <TableCell><div><p className="font-medium">{member.name}</p><p className="text-xs text-muted-foreground">{member.email}</p></div></TableCell>
                  <TableCell><Badge className={statusColors[member.plan] || ''}>{member.plan}</Badge></TableCell>
                  <TableCell>{formatDate(member.startDate)}</TableCell>
                  <TableCell>{formatDate(member.endDate)}</TableCell>
                  <TableCell><Badge className={member.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}>{member.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setMembers(prev => prev.map(m => m.id === member.id ? { ...m, status: 'active', endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10) } : m))
                          toast.success('Membership renewed')
                        }}>Renew</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => {
                          setMembers(prev => prev.filter(m => m.id !== member.id))
                          toast.success('Member removed')
                        }}>Remove</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Member</DialogTitle><DialogDescription>Register a new gym member</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Member name" /></div>
            <div><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="email@example.com" /></div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="+880..." /></div>
            <div><Label>Plan *</Label><Select value={form.plan} onValueChange={v => setForm({ ...form, plan: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{plans.map(p => <SelectItem key={p.name} value={p.name}>{p.name.charAt(0).toUpperCase() + p.name.slice(1)} — {formatCurrency(p.price)}/mo</SelectItem>)}</SelectContent></Select></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Start Date *</Label><Input type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })} /></div>
              <div><Label>End Date *</Label><Input type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Add Member</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Wellness Packages ============
function WellnessPackages() {
  const [packages, setPackages] = useState<WellnessPackage[]>([
    { id: '1', name: 'Relaxation Package', description: 'Full body relaxation experience', services: ['Swedish Massage (60min)', 'Aromatherapy (30min)', 'Sauna Access'], duration: 120, price: 5000, minSessions: 1 },
    { id: '2', name: 'Detox Package', description: 'Complete detox and rejuvenation', services: ['Deep Tissue Massage (60min)', 'Body Scrub (30min)', 'Steam Bath', 'Herbal Tea'], duration: 150, price: 7000, minSessions: 3 },
    { id: '3', name: 'Beauty Package', description: 'Comprehensive beauty treatments', services: ['Facial Treatment (45min)', 'Manicure & Pedicure (60min)', 'Hair Spa (30min)'], duration: 135, price: 6000, minSessions: 1 },
    { id: '4', name: 'Couples Retreat', description: 'Romantic spa experience for two', services: ['Couples Massage (60min)', 'Private Jacuzzi', 'Champagne', 'Fruit Platter'], duration: 180, price: 12000, minSessions: 1 },
    { id: '5', name: 'Ultimate Wellness', description: 'Our most comprehensive wellness package', services: ['Hot Stone Massage (75min)', 'Body Wrap (45min)', 'Facial (45min)', 'Reflexology (30min)', 'Sauna & Steam', 'Healthy Lunch'], duration: 300, price: 18000, minSessions: 5 },
  ])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [bookDialogOpen, setBookDialogOpen] = useState(false)
  const [selectedPkg, setSelectedPkg] = useState<WellnessPackage | null>(null)
  const [form, setForm] = useState({ name: '', description: '', servicesText: '', duration: '', price: '', minSessions: '' })
  const [bookForm, setBookForm] = useState({ guestName: '', dateTime: '' })

  const handleCreate = () => {
    if (!form.name || !form.price) { toast.error('Name and price are required'); return }
    setPackages(prev => [...prev, {
      id: String(Date.now()),
      name: form.name,
      description: form.description,
      services: form.servicesText.split(',').map(s => s.trim()).filter(Boolean),
      duration: parseInt(form.duration) || 60,
      price: parseFloat(form.price) || 0,
      minSessions: parseInt(form.minSessions) || 1,
    }])
    toast.success('Package created')
    setDialogOpen(false)
    setForm({ name: '', description: '', servicesText: '', duration: '', price: '', minSessions: '' })
  }

  const handleBook = () => {
    if (!bookForm.guestName || !bookForm.dateTime) { toast.error('Guest name and date/time are required'); return }
    toast.success(`${selectedPkg?.name} booked for ${bookForm.guestName}`)
    setBookDialogOpen(false)
    setBookForm({ guestName: '', dateTime: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Wellness Packages</h2><p className="text-muted-foreground">Curated spa and wellness packages</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Create Package</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {packages.map(pkg => (
          <Card key={pkg.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{pkg.name}</CardTitle>
                <Badge variant="outline">{pkg.duration} min</Badge>
              </div>
              <CardDescription>{pkg.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1">
                {pkg.services.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="text-emerald-500">✓</span>
                    <span>{s}</span>
                  </div>
                ))}
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold">{formatCurrency(pkg.price)}</span>
                  <span className="text-sm text-muted-foreground"> / session</span>
                </div>
                {pkg.minSessions > 1 && <span className="text-xs text-muted-foreground">Min {pkg.minSessions} sessions</span>}
              </div>
              <Button className="w-full" size="sm" onClick={() => { setSelectedPkg(pkg); setBookDialogOpen(true) }}>
                Book Package
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Create Package</DialogTitle><DialogDescription>Define a new wellness package</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Package Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Relaxation Package" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Package description" /></div>
            <div><Label>Services (comma-separated)</Label><Textarea value={form.servicesText} onChange={e => setForm({ ...form, servicesText: e.target.value })} placeholder="e.g. Massage, Facial, Sauna" /></div>
            <div className="grid grid-cols-3 gap-3">
              <div><Label>Duration (min)</Label><Input type="number" value={form.duration} onChange={e => setForm({ ...form, duration: e.target.value })} placeholder="60" /></div>
              <div><Label>Price *</Label><Input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} placeholder="0" /></div>
              <div><Label>Min Sessions</Label><Input type="number" value={form.minSessions} onChange={e => setForm({ ...form, minSessions: e.target.value })} placeholder="1" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={bookDialogOpen} onOpenChange={setBookDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Book {selectedPkg?.name}</DialogTitle><DialogDescription>Schedule your wellness package</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Guest Name *</Label><Input value={bookForm.guestName} onChange={e => setBookForm({ ...bookForm, guestName: e.target.value })} placeholder="Guest name" /></div>
            <div><Label>Date/Time *</Label><Input type="datetime-local" value={bookForm.dateTime} onChange={e => setBookForm({ ...bookForm, dateTime: e.target.value })} /></div>
            <div className="bg-muted p-3 rounded-lg space-y-1">
              <p className="text-sm font-medium">{selectedPkg?.name}</p>
              <p className="text-sm text-muted-foreground">Duration: {selectedPkg?.duration} min</p>
              <p className="text-lg font-bold">{formatCurrency(selectedPkg?.price || 0)}</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBookDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBook}>Confirm Booking</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Main Component ============
export default function SpaModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'spa-booking': return <SpaBookingView />
    case 'therapist': return <TherapistManagement />
    case 'gym': return <GymMembership />
    case 'wellness-packages': return <WellnessPackages />
    default: return <EmptyState title="Unknown Sub-module" description={`Sub-module "${subModule}" not found`} />
  }
}
