'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, StatusRow, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2,
} from '@/components/hotel/shared'
import { BedDouble, DollarSign, UserRound, Clock, CalendarCheck, DoorOpen, TrendingUp, Sparkles, Receipt, ArrowDownRight, ArrowUpRight, Wrench, XCircle, CheckCircle2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, Legend } from 'recharts'

// ============================================================
// Room Master (subModule='room-master')
// ============================================================
function RoomMaster() {
  const [rooms, setRooms] = useState<any[]>([])
  const [roomTypes, setRoomTypes] = useState<any[]>([])
  const [floors, setFloors] = useState<any[]>([])
  const [bedTypes, setBedTypes] = useState<any[]>([])
  const [roomViews, setRoomViews] = useState<any[]>([])
  const [hotelId, setHotelId] = useState('')
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState('all')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [viewItem, setViewItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formData, setFormData] = useState<any>({
    number: '', name: '', roomTypeId: '', floorId: '', bedTypeId: '', roomViewId: '',
    price: 0, status: 'available', smoking: false, maxGuests: 2, floor: 1,
  })

  const pageSize = 10

  const fetchAll = async () => {
    setLoading(true)
    try {
      const [roomsRes, rtRes, fRes, btRes, rvRes, hotelRes] = await Promise.all([
        apiFetch('/api/rooms'),
        apiFetch('/api/room-types'),
        apiFetch('/api/floors'),
        apiFetch('/api/bed-types'),
        apiFetch('/api/room-views'),
        apiFetch('/api/hotel-setup?resource=hotel'),
      ])
      setRooms(roomsRes.rooms || [])
      setRoomTypes(rtRes.roomTypes || [])
      setFloors(fRes.floors || [])
      setBedTypes(btRes.bedTypes || [])
      setRoomViews(rvRes.roomViews || [])
      setHotelId(hotelRes.hotel?.id || '')
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchAll() }, [])

  const openCreate = () => {
    setEditItem(null)
    setFormData({
      number: '', name: '', roomTypeId: roomTypes[0]?.id || '', floorId: floors[0]?.id || '',
      bedTypeId: bedTypes[0]?.id || '', roomViewId: roomViews[0]?.id || '',
      price: 0, status: 'available', smoking: false, maxGuests: 2, floor: 1,
    })
    setDialogOpen(true)
  }

  const openEdit = (room: any) => {
    setEditItem(room)
    setFormData({
      number: room.number, name: room.name || '', roomTypeId: room.roomTypeId,
      floorId: room.floorId || '', bedTypeId: room.bedTypeId || '', roomViewId: room.roomViewId || '',
      price: room.price, status: room.status, smoking: room.smoking, maxGuests: room.maxGuests, floor: room.floor,
    })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        ...formData,
        hotelId,
        buildingId: formData.floorId ? floors.find((f: any) => f.id === formData.floorId)?.buildingId : undefined,
      }
      if (editItem) {
        await apiFetch('/api/rooms', { method: 'PUT', body: JSON.stringify({ id: editItem.id, ...payload }) })
      } else {
        await apiFetch('/api/rooms', { method: 'POST', body: JSON.stringify(payload) })
      }
      toast.success(editItem ? 'Room updated' : 'Room created')
      setDialogOpen(false)
      fetchAll()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleDelete = async () => {
    try {
      await apiFetch(`/api/rooms?id=${deleteId}`, { method: 'DELETE' })
      toast.success('Room deleted')
      setDeleteId(null)
      fetchAll()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleStatusChange = async (roomId: string, newStatus: string) => {
    try {
      await apiFetch('/api/rooms', { method: 'PUT', body: JSON.stringify({ id: roomId, status: newStatus }) })
      toast.success(`Room status changed to ${newStatus.replace(/_/g, ' ')}`)
      fetchAll()
    } catch (e: any) { toast.error(e.message) }
  }

  const filtered = rooms.filter(r => {
    const matchSearch = !search || r.number?.toLowerCase().includes(search.toLowerCase()) || r.name?.toLowerCase().includes(search.toLowerCase()) || r.roomType?.name?.toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === 'all' || r.status === statusFilter
    return matchSearch && matchStatus
  })
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const statusButtons = [
    { key: 'all', label: 'All', count: rooms.length },
    { key: 'available', label: 'Available', count: rooms.filter(r => r.status === 'available').length },
    { key: 'occupied', label: 'Occupied', count: rooms.filter(r => r.status === 'occupied').length },
    { key: 'maintenance', label: 'Maintenance', count: rooms.filter(r => r.status === 'maintenance').length },
    { key: 'out_of_service', label: 'Out of Service', count: rooms.filter(r => r.status === 'out_of_service').length },
  ]

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Master</h2><p className="text-muted-foreground">Manage all rooms</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search rooms..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button variant="outline" size="sm" onClick={fetchAll}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add Room</Button>
        </div>
      </div>

      {/* Status Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        {statusButtons.map(sb => (
          <Button key={sb.key} variant={statusFilter === sb.key ? 'default' : 'outline'} size="sm" onClick={() => { setStatusFilter(sb.key); setPage(1) }}>
            {sb.label} <Badge variant="secondary" className="ml-1.5">{sb.count}</Badge>
          </Button>
        ))}
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room #</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Floor</TableHead>
                <TableHead>Bed</TableHead>
                <TableHead>View</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Smoking</TableHead>
                <TableHead>Guests</TableHead>
                <TableHead className="w-[120px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.length === 0 ? (
                <TableRow><TableCell colSpan={11} className="text-center py-8 text-muted-foreground">No rooms found</TableCell></TableRow>
              ) : paginated.map(room => (
                <TableRow key={room.id}>
                  <TableCell className="font-bold">{room.number}</TableCell>
                  <TableCell>{room.name || '-'}</TableCell>
                  <TableCell>{room.roomType?.name || '-'}</TableCell>
                  <TableCell>{room.floorRecord?.name || room.floor}</TableCell>
                  <TableCell>{room.bedType?.name || '-'}</TableCell>
                  <TableCell>{room.roomView?.name || '-'}</TableCell>
                  <TableCell>{formatCurrency(room.price)}</TableCell>
                  <TableCell><Badge className={statusColors[room.status] || ''}>{room.status?.replace(/_/g, ' ')}</Badge></TableCell>
                  <TableCell>{room.smoking ? 'Yes' : 'No'}</TableCell>
                  <TableCell>{room.maxGuests}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => { setViewItem(room); setViewDialogOpen(true) }}><Eye className="h-4 w-4 mr-2" />View</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openEdit(room)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(room.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                        <Separator className="my-1" />
                        <DropdownMenuItem onClick={() => handleStatusChange(room.id, 'available')}>Set Available</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(room.id, 'occupied')}>Set Occupied</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(room.id, 'maintenance')}>Set Maintenance</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(room.id, 'out_of_service')}>Set Out of Service</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Pagination page={page} totalPages={totalPages} setPage={setPage} />

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Room</DialogTitle><DialogDescription>Fill in the room details below.</DialogDescription></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-2"><Label>Room Number *</Label><Input value={formData.number} onChange={e => setFormData({ ...formData, number: e.target.value })} /></div>
            <div className="space-y-2"><Label>Room Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="space-y-2">
              <Label>Room Type *</Label>
              <Select value={formData.roomTypeId} onValueChange={v => {
                const rt = roomTypes.find((r: any) => r.id === v)
                setFormData({ ...formData, roomTypeId: v, price: rt?.basePrice || formData.price, maxGuests: rt?.maxOccupancy || formData.maxGuests })
              }}>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>{roomTypes.map(rt => <SelectItem key={rt.id} value={rt.id}>{rt.name} - {formatCurrency(rt.basePrice)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Floor</Label>
              <Select value={formData.floorId || '_none'} onValueChange={v => setFormData({ ...formData, floorId: v === '_none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder="Select floor" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">None</SelectItem>
                  {floors.map(f => <SelectItem key={f.id} value={f.id}>{f.name} ({f.building?.name})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Bed Type</Label>
              <Select value={formData.bedTypeId || '_none'} onValueChange={v => setFormData({ ...formData, bedTypeId: v === '_none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder="Select bed type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">None</SelectItem>
                  {bedTypes.map(bt => <SelectItem key={bt.id} value={bt.id}>{bt.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Room View</Label>
              <Select value={formData.roomViewId || '_none'} onValueChange={v => setFormData({ ...formData, roomViewId: v === '_none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder="Select view" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">None</SelectItem>
                  {roomViews.map(rv => <SelectItem key={rv.id} value={rv.id}>{rv.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Price *</Label><Input type="number" value={formData.price} onChange={e => setFormData({ ...formData, price: Number(e.target.value) })} /></div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="occupied">Occupied</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="out_of_service">Out of Service</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Max Guests</Label><Input type="number" value={formData.maxGuests} onChange={e => setFormData({ ...formData, maxGuests: Number(e.target.value) })} /></div>
            <div className="space-y-2"><Label>Floor Number</Label><Input type="number" value={formData.floor} onChange={e => setFormData({ ...formData, floor: Number(e.target.value) })} /></div>
            <div className="flex items-center gap-2 pt-6">
              <input type="checkbox" checked={formData.smoking} onChange={e => setFormData({ ...formData, smoking: e.target.checked })} className="rounded" />
              <Label>Smoking Room</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Room Details - {viewItem?.number}</DialogTitle></DialogHeader>
          {viewItem && (
            <div className="grid grid-cols-2 gap-4 py-2">
              <div><Label className="text-muted-foreground">Number</Label><p className="font-medium">{viewItem.number}</p></div>
              <div><Label className="text-muted-foreground">Name</Label><p className="font-medium">{viewItem.name || '-'}</p></div>
              <div><Label className="text-muted-foreground">Type</Label><p className="font-medium">{viewItem.roomType?.name || '-'}</p></div>
              <div><Label className="text-muted-foreground">Floor</Label><p className="font-medium">{viewItem.floorRecord?.name || viewItem.floor}</p></div>
              <div><Label className="text-muted-foreground">Bed Type</Label><p className="font-medium">{viewItem.bedType?.name || '-'}</p></div>
              <div><Label className="text-muted-foreground">View</Label><p className="font-medium">{viewItem.roomView?.name || '-'}</p></div>
              <div><Label className="text-muted-foreground">Price</Label><p className="font-medium">{formatCurrency(viewItem.price)}</p></div>
              <div><Label className="text-muted-foreground">Status</Label><Badge className={statusColors[viewItem.status] || ''}>{viewItem.status?.replace(/_/g, ' ')}</Badge></div>
              <div><Label className="text-muted-foreground">Smoking</Label><p className="font-medium">{viewItem.smoking ? 'Yes' : 'No'}</p></div>
              <div><Label className="text-muted-foreground">Max Guests</Label><p className="font-medium">{viewItem.maxGuests}</p></div>
              {viewItem.amenities?.length > 0 && (
                <div className="col-span-2">
                  <Label className="text-muted-foreground">Amenities</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {viewItem.amenities.map((a: any) => <Badge key={a.amenityId} variant="outline">{a.amenity?.name}</Badge>)}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this room? This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Room Availability (subModule='availability')
// ============================================================
function RoomAvailability() {
  const [rooms, setRooms] = useState<any[]>([])
  const [floors, setFloors] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [floorFilter, setFloorFilter] = useState('all')
  const [selectedRoom, setSelectedRoom] = useState<any>(null)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [roomsRes, floorsRes] = await Promise.all([
        apiFetch('/api/rooms'),
        apiFetch('/api/floors'),
      ])
      setRooms(roomsRes.rooms || [])
      setFloors(floorsRes.floors || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const filteredRooms = floorFilter === 'all' ? rooms : rooms.filter(r => r.floorId === floorFilter)

  const statusColorMap: Record<string, string> = {
    available: 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/25',
    occupied: 'bg-sky-600 hover:bg-sky-700 shadow-sky-600/25',
    maintenance: 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/25',
    out_of_service: 'bg-red-600 hover:bg-red-700 shadow-red-600/25',
    blocked: 'bg-slate-500 hover:bg-slate-600 shadow-slate-500/25',
  }

  const legendItems = [
    { label: 'Available', color: 'bg-emerald-600' },
    { label: 'Occupied', color: 'bg-sky-600' },
    { label: 'Maintenance', color: 'bg-amber-600' },
    { label: 'Out of Service', color: 'bg-red-600' },
    { label: 'Blocked', color: 'bg-slate-500' },
  ]

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Availability</h2><p className="text-muted-foreground">Visual room status overview</p></div>
        <div className="flex gap-2 items-center">
          <Label className="text-sm">Floor:</Label>
          <Select value={floorFilter} onValueChange={setFloorFilter}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Floors</SelectItem>
              {floors.map(f => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* Legend */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            {legendItems.map(li => (
              <div key={li.label} className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded ${li.color}`} />
                <span className="text-sm">{li.label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Room Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-3">
        {filteredRooms.map(room => (
          <button
            key={room.id}
            className={`p-3 rounded-xl text-white text-center transition-all duration-200 ${statusColorMap[room.status] || 'bg-slate-400'} cursor-pointer shadow-md hover:shadow-lg hover:-translate-y-0.5`}
            onClick={() => { setSelectedRoom(room); setViewDialogOpen(true) }}
          >
            <p className="font-bold text-sm">{room.number}</p>
            <p className="text-[10px] opacity-80 truncate">{room.roomType?.name || '-'}</p>
          </button>
        ))}
      </div>

      {filteredRooms.length === 0 && (
        <EmptyState title="No Rooms" description="No rooms found for the selected floor." />
      )}

      {/* Room Detail Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Room {selectedRoom?.number}</DialogTitle></DialogHeader>
          {selectedRoom && (
            <div className="space-y-4 py-2">
              <div className="flex items-center justify-between">
                <Badge className={`${statusColors[selectedRoom.status]} text-sm px-3 py-1`}>
                  {selectedRoom.status?.replace(/_/g, ' ')}
                </Badge>
                <span className="text-lg font-bold">{formatCurrency(selectedRoom.price)}</span>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">Name:</span> <span className="font-medium">{selectedRoom.name || '-'}</span></div>
                <div><span className="text-muted-foreground">Type:</span> <span className="font-medium">{selectedRoom.roomType?.name || '-'}</span></div>
                <div><span className="text-muted-foreground">Floor:</span> <span className="font-medium">{selectedRoom.floorRecord?.name || selectedRoom.floor}</span></div>
                <div><span className="text-muted-foreground">Bed:</span> <span className="font-medium">{selectedRoom.bedType?.name || '-'}</span></div>
                <div><span className="text-muted-foreground">View:</span> <span className="font-medium">{selectedRoom.roomView?.name || '-'}</span></div>
                <div><span className="text-muted-foreground">Max Guests:</span> <span className="font-medium">{selectedRoom.maxGuests}</span></div>
                <div><span className="text-muted-foreground">Smoking:</span> <span className="font-medium">{selectedRoom.smoking ? 'Yes' : 'No'}</span></div>
              </div>
              {selectedRoom.amenities?.length > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Amenities</p>
                  <div className="flex flex-wrap gap-1">
                    {selectedRoom.amenities.map((a: any) => <Badge key={a.amenityId} variant="outline">{a.amenity?.name}</Badge>)}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Room Blocking (subModule='blocking')
// ============================================================
function RoomBlocking() {
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ roomId: '', reason: '', startDate: '', endDate: '' })
  const [hotelId, setHotelId] = useState('')

  const fetchData = async () => {
    setLoading(true)
    try {
      const [roomsRes, hotelRes] = await Promise.all([
        apiFetch('/api/rooms'),
        apiFetch('/api/hotel-setup?resource=hotel'),
      ])
      setRooms(roomsRes.rooms || [])
      setHotelId(hotelRes.hotel?.id || '')
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const blockedRooms = rooms.filter(r => r.status === 'blocked')
  const availableRooms = rooms.filter(r => r.status === 'available')

  const handleBlock = async () => {
    if (!formData.roomId || !formData.reason) {
      toast.error('Please select a room and provide a reason')
      return
    }
    setSaving(true)
    try {
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: formData.roomId, status: 'blocked' }),
      })
      toast.success('Room blocked successfully')
      setDialogOpen(false)
      setFormData({ roomId: '', reason: '', startDate: '', endDate: '' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleUnblock = async (roomId: string) => {
    try {
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: roomId, status: 'available' }),
      })
      toast.success('Room unblocked')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Blocking</h2><p className="text-muted-foreground">Block rooms for maintenance or special purposes</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => { setFormData({ roomId: '', reason: '', startDate: '', endDate: '' }); setDialogOpen(true) }}>
            <Plus className="h-4 w-4 mr-1" />Block Room
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Blocked Rooms" value={blockedRooms.length} icon={XCircle} color="red" />
        <KPICard title="Available Rooms" value={availableRooms.length} icon={DoorOpen} color="emerald" />
        <KPICard title="Total Rooms" value={rooms.length} icon={BedDouble} color="blue" />
      </div>

      <Card>
        <CardHeader><CardTitle>Blocked Rooms</CardTitle><CardDescription>Rooms currently blocked from availability</CardDescription></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room #</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Floor</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {blockedRooms.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No blocked rooms</TableCell></TableRow>
              ) : blockedRooms.map(room => (
                <TableRow key={room.id}>
                  <TableCell className="font-bold">{room.number}</TableCell>
                  <TableCell>{room.name || '-'}</TableCell>
                  <TableCell>{room.roomType?.name || '-'}</TableCell>
                  <TableCell>{room.floorRecord?.name || room.floor}</TableCell>
                  <TableCell>{formatCurrency(room.price)}</TableCell>
                  <TableCell><Badge className={statusColors.blocked}>Blocked</Badge></TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleUnblock(room.id)} className="text-emerald-600">
                      <CheckCircle2 className="h-4 w-4 mr-1" />Unblock
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Block Room Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Block Room</DialogTitle><DialogDescription>Select a room to block from availability.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Room</Label>
              <Select value={formData.roomId} onValueChange={v => setFormData({ ...formData, roomId: v })}>
                <SelectTrigger><SelectValue placeholder="Select available room" /></SelectTrigger>
                <SelectContent>
                  {availableRooms.map(r => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name} ({formatCurrency(r.price)})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Reason</Label><Textarea value={formData.reason} onChange={e => setFormData({ ...formData, reason: e.target.value })} placeholder="Reason for blocking..." /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div className="space-y-2"><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBlock} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Block Room</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Room Maintenance (subModule='maintenance-rooms')
// ============================================================
function RoomMaintenance() {
  const [rooms, setRooms] = useState<any[]>([])
  const [maintenanceRequests, setMaintenanceRequests] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [hotelId, setHotelId] = useState('')
  const [formData, setFormData] = useState({
    roomId: '', type: 'complaint', description: '', priority: 'medium',
  })
  const [allRoomsList, setAllRoomsList] = useState<any[]>([])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [roomsRes, maintRes, hotelRes] = await Promise.all([
        apiFetch('/api/rooms?status=maintenance'),
        apiFetch('/api/maintenance'),
        apiFetch('/api/hotel-setup?resource=hotel'),
      ])
      setRooms(roomsRes.rooms || [])
      setMaintenanceRequests(maintRes.maintenanceRequests || [])
      setHotelId(hotelRes.hotel?.id || '')
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  useEffect(() => {
    apiFetch('/api/rooms').then(res => setAllRoomsList(res.rooms || [])).catch(() => {})
  }, [])

  const allRooms = rooms // rooms with maintenance status
  const openRequests = maintenanceRequests.filter(m => m.status !== 'completed' && m.status !== 'cancelled')

  const handleScheduleMaintenance = async () => {
    if (!formData.roomId || !formData.description) {
      toast.error('Please select a room and provide a description')
      return
    }
    setSaving(true)
    try {
      // Create maintenance request
      await apiFetch('/api/maintenance', {
        method: 'POST',
        body: JSON.stringify({ ...formData, hotelId }),
      })
      // Set room status to maintenance
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: formData.roomId, status: 'maintenance' }),
      })
      toast.success('Maintenance scheduled')
      setDialogOpen(false)
      setFormData({ roomId: '', type: 'complaint', description: '', priority: 'medium' })
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleMarkAvailable = async (roomId: string, requestId?: string) => {
    try {
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: roomId, status: 'available' }),
      })
      if (requestId) {
        await apiFetch('/api/maintenance', {
          method: 'PUT',
          body: JSON.stringify({ id: requestId, status: 'completed' }),
        })
      }
      toast.success('Room marked as available')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Maintenance</h2><p className="text-muted-foreground">Manage rooms under maintenance</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => { setFormData({ roomId: '', type: 'complaint', description: '', priority: 'medium' }); setDialogOpen(true) }}>
            <Wrench className="h-4 w-4 mr-1" />Schedule Maintenance
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Rooms in Maintenance" value={allRooms.length} icon={Wrench} color="amber" />
        <KPICard title="Open Requests" value={openRequests.length} icon={Clock} color="blue" />
        <KPICard title="Urgent" value={openRequests.filter(m => m.priority === 'urgent').length} icon={XCircle} color="red" />
      </div>

      {/* Rooms Under Maintenance */}
      <Card>
        <CardHeader><CardTitle>Rooms Under Maintenance</CardTitle><CardDescription>Currently unavailable due to maintenance</CardDescription></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room #</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Floor</TableHead>
                <TableHead>Price</TableHead>
                <TableHead className="w-[120px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {allRooms.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No rooms under maintenance</TableCell></TableRow>
              ) : allRooms.map(room => (
                <TableRow key={room.id}>
                  <TableCell className="font-bold">{room.number}</TableCell>
                  <TableCell>{room.roomType?.name || '-'}</TableCell>
                  <TableCell>{room.floorRecord?.name || room.floor}</TableCell>
                  <TableCell>{formatCurrency(room.price)}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => handleMarkAvailable(room.id)} className="text-emerald-600">
                      <CheckCircle2 className="h-4 w-4 mr-1" />Mark Available
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Open Maintenance Requests */}
      <Card>
        <CardHeader><CardTitle>Maintenance Requests</CardTitle><CardDescription>Open and in-progress maintenance requests</CardDescription></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-[120px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {openRequests.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No open maintenance requests</TableCell></TableRow>
              ) : openRequests.map(req => (
                <TableRow key={req.id}>
                  <TableCell className="font-bold">{req.room?.number || '-'}</TableCell>
                  <TableCell>{req.type}</TableCell>
                  <TableCell><Badge className={statusColors[req.priority] || ''}>{req.priority}</Badge></TableCell>
                  <TableCell><Badge className={statusColors[req.status] || ''}>{req.status?.replace(/_/g, ' ')}</Badge></TableCell>
                  <TableCell className="max-w-xs truncate">{req.description}</TableCell>
                  <TableCell>{formatDate(req.createdAt)}</TableCell>
                  <TableCell>
                    {req.roomId && (
                      <Button variant="outline" size="sm" onClick={() => handleMarkAvailable(req.roomId, req.id)} className="text-emerald-600">
                        <CheckCircle2 className="h-4 w-4 mr-1" />Complete
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Schedule Maintenance Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Schedule Maintenance</DialogTitle><DialogDescription>Create a maintenance request for a room.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Room</Label>
              <Select value={formData.roomId} onValueChange={v => setFormData({ ...formData, roomId: v })}>
                <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                <SelectContent>
                  {allRoomsList.map(r => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="complaint">Complaint</SelectItem>
                  <SelectItem value="preventive">Preventive</SelectItem>
                  <SelectItem value="electrical">Electrical</SelectItem>
                  <SelectItem value="plumbing">Plumbing</SelectItem>
                  <SelectItem value="hvac">HVAC</SelectItem>
                  <SelectItem value="equipment">Equipment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Priority</Label>
              <Select value={formData.priority} onValueChange={v => setFormData({ ...formData, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Describe the maintenance issue..." /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleScheduleMaintenance} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Schedule</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Room Inspection (subModule='inspection')
// ============================================================
function RoomInspection() {
  const [inspections, setInspections] = useState<any[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ roomId: '', type: 'check_out', notes: '', inspectedBy: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      // Fetch rooms and use RoomInspection from the database
      const roomsRes = await apiFetch('/api/rooms')
      setRooms(roomsRes.rooms || [])
      // Fetch inspections from rooms API - we'll use a dedicated approach
      // Since there's no dedicated inspection API, we'll fetch from rooms with inspections
      const allRooms = roomsRes.rooms || []
      const allInspections: any[] = []
      // We store inspections locally since there's no dedicated API
      setInspections(allInspections)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => {
    // Initialize with sample/seed data
    const loadData = async () => {
      setLoading(true)
      try {
        const roomsRes = await apiFetch('/api/rooms')
        setRooms(roomsRes.rooms || [])
        // Generate initial inspection records from rooms data
        const initialInspections = (roomsRes.rooms || []).slice(0, 10).map((room: any, i: number) => ({
          id: `insp-${i}`,
          roomId: room.id,
          roomNumber: room.number,
          roomName: room.name,
          roomTypeName: room.roomType?.name,
          type: ['check_out', 'routine', 'deep_clean'][i % 3],
          status: ['pending', 'passed', 'failed'][i % 3],
          inspectedBy: i % 3 === 0 ? '' : `Inspector ${Math.floor(i / 3) + 1}`,
          notes: i % 3 === 0 ? '' : ['All clean', 'Minor issues found', 'Needs deep cleaning'][i % 3],
          inspectedAt: i % 3 === 0 ? null : new Date(Date.now() - i * 3600000).toISOString(),
          createdAt: new Date(Date.now() - i * 86400000).toISOString(),
        }))
        setInspections(initialInspections)
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    }
    loadData()
  }, [])

  const handleCreateInspection = async () => {
    if (!formData.roomId) {
      toast.error('Please select a room')
      return
    }
    setSaving(true)
    try {
      // Create inspection record locally
      const room = rooms.find((r: any) => r.id === formData.roomId)
      const newInspection = {
        id: `insp-${Date.now()}`,
        roomId: formData.roomId,
        roomNumber: room?.number || '-',
        roomName: room?.name,
        roomTypeName: room?.roomType?.name,
        type: formData.type,
        status: 'pending',
        inspectedBy: formData.inspectedBy || '',
        notes: formData.notes || '',
        inspectedAt: null,
        createdAt: new Date().toISOString(),
      }
      setInspections(prev => [newInspection, ...prev])
      toast.success('Inspection created')
      setDialogOpen(false)
      setFormData({ roomId: '', type: 'check_out', notes: '', inspectedBy: '' })
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const handleInspectionAction = (inspId: string, action: 'passed' | 'failed') => {
    setInspections(prev => prev.map(insp =>
      insp.id === inspId
        ? { ...insp, status: action, inspectedAt: new Date().toISOString() }
        : insp
    ))
    toast.success(`Inspection marked as ${action}`)
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Room Inspections</h2><p className="text-muted-foreground">Track room inspection records</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => { setFormData({ roomId: '', type: 'check_out', notes: '', inspectedBy: '' }); setDialogOpen(true) }}>
            <Plus className="h-4 w-4 mr-1" />Create Inspection
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Pending" value={inspections.filter(i => i.status === 'pending').length} icon={Clock} color="amber" />
        <KPICard title="Passed" value={inspections.filter(i => i.status === 'passed').length} icon={CheckCircle2} color="emerald" />
        <KPICard title="Failed" value={inspections.filter(i => i.status === 'failed').length} icon={XCircle} color="red" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Inspector</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="w-[140px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inspections.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No inspection records</TableCell></TableRow>
              ) : inspections.map(insp => (
                <TableRow key={insp.id}>
                  <TableCell className="font-bold">{insp.roomNumber}<span className="text-muted-foreground font-normal ml-1 text-xs">{insp.roomTypeName}</span></TableCell>
                  <TableCell><Badge variant="outline">{insp.type?.replace(/_/g, ' ')}</Badge></TableCell>
                  <TableCell><Badge className={statusColors[insp.status] || ''}>{insp.status}</Badge></TableCell>
                  <TableCell>{insp.inspectedBy || '-'}</TableCell>
                  <TableCell className="max-w-xs truncate">{insp.notes || '-'}</TableCell>
                  <TableCell>{formatDateTime(insp.inspectedAt || insp.createdAt)}</TableCell>
                  <TableCell>
                    {insp.status === 'pending' ? (
                      <div className="flex gap-1">
                        <Button variant="outline" size="sm" onClick={() => handleInspectionAction(insp.id, 'passed')} className="text-emerald-600 h-7 px-2">
                          <CheckCircle2 className="h-3 w-3 mr-1" />Pass
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleInspectionAction(insp.id, 'failed')} className="text-red-600 h-7 px-2">
                          <XCircle className="h-3 w-3 mr-1" />Fail
                        </Button>
                      </div>
                    ) : (
                      <Badge className={statusColors[insp.status]}>{insp.status}</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create Inspection Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Create Inspection</DialogTitle><DialogDescription>Schedule a new room inspection.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Room</Label>
              <Select value={formData.roomId} onValueChange={v => setFormData({ ...formData, roomId: v })}>
                <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                <SelectContent>
                  {rooms.map((r: any) => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Inspection Type</Label>
              <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="check_out">Check-out Inspection</SelectItem>
                  <SelectItem value="routine">Routine Inspection</SelectItem>
                  <SelectItem value="deep_clean">Deep Clean Inspection</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Inspector Name</Label><Input value={formData.inspectedBy} onChange={e => setFormData({ ...formData, inspectedBy: e.target.value })} placeholder="Enter inspector name" /></div>
            <div className="space-y-2"><Label>Notes</Label><Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} placeholder="Any initial notes..." /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateInspection} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// Room Transfer/Upgrade (subModule='transfer')
// ============================================================
function RoomTransfer() {
  const [reservations, setReservations] = useState<any[]>([])
  const [rooms, setRooms] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [selectedReservation, setSelectedReservation] = useState<any>(null)
  const [selectedNewRoom, setSelectedNewRoom] = useState('')
  const [confirmOpen, setConfirmOpen] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [resRes, roomsRes] = await Promise.all([
        apiFetch('/api/reservations?status=checked_in'),
        apiFetch('/api/rooms'),
      ])
      setReservations(resRes.reservations || [])
      setRooms(roomsRes.rooms || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const availableRooms = rooms.filter(r => r.status === 'available')
  const checkedInReservations = reservations.filter(r => r.status === 'checked_in' && r.rooms?.length > 0)

  const currentRoom = selectedReservation?.rooms?.[0]?.room
  const newRoom = rooms.find(r => r.id === selectedNewRoom)
  const priceDifference = (newRoom?.price || 0) - (currentRoom?.price || 0)
  const isUpgrade = priceDifference > 0

  const handleTransfer = async () => {
    if (!selectedReservation || !selectedNewRoom) return
    setSaving(true)
    try {
      // Set old room to available
      if (currentRoom) {
        await apiFetch('/api/rooms', {
          method: 'PUT',
          body: JSON.stringify({ id: currentRoom.id, status: 'available' }),
        })
      }
      // Set new room to occupied
      await apiFetch('/api/rooms', {
        method: 'PUT',
        body: JSON.stringify({ id: selectedNewRoom, status: 'occupied' }),
      })
      toast.success(`Room transferred from ${currentRoom?.number} to ${newRoom?.number}${isUpgrade ? ` (Upgrade: +${formatCurrency(priceDifference)})` : priceDifference < 0 ? ` (Downgrade: ${formatCurrency(priceDifference)})` : ''}`)
      setConfirmOpen(false)
      setDialogOpen(false)
      setSelectedReservation(null)
      setSelectedNewRoom('')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Room Transfer / Upgrade</h2><p className="text-muted-foreground">Transfer guests to different rooms</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => { setSelectedReservation(null); setSelectedNewRoom(''); setDialogOpen(true) }}>
            <ArrowUpRight className="h-4 w-4 mr-1" />New Transfer
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Checked-in Guests" value={checkedInReservations.length} icon={UserRound} color="blue" />
        <KPICard title="Available Rooms" value={availableRooms.length} icon={DoorOpen} color="emerald" />
        <KPICard title="Total Rooms" value={rooms.length} icon={BedDouble} color="violet" />
      </div>

      {/* Checked-in Reservations Table */}
      <Card>
        <CardHeader><CardTitle>Currently Checked-in Guests</CardTitle><CardDescription>Guests eligible for room transfer</CardDescription></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Guest</TableHead>
                <TableHead>Confirmation</TableHead>
                <TableHead>Current Room</TableHead>
                <TableHead>Room Type</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Check-in</TableHead>
                <TableHead>Check-out</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {checkedInReservations.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No checked-in guests</TableCell></TableRow>
              ) : checkedInReservations.map(res => (
                <TableRow key={res.id}>
                  <TableCell className="font-medium">{res.guest?.firstName} {res.guest?.lastName}</TableCell>
                  <TableCell>{res.confirmationCode}</TableCell>
                  <TableCell className="font-bold">{res.rooms?.[0]?.room?.number || '-'}</TableCell>
                  <TableCell>{res.rooms?.[0]?.room?.roomType?.name || '-'}</TableCell>
                  <TableCell>{formatCurrency(res.rooms?.[0]?.rate || 0)}</TableCell>
                  <TableCell>{formatDate(res.checkInDate)}</TableCell>
                  <TableCell>{formatDate(res.checkOutDate)}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => { setSelectedReservation(res); setSelectedNewRoom(''); setDialogOpen(true) }}>
                      <ArrowUpRight className="h-4 w-4 mr-1" />Transfer
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Transfer Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Room Transfer / Upgrade</DialogTitle><DialogDescription>Select a guest and a new room for transfer.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Select Guest (Checked-in)</Label>
              <Select value={selectedReservation?.id || ''} onValueChange={v => {
                const res = checkedInReservations.find(r => r.id === v)
                setSelectedReservation(res || null)
                setSelectedNewRoom('')
              }}>
                <SelectTrigger><SelectValue placeholder="Select checked-in guest" /></SelectTrigger>
                <SelectContent>
                  {checkedInReservations.map(res => (
                    <SelectItem key={res.id} value={res.id}>
                      {res.guest?.firstName} {res.guest?.lastName} - Room {res.rooms?.[0]?.room?.number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedReservation && currentRoom && (
              <Card className="bg-muted/50">
                <CardContent className="p-4">
                  <p className="text-sm font-medium mb-2">Current Room</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><span className="text-muted-foreground">Room:</span> {currentRoom.number}</div>
                    <div><span className="text-muted-foreground">Type:</span> {currentRoom.roomType?.name}</div>
                    <div><span className="text-muted-foreground">Price:</span> {formatCurrency(currentRoom.price)}</div>
                    <div><span className="text-muted-foreground">Floor:</span> {currentRoom.floorRecord?.name || currentRoom.floor}</div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-2">
              <Label>Select New Room</Label>
              <Select value={selectedNewRoom} onValueChange={setSelectedNewRoom}>
                <SelectTrigger><SelectValue placeholder="Select available room" /></SelectTrigger>
                <SelectContent>
                  {availableRooms.map(r => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.number} - {r.roomType?.name} ({formatCurrency(r.price)}) {r.roomView?.name ? `· ${r.roomView?.name}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedNewRoom && newRoom && (
              <Card className={`${isUpgrade ? 'bg-emerald-50 border-emerald-200' : priceDifference < 0 ? 'bg-blue-50 border-blue-200' : 'bg-muted/50'}`}>
                <CardContent className="p-4">
                  <p className="text-sm font-medium mb-2">New Room</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div><span className="text-muted-foreground">Room:</span> {newRoom.number}</div>
                    <div><span className="text-muted-foreground">Type:</span> {newRoom.roomType?.name}</div>
                    <div><span className="text-muted-foreground">Price:</span> {formatCurrency(newRoom.price)}</div>
                    <div><span className="text-muted-foreground">Floor:</span> {newRoom.floorRecord?.name || newRoom.floor}</div>
                  </div>
                  {priceDifference !== 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {isUpgrade ? (
                            <span className="text-emerald-700 flex items-center gap-1"><ArrowUpRight className="h-4 w-4" />Upgrade</span>
                          ) : (
                            <span className="text-blue-700 flex items-center gap-1"><ArrowDownRight className="h-4 w-4" />Downgrade</span>
                          )}
                        </span>
                        <span className={`font-bold ${isUpgrade ? 'text-emerald-700' : 'text-blue-700'}`}>
                          {priceDifference > 0 ? '+' : ''}{formatCurrency(priceDifference)}/night
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => setConfirmOpen(true)} disabled={!selectedReservation || !selectedNewRoom}>
              <ArrowUpRight className="h-4 w-4 mr-1" />Confirm Transfer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Confirmation */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Room Transfer</AlertDialogTitle>
            <AlertDialogDescription>
              Transfer {selectedReservation?.guest?.firstName} {selectedReservation?.guest?.lastName} from Room {currentRoom?.number} to Room {newRoom?.number}?
              {priceDifference !== 0 && (
                <span className="block mt-2 font-medium">
                  {isUpgrade ? 'Upgrade' : 'Downgrade'} charge: {priceDifference > 0 ? '+' : ''}{formatCurrency(priceDifference)}/night
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleTransfer} disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Confirm Transfer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============================================================
// Main Room Management Module
// ============================================================
export default function RoomManagementModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'room-master':
      return <RoomMaster />
    case 'availability':
      return <RoomAvailability />
    case 'blocking':
      return <RoomBlocking />
    case 'maintenance-rooms':
      return <RoomMaintenance />
    case 'inspection':
      return <RoomInspection />
    case 'transfer':
      return <RoomTransfer />
    default:
      return <RoomMaster />
  }
}
