'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ ROLE MANAGEMENT ============
const ALL_PERMISSIONS = [
  { module: 'dashboard', permissions: ['view'] },
  { module: 'front-desk', permissions: ['view', 'create', 'edit', 'delete'] },
  { module: 'reservations', permissions: ['view', 'create', 'edit', 'cancel'] },
  { module: 'rooms', permissions: ['view', 'create', 'edit', 'delete'] },
  { module: 'guests', permissions: ['view', 'create', 'edit', 'delete'] },
  { module: 'housekeeping', permissions: ['view', 'create', 'edit'] },
  { module: 'restaurant', permissions: ['view', 'create', 'edit'] },
  { module: 'banquet', permissions: ['view', 'create', 'edit'] },
  { module: 'spa', permissions: ['view', 'create', 'edit'] },
  { module: 'laundry', permissions: ['view', 'create', 'edit'] },
  { module: 'hr', permissions: ['view', 'create', 'edit', 'delete'] },
  { module: 'accounting', permissions: ['view', 'create', 'edit', 'approve'] },
  { module: 'inventory', permissions: ['view', 'create', 'edit'] },
  { module: 'maintenance', permissions: ['view', 'create', 'edit'] },
  { module: 'reports', permissions: ['view'] },
  { module: 'security', permissions: ['view', 'create', 'edit', 'delete'] },
  { module: 'marketing', permissions: ['view', 'create', 'edit'] },
  { module: 'settings', permissions: ['view', 'edit'] },
]

function RoleManagement() {
  const [roles, setRoles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formData, setFormData] = useState({ name: '', description: '', permissions: {} as Record<string, string[]> })

  useEffect(() => {
    setTimeout(() => {
      setRoles([
        { id: '1', name: 'Super Admin', description: 'Full system access', permissions: { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit', 'delete'], reservations: ['view', 'create', 'edit', 'cancel'], rooms: ['view', 'create', 'edit', 'delete'], guests: ['view', 'create', 'edit', 'delete'], housekeeping: ['view', 'create', 'edit'], restaurant: ['view', 'create', 'edit'], banquet: ['view', 'create', 'edit'], spa: ['view', 'create', 'edit'], laundry: ['view', 'create', 'edit'], hr: ['view', 'create', 'edit', 'delete'], accounting: ['view', 'create', 'edit', 'approve'], inventory: ['view', 'create', 'edit'], maintenance: ['view', 'create', 'edit'], reports: ['view'], security: ['view', 'create', 'edit', 'delete'], marketing: ['view', 'create', 'edit'], settings: ['view', 'edit'] }, userCount: 2, isSystem: true },
        { id: '2', name: 'Manager', description: 'Department management access', permissions: { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit'], reservations: ['view', 'create', 'edit', 'cancel'], rooms: ['view', 'create', 'edit'], guests: ['view', 'create', 'edit'], housekeeping: ['view', 'create', 'edit'], restaurant: ['view', 'create', 'edit'], reports: ['view'] }, userCount: 5, isSystem: false },
        { id: '3', name: 'Front Desk', description: 'Front desk operations', permissions: { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit'], reservations: ['view', 'create', 'edit'], rooms: ['view'], guests: ['view', 'create', 'edit'] }, userCount: 8, isSystem: false },
        { id: '4', name: 'Housekeeping', description: 'Housekeeping staff access', permissions: { housekeeping: ['view', 'create', 'edit'], rooms: ['view'] }, userCount: 12, isSystem: false },
        { id: '5', name: 'Accountant', description: 'Finance and accounting', permissions: { accounting: ['view', 'create', 'edit', 'approve'], reports: ['view'] }, userCount: 3, isSystem: false },
        { id: '6', name: 'Viewer', description: 'Read-only access', permissions: { dashboard: ['view'], reports: ['view'] }, userCount: 4, isSystem: false },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ name: '', description: '', permissions: {} }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name, description: item.description, permissions: { ...item.permissions } }); setDialogOpen(true) }

  const togglePermission = (module: string, perm: string) => {
    const current = formData.permissions[module] || []
    const updated = current.includes(perm) ? current.filter((p: string) => p !== perm) : [...current, perm]
    setFormData({ ...formData, permissions: { ...formData.permissions, [module]: updated } })
  }

  const selectAllForModule = (module: string, perms: string[]) => {
    setFormData({ ...formData, permissions: { ...formData.permissions, [module]: perms } })
  }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setRoles(prev => prev.map(r => r.id === editItem.id ? { ...r, ...formData } : r))
      toast.success('Role updated')
    } else {
      setRoles(prev => [...prev, { ...formData, id: Date.now().toString(), userCount: 0, isSystem: false }])
      toast.success('Role created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setRoles(prev => prev.filter(r => r.id !== deleteId)); toast.success('Role deleted'); setDeleteId(null) }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Total Roles" value={roles.length} subtitle="Defined roles" color="blue" />
        <KPICard title="Total Users" value={roles.reduce((s, r) => s + r.userCount, 0)} subtitle="With assigned roles" color="emerald" />
        <KPICard title="System Roles" value={roles.filter(r => r.isSystem).length} subtitle="Cannot delete" color="amber" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Role Management</h2><p className="text-muted-foreground">Define roles and assign permissions</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Role</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Role Name</TableHead><TableHead>Description</TableHead><TableHead>Permissions</TableHead><TableHead>Users</TableHead><TableHead>Type</TableHead><TableHead className="w-10" /></TableRow>
              </TableHeader>
              <TableBody>
                {roles.map(r => {
                  const permCount = Object.values(r.permissions).reduce((s: number, p: any) => s + p.length, 0)
                  return (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">{r.name}</TableCell>
                      <TableCell>{r.description}</TableCell>
                      <TableCell>{permCount} permissions</TableCell>
                      <TableCell>{r.userCount}</TableCell>
                      <TableCell>{r.isSystem ? <Badge className="bg-amber-100 text-amber-800">System</Badge> : <Badge variant="outline">Custom</Badge>}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(r)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            {!r.isSystem && <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(r.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Role</DialogTitle><DialogDescription>Configure role name and permissions per module.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Role Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
              <div><Label>Description</Label><Input value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} /></div>
            </div>
            <Separator />
            <h4 className="font-medium">Module Permissions</h4>
            <div className="space-y-3">
              {ALL_PERMISSIONS.map(mp => (
                <div key={mp.module} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm capitalize">{mp.module.replace(/-/g, ' ')}</span>
                    <Button variant="ghost" size="sm" className="text-xs h-6" onClick={() => selectAllForModule(mp.module, mp.permissions)}>Select All</Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {mp.permissions.map(p => {
                      const active = (formData.permissions[mp.module] || []).includes(p)
                      return (
                        <button key={p} onClick={() => togglePermission(mp.module, p)}
                          className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${active ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-gray-100 text-gray-500 border border-gray-200'}`}>
                          {p}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Are you sure you want to delete this role? Users with this role will need to be reassigned.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ USER MANAGEMENT ============
function UserManagement() {
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', role: 'Front Desk', department: '', status: 'active' })

  useEffect(() => {
    setTimeout(() => {
      setUsers([
        { id: '1', name: 'Admin User', email: 'admin@grandhotel.com', phone: '+8801711000001', role: 'Super Admin', department: 'Management', status: 'active', lastLogin: '2024-11-15T08:00:00' },
        { id: '2', name: 'Rahim Uddin', email: 'rahim@grandhotel.com', phone: '+8801711000002', role: 'Manager', department: 'Front Office', status: 'active', lastLogin: '2024-11-15T07:45:00' },
        { id: '3', name: 'Fatima Begum', email: 'fatima@grandhotel.com', phone: '+8801711000003', role: 'Front Desk', department: 'Front Office', status: 'active', lastLogin: '2024-11-15T08:30:00' },
        { id: '4', name: 'Karim Hossain', email: 'karim@grandhotel.com', phone: '+8801711000004', role: 'Housekeeping', department: 'Housekeeping', status: 'active', lastLogin: '2024-11-14T06:00:00' },
        { id: '5', name: 'Nasreen Akter', email: 'nasreen@grandhotel.com', phone: '+8801711000005', role: 'Accountant', department: 'Finance', status: 'active', lastLogin: '2024-11-15T09:00:00' },
        { id: '6', name: 'Alam Hossain', email: 'alam@grandhotel.com', phone: '+8801711000006', role: 'Housekeeping', department: 'Maintenance', status: 'active', lastLogin: '2024-11-15T07:00:00' },
        { id: '7', name: 'Sara Khan', email: 'sara@grandhotel.com', phone: '+8801711000007', role: 'Front Desk', department: 'Front Office', status: 'inactive', lastLogin: '2024-10-20T10:00:00' },
        { id: '8', name: 'Jalal Miah', email: 'jalal@grandhotel.com', phone: '+8801711000008', role: 'Manager', department: 'Maintenance', status: 'active', lastLogin: '2024-11-15T06:30:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const pageSize = 10
  const filtered = users.filter(u => !search || Object.values(u).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const openCreate = () => { setEditItem(null); setFormData({ name: '', email: '', phone: '', role: 'Front Desk', department: '', status: 'active' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ name: item.name, email: item.email, phone: item.phone, role: item.role, department: item.department, status: item.status }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setUsers(prev => prev.map(u => u.id === editItem.id ? { ...u, ...formData } : u))
      toast.success('User updated')
    } else {
      setUsers(prev => [...prev, { ...formData, id: Date.now().toString(), lastLogin: '-' }])
      toast.success('User created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setUsers(prev => prev.filter(u => u.id !== deleteId)); toast.success('User deleted'); setDeleteId(null) }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <KPICard title="Total Users" value={users.length} subtitle="System accounts" color="blue" />
        <KPICard title="Active" value={users.filter(u => u.status === 'active').length} subtitle="Currently active" color="emerald" />
        <KPICard title="Inactive" value={users.filter(u => u.status === 'inactive').length} subtitle="Deactivated" color="gray" />
        <KPICard title="Roles Used" value={new Set(users.map(u => u.role)).size} subtitle="Different roles" color="violet" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">User Management</h2><p className="text-muted-foreground">Manage system users and role assignments</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search users..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />Add User</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Phone</TableHead><TableHead>Role</TableHead><TableHead>Department</TableHead><TableHead>Last Login</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(u => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.name}</TableCell>
                      <TableCell>{u.email}</TableCell>
                      <TableCell>{u.phone}</TableCell>
                      <TableCell><Badge variant="outline">{u.role}</Badge></TableCell>
                      <TableCell>{u.department}</TableCell>
                      <TableCell>{u.lastLogin ? formatDateTime(u.lastLogin) : '-'}</TableCell>
                      <TableCell><Badge className={statusColors[u.status] || ''}>{u.status}</Badge></TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(u)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(u.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'Add'} User</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Full Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Email</Label><Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Role</Label>
                <Select value={formData.role} onValueChange={v => setFormData({ ...formData, role: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Super Admin">Super Admin</SelectItem><SelectItem value="Manager">Manager</SelectItem><SelectItem value="Front Desk">Front Desk</SelectItem><SelectItem value="Housekeeping">Housekeeping</SelectItem><SelectItem value="Accountant">Accountant</SelectItem><SelectItem value="Viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Department</Label><Input value={formData.department} onChange={e => setFormData({ ...formData, department: e.target.value })} /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Delete this user account? This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ PERMISSIONS ============
function Permissions() {
  const [roles] = useState([
    { id: '1', name: 'Super Admin' },
    { id: '2', name: 'Manager' },
    { id: '3', name: 'Front Desk' },
    { id: '4', name: 'Housekeeping' },
    { id: '5', name: 'Accountant' },
    { id: '6', name: 'Viewer' },
  ])
  const [loading, setLoading] = useState(true)
  const [permissionMatrix, setPermissionMatrix] = useState<Record<string, Record<string, string[]>>>({})

  useEffect(() => {
    setTimeout(() => {
      setPermissionMatrix({
        'Super Admin': { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit', 'delete'], reservations: ['view', 'create', 'edit', 'cancel'], rooms: ['view', 'create', 'edit', 'delete'], guests: ['view', 'create', 'edit', 'delete'], housekeeping: ['view', 'create', 'edit'], restaurant: ['view', 'create', 'edit'], accounting: ['view', 'create', 'edit', 'approve'], reports: ['view'], security: ['view', 'create', 'edit', 'delete'], settings: ['view', 'edit'] },
        'Manager': { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit'], reservations: ['view', 'create', 'edit', 'cancel'], rooms: ['view', 'create', 'edit'], guests: ['view', 'create', 'edit'], housekeeping: ['view', 'create', 'edit'], reports: ['view'] },
        'Front Desk': { dashboard: ['view'], 'front-desk': ['view', 'create', 'edit'], reservations: ['view', 'create', 'edit'], rooms: ['view'], guests: ['view', 'create', 'edit'] },
        'Housekeeping': { housekeeping: ['view', 'create', 'edit'], rooms: ['view'] },
        'Accountant': { accounting: ['view', 'create', 'edit', 'approve'], reports: ['view'] },
        'Viewer': { dashboard: ['view'], reports: ['view'] },
      }); setLoading(false)
    }, 400)
  }, [])

  const permLabels: Record<string, string> = { view: 'V', create: 'C', edit: 'E', delete: 'D', cancel: 'X', approve: 'A' }
  const permColors: Record<string, string> = { view: 'bg-blue-100 text-blue-800', create: 'bg-emerald-100 text-emerald-800', edit: 'bg-amber-100 text-amber-800', delete: 'bg-red-100 text-red-800', cancel: 'bg-orange-100 text-orange-800', approve: 'bg-violet-100 text-violet-800' }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Permission Matrix</h2><p className="text-muted-foreground">Module-level permission overview for all roles</p></div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[150px]">Module</TableHead>
                  {roles.map(r => <TableHead key={r.id} className="text-center min-w-[120px]">{r.name}</TableHead>)}
                </TableRow>
              </TableHeader>
              <TableBody>
                {ALL_PERMISSIONS.map(mp => (
                  <TableRow key={mp.module}>
                    <TableCell className="font-medium capitalize">{mp.module.replace(/-/g, ' ')}</TableCell>
                    {roles.map(r => {
                      const perms = permissionMatrix[r.name]?.[mp.module] || []
                      return (
                        <TableCell key={r.id} className="text-center">
                          <div className="flex flex-wrap justify-center gap-1">
                            {mp.permissions.map(p => (
                              <span key={p} className={`inline-flex items-center justify-center w-6 h-6 rounded text-xs font-bold ${perms.includes(p) ? permColors[p] : 'bg-gray-50 text-gray-300'}`}>
                                {permLabels[p]}
                              </span>
                            ))}
                          </div>
                        </TableCell>
                      )
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="text-base">Legend</CardTitle></CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            {Object.entries(permLabels).map(([key, label]) => (
              <div key={key} className="flex items-center gap-1.5">
                <span className={`inline-flex items-center justify-center w-6 h-6 rounded text-xs font-bold ${permColors[key]}`}>{label}</span>
                <span className="text-sm capitalize">{key}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ AUDIT LOG ============
function AuditLog() {
  const [logs, setLogs] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterModule, setFilterModule] = useState('all')
  const [filterAction, setFilterAction] = useState('all')
  const [page, setPage] = useState(1)

  useEffect(() => {
    setTimeout(() => {
      setLogs([
        { id: '1', user: 'Admin User', action: 'create', module: 'reservations', details: 'Created reservation RES-1001 for Ahmed Khan', ip: '192.168.1.10', timestamp: '2024-11-15T14:30:00' },
        { id: '2', user: 'Fatima Begum', action: 'edit', module: 'guests', details: 'Updated guest profile for Sarah Rahman', ip: '192.168.1.15', timestamp: '2024-11-15T14:15:00' },
        { id: '3', user: 'Rahim Uddin', action: 'edit', module: 'rooms', details: 'Changed Room 205 status to maintenance', ip: '192.168.1.12', timestamp: '2024-11-15T13:00:00' },
        { id: '4', user: 'Admin User', action: 'delete', module: 'reservations', details: 'Cancelled reservation RES-0998 (No-show)', ip: '192.168.1.10', timestamp: '2024-11-15T12:30:00' },
        { id: '5', user: 'Nasreen Akter', action: 'create', module: 'accounting', details: 'Posted invoice INV-2050 for Room 301', ip: '192.168.1.20', timestamp: '2024-11-15T11:45:00' },
        { id: '6', user: 'Karim Hossain', action: 'edit', module: 'housekeeping', details: 'Marked Room 102 cleaning as completed', ip: '192.168.1.18', timestamp: '2024-11-15T11:00:00' },
        { id: '7', user: 'Admin User', action: 'edit', module: 'security', details: 'Updated role permissions for Manager', ip: '192.168.1.10', timestamp: '2024-11-15T10:30:00' },
        { id: '8', user: 'Fatima Begum', action: 'create', module: 'front-desk', details: 'Checked in guest Ahmed Khan to Room 501', ip: '192.168.1.15', timestamp: '2024-11-15T10:00:00' },
        { id: '9', user: 'Jalal Miah', action: 'create', module: 'maintenance', details: 'Created work order for AC repair Room 205', ip: '192.168.1.22', timestamp: '2024-11-15T09:30:00' },
        { id: '10', user: 'Admin User', action: 'login', module: 'security', details: 'User logged in from 192.168.1.10', ip: '192.168.1.10', timestamp: '2024-11-15T08:00:00' },
        { id: '11', user: 'Rahim Uddin', action: 'edit', module: 'reservations', details: 'Extended stay for RES-1002 by 2 nights', ip: '192.168.1.12', timestamp: '2024-11-14T16:00:00' },
        { id: '12', user: 'Nasreen Akter', action: 'approve', module: 'accounting', details: 'Approved payment PAY-2024-004', ip: '192.168.1.20', timestamp: '2024-11-14T15:00:00' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const filtered = logs.filter(l => {
    const matchSearch = !search || Object.values(l).some(v => String(v || '').toLowerCase().includes(search.toLowerCase()))
    const matchModule = filterModule === 'all' || l.module === filterModule
    const matchAction = filterAction === 'all' || l.action === filterAction
    return matchSearch && matchModule && matchAction
  })
  const pageSize = 10
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const actionColors: Record<string, string> = { create: 'bg-emerald-100 text-emerald-800', edit: 'bg-blue-100 text-blue-800', delete: 'bg-red-100 text-red-800', login: 'bg-gray-100 text-gray-800', approve: 'bg-violet-100 text-violet-800' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <KPICard title="Total Activities" value={logs.length} subtitle="All time" color="blue" />
        <KPICard title="Today" value={logs.filter(l => l.timestamp.startsWith('2024-11-15')).length} subtitle="Activities today" color="emerald" />
        <KPICard title="Creates" value={logs.filter(l => l.action === 'create').length} subtitle="New records" color="amber" />
        <KPICard title="Deletes" value={logs.filter(l => l.action === 'delete').length} subtitle="Removed records" color="red" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Audit Log</h2><p className="text-muted-foreground">Activity log with timestamp, user, action, and module</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-48" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Select value={filterModule} onValueChange={v => { setFilterModule(v); setPage(1) }}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Modules</SelectItem>
              <SelectItem value="reservations">Reservations</SelectItem><SelectItem value="guests">Guests</SelectItem>
              <SelectItem value="rooms">Rooms</SelectItem><SelectItem value="front-desk">Front Desk</SelectItem>
              <SelectItem value="accounting">Accounting</SelectItem><SelectItem value="housekeeping">Housekeeping</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem><SelectItem value="security">Security</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterAction} onValueChange={v => { setFilterAction(v); setPage(1) }}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem><SelectItem value="create">Create</SelectItem>
              <SelectItem value="edit">Edit</SelectItem><SelectItem value="delete">Delete</SelectItem>
              <SelectItem value="approve">Approve</SelectItem><SelectItem value="login">Login</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Timestamp</TableHead><TableHead>User</TableHead><TableHead>Action</TableHead><TableHead>Module</TableHead><TableHead>Details</TableHead><TableHead>IP</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(l => (
                    <TableRow key={l.id}>
                      <TableCell>{formatDateTime(l.timestamp)}</TableCell>
                      <TableCell className="font-medium">{l.user}</TableCell>
                      <TableCell><Badge className={actionColors[l.action] || ''}>{l.action}</Badge></TableCell>
                      <TableCell><Badge variant="outline">{l.module}</Badge></TableCell>
                      <TableCell className="max-w-[300px] truncate">{l.details}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{l.ip}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function SecurityModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'roles': return <RoleManagement />
    case 'users': return <UserManagement />
    case 'permissions': return <Permissions />
    case 'audit-log': return <AuditLog />
    default: return <EmptyState title="Unknown Sub-Module" description={`Security sub-module "${subModule}" not found.`} />
  }
}
