'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ WEBSITE BOOKING ============
function WebsiteBooking() {
  const [config, setConfig] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setConfig({
        siteName: 'Grand Hotel & Resort',
        tagline: 'Experience Luxury in the Heart of Dhaka',
        primaryColor: '#1a5632',
        logo: '/logo.png',
        bookingEngineEnabled: true,
        allowGuestBooking: true,
        requirePayment: false,
        depositPercentage: 20,
        maxAdvanceDays: 365,
        minAdvanceHours: 6,
        cancellationPolicy: 'Free cancellation up to 48 hours before check-in. 50% charge for late cancellation.',
        checkInTime: '14:00',
        checkOutTime: '12:00',
        currency: 'BDT',
        languages: ['en', 'bn'],
        seoTitle: 'Grand Hotel Dhaka - Luxury Accommodation',
        seoDescription: 'Book your stay at Grand Hotel Dhaka. Premium rooms, world-class dining, and exceptional service.',
        socialLinks: { facebook: '', instagram: '', twitter: '' },
      }); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Website booking configuration saved'); setSaving(false)
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Website Booking Engine</h2><p className="text-muted-foreground">Configure your hotel's online booking engine</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">General Settings</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Site Name</Label><Input value={config.siteName} onChange={e => setConfig({ ...config, siteName: e.target.value })} /></div>
            <div><Label>Tagline</Label><Input value={config.tagline} onChange={e => setConfig({ ...config, tagline: e.target.value })} /></div>
            <div><Label>Primary Color</Label><div className="flex gap-2"><Input value={config.primaryColor} onChange={e => setConfig({ ...config, primaryColor: e.target.value })} /><div className="w-10 h-10 rounded border" style={{ backgroundColor: config.primaryColor }} /></div></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Check-in Time</Label><Input value={config.checkInTime} onChange={e => setConfig({ ...config, checkInTime: e.target.value })} /></div>
              <div><Label>Check-out Time</Label><Input value={config.checkOutTime} onChange={e => setConfig({ ...config, checkOutTime: e.target.value })} /></div>
            </div>
            <div><Label>Currency</Label>
              <Select value={config.currency} onValueChange={v => setConfig({ ...config, currency: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="BDT">BDT - Bangladeshi Taka</SelectItem><SelectItem value="USD">USD - US Dollar</SelectItem></SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Booking Settings</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between"><Label>Booking Engine Enabled</Label>
              <Select value={config.bookingEngineEnabled ? 'yes' : 'no'} onValueChange={v => setConfig({ ...config, bookingEngineEnabled: v === 'yes' })}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between"><Label>Allow Guest Booking (No Account)</Label>
              <Select value={config.allowGuestBooking ? 'yes' : 'no'} onValueChange={v => setConfig({ ...config, allowGuestBooking: v === 'yes' })}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between"><Label>Require Payment at Booking</Label>
              <Select value={config.requirePayment ? 'yes' : 'no'} onValueChange={v => setConfig({ ...config, requirePayment: v === 'yes' })}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>Deposit Percentage (%)</Label><Input type="number" value={config.depositPercentage} onChange={e => setConfig({ ...config, depositPercentage: Number(e.target.value) })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Max Advance Days</Label><Input type="number" value={config.maxAdvanceDays} onChange={e => setConfig({ ...config, maxAdvanceDays: Number(e.target.value) })} /></div>
              <div><Label>Min Advance Hours</Label><Input type="number" value={config.minAdvanceHours} onChange={e => setConfig({ ...config, minAdvanceHours: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Cancellation Policy</Label><Textarea value={config.cancellationPolicy} onChange={e => setConfig({ ...config, cancellationPolicy: e.target.value })} rows={3} /></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">SEO Settings</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>SEO Title</Label><Input value={config.seoTitle} onChange={e => setConfig({ ...config, seoTitle: e.target.value })} /></div>
            <div><Label>SEO Description</Label><Textarea value={config.seoDescription} onChange={e => setConfig({ ...config, seoDescription: e.target.value })} rows={3} /></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Booking Preview</CardTitle></CardHeader>
          <CardContent>
            <div className="border rounded-lg p-6 space-y-4">
              <div className="text-center">
                <h3 className="text-xl font-bold" style={{ color: config.primaryColor }}>{config.siteName}</h3>
                <p className="text-muted-foreground">{config.tagline}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Check-in</Label><Input type="date" className="h-8 text-sm" /></div>
                <div><Label className="text-xs">Check-out</Label><Input type="date" className="h-8 text-sm" /></div>
                <div><Label className="text-xs">Adults</Label><Input type="number" defaultValue={1} className="h-8 text-sm" /></div>
                <div><Label className="text-xs">Children</Label><Input type="number" defaultValue={0} className="h-8 text-sm" /></div>
              </div>
              <Button className="w-full" style={{ backgroundColor: config.primaryColor }}>Search Rooms</Button>
              <p className="text-xs text-center text-muted-foreground">Check-in: {config.checkInTime} | Check-out: {config.checkOutTime}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end"><Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save Configuration</Button></div>
    </div>
  )
}

// ============ MOBILE BOOKING ============
function MobileBooking() {
  const [config, setConfig] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setConfig({
        appEnabled: true, appName: 'Grand Hotel', appStoreLink: '', playStoreLink: '',
        pushNotifications: true, biometricLogin: true, mobileCheckIn: true,
        digitalKey: false, inAppChat: true, mobilePayments: true,
        loyaltyIntegration: true, roomService: true, spaBooking: false,
        theme: 'light', splashScreen: true, appVersion: '2.1.0',
        minAppVersion: '2.0.0',
      }); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Mobile booking settings saved'); setSaving(false)
  }

  if (loading) return <LoadingSkeleton />

  const features = [
    { key: 'pushNotifications', label: 'Push Notifications', desc: 'Send booking updates and offers' },
    { key: 'biometricLogin', label: 'Biometric Login', desc: 'Fingerprint/Face ID authentication' },
    { key: 'mobileCheckIn', label: 'Mobile Check-in', desc: 'Allow guests to check in from app' },
    { key: 'digitalKey', label: 'Digital Room Key', desc: 'Use phone as room key via Bluetooth' },
    { key: 'inAppChat', label: 'In-App Chat', desc: 'Chat with hotel staff' },
    { key: 'mobilePayments', label: 'Mobile Payments', desc: 'Pay through the app' },
    { key: 'loyaltyIntegration', label: 'Loyalty Integration', desc: 'Show points and tier info' },
    { key: 'roomService', label: 'Room Service Ordering', desc: 'Order food from the app' },
    { key: 'spaBooking', label: 'Spa & Wellness Booking', desc: 'Book spa appointments' },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="App Downloads" value="3,450" subtitle="Total installs" color="blue" />
        <KPICard title="Active Users" value="1,280" subtitle="Monthly active" color="emerald" />
        <KPICard title="App Bookings" value="342" subtitle="This month" color="violet" />
      </div>

      <div><h2 className="text-2xl font-bold">Mobile Booking Settings</h2><p className="text-muted-foreground">Configure the mobile app booking experience</p></div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">App Configuration</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between"><Label>Mobile App Enabled</Label>
              <Select value={config.appEnabled ? 'yes' : 'no'} onValueChange={v => setConfig({ ...config, appEnabled: v === 'yes' })}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>App Name</Label><Input value={config.appName} onChange={e => setConfig({ ...config, appName: e.target.value })} /></div>
            <div><Label>App Store Link</Label><Input value={config.appStoreLink} onChange={e => setConfig({ ...config, appStoreLink: e.target.value })} placeholder="https://apps.apple.com/..." /></div>
            <div><Label>Play Store Link</Label><Input value={config.playStoreLink} onChange={e => setConfig({ ...config, playStoreLink: e.target.value })} placeholder="https://play.google.com/..." /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Current Version</Label><Input value={config.appVersion} onChange={e => setConfig({ ...config, appVersion: e.target.value })} /></div>
              <div><Label>Min Required Version</Label><Input value={config.minAppVersion} onChange={e => setConfig({ ...config, minAppVersion: e.target.value })} /></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Feature Configuration</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              {features.map(f => (
                <div key={f.key} className="flex items-center justify-between p-3 rounded-lg border">
                  <div><p className="text-sm font-medium">{f.label}</p><p className="text-xs text-muted-foreground">{f.desc}</p></div>
                  <Select value={(config as any)[f.key] ? 'yes' : 'no'} onValueChange={v => setConfig({ ...config, [f.key]: v === 'yes' })}>
                    <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="yes">On</SelectItem><SelectItem value="no">Off</SelectItem></SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end"><Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save Settings</Button></div>
    </div>
  )
}

// ============ LIVE PRICING ============
function LivePricing() {
  const [rates, setRates] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    roomType: '', season: 'regular', basePrice: 0, weekendPrice: 0, holidayPrice: 0, startDate: '', endDate: '', status: 'active',
  })

  useEffect(() => {
    setTimeout(() => {
      setRates([
        { id: '1', roomType: 'Standard Single', season: 'regular', basePrice: 3500, weekendPrice: 4500, holidayPrice: 5500, startDate: '2024-01-01', endDate: '2024-12-31', status: 'active' },
        { id: '2', roomType: 'Standard Double', season: 'regular', basePrice: 4500, weekendPrice: 5500, holidayPrice: 7000, startDate: '2024-01-01', endDate: '2024-12-31', status: 'active' },
        { id: '3', roomType: 'Deluxe Room', season: 'regular', basePrice: 6500, weekendPrice: 8000, holidayPrice: 10000, startDate: '2024-01-01', endDate: '2024-12-31', status: 'active' },
        { id: '4', roomType: 'Suite', season: 'regular', basePrice: 12000, weekendPrice: 15000, holidayPrice: 20000, startDate: '2024-01-01', endDate: '2024-12-31', status: 'active' },
        { id: '5', roomType: 'Deluxe Room', season: 'peak', basePrice: 8000, weekendPrice: 10000, holidayPrice: 14000, startDate: '2024-12-15', endDate: '2025-01-05', status: 'active' },
        { id: '6', roomType: 'Suite', season: 'peak', basePrice: 16000, weekendPrice: 20000, holidayPrice: 28000, startDate: '2024-12-15', endDate: '2025-01-05', status: 'active' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const openCreate = () => { setEditItem(null); setFormData({ roomType: '', season: 'regular', basePrice: 0, weekendPrice: 0, holidayPrice: 0, startDate: '', endDate: '', status: 'active' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setRates(prev => prev.map(r => r.id === editItem.id ? { ...r, ...formData } : r))
      toast.success('Rate updated')
    } else {
      setRates(prev => [...prev, { ...formData, id: Date.now().toString() }])
      toast.success('Rate created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const seasons: Record<string, string> = { regular: 'Regular', peak: 'Peak Season', off: 'Off Season' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Rate Plans" value={rates.filter(r => r.status === 'active').length} subtitle="Currently live" color="emerald" />
        <KPICard title="Room Types" value={new Set(rates.map(r => r.roomType)).size} subtitle="Configured" color="blue" />
        <KPICard title="Seasons" value={new Set(rates.map(r => r.season)).size} subtitle="Rate periods" color="amber" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Live Pricing</h2><p className="text-muted-foreground">Manage room rates with seasonal adjustments</p></div>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Rate</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Room Type</TableHead><TableHead>Season</TableHead><TableHead>Base Price</TableHead><TableHead>Weekend</TableHead><TableHead>Holiday</TableHead><TableHead>Period</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
              </TableHeader>
              <TableBody>
                {rates.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.roomType}</TableCell>
                    <TableCell><Badge variant="outline">{seasons[r.season]}</Badge></TableCell>
                    <TableCell>{formatCurrency(r.basePrice)}</TableCell>
                    <TableCell>{formatCurrency(r.weekendPrice)}</TableCell>
                    <TableCell>{formatCurrency(r.holidayPrice)}</TableCell>
                    <TableCell className="text-xs">{formatDate(r.startDate)} - {formatDate(r.endDate)}</TableCell>
                    <TableCell><Badge className={statusColors[r.status] || ''}>{r.status}</Badge></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(r)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Rate Plan</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Room Type</Label><Input value={formData.roomType} onChange={e => setFormData({ ...formData, roomType: e.target.value })} /></div>
              <div><Label>Season</Label>
                <Select value={formData.season} onValueChange={v => setFormData({ ...formData, season: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(seasons).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><Label>Base Price</Label><Input type="number" value={formData.basePrice} onChange={e => setFormData({ ...formData, basePrice: Number(e.target.value) })} /></div>
              <div><Label>Weekend Price</Label><Input type="number" value={formData.weekendPrice} onChange={e => setFormData({ ...formData, weekendPrice: Number(e.target.value) })} /></div>
              <div><Label>Holiday Price</Label><Input type="number" value={formData.holidayPrice} onChange={e => setFormData({ ...formData, holidayPrice: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ ONLINE PAYMENT ============
function OnlinePayment() {
  const [gateways, setGateways] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [editGateway, setEditGateway] = useState<any>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setTimeout(() => {
      setGateways([
        { id: '1', name: 'bKash', type: 'mobile_banking', enabled: true, apiKey: 'bk_****3456', merchantNumber: '01711XXXXXX', testMode: false, currency: 'BDT' },
        { id: '2', name: 'Nagad', type: 'mobile_banking', enabled: true, apiKey: 'ng_****7890', merchantNumber: '01811XXXXXX', testMode: false, currency: 'BDT' },
        { id: '3', name: 'Rocket', type: 'mobile_banking', enabled: false, apiKey: '', merchantNumber: '', testMode: true, currency: 'BDT' },
        { id: '4', name: 'SSLCommerz', type: 'payment_gateway', enabled: true, apiKey: 'ssl_****1234', storeId: 'grand_hotel_live', testMode: false, currency: 'BDT' },
        { id: '5', name: 'Stripe', type: 'international', enabled: true, apiKey: 'sk_live_****xyz', webhookSecret: 'whsec_****', testMode: false, currency: 'USD' },
        { id: '6', name: 'PayPal', type: 'international', enabled: false, apiKey: '', clientId: '', testMode: true, currency: 'USD' },
        { id: '7', name: 'Bank Transfer', type: 'bank', enabled: true, accountName: 'Grand Hotel Ltd', accountNumber: 'XXXX-XXXX-4521', bankName: 'Dutch-Bangla Bank', routingNumber: '090260842', currency: 'BDT' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 500))
    toast.success('Gateway configuration saved'); setSaving(false); setDialogOpen(false)
  }

  const toggleGateway = (id: string) => {
    setGateways(prev => prev.map(g => g.id === id ? { ...g, enabled: !g.enabled } : g))
    toast.success('Gateway status updated')
  }

  const typeLabels: Record<string, string> = { mobile_banking: 'Mobile Banking', payment_gateway: 'Payment Gateway', international: 'International', bank: 'Bank Transfer' }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Gateways" value={gateways.filter(g => g.enabled).length} subtitle="Accepting payments" color="emerald" />
        <KPICard title="Total Gateways" value={gateways.length} subtitle="Configured" color="blue" />
        <KPICard title="Test Mode" value={gateways.filter(g => g.testMode).length} subtitle="In sandbox" color="amber" />
      </div>

      <div><h2 className="text-2xl font-bold">Online Payment Gateways</h2><p className="text-muted-foreground">Configure payment gateway integrations</p></div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gateways.map(g => (
            <Card key={g.id} className={!g.enabled ? 'opacity-60' : ''}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{g.name}</CardTitle>
                    <CardDescription>{typeLabels[g.type]}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    {g.testMode && <Badge variant="outline" className="text-amber-600">Test</Badge>}
                    <Badge className={g.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'}>{g.enabled ? 'Active' : 'Inactive'}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {g.apiKey && <div className="flex justify-between"><span className="text-muted-foreground">API Key:</span><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{g.apiKey}</code></div>}
                  {g.merchantNumber && <div className="flex justify-between"><span className="text-muted-foreground">Merchant:</span><span>{g.merchantNumber}</span></div>}
                  {g.storeId && <div className="flex justify-between"><span className="text-muted-foreground">Store ID:</span><span>{g.storeId}</span></div>}
                  {g.accountNumber && <div className="flex justify-between"><span className="text-muted-foreground">Account:</span><span>{g.accountNumber}</span></div>}
                  <div className="flex justify-between"><span className="text-muted-foreground">Currency:</span><span>{g.currency}</span></div>
                </div>
                <Separator className="my-3" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => { setEditGateway(g); setDialogOpen(true) }}><Edit className="h-3 w-3 mr-1" />Configure</Button>
                  <Button variant="outline" size="sm" onClick={() => toggleGateway(g.id)}>{g.enabled ? 'Disable' : 'Enable'}</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Configure {editGateway?.name}</DialogTitle><DialogDescription>{typeLabels[editGateway?.type]}</DialogDescription></DialogHeader>
          {editGateway && (
            <div className="space-y-4 py-2">
              <div><Label>API Key / Secret Key</Label><Input value={editGateway.apiKey} onChange={e => setEditGateway({ ...editGateway, apiKey: e.target.value })} type="password" /></div>
              {editGateway.type === 'mobile_banking' && <div><Label>Merchant Number</Label><Input value={editGateway.merchantNumber} onChange={e => setEditGateway({ ...editGateway, merchantNumber: e.target.value })} /></div>}
              {editGateway.type === 'payment_gateway' && <div><Label>Store ID</Label><Input value={editGateway.storeId} onChange={e => setEditGateway({ ...editGateway, storeId: e.target.value })} /></div>}
              {editGateway.type === 'international' && <div><Label>Client ID</Label><Input value={editGateway.clientId || ''} onChange={e => setEditGateway({ ...editGateway, clientId: e.target.value })} /></div>}
              {editGateway.type === 'bank' && (
                <>
                  <div><Label>Account Name</Label><Input value={editGateway.accountName} onChange={e => setEditGateway({ ...editGateway, accountName: e.target.value })} /></div>
                  <div><Label>Account Number</Label><Input value={editGateway.accountNumber} onChange={e => setEditGateway({ ...editGateway, accountNumber: e.target.value })} /></div>
                  <div><Label>Bank Name</Label><Input value={editGateway.bankName} onChange={e => setEditGateway({ ...editGateway, bankName: e.target.value })} /></div>
                </>
              )}
              <div className="flex items-center justify-between"><Label>Test Mode</Label>
                <Select value={editGateway.testMode ? 'yes' : 'no'} onValueChange={v => setEditGateway({ ...editGateway, testMode: v === 'yes' })}>
                  <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function OnlineBookingModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'website-booking': return <WebsiteBooking />
    case 'mobile-booking': return <MobileBooking />
    case 'live-pricing': return <LivePricing />
    case 'online-payment': return <OnlinePayment />
    default: return <EmptyState title="Unknown Sub-Module" description={`Online Booking sub-module "${subModule}" not found.`} />
  }
}
