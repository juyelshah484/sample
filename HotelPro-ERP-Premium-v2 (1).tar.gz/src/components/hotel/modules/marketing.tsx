'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ PROMOTIONS ============
function Promotions() {
  const [items, setItems] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editItem, setEditItem] = useState<any>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: '', code: '', type: 'percentage', value: 0, minStay: 1, startDate: '', endDate: '', maxUsage: 100, currentUsage: 0, status: 'active', description: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setItems([
        { id: '1', name: 'Summer Special', code: 'SUMMER25', type: 'percentage', value: 25, minStay: 2, startDate: '2024-06-01', endDate: '2024-08-31', maxUsage: 500, currentUsage: 342, status: 'active', description: '25% off for summer bookings' },
        { id: '2', name: 'Weekend Getaway', code: 'WEEKEND15', type: 'percentage', value: 15, minStay: 1, startDate: '2024-01-01', endDate: '2024-12-31', maxUsage: 1000, currentUsage: 567, status: 'active', description: '15% off weekend stays' },
        { id: '3', name: 'Flat Discount', code: 'FLAT2000', type: 'flat', value: 2000, minStay: 3, startDate: '2024-11-01', endDate: '2024-11-30', maxUsage: 100, currentUsage: 45, status: 'active', description: 'BDT 2000 off for 3+ night stays' },
        { id: '4', name: 'Early Bird', code: 'EARLY20', type: 'percentage', value: 20, minStay: 1, startDate: '2024-10-01', endDate: '2024-10-31', maxUsage: 200, currentUsage: 200, status: 'inactive', description: 'Book 30 days ahead, get 20% off' },
        { id: '5', name: 'Loyalty Bonus', code: 'LOYAL10', type: 'percentage', value: 10, minStay: 1, startDate: '2024-01-01', endDate: '2024-12-31', maxUsage: 9999, currentUsage: 1205, status: 'active', description: 'Extra 10% for loyalty members' },
        { id: '6', name: 'New Year Deal', code: 'NYE2025', type: 'flat', value: 5000, minStay: 2, startDate: '2024-12-28', endDate: '2025-01-02', maxUsage: 50, currentUsage: 0, status: 'active', description: 'BDT 5000 off New Year packages' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const pageSize = 10
  const filtered = items.filter(i => !search || Object.values(i).some(v => String(v || '').toLowerCase().includes(search.toLowerCase())))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const openCreate = () => { setEditItem(null); setFormData({ name: '', code: '', type: 'percentage', value: 0, minStay: 1, startDate: '', endDate: '', maxUsage: 100, currentUsage: 0, status: 'active', description: '' }); setDialogOpen(true) }
  const openEdit = (item: any) => { setEditItem(item); setFormData({ ...item }); setDialogOpen(true) }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    if (editItem) {
      setItems(prev => prev.map(i => i.id === editItem.id ? { ...i, ...formData } : i))
      toast.success('Promotion updated')
    } else {
      setItems(prev => [...prev, { ...formData, id: Date.now().toString() }])
      toast.success('Promotion created')
    }
    setSaving(false); setDialogOpen(false)
  }

  const handleDelete = async () => {
    if (deleteId) { setItems(prev => prev.filter(i => i.id !== deleteId)); toast.success('Promotion deleted'); setDeleteId(null) }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Active Promotions" value={items.filter(i => i.status === 'active').length} subtitle="Currently running" color="emerald" />
        <KPICard title="Total Usage" value={items.reduce((s, i) => s + i.currentUsage, 0)} subtitle="All promotions" color="blue" />
        <KPICard title="Expired" value={items.filter(i => i.status === 'inactive').length} subtitle="No longer active" color="gray" />
        <KPICard title="Total Promotions" value={items.length} subtitle="All time" color="violet" />
      </div>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Promotions</h2><p className="text-muted-foreground">Manage hotel promotions and offers</p></div>
        <div className="flex gap-2">
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} /></div>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1" />New Promotion</Button>
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Type</TableHead><TableHead>Value</TableHead><TableHead>Min Stay</TableHead><TableHead>Period</TableHead><TableHead>Usage</TableHead><TableHead>Status</TableHead><TableHead className="w-10" /></TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell><code className="text-xs bg-muted px-1.5 py-0.5 rounded">{item.code}</code></TableCell>
                      <TableCell><Badge variant="outline">{item.type === 'percentage' ? '% Off' : 'Flat'}</Badge></TableCell>
                      <TableCell>{item.type === 'percentage' ? `${item.value}%` : formatCurrency(item.value)}</TableCell>
                      <TableCell>{item.minStay} night(s)</TableCell>
                      <TableCell className="text-xs">{formatDate(item.startDate)} - {formatDate(item.endDate)}</TableCell>
                      <TableCell>{item.currentUsage}/{item.maxUsage}</TableCell>
                      <TableCell><Badge className={statusColors[item.status] || ''}>{item.status}</Badge></TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild><Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(item)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => setDeleteId(item.id)}><Trash2 className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editItem ? 'Edit' : 'New'} Promotion</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
              <div><Label>Code</Label><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase() })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Discount Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="percentage">Percentage</SelectItem><SelectItem value="flat">Flat Amount</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Value {formData.type === 'percentage' ? '(%)' : '(BDT)'}</Label><Input type="number" value={formData.value} onChange={e => setFormData({ ...formData, value: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Min Stay (nights)</Label><Input type="number" value={formData.minStay} onChange={e => setFormData({ ...formData, minStay: Number(e.target.value) })} /></div>
              <div><Label>Max Usage</Label><Input type="number" value={formData.maxUsage} onChange={e => setFormData({ ...formData, maxUsage: Number(e.target.value) })} /></div>
            </div>
            <div><Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData({ ...formData, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="inactive">Inactive</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>Description</Label><Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}{editItem ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Confirm Delete</AlertDialogTitle><AlertDialogDescription>Delete this promotion?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ============ COUPONS ============
function Coupons() {
  const [coupons, setCoupons] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ code: '', type: 'percentage', value: 0, maxUsage: 50, expiresAt: '', singleUse: true, status: 'active' })

  useEffect(() => {
    setTimeout(() => {
      setCoupons([
        { id: '1', code: 'WELCOME10', type: 'percentage', value: 10, maxUsage: 1000, usedCount: 456, expiresAt: '2025-06-30', singleUse: true, status: 'active' },
        { id: '2', code: 'BDAY500', type: 'flat', value: 500, maxUsage: 200, usedCount: 89, expiresAt: '2024-12-31', singleUse: true, status: 'active' },
        { id: '3', code: 'REPEAT20', type: 'percentage', value: 20, maxUsage: 500, usedCount: 234, expiresAt: '2025-03-31', singleUse: false, status: 'active' },
        { id: '4', code: 'VIP3000', type: 'flat', value: 3000, maxUsage: 50, usedCount: 50, expiresAt: '2024-12-01', singleUse: true, status: 'inactive' },
        { id: '5', code: 'SUMMERFUN', type: 'percentage', value: 30, maxUsage: 300, usedCount: 12, expiresAt: '2025-08-31', singleUse: true, status: 'active' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const generateCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    let code = ''
    for (let i = 0; i < 8; i++) code += chars.charAt(Math.floor(Math.random() * chars.length))
    setFormData({ ...formData, code })
  }

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    setCoupons(prev => [...prev, { ...formData, id: Date.now().toString(), usedCount: 0 }])
    toast.success('Coupon created'); setSaving(false); setDialogOpen(false)
    setFormData({ code: '', type: 'percentage', value: 0, maxUsage: 50, expiresAt: '', singleUse: true, status: 'active' })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="Active Coupons" value={coupons.filter(c => c.status === 'active').length} subtitle="Currently valid" color="emerald" />
        <KPICard title="Total Redemptions" value={coupons.reduce((s, c) => s + c.usedCount, 0)} subtitle="All coupons" color="blue" />
        <KPICard title="Total Coupons" value={coupons.length} subtitle="Created" color="violet" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Coupons</h2><p className="text-muted-foreground">Manage discount coupons with code generation</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Coupon</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Code</TableHead><TableHead>Type</TableHead><TableHead>Value</TableHead><TableHead>Usage</TableHead><TableHead>Expires</TableHead><TableHead>Single Use</TableHead><TableHead>Status</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {coupons.map(c => (
                  <TableRow key={c.id}>
                    <TableCell><code className="text-sm font-mono bg-muted px-2 py-1 rounded">{c.code}</code></TableCell>
                    <TableCell><Badge variant="outline">{c.type === 'percentage' ? '% Off' : 'Flat'}</Badge></TableCell>
                    <TableCell>{c.type === 'percentage' ? `${c.value}%` : formatCurrency(c.value)}</TableCell>
                    <TableCell>{c.usedCount}/{c.maxUsage}</TableCell>
                    <TableCell>{formatDate(c.expiresAt)}</TableCell>
                    <TableCell>{c.singleUse ? 'Yes' : 'No'}</TableCell>
                    <TableCell><Badge className={statusColors[c.status] || ''}>{c.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>New Coupon</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Coupon Code</Label>
              <div className="flex gap-2"><Input value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase() })} /><Button variant="outline" onClick={generateCode}>Generate</Button></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="percentage">Percentage</SelectItem><SelectItem value="flat">Flat Amount</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Value</Label><Input type="number" value={formData.value} onChange={e => setFormData({ ...formData, value: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Max Usage</Label><Input type="number" value={formData.maxUsage} onChange={e => setFormData({ ...formData, maxUsage: Number(e.target.value) })} /></div>
              <div><Label>Expires</Label><Input type="date" value={formData.expiresAt} onChange={e => setFormData({ ...formData, expiresAt: e.target.value })} /></div>
            </div>
            <div><Label>Single Use Per Customer</Label>
              <Select value={formData.singleUse ? 'yes' : 'no'} onValueChange={v => setFormData({ ...formData, singleUse: v === 'yes' })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="yes">Yes</SelectItem><SelectItem value="no">No</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving || !formData.code}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ CAMPAIGNS ============
function Campaigns() {
  const [campaigns, setCampaigns] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({ name: '', type: 'email', channel: 'email', startDate: '', endDate: '', budget: 0, targetAudience: '', message: '', status: 'draft' })

  useEffect(() => {
    setTimeout(() => {
      setCampaigns([
        { id: '1', name: 'Winter Wonderland Package', type: 'seasonal', channel: 'email', startDate: '2024-12-01', endDate: '2025-01-31', budget: 50000, spent: 32000, targetAudience: 'All loyalty members', recipients: 2500, opens: 1850, clicks: 620, conversions: 89, status: 'active', message: 'Discover our exclusive winter packages...' },
        { id: '2', name: 'Eid Special Offer', type: 'seasonal', channel: 'sms', startDate: '2024-04-01', endDate: '2024-04-15', budget: 20000, spent: 18500, targetAudience: 'Gold+ members', recipients: 800, opens: 0, clicks: 340, conversions: 56, status: 'completed', message: 'Eid Mubarak! Special rates...' },
        { id: '3', name: 'Corporate Rate Push', type: 'promotional', channel: 'email', startDate: '2024-11-01', endDate: '2024-12-31', budget: 30000, spent: 15000, targetAudience: 'Corporate clients', recipients: 450, opens: 380, clicks: 145, conversions: 32, status: 'active', message: 'Exclusive corporate rates...' },
        { id: '4', name: 'New Year Blast', type: 'event', channel: 'multi', startDate: '2024-12-28', endDate: '2025-01-02', budget: 75000, spent: 0, targetAudience: 'All guests', recipients: 0, opens: 0, clicks: 0, conversions: 0, status: 'draft', message: 'Welcome 2025 with us!' },
      ]); setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setSaving(true); await new Promise(r => setTimeout(r, 300))
    setCampaigns(prev => [...prev, { ...formData, id: Date.now().toString(), spent: 0, recipients: 0, opens: 0, clicks: 0, conversions: 0 }])
    toast.success('Campaign created'); setSaving(false); setDialogOpen(false)
    setFormData({ name: '', type: 'seasonal', channel: 'email', startDate: '', endDate: '', budget: 0, targetAudience: '', message: '', status: 'draft' })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Active Campaigns" value={campaigns.filter(c => c.status === 'active').length} subtitle="Running now" color="emerald" />
        <KPICard title="Total Spent" value={formatCurrency(campaigns.reduce((s, c) => s + c.spent, 0))} subtitle="Budget used" color="amber" />
        <KPICard title="Total Conversions" value={campaigns.reduce((s, c) => s + c.conversions, 0)} subtitle="Bookings generated" color="blue" />
        <KPICard title="Avg. Open Rate" value="72%" subtitle="Email campaigns" color="violet" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Marketing Campaigns</h2><p className="text-muted-foreground">Create and track marketing campaigns</p></div>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Campaign</Button>
      </div>

      {loading ? <LoadingSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {campaigns.map(c => (
            <Card key={c.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{c.name}</CardTitle>
                    <CardDescription>{c.type} | {c.channel.toUpperCase()} | {c.targetAudience}</CardDescription>
                  </div>
                  <Badge className={statusColors[c.status] || ''}>{c.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><span className="text-muted-foreground">Period:</span><p>{formatDate(c.startDate)} - {formatDate(c.endDate)}</p></div>
                  <div><span className="text-muted-foreground">Budget:</span><p>{formatCurrency(c.budget)} (Spent: {formatCurrency(c.spent)})</p></div>
                  <div><span className="text-muted-foreground">Recipients:</span><p>{c.recipients.toLocaleString()}</p></div>
                  <div><span className="text-muted-foreground">Opens/Clicks:</span><p>{c.opens.toLocaleString()} / {c.clicks.toLocaleString()}</p></div>
                  <div className="col-span-2"><span className="text-muted-foreground">Conversions:</span><span className="font-medium ml-2">{c.conversions}</span></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Campaign</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Campaign Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="seasonal">Seasonal</SelectItem><SelectItem value="promotional">Promotional</SelectItem><SelectItem value="event">Event</SelectItem><SelectItem value="re_engagement">Re-engagement</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>Channel</Label>
                <Select value={formData.channel} onValueChange={v => setFormData({ ...formData, channel: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="email">Email</SelectItem><SelectItem value="sms">SMS</SelectItem><SelectItem value="multi">Multi-channel</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Start Date</Label><Input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} /></div>
              <div><Label>End Date</Label><Input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Budget (BDT)</Label><Input type="number" value={formData.budget} onChange={e => setFormData({ ...formData, budget: Number(e.target.value) })} /></div>
              <div><Label>Target Audience</Label><Input value={formData.targetAudience} onChange={e => setFormData({ ...formData, targetAudience: e.target.value })} /></div>
            </div>
            <div><Label>Message</Label><Textarea value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ EMAIL/SMS MARKETING ============
function EmailSmsMarketing() {
  const [templates, setTemplates] = useState<any[]>([])
  const [sendHistory, setSendHistory] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'templates' | 'history'>('templates')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', type: 'email', subject: '', body: '', status: 'active' })

  useEffect(() => {
    setTimeout(() => {
      setTemplates([
        { id: '1', name: 'Welcome Email', type: 'email', subject: 'Welcome to Grand Hotel!', body: 'Dear {name}, welcome to our loyalty program...', status: 'active', lastUsed: '2024-11-15' },
        { id: '2', name: 'Booking Confirmation', type: 'email', subject: 'Your Booking is Confirmed', body: 'Dear {name}, your booking {ref} is confirmed...', status: 'active', lastUsed: '2024-11-15' },
        { id: '3', name: 'Check-in Reminder', type: 'sms', subject: '', body: 'Hi {name}, your check-in at Grand Hotel is tomorrow. See you soon!', status: 'active', lastUsed: '2024-11-14' },
        { id: '4', name: 'Promo Offer', type: 'email', subject: 'Special Offer Just for You!', body: 'Dear {name}, enjoy {discount}% off your next stay...', status: 'active', lastUsed: '2024-11-10' },
        { id: '5', name: 'Checkout SMS', type: 'sms', subject: '', body: 'Thank you for staying with us! We hope to see you again.', status: 'active', lastUsed: '2024-11-15' },
      ])
      setSendHistory([
        { id: '1', template: 'Welcome Email', type: 'email', recipients: 45, sent: 45, delivered: 43, opened: 38, clicked: 12, date: '2024-11-15T10:00:00' },
        { id: '2', template: 'Check-in Reminder', type: 'sms', recipients: 120, sent: 120, delivered: 118, opened: 0, clicked: 0, date: '2024-11-14T16:00:00' },
        { id: '3', template: 'Promo Offer', type: 'email', recipients: 2500, sent: 2495, delivered: 2420, opened: 1850, clicked: 620, date: '2024-11-10T09:00:00' },
        { id: '4', template: 'Checkout SMS', type: 'sms', recipients: 85, sent: 85, delivered: 84, opened: 0, clicked: 0, date: '2024-11-09T12:00:00' },
      ])
      setLoading(false)
    }, 400)
  }, [])

  const handleSave = async () => {
    setTemplates(prev => [...prev, { ...formData, id: Date.now().toString(), lastUsed: '-' }])
    toast.success('Template created'); setDialogOpen(false)
    setFormData({ name: '', type: 'email', subject: '', body: '', status: 'active' })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <MiniStat label="Email Templates" value={templates.filter(t => t.type === 'email').length} color="bg-blue-50" />
        <MiniStat label="SMS Templates" value={templates.filter(t => t.type === 'sms').length} color="bg-emerald-50" />
        <MiniStat label="Emails Sent" value={sendHistory.filter(h => h.type === 'email').reduce((s, h) => s + h.sent, 0)} color="bg-amber-50" />
        <MiniStat label="SMS Sent" value={sendHistory.filter(h => h.type === 'sms').reduce((s, h) => s + h.sent, 0)} color="bg-violet-50" />
      </div>

      <div className="flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Email/SMS Marketing</h2><p className="text-muted-foreground">Manage templates and send history</p></div>
        <div className="flex gap-2">
          <Button variant={tab === 'templates' ? 'default' : 'outline'} size="sm" onClick={() => setTab('templates')}>Templates</Button>
          <Button variant={tab === 'history' ? 'default' : 'outline'} size="sm" onClick={() => setTab('history')}>Send History</Button>
          {tab === 'templates' && <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Template</Button>}
        </div>
      </div>

      {loading ? <LoadingSkeleton /> : tab === 'templates' ? (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead>Subject</TableHead><TableHead>Last Used</TableHead><TableHead>Status</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {templates.map(t => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">{t.name}</TableCell>
                    <TableCell><Badge variant="outline">{t.type.toUpperCase()}</Badge></TableCell>
                    <TableCell className="max-w-[250px] truncate">{t.subject || '-'}</TableCell>
                    <TableCell>{t.lastUsed ? formatDate(t.lastUsed) : '-'}</TableCell>
                    <TableCell><Badge className={statusColors[t.status] || ''}>{t.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Date</TableHead><TableHead>Template</TableHead><TableHead>Type</TableHead><TableHead>Recipients</TableHead><TableHead>Sent</TableHead><TableHead>Delivered</TableHead><TableHead>Opened</TableHead><TableHead>Clicked</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {sendHistory.map(h => (
                  <TableRow key={h.id}>
                    <TableCell>{formatDateTime(h.date)}</TableCell>
                    <TableCell className="font-medium">{h.template}</TableCell>
                    <TableCell><Badge variant="outline">{h.type.toUpperCase()}</Badge></TableCell>
                    <TableCell>{h.recipients}</TableCell>
                    <TableCell>{h.sent}</TableCell>
                    <TableCell>{h.delivered}</TableCell>
                    <TableCell>{h.opened || '-'}</TableCell>
                    <TableCell>{h.clicked || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Template</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Template Name</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} /></div>
              <div><Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({ ...formData, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="email">Email</SelectItem><SelectItem value="sms">SMS</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            {formData.type === 'email' && <div><Label>Subject</Label><Input value={formData.subject} onChange={e => setFormData({ ...formData, subject: e.target.value })} placeholder="Use {name} for personalization" /></div>}
            <div><Label>Body</Label><Textarea value={formData.body} onChange={e => setFormData({ ...formData, body: e.target.value })} rows={5} placeholder="Use {name}, {ref}, {discount} as placeholders" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ MAIN EXPORT ============
export default function MarketingModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'promotions': return <Promotions />
    case 'coupons': return <Coupons />
    case 'campaigns': return <Campaigns />
    case 'email-marketing': return <EmailSmsMarketing />
    default: return <EmptyState title="Unknown Sub-Module" description={`Marketing sub-module "${subModule}" not found.`} />
  }
}
