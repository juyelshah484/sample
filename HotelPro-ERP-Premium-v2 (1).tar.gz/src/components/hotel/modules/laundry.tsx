'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'

// ============ Types ============
interface LaundryOrderItem {
  id: string
  itemName: string
  quantity: number
  price: number
  service: string
}

interface LaundryOrder {
  id: string
  guestId: string
  hotelId: string | null
  type: string
  status: string
  totalAmount: number
  notes: string | null
  createdAt: string
  updatedAt: string
  guest?: { id: string; firstName: string; lastName: string }
  items?: LaundryOrderItem[]
}

interface LinenStockItem {
  id: string
  category: string
  name: string
  totalStock: number
  inUse: number
  inLaundry: number
  available: number
}

// ============ Guest Laundry ============
function GuestLaundry() {
  const [orders, setOrders] = useState<LaundryOrder[]>([])
  const [guests, setGuests] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [orderItems, setOrderItems] = useState([{ itemName: '', quantity: 1, service: 'wash', price: 0 }])
  const [form, setForm] = useState({ guestId: '', notes: '' })

  const servicePrices: Record<string, number> = {
    wash: 50, dry_clean: 150, iron: 30, express: 100,
  }

  const fetchData = async () => {
    setLoading(true)
    try {
      const [laundryRes, guestRes] = await Promise.all([apiFetch('/api/laundry'), apiFetch('/api/guests')])
      const allOrders: LaundryOrder[] = laundryRes.orders || []
      setOrders(allOrders.filter(o => o.type === 'guest'))
      setGuests(guestRes.guests || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const statusProgression: Record<string, string> = {
    collected: 'washing',
    washing: 'ironing',
    ironing: 'ready',
    ready: 'delivered',
  }

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      await apiFetch('/api/laundry', { method: 'PUT', body: JSON.stringify({ id: orderId, status: newStatus }) })
      toast.success(`Order marked as ${newStatus}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const addItem = () => setOrderItems(prev => [...prev, { itemName: '', quantity: 1, service: 'wash', price: 50 }])
  const removeItem = (idx: number) => setOrderItems(prev => prev.filter((_, i) => i !== idx))
  const updateItem = (idx: number, field: string, value: any) => {
    setOrderItems(prev => prev.map((item, i) => {
      if (i !== idx) return item
      const updated = { ...item, [field]: value }
      if (field === 'service') updated.price = servicePrices[value] || 50
      return updated
    }))
  }

  const handleCreate = async () => {
    if (!form.guestId) { toast.error('Please select a guest'); return }
    if (orderItems.some(i => !i.itemName)) { toast.error('Item name is required for all items'); return }
    setSaving(true)
    const totalAmount = orderItems.reduce((s, i) => s + i.price * i.quantity, 0)
    try {
      await apiFetch('/api/laundry', {
        method: 'POST',
        body: JSON.stringify({
          guestId: form.guestId,
          hotelId: 'default',
          type: 'guest',
          status: 'collected',
          totalAmount,
          notes: form.notes,
          items: orderItems.map(i => ({
            itemName: i.itemName,
            quantity: i.quantity,
            price: i.price,
            service: i.service,
          })),
        }),
      })
      toast.success('Laundry order created')
      setDialogOpen(false)
      setForm({ guestId: '', notes: '' })
      setOrderItems([{ itemName: '', quantity: 1, service: 'wash', price: 50 }])
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Guest Laundry</h2><p className="text-muted-foreground">Manage guest laundry orders</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Order</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <MiniStat label="Collected" value={orders.filter(o => o.status === 'collected').length} color="bg-amber-50" />
        <MiniStat label="Washing" value={orders.filter(o => o.status === 'washing').length} color="bg-blue-50" />
        <MiniStat label="Ironing" value={orders.filter(o => o.status === 'ironing').length} color="bg-violet-50" />
        <MiniStat label="Ready" value={orders.filter(o => o.status === 'ready').length} color="bg-emerald-50" />
        <MiniStat label="Delivered" value={orders.filter(o => o.status === 'delivered').length} color="bg-gray-50" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Guest</TableHead><TableHead>Items</TableHead><TableHead>Status</TableHead><TableHead>Total</TableHead><TableHead>Created</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No guest laundry orders</TableCell></TableRow>
              ) : orders.map(order => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.guest ? `${order.guest.firstName} ${order.guest.lastName}` : '-'}</TableCell>
                  <TableCell>{order.items?.length || 0} items</TableCell>
                  <TableCell><Badge className={statusColors[order.status] || ''}>{order.status}</Badge></TableCell>
                  <TableCell>{formatCurrency(order.totalAmount)}</TableCell>
                  <TableCell>{formatDateTime(order.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    {statusProgression[order.status] && (
                      <Button size="sm" variant="outline" onClick={() => handleStatusUpdate(order.id, statusProgression[order.status])}>
                        → {statusProgression[order.status]}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Laundry Order</DialogTitle><DialogDescription>Create a guest laundry order</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Guest *</Label><Select value={form.guestId} onValueChange={v => setForm({ ...form, guestId: v })}><SelectTrigger><SelectValue placeholder="Select guest" /></SelectTrigger><SelectContent>{guests.map((g: any) => <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName}</SelectItem>)}</SelectContent></Select></div>

            <div className="space-y-2">
              <div className="flex items-center justify-between"><Label>Items</Label><Button size="sm" variant="outline" onClick={addItem}><Plus className="h-3 w-3 mr-1" />Add</Button></div>
              {orderItems.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-end p-2 bg-muted rounded-lg">
                  <div className="flex-1"><Label className="text-xs">Item</Label><Input value={item.itemName} onChange={e => updateItem(idx, 'itemName', e.target.value)} placeholder="e.g. Shirt" /></div>
                  <div className="w-20"><Label className="text-xs">Qty</Label><Input type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', parseInt(e.target.value) || 1)} /></div>
                  <div className="w-32"><Label className="text-xs">Service</Label><Select value={item.service} onValueChange={v => updateItem(idx, 'service', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="wash">Wash ({formatCurrency(servicePrices.wash)})</SelectItem><SelectItem value="dry_clean">Dry Clean ({formatCurrency(servicePrices.dry_clean)})</SelectItem><SelectItem value="iron">Iron ({formatCurrency(servicePrices.iron)})</SelectItem><SelectItem value="express">Express ({formatCurrency(servicePrices.express)})</SelectItem></SelectContent></Select></div>
                  <div className="w-24"><Label className="text-xs">Price</Label><Input type="number" value={item.price} onChange={e => updateItem(idx, 'price', parseFloat(e.target.value) || 0)} /></div>
                  {orderItems.length > 1 && <Button size="sm" variant="ghost" className="text-red-500 h-8" onClick={() => removeItem(idx)}><X className="h-4 w-4" /></Button>}
                </div>
              ))}
              <div className="text-right font-bold">
                Total: {formatCurrency(orderItems.reduce((s, i) => s + i.price * i.quantity, 0))}
              </div>
            </div>

            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Special instructions" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create Order</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Internal Laundry ============
function InternalLaundry() {
  const [orders, setOrders] = useState<LaundryOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [orderItems, setOrderItems] = useState([{ itemName: '', quantity: 1, service: 'wash', price: 0 }])
  const [form, setForm] = useState({ department: '', notes: '' })

  const servicePrices: Record<string, number> = {
    wash: 30, dry_clean: 100, iron: 20, express: 60,
  }

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/laundry')
      const allOrders: LaundryOrder[] = res.orders || []
      setOrders(allOrders.filter(o => o.type === 'internal'))
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const statusProgression: Record<string, string> = {
    collected: 'washing',
    washing: 'ironing',
    ironing: 'ready',
    ready: 'delivered',
  }

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      await apiFetch('/api/laundry', { method: 'PUT', body: JSON.stringify({ id: orderId, status: newStatus }) })
      toast.success(`Order marked as ${newStatus}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const addItem = () => setOrderItems(prev => [...prev, { itemName: '', quantity: 1, service: 'wash', price: 30 }])
  const removeItem = (idx: number) => setOrderItems(prev => prev.filter((_, i) => i !== idx))
  const updateItem = (idx: number, field: string, value: any) => {
    setOrderItems(prev => prev.map((item, i) => {
      if (i !== idx) return item
      const updated = { ...item, [field]: value }
      if (field === 'service') updated.price = servicePrices[value] || 30
      return updated
    }))
  }

  const handleCreate = async () => {
    if (!form.department) { toast.error('Department is required'); return }
    if (orderItems.some(i => !i.itemName)) { toast.error('Item name is required'); return }
    setSaving(true)
    try {
      await apiFetch('/api/laundry', {
        method: 'POST',
        body: JSON.stringify({
          guestId: 'internal',
          hotelId: 'default',
          type: 'internal',
          status: 'collected',
          totalAmount: orderItems.reduce((s, i) => s + i.price * i.quantity, 0),
          notes: `Dept: ${form.department}. ${form.notes}`,
          items: orderItems.map(i => ({ itemName: i.itemName, quantity: i.quantity, price: i.price, service: i.service })),
        }),
      })
      toast.success('Internal laundry order created')
      setDialogOpen(false)
      setForm({ department: '', notes: '' })
      setOrderItems([{ itemName: '', quantity: 1, service: 'wash', price: 30 }])
      fetchData()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Internal Laundry</h2><p className="text-muted-foreground">Staff uniform and linen laundry</p></div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Order</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MiniStat label="Collected" value={orders.filter(o => o.status === 'collected').length} color="bg-amber-50" />
        <MiniStat label="In Process" value={orders.filter(o => ['washing', 'ironing'].includes(o.status)).length} color="bg-blue-50" />
        <MiniStat label="Ready" value={orders.filter(o => o.status === 'ready').length} color="bg-emerald-50" />
        <MiniStat label="Delivered" value={orders.filter(o => o.status === 'delivered').length} color="bg-gray-50" />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Department</TableHead><TableHead>Items</TableHead><TableHead>Status</TableHead><TableHead>Total</TableHead><TableHead>Created</TableHead><TableHead className="text-right">Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No internal laundry orders</TableCell></TableRow>
              ) : orders.map(order => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.notes?.replace('Dept: ', '').split('.')[0] || '-'}</TableCell>
                  <TableCell>{order.items?.length || 0} items</TableCell>
                  <TableCell><Badge className={statusColors[order.status] || ''}>{order.status}</Badge></TableCell>
                  <TableCell>{formatCurrency(order.totalAmount)}</TableCell>
                  <TableCell>{formatDateTime(order.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    {statusProgression[order.status] && (
                      <Button size="sm" variant="outline" onClick={() => handleStatusUpdate(order.id, statusProgression[order.status])}>
                        → {statusProgression[order.status]}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Internal Laundry Order</DialogTitle><DialogDescription>Create order for staff uniforms/linen</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Department *</Label><Select value={form.department} onValueChange={v => setForm({ ...form, department: v })}><SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger><SelectContent><SelectItem value="Housekeeping">Housekeeping</SelectItem><SelectItem value="Front Office">Front Office</SelectItem><SelectItem value="Kitchen">Kitchen</SelectItem><SelectItem value="F&B Service">F&B Service</SelectItem><SelectItem value="Maintenance">Maintenance</SelectItem><SelectItem value="Security">Security</SelectItem></SelectContent></Select></div>
            <div className="space-y-2">
              <div className="flex items-center justify-between"><Label>Items</Label><Button size="sm" variant="outline" onClick={addItem}><Plus className="h-3 w-3 mr-1" />Add</Button></div>
              {orderItems.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-end p-2 bg-muted rounded-lg">
                  <div className="flex-1"><Label className="text-xs">Item</Label><Input value={item.itemName} onChange={e => updateItem(idx, 'itemName', e.target.value)} placeholder="e.g. Uniform" /></div>
                  <div className="w-20"><Label className="text-xs">Qty</Label><Input type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', parseInt(e.target.value) || 1)} /></div>
                  <div className="w-32"><Label className="text-xs">Service</Label><Select value={item.service} onValueChange={v => updateItem(idx, 'service', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="wash">Wash ({formatCurrency(servicePrices.wash)})</SelectItem><SelectItem value="dry_clean">Dry Clean ({formatCurrency(servicePrices.dry_clean)})</SelectItem><SelectItem value="iron">Iron ({formatCurrency(servicePrices.iron)})</SelectItem><SelectItem value="express">Express ({formatCurrency(servicePrices.express)})</SelectItem></SelectContent></Select></div>
                  <div className="w-24"><Label className="text-xs">Price</Label><Input type="number" value={item.price} onChange={e => updateItem(idx, 'price', parseFloat(e.target.value) || 0)} /></div>
                  {orderItems.length > 1 && <Button size="sm" variant="ghost" className="text-red-500 h-8" onClick={() => removeItem(idx)}><X className="h-4 w-4" /></Button>}
                </div>
              ))}
              <div className="text-right font-bold">Total: {formatCurrency(orderItems.reduce((s, i) => s + i.price * i.quantity, 0))}</div>
            </div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Linen Stock ============
function LinenStock() {
  const [linenItems, setLinenItems] = useState<LinenStockItem[]>([
    { id: '1', category: 'Bed Sheet', name: 'Single Bed Sheet', totalStock: 200, inUse: 85, inLaundry: 30, available: 85 },
    { id: '2', category: 'Bed Sheet', name: 'Double Bed Sheet', totalStock: 150, inUse: 60, inLaundry: 20, available: 70 },
    { id: '3', category: 'Bed Sheet', name: 'King Bed Sheet', totalStock: 100, inUse: 40, inLaundry: 15, available: 45 },
    { id: '4', category: 'Towel', name: 'Bath Towel', totalStock: 300, inUse: 120, inLaundry: 50, available: 130 },
    { id: '5', category: 'Towel', name: 'Hand Towel', totalStock: 250, inUse: 90, inLaundry: 35, available: 125 },
    { id: '6', category: 'Towel', name: 'Face Towel', totalStock: 200, inUse: 70, inLaundry: 25, available: 105 },
    { id: '7', category: 'Pillow Case', name: 'Standard Pillow Case', totalStock: 400, inUse: 180, inLaundry: 60, available: 160 },
    { id: '8', category: 'Pillow Case', name: 'King Pillow Case', totalStock: 200, inUse: 80, inLaundry: 25, available: 95 },
    { id: '9', category: 'Blanket', name: 'Wool Blanket', totalStock: 100, inUse: 30, inLaundry: 10, available: 60 },
    { id: '10', category: 'Duvet', name: 'Duvet Cover', totalStock: 120, inUse: 45, inLaundry: 18, available: 57 },
    { id: '11', category: 'Duvet', name: 'Duvet Insert', totalStock: 100, inUse: 20, inLaundry: 5, available: 75 },
    { id: '12', category: 'Table Cloth', name: 'Dining Table Cloth', totalStock: 50, inUse: 20, inLaundry: 8, available: 22 },
  ])
  const [adjustDialogOpen, setAdjustDialogOpen] = useState(false)
  const [adjustForm, setAdjustForm] = useState({ itemId: '', field: 'totalStock', quantity: '', reason: '' })

  const categories = [...new Set(linenItems.map(i => i.category))]

  const handleAdjust = () => {
    const qty = parseInt(adjustForm.quantity) || 0
    if (!adjustForm.itemId || qty === 0) { toast.error('Select item and enter quantity'); return }
    setLinenItems(prev => prev.map(item => {
      if (item.id !== adjustForm.itemId) return item
      const updated = { ...item, [adjustForm.field]: item[adjustForm.field as keyof LinenStockItem] as number + qty }
      updated.available = updated.totalStock - updated.inUse - updated.inLaundry
      return updated
    }))
    toast.success('Stock adjusted')
    setAdjustDialogOpen(false)
    setAdjustForm({ itemId: '', field: 'totalStock', quantity: '', reason: '' })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Linen Stock</h2><p className="text-muted-foreground">Linen inventory and stock levels</p></div>
        <Button size="sm" onClick={() => setAdjustDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Adjust Stock</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Stock" value={linenItems.reduce((s, i) => s + i.totalStock, 0)} color="blue" />
        <KPICard title="In Use" value={linenItems.reduce((s, i) => s + i.inUse, 0)} color="amber" />
        <KPICard title="In Laundry" value={linenItems.reduce((s, i) => s + i.inLaundry, 0)} color="violet" />
        <KPICard title="Available" value={linenItems.reduce((s, i) => s + i.available, 0)} color="emerald" />
      </div>

      {categories.map(cat => {
        const catItems = linenItems.filter(i => i.category === cat)
        return (
          <Card key={cat}>
            <CardHeader className="pb-3"><CardTitle className="text-lg">{cat}</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Name</TableHead><TableHead>Total</TableHead><TableHead>In Use</TableHead><TableHead>In Laundry</TableHead><TableHead>Available</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {catItems.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.totalStock}</TableCell>
                      <TableCell><Badge className="bg-blue-100 text-blue-800">{item.inUse}</Badge></TableCell>
                      <TableCell><Badge className="bg-violet-100 text-violet-800">{item.inLaundry}</Badge></TableCell>
                      <TableCell>
                        <Badge className={item.available < 30 ? 'bg-red-100 text-red-800' : item.available < 60 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}>
                          {item.available}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )
      })}

      <Dialog open={adjustDialogOpen} onOpenChange={setAdjustDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Adjust Stock</DialogTitle><DialogDescription>Update linen stock levels</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Item</Label><Select value={adjustForm.itemId} onValueChange={v => setAdjustForm({ ...adjustForm, itemId: v })}><SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger><SelectContent>{linenItems.map(i => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Field</Label><Select value={adjustForm.field} onValueChange={v => setAdjustForm({ ...adjustForm, field: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="totalStock">Total Stock</SelectItem><SelectItem value="inUse">In Use</SelectItem><SelectItem value="inLaundry">In Laundry</SelectItem></SelectContent></Select></div>
            <div><Label>Adjustment (use negative for decrease)</Label><Input type="number" value={adjustForm.quantity} onChange={e => setAdjustForm({ ...adjustForm, quantity: e.target.value })} placeholder="e.g. +10 or -5" /></div>
            <div><Label>Reason</Label><Textarea value={adjustForm.reason} onChange={e => setAdjustForm({ ...adjustForm, reason: e.target.value })} placeholder="Reason for adjustment" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdjustDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAdjust}>Adjust</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ Laundry Status (Kanban) ============
function LaundryStatus() {
  const [orders, setOrders] = useState<LaundryOrder[]>([])
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/laundry')
      setOrders(res.orders || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      await apiFetch('/api/laundry', { method: 'PUT', body: JSON.stringify({ id: orderId, status: newStatus }) })
      toast.success(`Order moved to ${newStatus}`)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const statusColumns = [
    { key: 'collected', label: 'Collected', color: 'border-amber-300 bg-amber-50' },
    { key: 'washing', label: 'Washing', color: 'border-blue-300 bg-blue-50' },
    { key: 'ironing', label: 'Ironing', color: 'border-violet-300 bg-violet-50' },
    { key: 'ready', label: 'Ready', color: 'border-emerald-300 bg-emerald-50' },
    { key: 'delivered', label: 'Delivered', color: 'border-gray-300 bg-gray-50' },
  ]

  const statusProgression: Record<string, string> = {
    collected: 'washing',
    washing: 'ironing',
    ironing: 'ready',
    ready: 'delivered',
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Laundry Status Board</h2><p className="text-muted-foreground">Kanban-style view of all laundry orders</p></div>
        <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4 mr-1" />Refresh</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {statusColumns.map(col => {
          const colOrders = orders.filter(o => o.status === col.key)
          return (
            <div key={col.key} className={`rounded-lg border-2 ${col.color} min-h-[300px]`}>
              <div className="p-3 border-b border-current/10">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-sm">{col.label}</h3>
                  <Badge variant="outline" className="text-xs">{colOrders.length}</Badge>
                </div>
              </div>
              <div className="p-2 space-y-2 max-h-[60vh] overflow-y-auto">
                {colOrders.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">No orders</p>
                ) : colOrders.map(order => (
                  <Card key={order.id} className="bg-white shadow-sm">
                    <CardContent className="p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-muted-foreground">{order.type === 'guest' ? 'Guest' : order.type === 'internal' ? 'Internal' : 'Linen'}</span>
                        <Badge className={`text-[10px] ${statusColors[order.type] || ''}`}>{order.type}</Badge>
                      </div>
                      <p className="text-sm font-medium">{order.guest ? `${order.guest.firstName} ${order.guest.lastName}` : order.notes?.slice(0, 30) || 'Order'}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">{order.items?.length || 0} items</span>
                        <span className="text-sm font-bold">{formatCurrency(order.totalAmount)}</span>
                      </div>
                      <p className="text-[10px] text-muted-foreground">{formatDateTime(order.createdAt)}</p>
                      {statusProgression[order.status] && (
                        <Button size="sm" variant="outline" className="w-full text-xs h-7" onClick={() => handleStatusUpdate(order.id, statusProgression[order.status])}>
                          → {statusProgression[order.status]}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ============ Main Component ============
export default function LaundryModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'guest-laundry': return <GuestLaundry />
    case 'internal-laundry': return <InternalLaundry />
    case 'linen-stock': return <LinenStock />
    case 'laundry-status': return <LaundryStatus />
    default: return <EmptyState title="Unknown Sub-module" description={`Sub-module "${subModule}" not found`} />
  }
}
