'use client'
import React, { useState, useEffect } from 'react'
import {
  KPICard, MiniStat, Pagination, LoadingSkeleton, EmptyState, useCrud,
  formatCurrency, formatDate, formatDateTime, statusColors, COLORS, apiFetch, toast,
  Badge, Button, Input, Label, Textarea, Card, CardContent, CardHeader, CardTitle, CardDescription,
  Separator, Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  Plus, Edit, Trash2, Eye, MoreHorizontal, Search, RefreshCw, Loader2, X,
} from '@/components/hotel/shared'
import { CalendarCheck, UserCheck, Users, Star, DollarSign, BedDouble, Clock, Phone, Mail, CheckCircle2, XCircle, AlertTriangle, UserRound, ArrowDownRight, ArrowUpRight } from 'lucide-react'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'

// ============ TYPES ============
interface Guest { id: string; firstName: string; lastName: string; email?: string; phone?: string; nationality?: string; guestType: string }
interface Room { id: string; number: string; name?: string; price: number; status: string; roomType?: { name: string }; maxGuests: number }
interface ReservationRoom { id: string; roomId: string; rate: number; status: string; room: Room }
interface Reservation {
  id: string; confirmationCode: string; guestId: string; hotelId: string;
  bookingSource: string; status: string; checkInDate: string; checkOutDate: string;
  numberOfGuests: number; numberOfRooms: number; specialRequests?: string; notes?: string;
  totalAmount: number; paidAmount: number; discount: number; taxAmount: number;
  otaReference?: string; createdAt: string; updatedAt: string;
  guest: Guest; rooms: ReservationRoom[];
}

const STATUS_OPTIONS = ['confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show', 'waitlisted'] as const
const SOURCE_OPTIONS = ['direct', 'online', 'walk_in', 'corporate', 'group', 'tour', 'travel_agency', 'ota'] as const
const SOURCE_LABELS: Record<string, string> = {
  direct: 'Direct', online: 'Online', walk_in: 'Walk-in', corporate: 'Corporate',
  group: 'Group', tour: 'Tour', travel_agency: 'Travel Agency', ota: 'OTA'
}
const STATUS_LABELS: Record<string, string> = {
  confirmed: 'Confirmed', checked_in: 'Checked In', checked_out: 'Checked Out',
  cancelled: 'Cancelled', no_show: 'No Show', waitlisted: 'Waitlisted'
}

const defaultForm = (source?: string) => ({
  hotelId: '', guestId: '', checkInDate: new Date().toISOString().split('T')[0],
  checkOutDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
  bookingSource: source || 'direct', numberOfGuests: 1, specialRequests: '',
  rooms: [{ roomId: '', rate: 0 }] as { roomId: string; rate: number }[],
  discount: 0, notes: '',
})

// ============ RESERVATION TABLE ============
function ReservationTable({
  reservations, loading, onAction, page, totalPages, setPage, statusFilter, setStatusFilter
}: {
  reservations: Reservation[]; loading: boolean;
  onAction: (action: string, res: Reservation) => void;
  page: number; totalPages: number; setPage: (p: number) => void;
  statusFilter: string; setStatusFilter: (s: string) => void;
}) {
  const statusButtons = [
    { key: 'all', label: 'All' },
    { key: 'confirmed', label: 'Confirmed' },
    { key: 'checked_in', label: 'Checked In' },
    { key: 'checked_out', label: 'Checked Out' },
    { key: 'cancelled', label: 'Cancelled' },
  ]
  return (
    <>
      <div className="flex flex-wrap gap-2 mb-4">
        {statusButtons.map(s => (
          <Button key={s.key} variant={statusFilter === s.key ? 'default' : 'outline'} size="sm"
            onClick={() => setStatusFilter(s.key)}>
            {s.label}
          </Button>
        ))}
      </div>
      {loading ? <LoadingSkeleton /> : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Confirmation</TableHead>
                    <TableHead>Guest</TableHead>
                    <TableHead>Room</TableHead>
                    <TableHead>Check-in</TableHead>
                    <TableHead>Check-out</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reservations.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                        No reservations found
                      </TableCell>
                    </TableRow>
                  ) : reservations.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono font-medium">{r.confirmationCode}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className="text-xs">
                              {r.guest?.firstName?.[0]}{r.guest?.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <span>{r.guest?.firstName} {r.guest?.lastName}</span>
                        </div>
                      </TableCell>
                      <TableCell>{r.rooms?.map(rr => rr.room?.number).join(', ') || '-'}</TableCell>
                      <TableCell>{formatDate(r.checkInDate)}</TableCell>
                      <TableCell>{formatDate(r.checkOutDate)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">{SOURCE_LABELS[r.bookingSource] || r.bookingSource}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={statusColors[r.status] || 'bg-gray-100 text-gray-800'}>
                          {STATUS_LABELS[r.status] || r.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium">{formatCurrency(r.totalAmount)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm"><MoreHorizontal className="h-4 w-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onAction('view', r)}><Eye className="h-4 w-4 mr-2" />View Details</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onAction('edit', r)}><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                            {r.status === 'confirmed' && (
                              <DropdownMenuItem onClick={() => onAction('checkin', r)}><CheckCircle2 className="h-4 w-4 mr-2" />Check-in</DropdownMenuItem>
                            )}
                            {r.status === 'checked_in' && (
                              <DropdownMenuItem onClick={() => onAction('checkout', r)}><XCircle className="h-4 w-4 mr-2" />Check-out</DropdownMenuItem>
                            )}
                            {r.status !== 'cancelled' && r.status !== 'checked_out' && (
                              <DropdownMenuItem onClick={() => onAction('cancel', r)} className="text-red-600"><AlertTriangle className="h-4 w-4 mr-2" />Cancel</DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </>
  )
}

// ============ NEW RESERVATION DIALOG ============
function NewReservationDialog({
  open, onClose, onSave, defaultSource, guests, rooms, hotelId
}: {
  open: boolean; onClose: () => void; onSave: (data: any) => void;
  defaultSource?: string; guests: Guest[]; rooms: Room[]; hotelId: string;
}) {
  const [form, setForm] = useState(defaultForm(defaultSource))
  const [saving, setSaving] = useState(false)
  const [prevOpen, setPrevOpen] = useState(false)
  if (open !== prevOpen) {
    setPrevOpen(open)
    if (open) {
      setForm({ ...defaultForm(defaultSource), hotelId })
    }
  }

  const availableRooms = rooms.filter(r => r.status === 'available')
  const nights = Math.max(1, Math.ceil((new Date(form.checkOutDate).getTime() - new Date(form.checkInDate).getTime()) / 86400000))
  const totalAmount = form.rooms.reduce((sum, r) => sum + r.rate * nights, 0)

  const addRoom = () => setForm(f => ({ ...f, rooms: [...f.rooms, { roomId: '', rate: 0 }] }))
  const removeRoom = (idx: number) => setForm(f => ({ ...f, rooms: f.rooms.filter((_, i) => i !== idx) }))
  const updateRoom = (idx: number, field: string, value: any) => {
    setForm(f => {
      const rooms = [...f.rooms]
      rooms[idx] = { ...rooms[idx], [field]: value }
      if (field === 'roomId') {
        const room = availableRooms.find(r => r.id === value)
        if (room) rooms[idx].rate = room.price
      }
      return { ...f, rooms }
    })
  }

  const handleSave = async () => {
    if (!form.guestId) { toast.error('Please select a guest'); return }
    if (form.rooms.some(r => !r.roomId)) { toast.error('Please select all rooms'); return }
    if (new Date(form.checkOutDate) <= new Date(form.checkInDate)) { toast.error('Check-out must be after check-in'); return }
    setSaving(true)
    await onSave({ ...form, totalAmount })
    setSaving(false)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>New Reservation</DialogTitle>
          <DialogDescription>Create a new reservation for a guest.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Guest *</Label>
              <Select value={form.guestId} onValueChange={v => setForm(f => ({ ...f, guestId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select guest" /></SelectTrigger>
                <SelectContent>
                  {guests.map(g => (
                    <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName} {g.phone ? `(${g.phone})` : ''}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Booking Source</Label>
              <Select value={form.bookingSource} onValueChange={v => setForm(f => ({ ...f, bookingSource: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SOURCE_OPTIONS.map(s => <SelectItem key={s} value={s}>{SOURCE_LABELS[s]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Check-in Date *</Label>
              <Input type="date" value={form.checkInDate} onChange={e => setForm(f => ({ ...f, checkInDate: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Check-out Date *</Label>
              <Input type="date" value={form.checkOutDate} onChange={e => setForm(f => ({ ...f, checkOutDate: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Number of Guests</Label>
              <Input type="number" min={1} value={form.numberOfGuests} onChange={e => setForm(f => ({ ...f, numberOfGuests: parseInt(e.target.value) || 1 }))} />
            </div>
            <div className="space-y-2">
              <Label>Discount</Label>
              <Input type="number" min={0} value={form.discount} onChange={e => setForm(f => ({ ...f, discount: parseFloat(e.target.value) || 0 }))} />
            </div>
          </div>

          <Separator />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Rooms</Label>
              <Button type="button" variant="outline" size="sm" onClick={addRoom}><Plus className="h-4 w-4 mr-1" />Add Room</Button>
            </div>
            {form.rooms.map((room, idx) => (
              <div key={idx} className="flex gap-3 items-end">
                <div className="flex-1 space-y-1">
                  <Label className="text-xs">Room</Label>
                  <Select value={room.roomId} onValueChange={v => updateRoom(idx, 'roomId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                    <SelectContent>
                      {availableRooms.map(r => (
                        <SelectItem key={r.id} value={r.id}>
                          {r.number} - {r.roomType?.name || 'Room'} ({formatCurrency(r.price)}/night)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-28 space-y-1">
                  <Label className="text-xs">Rate/Night</Label>
                  <Input type="number" min={0} value={room.rate} onChange={e => updateRoom(idx, 'rate', parseFloat(e.target.value) || 0)} />
                </div>
                {form.rooms.length > 1 && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => removeRoom(idx)} className="text-red-500"><X className="h-4 w-4" /></Button>
                )}
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label>Special Requests</Label>
            <Textarea value={form.specialRequests} onChange={e => setForm(f => ({ ...f, specialRequests: e.target.value }))} rows={2} />
          </div>

          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <div className="flex justify-between text-sm"><span>Nights:</span><span className="font-medium">{nights}</span></div>
              <div className="flex justify-between text-sm"><span>Rooms:</span><span className="font-medium">{form.rooms.length}</span></div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold"><span>Total:</span><span>{formatCurrency(totalAmount)}</span></div>
            </CardContent>
          </Card>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Create Reservation</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============ VIEW RESERVATION DIALOG ============
function ViewReservationDialog({ reservation, open, onClose }: { reservation: Reservation | null; open: boolean; onClose: () => void }) {
  if (!reservation) return null
  const r = reservation
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Reservation Details</DialogTitle>
          <DialogDescription>{r.confirmationCode}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground">Guest:</span><p className="font-medium">{r.guest?.firstName} {r.guest?.lastName}</p></div>
            <div><span className="text-muted-foreground">Status:</span><p><Badge className={statusColors[r.status]}>{STATUS_LABELS[r.status]}</Badge></p></div>
            <div><span className="text-muted-foreground">Source:</span><p className="font-medium">{SOURCE_LABELS[r.bookingSource]}</p></div>
            <div><span className="text-muted-foreground">Guests:</span><p className="font-medium">{r.numberOfGuests}</p></div>
            <div><span className="text-muted-foreground">Check-in:</span><p className="font-medium">{formatDate(r.checkInDate)}</p></div>
            <div><span className="text-muted-foreground">Check-out:</span><p className="font-medium">{formatDate(r.checkOutDate)}</p></div>
          </div>
          <Separator />
          <div>
            <p className="text-sm text-muted-foreground mb-2">Room(s):</p>
            {r.rooms?.map((rr, i) => (
              <div key={i} className="flex justify-between text-sm py-1">
                <span>{rr.room?.number} - {rr.room?.roomType?.name}</span>
                <span>{formatCurrency(rr.rate)}/night</span>
              </div>
            ))}
          </div>
          <Separator />
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground">Total:</span><p className="font-semibold">{formatCurrency(r.totalAmount)}</p></div>
            <div><span className="text-muted-foreground">Paid:</span><p className="font-semibold text-emerald-600">{formatCurrency(r.paidAmount)}</p></div>
            <div><span className="text-muted-foreground">Tax:</span><p>{formatCurrency(r.taxAmount)}</p></div>
            <div><span className="text-muted-foreground">Discount:</span><p>{formatCurrency(r.discount)}</p></div>
          </div>
          {r.specialRequests && (
            <div><span className="text-sm text-muted-foreground">Special Requests:</span><p className="text-sm mt-1">{r.specialRequests}</p></div>
          )}
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Close</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============ CANCEL RESERVATION DIALOG ============
function CancelDialog({ open, onClose, onConfirm }: { open: boolean; onClose: () => void; onConfirm: (reason: string) => void }) {
  const [reason, setReason] = useState('')
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Cancel Reservation</DialogTitle>
          <DialogDescription>Are you sure you want to cancel this reservation? This action cannot be undone.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <Label>Cancellation Reason</Label>
          <Textarea value={reason} onChange={e => setReason(e.target.value)} placeholder="Enter reason for cancellation..." rows={3} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Keep Reservation</Button>
          <Button variant="destructive" onClick={() => onConfirm(reason)}>Cancel Reservation</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============ EDIT RESERVATION DIALOG ============
function EditReservationDialog({
  reservation, open, onClose, onSave, guests, rooms
}: {
  reservation: Reservation | null; open: boolean; onClose: () => void;
  onSave: (data: any) => void; guests: Guest[]; rooms: Room[];
}) {
  const [form, setForm] = useState<any>({})
  const [saving, setSaving] = useState(false)
  const [prevOpen, setPrevOpen] = useState(false)
  if (open !== prevOpen) {
    setPrevOpen(open)
    if (open && reservation) {
      setForm({
        id: reservation.id,
        guestId: reservation.guestId,
        bookingSource: reservation.bookingSource,
        checkInDate: reservation.checkInDate?.split('T')[0] || '',
        checkOutDate: reservation.checkOutDate?.split('T')[0] || '',
        numberOfGuests: reservation.numberOfGuests,
        specialRequests: reservation.specialRequests || '',
        notes: reservation.notes || '',
        discount: reservation.discount,
        rooms: reservation.rooms?.map((rr: any) => ({ roomId: rr.roomId, rate: rr.rate })) || [{ roomId: '', rate: 0 }],
      })
    }
  }

  const availableRooms = rooms.filter(r => r.status === 'available' || reservation?.rooms?.some(rr => rr.roomId === r.id))
  const nights = Math.max(1, Math.ceil((new Date(form.checkOutDate || Date.now()).getTime() - new Date(form.checkInDate || Date.now()).getTime()) / 86400000))
  const totalAmount = (form.rooms || []).reduce((sum: number, r: any) => sum + (r.rate || 0) * nights, 0)

  const addRoom = () => setForm((f: any) => ({ ...f, rooms: [...(f.rooms || []), { roomId: '', rate: 0 }] }))
  const removeRoom = (idx: number) => setForm((f: any) => ({ ...f, rooms: f.rooms.filter((_: any, i: number) => i !== idx) }))
  const updateRoom = (idx: number, field: string, value: any) => {
    setForm((f: any) => {
      const rooms = [...(f.rooms || [])]
      rooms[idx] = { ...rooms[idx], [field]: value }
      if (field === 'roomId') {
        const room = availableRooms.find(r => r.id === value)
        if (room) rooms[idx].rate = room.price
      }
      return { ...f, rooms }
    })
  }

  const handleSave = async () => {
    setSaving(true)
    await onSave({ ...form, totalAmount })
    setSaving(false)
  }

  if (!reservation) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Reservation - {reservation.confirmationCode}</DialogTitle>
          <DialogDescription>Update reservation details.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Guest</Label>
              <Select value={form.guestId} onValueChange={v => setForm((f: any) => ({ ...f, guestId: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {guests.map(g => <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Booking Source</Label>
              <Select value={form.bookingSource} onValueChange={v => setForm((f: any) => ({ ...f, bookingSource: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SOURCE_OPTIONS.map(s => <SelectItem key={s} value={s}>{SOURCE_LABELS[s]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Check-in</Label><Input type="date" value={form.checkInDate} onChange={e => setForm((f: any) => ({ ...f, checkInDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Check-out</Label><Input type="date" value={form.checkOutDate} onChange={e => setForm((f: any) => ({ ...f, checkOutDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Guests</Label><Input type="number" min={1} value={form.numberOfGuests} onChange={e => setForm((f: any) => ({ ...f, numberOfGuests: parseInt(e.target.value) || 1 }))} /></div>
            <div className="space-y-2"><Label>Discount</Label><Input type="number" min={0} value={form.discount} onChange={e => setForm((f: any) => ({ ...f, discount: parseFloat(e.target.value) || 0 }))} /></div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Rooms</Label>
              <Button type="button" variant="outline" size="sm" onClick={addRoom}><Plus className="h-4 w-4 mr-1" />Add Room</Button>
            </div>
            {(form.rooms || []).map((room: any, idx: number) => (
              <div key={idx} className="flex gap-3 items-end">
                <div className="flex-1 space-y-1">
                  <Select value={room.roomId} onValueChange={v => updateRoom(idx, 'roomId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                    <SelectContent>
                      {availableRooms.map(r => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-28"><Input type="number" min={0} value={room.rate} onChange={e => updateRoom(idx, 'rate', parseFloat(e.target.value) || 0)} /></div>
                {(form.rooms || []).length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => removeRoom(idx)} className="text-red-500"><X className="h-4 w-4" /></Button>}
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <Label>Special Requests</Label>
            <Textarea value={form.specialRequests} onChange={e => setForm((f: any) => ({ ...f, specialRequests: e.target.value }))} rows={2} />
          </div>
          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <div className="flex justify-between font-semibold"><span>Total ({nights} night(s)):</span><span>{formatCurrency(totalAmount)}</span></div>
            </CardContent>
          </Card>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Update</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============ ALL RESERVATIONS ============
function AllReservations({ defaultSource }: { defaultSource?: string }) {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [guests, setGuests] = useState<Guest[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [hotelId, setHotelId] = useState('')
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [page, setPage] = useState(1)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [viewRes, setViewRes] = useState<Reservation | null>(null)
  const [editRes, setEditRes] = useState<Reservation | null>(null)
  const [cancelRes, setCancelRes] = useState<Reservation | null>(null)
  const pageSize = 10

  const fetchData = async () => {
    setLoading(true)
    try {
      const [resData, guestData, roomData] = await Promise.all([
        apiFetch(defaultSource ? `/api/reservations?source=${defaultSource}` : '/api/reservations'),
        apiFetch('/api/guests'),
        apiFetch('/api/rooms?status=available'),
      ])
      setReservations(resData.reservations || [])
      setGuests(guestData.guests || [])
      setRooms(roomData.rooms || [])
      if (resData.reservations?.[0]?.hotelId) setHotelId(resData.reservations[0].hotelId)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [defaultSource])

  const filtered = reservations.filter(r => {
    const matchStatus = statusFilter === 'all' || r.status === statusFilter
    const matchSearch = !search ||
      r.confirmationCode.toLowerCase().includes(search.toLowerCase()) ||
      `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase())
    return matchStatus && matchSearch
  })
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  const stats = {
    total: reservations.length,
    confirmed: reservations.filter(r => r.status === 'confirmed').length,
    checkedIn: reservations.filter(r => r.status === 'checked_in').length,
    checkedOut: reservations.filter(r => r.status === 'checked_out').length,
    cancelled: reservations.filter(r => r.status === 'cancelled').length,
  }

  const handleAction = (action: string, res: Reservation) => {
    if (action === 'view') setViewRes(res)
    else if (action === 'edit') setEditRes(res)
    else if (action === 'checkin') handleCheckIn(res)
    else if (action === 'checkout') handleCheckOut(res)
    else if (action === 'cancel') setCancelRes(res)
  }

  const handleCheckIn = async (res: Reservation) => {
    try {
      await apiFetch('/api/reservations', { method: 'PUT', body: JSON.stringify({ id: res.id, status: 'checked_in' }) })
      toast.success('Guest checked in successfully')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleCheckOut = async (res: Reservation) => {
    try {
      await apiFetch('/api/reservations', { method: 'PUT', body: JSON.stringify({ id: res.id, status: 'checked_out' }) })
      toast.success('Guest checked out successfully')
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleCancel = async (reason: string) => {
    if (!cancelRes) return
    try {
      await apiFetch('/api/reservations', { method: 'PUT', body: JSON.stringify({ id: cancelRes.id, status: 'cancelled', notes: `Cancelled: ${reason}` }) })
      toast.success('Reservation cancelled')
      setCancelRes(null)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleCreate = async (data: any) => {
    try {
      await apiFetch('/api/reservations', { method: 'POST', body: JSON.stringify(data) })
      toast.success('Reservation created successfully')
      setDialogOpen(false)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const handleEditSave = async (data: any) => {
    try {
      await apiFetch('/api/reservations', { method: 'PUT', body: JSON.stringify(data) })
      toast.success('Reservation updated')
      setEditRes(null)
      fetchData()
    } catch (e: any) { toast.error(e.message) }
  }

  const title = defaultSource ? `${SOURCE_LABELS[defaultSource] || defaultSource} Bookings` : 'All Reservations'

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <p className="text-muted-foreground">Manage hotel reservations</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search guest or code..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
          </div>
          <Button variant="outline" size="sm" onClick={fetchData}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />New Reservation</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <KPICard title="Total" value={stats.total} icon={CalendarCheck} color="blue" />
        <KPICard title="Confirmed" value={stats.confirmed} icon={CheckCircle2} color="emerald" />
        <KPICard title="Checked In" value={stats.checkedIn} icon={UserCheck} color="violet" />
        <KPICard title="Cancelled" value={stats.cancelled} icon={XCircle} color="red" />
      </div>

      <ReservationTable
        reservations={paginated} loading={loading} onAction={handleAction}
        page={page} totalPages={totalPages} setPage={setPage}
        statusFilter={statusFilter} setStatusFilter={setStatusFilter}
      />

      <NewReservationDialog
        open={dialogOpen} onClose={() => setDialogOpen(false)} onSave={handleCreate}
        defaultSource={defaultSource} guests={guests} rooms={rooms} hotelId={hotelId}
      />
      <ViewReservationDialog reservation={viewRes} open={!!viewRes} onClose={() => setViewRes(null)} />
      <EditReservationDialog reservation={editRes} open={!!editRes} onClose={() => setEditRes(null)} onSave={handleEditSave} guests={guests} rooms={rooms} />
      <CancelDialog open={!!cancelRes} onClose={() => setCancelRes(null)} onConfirm={handleCancel} />
    </div>
  )
}

// ============ WALK-IN BOOKING ============
function WalkInBooking() {
  const [guests, setGuests] = useState<Guest[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [hotelId, setHotelId] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    hotelId: '', guestId: '', checkInDate: new Date().toISOString().split('T')[0],
    checkOutDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    numberOfGuests: 1, specialRequests: '', roomId: '', rate: 0,
  })

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const [guestData, roomData] = await Promise.all([
          apiFetch('/api/guests'), apiFetch('/api/rooms?status=available'),
        ])
        setGuests(guestData.guests || [])
        const available = (roomData.rooms || []).filter((r: Room) => r.status === 'available')
        setRooms(available)
        if (available[0]) setHotelId(available[0].hotelId || '')
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const nights = Math.max(1, Math.ceil((new Date(form.checkOutDate).getTime() - new Date(form.checkInDate).getTime()) / 86400000))
  const totalAmount = form.rate * nights

  const handleSave = async () => {
    if (!form.guestId || !form.roomId) { toast.error('Please select guest and room'); return }
    setSaving(true)
    try {
      await apiFetch('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({
          hotelId: form.hotelId || hotelId, guestId: form.guestId,
          checkInDate: form.checkInDate, checkOutDate: form.checkOutDate,
          bookingSource: 'walk_in', numberOfGuests: form.numberOfGuests,
          specialRequests: form.specialRequests,
          rooms: [{ roomId: form.roomId, rate: form.rate }],
        }),
      })
      toast.success('Walk-in booking created!')
      setForm(f => ({ ...f, guestId: '', roomId: '', rate: 0, specialRequests: '' }))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Walk-in Booking</h2><p className="text-muted-foreground">Quick booking for walk-in guests</p></div>
      <Card>
        <CardHeader><CardTitle>Quick Check-in</CardTitle><CardDescription>Fast booking - source auto-set to Walk-in</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Guest *</Label>
              <Select value={form.guestId} onValueChange={v => setForm(f => ({ ...f, guestId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select or search guest" /></SelectTrigger>
                <SelectContent>
                  {guests.map(g => <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Room *</Label>
              <Select value={form.roomId} onValueChange={v => {
                const room = rooms.find(r => r.id === v)
                setForm(f => ({ ...f, roomId: v, rate: room?.price || 0 }))
              }}>
                <SelectTrigger><SelectValue placeholder="Select available room" /></SelectTrigger>
                <SelectContent>
                  {rooms.map(r => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name} ({formatCurrency(r.price)})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Check-in</Label><Input type="date" value={form.checkInDate} onChange={e => setForm(f => ({ ...f, checkInDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Check-out</Label><Input type="date" value={form.checkOutDate} onChange={e => setForm(f => ({ ...f, checkOutDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Guests</Label><Input type="number" min={1} value={form.numberOfGuests} onChange={e => setForm(f => ({ ...f, numberOfGuests: parseInt(e.target.value) || 1 }))} /></div>
            <div className="space-y-2"><Label>Rate/Night</Label><Input type="number" value={form.rate} onChange={e => setForm(f => ({ ...f, rate: parseFloat(e.target.value) || 0 }))} /></div>
          </div>
          <div className="space-y-2"><Label>Special Requests</Label><Textarea value={form.specialRequests} onChange={e => setForm(f => ({ ...f, specialRequests: e.target.value }))} rows={2} /></div>
          <Card className="bg-muted/50">
            <CardContent className="p-4 flex justify-between font-semibold">
              <span>Total ({nights} night(s)):</span><span>{formatCurrency(totalAmount)}</span>
            </CardContent>
          </Card>
          <Button className="w-full" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <BedDouble className="h-4 w-4 mr-2" />}
            Complete Walk-in Booking
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ GROUP BOOKING ============
function GroupBooking() {
  const [guests, setGuests] = useState<Guest[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [hotelId, setHotelId] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    hotelId: '', guestId: '', groupName: '',
    checkInDate: new Date().toISOString().split('T')[0],
    checkOutDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    numberOfGuests: 10, specialRequests: '',
    rooms: [{ roomId: '', rate: 0 }] as { roomId: string; rate: number }[],
  })

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const [guestData, roomData] = await Promise.all([apiFetch('/api/guests'), apiFetch('/api/rooms?status=available')])
        setGuests(guestData.guests || [])
        const available = (roomData.rooms || []).filter((r: Room) => r.status === 'available')
        setRooms(available)
        if (available[0]) setHotelId(available[0].hotelId || '')
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const availableRooms = rooms
  const nights = Math.max(1, Math.ceil((new Date(form.checkOutDate).getTime() - new Date(form.checkInDate).getTime()) / 86400000))
  const totalAmount = form.rooms.reduce((sum, r) => sum + r.rate * nights, 0)

  const addRoom = () => setForm(f => ({ ...f, rooms: [...f.rooms, { roomId: '', rate: 0 }] }))
  const removeRoom = (idx: number) => setForm(f => ({ ...f, rooms: f.rooms.filter((_, i) => i !== idx) }))
  const updateRoom = (idx: number, field: string, value: any) => {
    setForm(f => {
      const rooms = [...f.rooms]
      rooms[idx] = { ...rooms[idx], [field]: value }
      if (field === 'roomId') {
        const room = availableRooms.find(r => r.id === value)
        if (room) rooms[idx].rate = room.price
      }
      return { ...f, rooms }
    })
  }

  const handleSave = async () => {
    if (!form.guestId || form.rooms.some(r => !r.roomId)) { toast.error('Please fill all required fields'); return }
    setSaving(true)
    try {
      await apiFetch('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({
          ...form, hotelId: form.hotelId || hotelId, bookingSource: 'group',
          notes: `Group: ${form.groupName}`, totalAmount,
        }),
      })
      toast.success('Group booking created!')
      setForm(f => ({ ...f, groupName: '', guestId: '', rooms: [{ roomId: '', rate: 0 }] }))
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Group Booking</h2><p className="text-muted-foreground">Book multiple rooms for a group</p></div>
      <Card>
        <CardHeader><CardTitle>Group Reservation</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Group Name *</Label>
              <Input value={form.groupName} onChange={e => setForm(f => ({ ...f, groupName: e.target.value }))} placeholder="Enter group name" />
            </div>
            <div className="space-y-2">
              <Label>Primary Contact Guest *</Label>
              <Select value={form.guestId} onValueChange={v => setForm(f => ({ ...f, guestId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select guest" /></SelectTrigger>
                <SelectContent>{guests.map(g => <SelectItem key={g.id} value={g.id}>{g.firstName} {g.lastName}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Check-in</Label><Input type="date" value={form.checkInDate} onChange={e => setForm(f => ({ ...f, checkInDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Check-out</Label><Input type="date" value={form.checkOutDate} onChange={e => setForm(f => ({ ...f, checkOutDate: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Total Guests</Label><Input type="number" min={1} value={form.numberOfGuests} onChange={e => setForm(f => ({ ...f, numberOfGuests: parseInt(e.target.value) || 1 }))} /></div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Rooms ({form.rooms.length})</Label>
              <Button type="button" variant="outline" size="sm" onClick={addRoom}><Plus className="h-4 w-4 mr-1" />Add Room</Button>
            </div>
            {form.rooms.map((room, idx) => (
              <div key={idx} className="flex gap-3 items-end">
                <div className="flex-1">
                  <Select value={room.roomId} onValueChange={v => updateRoom(idx, 'roomId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                    <SelectContent>{availableRooms.map(r => <SelectItem key={r.id} value={r.id}>{r.number} - {r.roomType?.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="w-28"><Input type="number" min={0} value={room.rate} onChange={e => updateRoom(idx, 'rate', parseFloat(e.target.value) || 0)} /></div>
                {form.rooms.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => removeRoom(idx)} className="text-red-500"><X className="h-4 w-4" /></Button>}
              </div>
            ))}
          </div>
          <div className="space-y-2"><Label>Special Requests</Label><Textarea value={form.specialRequests} onChange={e => setForm(f => ({ ...f, specialRequests: e.target.value }))} rows={2} /></div>
          <Card className="bg-muted/50">
            <CardContent className="p-4 flex justify-between font-semibold">
              <span>Total ({nights} nights, {form.rooms.length} rooms):</span><span>{formatCurrency(totalAmount)}</span>
            </CardContent>
          </Card>
          <Button className="w-full" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Users className="h-4 w-4 mr-2" />}
            Create Group Booking
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

// ============ WAITLIST ============
function Waitlist() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations?status=waitlisted')
        setReservations(data.reservations || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const totalPages = Math.max(1, Math.ceil(reservations.length / pageSize))
  const paginated = reservations.slice((page - 1) * pageSize, page * pageSize)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold">Waitlist</h2><p className="text-muted-foreground">Reservations on the waitlist</p></div>
      {paginated.length === 0 ? (
        <EmptyState title="No Waitlisted Reservations" description="All reservations have been assigned rooms." />
      ) : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Confirmation</TableHead><TableHead>Guest</TableHead><TableHead>Check-in</TableHead><TableHead>Check-out</TableHead><TableHead>Source</TableHead><TableHead>Guests</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono">{r.confirmationCode}</TableCell>
                      <TableCell>{r.guest?.firstName} {r.guest?.lastName}</TableCell>
                      <TableCell>{formatDate(r.checkInDate)}</TableCell>
                      <TableCell>{formatDate(r.checkOutDate)}</TableCell>
                      <TableCell><Badge variant="outline">{SOURCE_LABELS[r.bookingSource]}</Badge></TableCell>
                      <TableCell>{r.numberOfGuests}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============ CANCELLATIONS ============
function Cancellations() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    (async () => {
      setLoading(true)
      try {
        const data = await apiFetch('/api/reservations?status=cancelled')
        setReservations(data.reservations || [])
      } catch (e: any) { toast.error(e.message) }
      finally { setLoading(false) }
    })()
  }, [])

  const filtered = reservations.filter(r => !search || `${r.guest?.firstName} ${r.guest?.lastName}`.toLowerCase().includes(search.toLowerCase()) || r.confirmationCode.toLowerCase().includes(search.toLowerCase()))
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize)

  if (loading) return <LoadingSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div><h2 className="text-2xl font-bold">Cancellations</h2><p className="text-muted-foreground">Cancelled reservations</p></div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search..." className="pl-8 w-56" value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
        </div>
      </div>
      {paginated.length === 0 ? (
        <EmptyState title="No Cancelled Reservations" description="No cancellations found." />
      ) : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Confirmation</TableHead><TableHead>Guest</TableHead><TableHead>Room</TableHead>
                    <TableHead>Dates</TableHead><TableHead>Source</TableHead><TableHead>Amount</TableHead><TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginated.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono">{r.confirmationCode}</TableCell>
                      <TableCell>{r.guest?.firstName} {r.guest?.lastName}</TableCell>
                      <TableCell>{r.rooms?.map(rr => rr.room?.number).join(', ') || '-'}</TableCell>
                      <TableCell>{formatDate(r.checkInDate)} - {formatDate(r.checkOutDate)}</TableCell>
                      <TableCell><Badge variant="outline">{SOURCE_LABELS[r.bookingSource]}</Badge></TableCell>
                      <TableCell>{formatCurrency(r.totalAmount)}</TableCell>
                      <TableCell className="max-w-48 truncate text-muted-foreground">{r.notes || '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </>
      )}
    </div>
  )
}

// ============ MAIN COMPONENT ============
export default function ReservationModule({ subModule }: { subModule: string }) {
  switch (subModule) {
    case 'all-reservations': return <AllReservations />
    case 'direct-booking': return <AllReservations defaultSource="direct" />
    case 'online-booking': return <AllReservations defaultSource="online" />
    case 'walk-in': return <WalkInBooking />
    case 'corporate-booking': return <AllReservations defaultSource="corporate" />
    case 'group-booking': return <GroupBooking />
    case 'waitlist': return <Waitlist />
    case 'cancellation': return <Cancellations />
    default: return <AllReservations />
  }
}
