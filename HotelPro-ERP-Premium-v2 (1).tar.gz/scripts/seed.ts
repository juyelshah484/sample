import { PrismaClient } from '@prisma/client'
const db = new PrismaClient({ log: [] })

async function seed() {
  console.log('🌱 Seeding database...')

  // Create Hotel
  const hotel = await db.hotel.create({
    data: {
      name: 'Grand Palace Hotel & Resort',
      code: 'GPH',
      address: '45 Gulshan Avenue',
      city: 'Dhaka',
      country: 'Bangladesh',
      phone: '+880 2 8888-9999',
      email: 'info@grandpalacehotel.com',
      website: 'www.grandpalacehotel.com',
      starRating: 5,
      currency: 'BDT',
      taxRate: 15.0,
      vatRate: 5.0,
    }
  })

  // Create Building
  const mainBuilding = await db.building.create({
    data: {
      name: 'Main Building',
      code: 'MB',
      hotelId: hotel.id,
      floors: 8,
    }
  })

  // Create Floors
  const floors = []
  for (let i = 1; i <= 8; i++) {
    floors.push(await db.floor.create({
      data: {
        name: `Floor ${i}`,
        number: i,
        buildingId: mainBuilding.id,
        hotelId: hotel.id,
      }
    }))
  }

  // Create Room Types
  const roomTypes = [
    { name: 'Standard Single', code: 'SS', basePrice: 3500, maxOccupancy: 1 },
    { name: 'Standard Double', code: 'SD', basePrice: 4500, maxOccupancy: 2 },
    { name: 'Deluxe Double', code: 'DD', basePrice: 6500, maxOccupancy: 2 },
    { name: 'Deluxe Twin', code: 'DT', basePrice: 6500, maxOccupancy: 2 },
    { name: 'Executive Suite', code: 'ES', basePrice: 9500, maxOccupancy: 3 },
    { name: 'Premium Suite', code: 'PS', basePrice: 14000, maxOccupancy: 4 },
    { name: 'Presidential Suite', code: 'PRS', basePrice: 25000, maxOccupancy: 4 },
    { name: 'Family Room', code: 'FR', basePrice: 8000, maxOccupancy: 5 },
  ]

  const createdRoomTypes = []
  for (const rt of roomTypes) {
    createdRoomTypes.push(await db.roomType.create({
      data: { ...rt, hotelId: hotel.id }
    }))
  }

  // Create Room Categories
  const roomCategories = [
    { name: 'Standard', code: 'STD', hotelId: hotel.id },
    { name: 'Deluxe', code: 'DLX', hotelId: hotel.id },
    { name: 'Suite', code: 'STE', hotelId: hotel.id },
    { name: 'Family', code: 'FAM', hotelId: hotel.id },
  ]
  const createdCategories = []
  for (const rc of roomCategories) {
    createdCategories.push(await db.roomCategory.create({ data: rc }))
  }

  // Create Bed Types
  const bedTypes = [
    { name: 'Single', code: 'SGL', size: '90x190cm' },
    { name: 'Double', code: 'DBL', size: '140x190cm' },
    { name: 'King', code: 'KNG', size: '180x200cm' },
    { name: 'Twin', code: 'TWN', size: '2x90x190cm' },
    { name: 'Queen', code: 'QUN', size: '150x200cm' },
  ]
  const createdBedTypes = []
  for (const bt of bedTypes) {
    createdBedTypes.push(await db.bedType.create({ data: bt }))
  }

  // Create Room Views
  const roomViews = [
    { name: 'City View', code: 'CV' },
    { name: 'Pool View', code: 'PV' },
    { name: 'Garden View', code: 'GV' },
    { name: 'Sea View', code: 'SV' },
    { name: 'Lake View', code: 'LV' },
  ]
  const createdViews = []
  for (const rv of roomViews) {
    createdViews.push(await db.roomView.create({ data: rv }))
  }

  // Create Amenities
  const amenities = [
    { name: 'Air Conditioning', code: 'AC', category: 'comfort' },
    { name: 'WiFi', code: 'WIFI', category: 'technology' },
    { name: 'TV', code: 'TV', category: 'entertainment' },
    { name: 'Mini Bar', code: 'MB', category: 'food' },
    { name: 'Safe', code: 'SAFE', category: 'security' },
    { name: 'Hair Dryer', code: 'HD', category: 'bathroom' },
    { name: 'Tea/Coffee Maker', code: 'TCM', category: 'food' },
    { name: 'Bathtub', code: 'BT', category: 'bathroom' },
    { name: 'Balcony', code: 'BAL', category: 'outdoor' },
    { name: 'Room Service', code: 'RS', category: 'service' },
  ]
  const createdAmenities = []
  for (const a of amenities) {
    createdAmenities.push(await db.amenity.create({ data: a }))
  }

  // Create Rooms
  const roomStatuses = ['available', 'available', 'available', 'occupied', 'occupied', 'available', 'maintenance', 'available', 'occupied', 'available']
  const rooms = []
  let roomNumber = 101
  for (let floorIdx = 0; floorIdx < 4; floorIdx++) {
    const roomsOnFloor = floorIdx < 2 ? 10 : 8
    for (let roomIdx = 0; roomIdx < roomsOnFloor; roomIdx++) {
      const rtIdx = Math.min(floorIdx * 2 + (roomIdx < 4 ? 0 : roomIdx < 7 ? 1 : 2), createdRoomTypes.length - 1)
      const catIdx = Math.min(floorIdx, createdCategories.length - 1)
      const btIdx = roomIdx % createdBedTypes.length
      const rvIdx = (floorIdx + roomIdx) % createdViews.length
      
      rooms.push(await db.room.create({
        data: {
          number: String(roomNumber + roomIdx),
          hotelId: hotel.id,
          buildingId: mainBuilding.id,
          floorId: floors[floorIdx].id,
          roomTypeId: createdRoomTypes[rtIdx].id,
          roomCategoryId: createdCategories[catIdx].id,
          bedTypeId: createdBedTypes[btIdx].id,
          roomViewId: createdViews[rvIdx].id,
          status: roomStatuses[roomIdx % roomStatuses.length],
          smoking: roomIdx % 5 === 0,
          floor: floorIdx + 1,
          price: createdRoomTypes[rtIdx].basePrice,
          maxGuests: createdRoomTypes[rtIdx].maxOccupancy,
          name: `${createdRoomTypes[rtIdx].name} - ${roomNumber + roomIdx}`,
        }
      }))
    }
    roomNumber += 100
  }

  // Add amenities to rooms
  for (const room of rooms.slice(0, 20)) {
    for (const amenity of createdAmenities.slice(0, 6)) {
      await db.roomAmenity.create({
        data: {
          roomId: room.id,
          amenityId: amenity.id,
        }
      })
    }
  }

  // Create Guests
  const guestNames = [
    { firstName: 'Rahim', lastName: 'Uddin', nationality: 'Bangladeshi', phone: '+880 1711-234567' },
    { firstName: 'Karim', lastName: 'Hossain', nationality: 'Bangladeshi', phone: '+880 1812-345678' },
    { firstName: 'Fatima', lastName: 'Begum', nationality: 'Bangladeshi', phone: '+880 1913-456789' },
    { firstName: 'James', lastName: 'Wilson', nationality: 'British', phone: '+44 7700 900123' },
    { firstName: 'Sarah', lastName: 'Johnson', nationality: 'American', phone: '+1 555-0123' },
    { firstName: 'Ahmed', lastName: 'Al-Rashid', nationality: 'Saudi', phone: '+966 50 123 4567' },
    { firstName: 'Priya', lastName: 'Sharma', nationality: 'Indian', phone: '+91 98765 43210' },
    { firstName: 'Li', lastName: 'Wei', nationality: 'Chinese', phone: '+86 138 0013 8000' },
    { firstName: 'Takeshi', lastName: 'Yamamoto', nationality: 'Japanese', phone: '+81 90-1234-5678' },
    { firstName: 'Maria', lastName: 'Garcia', nationality: 'Spanish', phone: '+34 612 345 678' },
    { firstName: 'Hans', lastName: 'Mueller', nationality: 'German', phone: '+49 151 12345678' },
    { firstName: 'Pierre', lastName: 'Dubois', nationality: 'French', phone: '+33 6 12 34 56 78' },
    { firstName: 'Anna', lastName: 'Petrov', nationality: 'Russian', phone: '+7 916 123-45-67' },
    { firstName: 'David', lastName: 'Chen', nationality: 'Canadian', phone: '+1 416-555-0199' },
    { firstName: 'Siti', lastName: 'Rahayu', nationality: 'Indonesian', phone: '+62 812 3456 7890' },
  ]

  const createdGuests = []
  for (let i = 0; i < guestNames.length; i++) {
    const g = guestNames[i]
    const guestType = i === 3 || i === 4 ? 'corporate' : i === 5 ? 'vip' : i < 3 ? 'frequent' : 'individual'
    const tier = i === 5 ? 'platinum' : i < 3 ? 'gold' : i < 8 ? 'silver' : 'standard'
    
    createdGuests.push(await db.guest.create({
      data: {
        firstName: g.firstName,
        lastName: g.lastName,
        email: `${g.firstName.toLowerCase()}.${g.lastName.toLowerCase().replace(/[^a-z]/g, '')}@email.com`,
        phone: g.phone,
        nationality: g.nationality,
        hotelId: hotel.id,
        guestType,
        loyaltyTier: tier,
        loyaltyPoints: Math.floor(Math.random() * 5000) + 500,
        totalStays: Math.floor(Math.random() * 30) + 1,
        totalSpent: Math.floor(Math.random() * 500000) + 10000,
        lastStayDate: new Date(Date.now() - Math.random() * 30 * 86400000),
        city: g.nationality === 'Bangladeshi' ? 'Dhaka' : undefined,
        country: g.nationality === 'Bangladeshi' ? 'Bangladesh' : undefined,
      }
    }))
  }

  // Create Reservations
  const bookingSources = ['direct', 'online', 'walk_in', 'corporate', 'ota', 'travel_agency']
  const reservationStatuses = ['confirmed', 'checked_in', 'checked_out', 'confirmed', 'confirmed', 'cancelled']
  
  for (let i = 0; i < 25; i++) {
    const checkIn = new Date(Date.now() + (Math.random() - 0.5) * 30 * 86400000)
    const nights = Math.floor(Math.random() * 7) + 1
    const checkOut = new Date(checkIn.getTime() + nights * 86400000)
    const status = reservationStatuses[i % reservationStatuses.length]
    const guest = createdGuests[i % createdGuests.length]
    const room = rooms[i % rooms.length]
    const totalAmount = room.price * nights
    const paidAmount = status === 'checked_out' ? totalAmount : status === 'checked_in' ? totalAmount * 0.5 : totalAmount * 0.2

    const reservation = await db.reservation.create({
      data: {
        hotelId: hotel.id,
        guestId: guest.id,
        confirmationCode: `GPH${String(100000 + i).slice(1)}`,
        bookingSource: bookingSources[i % bookingSources.length],
        status,
        checkInDate: checkIn,
        checkOutDate: checkOut,
        numberOfGuests: Math.floor(Math.random() * 3) + 1,
        numberOfRooms: 1,
        totalAmount,
        paidAmount,
        discount: i % 5 === 0 ? totalAmount * 0.1 : 0,
        taxAmount: totalAmount * 0.15,
      }
    })

    await db.reservationRoom.create({
      data: {
        reservationId: reservation.id,
        roomId: room.id,
        checkInDate: checkIn,
        checkOutDate: checkOut,
        rate: room.price,
        status: status === 'checked_in' ? 'checked_in' : status === 'checked_out' ? 'checked_out' : 'reserved',
      }
    })

    // Create folio for checked-in or checked-out
    if (status === 'checked_in' || status === 'checked_out') {
      const folio = await db.folio.create({
        data: {
          reservationId: reservation.id,
          guestId: guest.id,
          hotelId: hotel.id,
          folioNumber: `FOL-${String(1000 + i)}`,
          status: status === 'checked_out' ? 'closed' : 'open',
          totalAmount,
          paidAmount,
          balance: totalAmount - paidAmount,
        }
      })

      // Add room charges to folio
      await db.folioItem.create({
        data: {
          folioId: folio.id,
          description: `Room ${room.number} - ${nights} nights`,
          category: 'room',
          amount: totalAmount,
          quantity: nights,
        }
      })
    }
  }

  // Create Restaurants
  const restaurantNames = [
    { name: 'The Grand Dining', code: 'TGD', type: 'restaurant', capacity: 80 },
    { name: 'Sky Lounge Bar', code: 'SLB', type: 'bar', capacity: 40 },
    { name: 'Café Bloom', code: 'CFB', type: 'cafe', capacity: 30 },
    { name: 'Room Service', code: 'RMS', type: 'room_service', capacity: 0 },
  ]

  for (const r of restaurantNames) {
    await db.restaurant.create({ data: { ...r, hotelId: hotel.id } })
  }

  // Create Employees
  const departments = ['Front Office', 'Housekeeping', 'F&B', 'Maintenance', 'Security', 'HR', 'Finance', 'IT']
  const positions = ['Manager', 'Supervisor', 'Staff', 'Attendant', 'Executive', 'Officer']
  
  for (let i = 0; i < 20; i++) {
    await db.employee.create({
      data: {
        hotelId: hotel.id,
        employeeId: `EMP-${String(100 + i)}`,
        firstName: ['Mohammad', 'Amina', 'Rafiq', 'Nasreen', 'Imran', 'Taslima', 'Farhan', 'Rumi', 'Sadia', 'Arif',
                     'Nadia', 'Omar', 'Lina', 'Kamal', 'Zara', 'Hasib', 'Rita', 'Sajid', 'Mita', 'Tariq'][i],
        lastName: ['Islam', 'Khan', 'Ahmed', 'Begum', 'Hossain', 'Akter', 'Rahman', 'Chowdhury', 'Sultana', 'Mia',
                   'Uddin', 'Sharif', 'Das', 'Malik', 'Haque', 'Siddiqui', 'Bhowmik', 'Talukder', 'Sen', 'Rana'][i],
        email: `employee${i + 1}@grandpalacehotel.com`,
        phone: `+880 17${String(10000000 + i)}`,
        department: departments[i % departments.length],
        position: positions[i % positions.length],
        joinDate: new Date(Date.now() - Math.random() * 365 * 3 * 86400000),
        salary: [25000, 35000, 20000, 18000, 45000, 30000, 40000, 22000, 50000, 28000,
                 32000, 38000, 21000, 42000, 27000, 48000, 19000, 36000, 23000, 55000][i],
        status: 'active',
      }
    })
  }

  // Create Suppliers
  const supplierNames = ['Fresh Foods BD', 'Linen Care Ltd', 'Tech Solutions', 'Royal Beverages', 'Cleaning Pro', 'Guest Amenities Co']
  for (let i = 0; i < supplierNames.length; i++) {
    await db.supplier.create({
      data: {
        hotelId: hotel.id,
        name: supplierNames[i],
        code: `SUP-${String(i + 1).padStart(3, '0')}`,
        contactPerson: `Contact ${i + 1}`,
        email: `supplier${i + 1}@company.com`,
        phone: `+880 2 ${String(10000000 + i)}`,
        balance: Math.floor(Math.random() * 100000),
      }
    })
  }

  // Create Banquet Halls
  const halls = [
    { name: 'Grand Ballroom', capacity: 500, pricePerHour: 50000 },
    { name: 'Crystal Hall', capacity: 200, pricePerHour: 30000 },
    { name: 'Emerald Conference', capacity: 100, pricePerHour: 15000 },
    { name: 'Ruby Meeting Room', capacity: 30, pricePerHour: 5000 },
  ]
  for (const h of halls) {
    await db.banquetHall.create({ data: { ...h, hotelId: hotel.id } })
  }

  // Create Spa Services
  const spaServices = [
    { name: 'Swedish Massage', category: 'massage', duration: 60, price: 5000 },
    { name: 'Deep Tissue Massage', category: 'massage', duration: 90, price: 7000 },
    { name: 'Aromatherapy', category: 'massage', duration: 60, price: 5500 },
    { name: 'Facial Treatment', category: 'beauty', duration: 45, price: 3500 },
    { name: 'Manicure & Pedicure', category: 'beauty', duration: 60, price: 2500 },
    { name: 'Hair Spa', category: 'beauty', duration: 45, price: 3000 },
    { name: 'Sauna Session', category: 'wellness', duration: 30, price: 2000 },
    { name: 'Gym Day Pass', category: 'gym', duration: 120, price: 1500 },
    { name: 'Swimming Pool Access', category: 'pool', duration: 120, price: 1000 },
    { name: 'Wellness Package', category: 'wellness', duration: 180, price: 12000 },
  ]
  for (const s of spaServices) {
    await db.spaService.create({ data: { ...s, hotelId: hotel.id } })
  }

  // Create System User
  await db.systemUser.create({
    data: {
      username: 'admin',
      email: 'admin@grandpalacehotel.com',
      name: 'System Administrator',
      password: 'admin123',
      role: 'super_admin',
      hotelId: hotel.id,
    }
  })

  // Create Accounts
  const accountTypes = [
    { code: '1000', name: 'Cash', type: 'asset' },
    { code: '1100', name: 'Bank', type: 'asset' },
    { code: '1200', name: 'Accounts Receivable', type: 'asset' },
    { code: '1300', name: 'Inventory', type: 'asset' },
    { code: '1400', name: 'Fixed Assets', type: 'asset' },
    { code: '2000', name: 'Accounts Payable', type: 'liability' },
    { code: '2100', name: 'Tax Payable', type: 'liability' },
    { code: '2200', name: 'Advance Deposits', type: 'liability' },
    { code: '3000', name: 'Owner Equity', type: 'equity' },
    { code: '4000', name: 'Room Revenue', type: 'income' },
    { code: '4100', name: 'F&B Revenue', type: 'income' },
    { code: '4200', name: 'Spa Revenue', type: 'income' },
    { code: '4300', name: 'Banquet Revenue', type: 'income' },
    { code: '4400', name: 'Other Revenue', type: 'income' },
    { code: '5000', name: 'Payroll Expense', type: 'expense' },
    { code: '5100', name: 'Utilities Expense', type: 'expense' },
    { code: '5200', name: 'Supplies Expense', type: 'expense' },
    { code: '5300', name: 'Maintenance Expense', type: 'expense' },
    { code: '5400', name: 'Marketing Expense', type: 'expense' },
  ]
  for (const a of accountTypes) {
    await db.account.create({
      data: { ...a, hotelId: hotel.id }
    })
  }

  // Create some housekeeping tasks
  const hkStatuses = ['pending', 'in_progress', 'completed', 'pending']
  const hkTypes = ['cleaning', 'inspection', 'deep_clean', 'cleaning']
  for (let i = 0; i < 15; i++) {
    const room = rooms[i % rooms.length]
    await db.housekeepingTask.create({
      data: {
        roomId: room.id,
        type: hkTypes[i % hkTypes.length],
        status: hkStatuses[i % hkStatuses.length],
        priority: i % 5 === 0 ? 'urgent' : i % 3 === 0 ? 'high' : 'normal',
      }
    })
  }

  // Create notifications
  const notifTypes = ['booking', 'checkin', 'checkout', 'payment', 'maintenance', 'housekeeping']
  const notifTitles = [
    'New Reservation Received',
    'Guest Check-in Reminder',
    'Guest Check-out Today',
    'Payment Received',
    'Maintenance Request',
    'Room Cleaning Required',
  ]
  const notifMessages = [
    'A new reservation has been received from Booking.com',
    'Guest Mr. Rahim Uddin is expected to check in today',
    'Guest in Room 204 is scheduled for check-out today',
    'Payment of BDT 15,000 received via bKash',
    'AC maintenance required in Room 305',
    'Room 102 needs immediate cleaning after check-out',
  ]
  for (let i = 0; i < 10; i++) {
    await db.notification.create({
      data: {
        hotelId: hotel.id,
        type: notifTypes[i % notifTypes.length],
        title: notifTitles[i % notifTitles.length],
        message: notifMessages[i % notifMessages.length],
        isRead: i > 3,
        channel: 'in_app',
      }
    })
  }

  // Create promotions
  const promos = [
    { name: 'Summer Special', code: 'SUMMER25', type: 'discount', value: 25, valueType: 'percentage', startDate: new Date(), endDate: new Date(Date.now() + 30 * 86400000) },
    { name: 'Corporate Rate', code: 'CORP15', type: 'corporate', value: 15, valueType: 'percentage', startDate: new Date(), endDate: new Date(Date.now() + 90 * 86400000) },
    { name: 'Weekend Getaway', code: 'WEEKEND', type: 'package', value: 1000, valueType: 'fixed', startDate: new Date(), endDate: new Date(Date.now() + 60 * 86400000) },
  ]
  for (const p of promos) {
    await db.promotion.create({
      data: { ...p, hotelId: hotel.id }
    })
  }

  console.log('✅ Seeding complete!')
  console.log(`   Hotel: ${hotel.name}`)
  console.log(`   Rooms: ${rooms.length}`)
  console.log(`   Guests: ${createdGuests.length}`)
}

seed()
  .catch(console.error)
  .finally(() => db.$disconnect())
